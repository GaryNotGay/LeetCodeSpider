
# 新手上路


## 前言
# 前言
现在 Vue.js、React 库及生态组成的框架，在脚手架搭建的过程中一些 Webpack ( Vue.js 3.0 开始使用 Vite ) 配置都已经内置，因此我们对 Webpack 的使用，常常停留在配置出入口、应用 Loader、插件等，很少深入配置和工具的原理。

虽然网上相关的文章比较多，但过于碎片化，读者难以形成系统的知识框架。

本书会带着你从零开始探索 Webpack 核心概念，从配置、优化到深入原理，系统性地认识 Webpack。

本测一共包含四块内容：新手上路、核心概念、 Webpack 环境配置、优化（只包含两块）。功能偏基础更适合一些新手小白学习，如果是有一些 Webpack 经验的也可以看下核心部分，这些部分除了一些配置用法外，还会穿插原理性概念。
<br>
# 声明

本文章的一些概念性内容参考官网，代码及原理等内容为原创。

## Hello World
#  webpack简介
## 简介
本质上，webpack 是一个用于现代 JavaScript 应用程序的 静态模块打包工具。当 webpack 处理应用程序时，它会在内部从一个或多个入口点构建一个 依赖图(dependency graph)，然后将你项目中所需的每一个模块组合成一个或多个 bundles，它们均为静态资源，用于展示你的内容。

webpack的核心概念为以下模块，后续会对以下概念针对性输出文章。
- 入口（entry）
- 输出（output）
- loader
- 插件（plugin）
<br>
## 安装
webpack 对操作系统没有要求，使用 Windows、Mac、Linux 操作系统均可，它唯一的依赖是 Node.js，所以使用 webpack 前需要先安装 Node.js，安装地址为 [Nodejs]](http://nodejs.cn/download/) 推荐安装TLS（长期维护）版本。node 安装完成后，在命令行输入 node -v，可显示版本号即安装成功。
接下来，我们需要使用 Node.js 的包管理器 npm 来安装 webpack ，安装模块的方式有两种：一种是全局安装，一种是本地安装，此处我们选择本地安装，主要有以下两点原因：

1. 如果采用全局安装，那在与他人协作时，由于每个人的 webpack 版本不同，可能导致打包出的内容不一致
2. 通常会通过运行一个或多个 npm scripts 以在本地 node_modules 目录中查找安装的 webpack，来运行 webpack，所以在这种情况下可能导致本地全局都有，容易造成混淆
```
"scripts": {
    "build": "webpack"
}
```
基于以上两点，我们选择在项目内安装，首先新建一个工程目录，并执行 npm 的初始化命令

``` javascript
 mkdir webpack_init && cd webpack_init
 npm init
```

命令行输入项目的基本信息，如：名称、版本、描述、仓库地址等信息。成功后工程目录中会出现一个 package.json 文件。
接下来输入安装webpack的命令：
``` javascript
 npm install webpack webpack-cli --save-dev
```
webpack v4+ 版本都需要手动安装 webpack-cli，webpack-cli 提供了许多命令用于在命令行中运行 webpack。具体包含命令可查看文档[webpack-cli]](https://webpack.docschina.org/api/cli/) 检查安装是否成功执行 webpack -v ， webpack-cli -v ，显示对应版本则安装成功

<br>
## 打包第一个应用
在 webpack_init 文件夹下添加 index.html、src 文件夹下添加 index.js、hello.js 文件

index.html
``` javascript
<!doctype html>
<html>
  <head>
    <title>demo</title>
  </head>
  <body>
    <script src="./dist/main.js"></script>
  </body>
</html>
```

src/index.js
``` javascript
import helloWorld from './hello.js';

function component() {
  const element = document.createElement('div'); 
  element.innerHTML = helloWorld();
  return element;
}

document.body.appendChild(component());
```

src/hello.js
``` javascript
export default function() {
    return 'hello world!!!'
}
```

在控制台输入打包命令 npx webpack，
``` javascript
npx webpack
```
因为 npm 会从全局模块中找 webpack ，但是我并非全局安装，而是项目本地安装，所以报错。所以需要 npx 命令运行命令。npx 会先找当前目录下的 node_modules/.bin 目录下的二进制可执行文件，如果当前目录下没有 npx 会在 PATH 目录下继续寻找，如果没有会自动下载安装 webpack。此时，第一步手动安装 npm install webpack --save-dev 可省略。执行命令成功后会在项目中增加一个 dist 文件，文件中有一个打包后的 main.js 文件。
![2.png](https://pic.leetcode-cn.com/1655453743-XEjonp-2.png)

此时我们在浏览器中打开 index.html 文件，在页面中看到 hello world!!!
![1.png](https://pic.leetcode-cn.com/1655453821-swEKUQ-1.png)

在上面的命令中，我们采用了 webpack 的默认设置，我们也可以在命令行中指定入口文件、输出文件、打包模式等信息

``` javascript
npx webpack --entry=./src/index.js --output-filename=bundle.js --mode=development
```
删除 webpack 默认配置打包的内容，重新执行带配置的命令，打包后在 dist 目录下生成了 bundle.js 文件，将 index.html 中引入 js 文件地址 main.js 改为 bundle.js，在浏览器打开 index.html 发现控制台再一次输出了 hello world!!!。
<br>
## 使用 npm scripts
从上面的命令行配置打包例子来看，每次打包都需要在命令行输入冗长的命令，这样做会很耗时和容易出错，为了使命令更加简洁，可以在 package.json 文件中的"scripts"对象下添加一个打包命令脚本 build。
scripts 是 npm 提供的脚本命令功能，所以在这里我们可以直接使用 webpack 命令取代之前的 npx webpack。

``` javascript
"scripts": {
  "build": "webpack"
}
```
在控制台输入npm命令，打包成功
![3.png](https://pic.leetcode-cn.com/1655453846-cPODUe-3.png)
```
npm run build
```
<br>
## 使用配置文件

在 webpack4 中，可以无需配置采用默认方式打包，直接在控制台输入 npx webpack 即可打包，然后大多数项目需要很复杂的设置，如项目分包、压缩、懒加载等，所以大多数情况下还是需要一个配置文件，webpack 默认加载的配置文件为 webpack.config.js，也可以指定 webpack 配置文件，需要命令行指定。
<br>
### webpack.config.js
在项目 webpack_init 中新建一个 webpack.config.js 文件

webpack.config.js
```
const path = require('path');

module.exports = {
  entry: './src/index.js',
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, 'dist')
  }
};
```
上面通过 module.exports 导出了一个对象，将之前命令行中输入的 key-value 形式的参数放在这个对象中。
这个对象包含连个属性，entry 为项目入口文件，output 为打包出口文件，其中 filename 为打包文件名称，path 为文件打包路径。通过调用 node.js 的path模块，将 __dirname(node.js内置全局变量，__dirname 为当前文件所在目录的绝对路径)与输出路径连接起来，得到了最终资源输出路径。

现在我们去掉 package.json 中 build 后面的参数去掉，只保留 "build": "webpack"，然后在控制台输入 npm run build，打包成功了
![4.png](https://pic.leetcode-cn.com/1655453847-kbCvea-4.png)
<br>
### 使用不同的配置文件

出于某种原因，需要根据特定情况使用不同的配置文件，则可以通过在命令行中使用 --config 标志修改
删除项目中的 webpack-config.js，新建一个 webpack-config-dev.js，内容和 webpack-config.js 一致。在命令行输入npm run build --config webpack.config.dev.js 或者在 package.json 的 scripts 中增加配置
```
  "scripts": {
    "build": "webpack --config webpack.config.dev.js"
  },
```
执行打包命令后。打包结果如下
![5.png](https://pic.leetcode-cn.com/1655453849-gYWreG-5.png)
<br>
# 总结
在上面我们介绍了
- webpack 的作用及包含核心模块
- 如何从零安装一个 webpack 运行环境
- 打包第一个 webpack 项目
- 告别命令行，通过配置文件打包 webpack
  
下一节我们将介绍下 webpack 的配置文件，包含的参数及作用。


# 核心概念-入口


## 资源处理流程
# 资源处理流程

借用 webpack 官网对 webpack 的描述： webpack 是一个现代 JavaScript 应用程序的静态模块打包工具。当 webpack 处理应用程序时，它会在内部构建一个 依赖图(dependency graph)，此依赖图会映射项目所需的每个模块，并生成一个或多个 bundle
<br>
## 什么是bundle
代码分离是 webpack 的特性之一，使用 entry 配置入口起点，会将代码分成源代码和分发代码
其中源代码是开发编辑的代码，分发代码是经过 webpack 构建，可能经过转义、压缩或优化后的代码，这些代码存放于 bundle 中，可以被浏览器等环境直接运行
<br>

## 什么是dependency graph
![6.png](https://pic.leetcode-cn.com/1655453942-GhafnS-6.png)

看了上面的内容，其实我们还是不清楚 webpack 到底做了哪些事情使浏览器不支持的语法变得可以执行，而去查看源码，会发现源码中代码对我们不是特别友好，经常左跳右跳无法持续跟踪，所以针对 webpack 打包流程，总结了下面的一个简版打包代码，让我们能大体看清 webpack 做了哪些操作，以下只是简版  demo，没有强行靠近 webpack 打包结果，让我们更能清晰的梳理流程。

<br>
## 打包步骤总结
1.  我们工程的依赖路径 index.js -> hello.js -> message.js
2. 根据 webpack.config.js 中定义的 entry 解析入口（index.js）文件，找到他的依赖
3. 递归的构建依赖关系图
4. 将所有内容打包到 webpack.config.js 定义的 output 文件

在整理打包内容之前，我们先来看下我们现在项目的结构，项目名称为 webpack_demo，其中包含 webpack.config.js，package.json，dist/main.js，src/index.js，src/hello.js，src/message.js，src/bundler.js，src/complier.js。

webpack.config.js 定义对象，导出项目入口出口文件
``` javascript
const path = require('path')

module.exports = {
    entry: './src/index.js',
    output: {
        path: path.resolve(__dirname, './dist'),
        filename: 'main.js'
    }
}
```

src/index.js 代码中导入 hello.js方法并执行

``` javascript
import hello from './hello.js'
console.log(hello())
```

src/hello.js 代码中导入 message.js中的message参数

``` javascript
import { message } from './message.js'
export default function() {
    return 'hello ' + message;
}
```
src/message.js 中定义了一个message变量

``` javascript
export const message = 'world!!!'
```

上面的代码层层引用下来，可以在控制台输出 ‘hello world!!!’，就代表打包成功了。

上面的环境已经定义完成，接下来让我们按照步骤完成打包操作：
1. 在src/complier.js文件中创建complier构造函数，在构造函数中获取webpack.config.js中定义的入口出口参数
``` javascript
module.exports = class Complier {
    constructor(options) {
      const { entry, output } = options
      this.entry = entry
      console.log(options)
      this.output = output
    }
}
```
2. 在 src/bundler.js 文件中引入 webpack.config.js 文件，创建 Complier 的实例化对象并传入 options
``` javascript
const complier = require('./complier')
const options = require('../webpack.config')
new complier(options)
```
在命令行执行 node src/bundler.js 后，在控制台会打印出 options 内容
![12.png](https://pic.leetcode-cn.com/1655453942-qDwVoX-12.png)

3. 拿到配置参数后，开始根据入口文件解析文件内容，解析单流程整体为：
   
   1. 根据入口文件名称通过 nodejs 提供的方法 fs.readFileSync 读取到文件内容
   2. 使用 @babel/parser 将文件内容转换成ast语法树
   3. ast 语法树中 node 节点中包含了文件依赖的文件名称，使用 @babel/traverse 方法提取出依赖的文件名称并存储到一个数组中
   4. 通过 @babel/core 中的 babel.transformFromAst 方法将 ast 转换成目标浏览器可执行的代码
   5. 将上述获取的参数返回个对象，对象包含文件名，依赖数组，文件可执行代码，这个对象即为一个依赖图谱中的一个节点
   6. 遍历入口文件的依赖数组，由于数组中是文件名，则递归执行上述方法，直到找到所有依赖
   7. 返回所有依赖对象
   
根据上面总结内容我们在 src/complier.js 中创建一个 createAsset 方法
``` javascript
const fs = require('fs')
const path = require('path')
const parser = require('@babel/parser')
const traverse = require('@babel/traverse').default
const babel = require('@babel/core')
...
// 开始编译，构建ast语法树 filename: ./src/index.js
    createAsset(filename) {
       // 1
       // content 内容即为index.js中书写的内容
      const content = fs.readFileSync(filename, 'utf-8')
      // 2
      // ast 内容为对象，具体内容可以console.log(ast)查看
      // https://astexplorer.net/ 在官网输入index.js内容即可看到对应的树
      const ast = parser.parse(content, {
          sourceType: 'module'
      })
      // 创建依赖对象
      const dependencies = {}
      // 3
      // 获取抽象语法树中的依赖文件名
      traverse(ast, {
            ImportDeclaration: ({node}) => {
             // 获取文件的路径名如 './src/index.js' dirname='./src'
             const dirname = path.dirname(filename)
             const absPath = path.join(dirname, node.source.value)
             // node.source.value: .hello.js
             // absPath: ./src/index.js
             dependencies[node.source.value] = absPath
            }
      })
      // 4
      // 将ast转换成可执行代码 
      // https://www.babeljs.cn/docs/babel-core 将index.js内容直接放在官网即可看到转译后代码
      const { code } = babel.transformFromAst(ast, null, {
        presets: ['@babel/preset-env']
      })
      // 5
      return {
          filename,
          dependencies,
          code
      }
    }
```
 入口文件的依赖关系已经定义好，接下来根据入口文件的 dependencies ，递归遍历出所有子依赖，在 src/complier.js 文件中定义 run 方法
``` javascript
   // 拿到参数、执行、分析入口文件
    run() {
       // 拿到入口文件的依赖
       const mainAsset = this.createAsset(this.entry)
       const queue = [mainAsset]
       // 6
       // 遍历对象
       for (const asset of queue) {
          // 遍历文件的依赖文件，递归创建依赖图
         Object.values(asset.dependencies).forEach(filename => {
             const child = this.createAsset(filename)
             queue.push(child)
         })
       }
       // 7
       return queue
    }
```
命令行执行 node src/bundler.js 看下 queue 的内容如下
![8.png](https://pic.leetcode-cn.com/1655453942-BjjsRD-8.png)

4. 依赖树已经拿到，接下来在 src/bundler.js 中获取 complier 中返回的 queue
``` javascript
// 获取dependence graph
const graph = new complier(options).run()
```

5. 在 src/bundler.js 中创建函数 bundle，解析 graph 树，定义 require 函数，定义 modules，通过 eval 函数执行依赖树中的 code，在此我们可以知道 webpack 重写了 require 函数，所以 babel 中转换的函数可以正常执行
``` javascript
function bundle(graph){
  // 得到依赖文件名的对象 
  let modules = {};
  graph.forEach(item => {
     // 将文件名作为key, value为依赖文件，code为文件名对应的函数
    modules[item.filename] = {
        dependencies: item.dependencies,
        code: item.code
    }
  })
  modules = JSON.stringify(modules)
  const result = `(function(graph){
      function require(filepath) {
        function localRequire(relativePath) {
            // 将代码中的require中的路径转换成dependencies存储的带文件夹名的路径
           return require(graph[filepath].dependencies[relativePath])
        }
        var exports = {}
        function fn(require, exports, code) {
            eval(code)
        }
        fn(localRequire, exports, graph[filepath].code)
        return exports
      }
      require('${entry}')
    })(${modules})`
  return result
}

const graph = new complier(options).run()
// 执行bundle函数
const result = bundle(graph)
```
命令行输出 result 内容，粘贴内容到浏览器控制台并回车执行，发现我们预期的 'hello world!!!' 已经可以正常打印
![11.png](https://pic.leetcode-cn.com/1655454170-vhNhQb-11.png)
   
6. 以上我们已经拿到了编译后的代码，最后将它输出到 dist/main.js 中，在 src/bundler.js 中创建方法 createFile()，使用 fs 对象的  writeFileSync 将内容输出，在命令行执行命令后可以看到 src/main.js 中输出了对应内容
``` javascript
function createFile(code) {
    fs.writeFileSync(path.join(output.path, output.filename), code)
}
```

7. 下面是 src/complier.js和 src/bundler.js文件全部内容
   
complier.js
``` javascript
// 文件操作模块，读取文件内容
const fs = require('fs')
const path = require('path')
const parser = require('@babel/parser')
const traverse = require('@babel/traverse').default
const babel = require('@babel/core')

module.exports = class Complier {
    constructor(options) {
      const { entry, output } = options
      this.entry = entry
      this.output = output
    }
    // 拿到参数、执行、分析入口文件
    run() {
       const mainAsset = this.createAsset(this.entry)
       const queue = [mainAsset]
       for (const asset of queue) {
         Object.values(asset.dependencies).forEach(filename => {
             const child = this.createAsset(filename)
             queue.push(child)
         })
       }
       console.log(queue)
       return queue
    }
    // 开始编译，构建ast语法树 filename: ./src/index.js
    createAsset(filename) {
      const content = fs.readFileSync(filename, 'utf-8')
      const ast = parser.parse(content, {
          sourceType: 'module'
      })
      // 创建依赖
      const dependencies = {}
      traverse(ast, {
            ImportDeclaration: ({node}) => {
             // 获取文件的路径名如 './src/index.js' dirname='./src'
             const dirname = path.dirname(filename)
             const absPath = path.join(dirname, node.source.value)
             dependencies[node.source.value] = absPath
            }
        })
      // 将ast转换成代码 
      // https://www.babeljs.cn/docs/babel-core
      const { code } = babel.transformFromAst(ast, null, {
        presets: ['@babel/preset-env']
      })

      return {
          filename,
          dependencies,
          code
      }
    }
}
```

 bundler.js
``` javascript
// 引入配置
const fs = require('fs');
const path = require('path')
const options = require('../webpack.config')

const complier = require('./complier')

const { entry, output } = options

function bundle(graph){
  // 得到以依赖文件名的对象 
  let modules = {};
  graph.forEach(item => {
    modules[item.filename] = {
        dependencies: item.dependencies,
        code: item.code
    }
  })
  modules = JSON.stringify(modules)
  const result = `(function(graph){
      function require(filepath) {
        function localRequire(relativePath) {
            // 将代码中的require中的路径转换成dependencies存储的带文件夹名的路径
           return require(graph[filepath].dependencies[relativePath])
        }
        var exports = {}
        
        function fn(require, exports, code) {
            eval(code)
        }
        
        fn(localRequire, exports, graph[filepath].code)

        return exports
      }
      require('${entry}')
    })(${modules})`
  return result
}

function createFile(code) {
    fs.writeFileSync(path.join(output.path, output.filename), code)
}

const graph = new complier(options).run()
const result = bundle(graph)
createFile(result)

```
<br>
## 总结：
通过上面的 demo，我们已经可以大概了解 webpack 的编译流程，当然 webpack 的源码功能强大且复杂，感兴趣的小伙伴儿可以自行研究。

## Entry 和 Context
# 配置入口context和entry

webpack 在构建打包时，通过 context 和 entry 这两个配置来找到打包入口路径。在配置入口时其实做了两件事：
- 确认入口文件位置，告诉 webpack 从哪个文件开始打包
- 描述 chunk name。如果传入一个字符串或字符串数组，那么默认的 chunk name 为 “main”，如果传入的是一个对象，则每个属性的 key 会是 chunk 的名称，该属性的值描述了 chunk 的入口点
 <br>
## context

context 可以理解为配置资源入口的基础目录，在配置时要求必须使用绝对路径。如：现有的目录结构入口为 /src/script/index.js，则我们可以通过下面的配置来指定入口目录

``` javascript
const path = require('path');
module.exports = {
  context: path.resolve(__dirname, './src/script'),
  entry: './index.js'
};
module.exports = {
  context: path.resolve(__dirname, './src'),
  entry: './script/index.js'
};
```
这样配置后，命令行执行打包，发现依然成功的找到了入口并顺利打包（我们使用 hello world 的那个 demo 来执行现有配置）
![1.png](https://pic.leetcode-cn.com/1655454753-KcOwRo-1.png)

配置 context 的目的可以使 entry 的写法更加简洁，尤其是在多入口文件的情况下。不过 context 是可以省略的，默认值为当前工程的根目录。
<br>
## entry
在 webpack 配置中有多种方式定义 entry 属性，如：字符串、数组、对象、函数，接下来我们展示下每种类型如何配置
<br>
### 字符串类型

直接定义入口名称
``` javascript
module.exports = {
  entry: './src/script/index.js',
};
// entry 单入口语法，是下面的简写
module.exports = {
  entry: {
    main: './src/script/index.js',
  },
};
```
<br>
### 数组类型

传入一个数组的作用是将多个文件预先合并，最终将多个依赖的内容绘制在一个 chunk 中，在打包时 webpack 会将数组中的最后一个元素作为实际的入口路径，其余文件会预先构建到入口文件。
``` javascript
module.exports = {
  entry: ['lodash', './src/script/index.js'],
};
```
这种配置和下面是等效的
``` javascript
// index.js
import * from 'lodash'
// webpack.config.js
module.exports = {
  entry: './src/script/index.js',
}
```
这种写法会将 lodash 打包到我们的 bundle.js 中。这种写法类似于在 index.js 中引入 lodash，在控制台执行打包命令我们来看下生成的文件，从下面两张图可以看到在 index 中我们没有引入 lodash，但打包的文件中已经引入了 lodash
![2.png](https://pic.leetcode-cn.com/1655454755-pHqfJy-2.png)
<br>
### 对象类型

如果要定义多入口文件则需要使用对象的形式，通过这种方式可以自定义 chunk name，其中对象的key即为 chunk name，对象的 value 为入口路径。在使用对象描述入口时，我们可以使用以下属性

- dependOn: 当前入口所依赖的入口。它们必须在该入口被加载前被加载
- filename: 指定要输出的文件名称
- import: 启动时需加载的模块
- library: 指定 library 选项，为当前 entry 构建一个 library
- runtime: 运行时 chunk 的名字。如果设置了，就会创建一个新的运行时 chunk。在 webpack 5.43.0 之后可将其设为 false 以避免一个新的运行时 chunk
- publicPath: 当该入口的输出文件在浏览器中被引用时，为它们指定一个公共 URL 地址

多入口配置本质上打包后生成多个js文件
``` javascript
module.exports = {
  entry: {
    index: ['lodash', './src/script/index.js'],
    vendor: './vendor'
  }
}
```
<br>
### 函数类型

使用函数类型定义入口时，只要返回上面介绍的几种形式即可，如

``` javascript
// 返回字符串
module.exports = {
  entry: () => './src/script/index.js'
}
// 返回对象
module.exports = {
  entry: () => ({
    index: ['lodash', './src/script/index.js'],
    vendor: './vendor'
  })
}
```
传入函数的优点是我们可以通过函数中增加一些逻辑来动态改变打包入口
<br>
# 总结
本章我们梳理了 webpack 入口配置的几种方式，包括字符串、对象、数组、函数几种

## Entry 配置实例
# entry 配置实例

webpack 的 entry 配置在实际的应用中可以分几个场景。
- 单页应用
- 多页应用
- 分离应用程序和第三方库
  
下面我们来介绍下这几种应用
<br>
## 单页应用

对于单页应用，我们一般来定义单一入口即可
``` javascript
module.exports = {
  entry: './src/index.js',
};
```

通过单一入口打包文件，可以将所有入口文件依赖的 框架、引入的工具库、各个页面内容打包到一起。这样的好处是将所有内容都打包成一个 js 文件，依赖关系清晰。但是这种方式也有个弊端，即所有模块都打到一个包中，当应用规模上升到一定程度后导致打包资源体积过大，导致页面首次加载速度变慢
<br>
## 多页应用

对于多页应用的场景，为了尽可能减少打包资源的体积，我们希望每个页面都只加载各自必要的逻辑，而不是将所有内容都打包到一个 bundle 中，我们来看下多应用的配置

```javascript
const path = require('path');
module.exports = {
  entry: {
    index: './src/index.js',
    hello: './src/hello.js'
  },
  output: {
    path: path.resolve(__dirname, 'dist')
  }
};
```
打包后的文件如下，可以看到打包的内容中包含了 index.js 和 hello.js 两个文件。
![1.png](https://pic.leetcode-cn.com/1655454806-jTABfY-1.png)
<br>
## 分离应用程序和第三方库

在一个应用中，我们使用的框架、库、第三方依赖等往往很少会有改动，如果我们将所有内容都打包到一个 bundle 文件，一旦业务代码有一点点变更，那用户就要重新下载整个资源，这对于页面的性能是很不友好的。为了解决这个问题，我们可以使用应用程序和第三方库分离的方式来打包文件。也就是将业务代码和不频繁变更的第三方依赖分 bundle 打包，示例如下
webpack.config.js
```javascript
module.exports = {
  mode: 'development',
  entry: {
    index: './src/index.js',
    vendor: ['lodash']
  }
};
```
index.js
```javascript
import * as _ from 'lodash'
```
在上面的配置中，index.js 仍然和之前一样不做任何处理，只是我们新添加了一个 chunk name 为 vendor 的入口，并通过数组的形式将第三方依赖添加进去，执行打包命令我们看到输出了两个打包文件。
![2.png](https://pic.leetcode-cn.com/1655454806-dpjQmi-2.png)

其实上面的代码虽然打包成功了，也成功提取了 vender 文件，但是打开打包后的 dist/index.js 我们发现 lodash 还是被打到文件中了，对于这种情况我们可以配合使用 optimization.splitChunks，将 vender 和 index 中的公共代码提取出来，这个方法我们后面的文章在详细介绍。 

通过上面的配置，我们可以业务依赖的第三方模块抽取成一个独立的 bundle，由于这个 bundle 不经常变动，因此可以有效的利用客户端缓存，在用户后续请求页面时加快整体渲染速度。


# 核心概念-出口


## 配置参数详解
# output 输出配置详解

output 属性告诉 webpack 在哪里输出它所创建的 bundle，以及如何命名这些文件。主要输出文件的默认值是 ./dist/main.js，其他生成文件默认放置在 ./dist 文件夹中。

我们可以通过在配置中指定一个 output 对象，来配置这些处理过程：
  
``` javascript
const path = require('path');
module.exports = {
  mode: 'development',
  entry: {
    index: './src/index.js'
  },
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, 'dist'),
    publicPath: '/assets/',
    library: 'DemoLibrary', // 导出名称
    libraryTarget: 'window' // 挂载目标
  }
};
```

output 对象中可以包含数十个配置项，其中大部分开发中使用频率不高，我们在本章内容中只介绍几个常用配置，对其他配置感兴趣的同学可以查看官网  [output配置](https://webpack.docschina.org/configuration/output/#outputlibrary)
<br>
## filename

filename 决定了每个输出 bundle 的名称。这些 bundle 将写入到 output.path 选项指定的目录下。
对于单个入口起点，filename 会是一个静态名称。 filename 支持以字符串和函数的形式定义参数。
``` javascript
// 字符串形式
module.exports = {
  ...
  output: {
    filename: 'bundle.js',
  }
};
// 函数形式
module.exports = {
  ...
  output: {
    filename: (pathData) => {
      console.log(pathData)
      return '[name].js';
    }
  }
};
```
字符串形式的 filename，会在输出文件中生成 bundle.js，函数形式的 filename 会在输出文件中生成 index.js (以 chunk name 命名)，在控制台输出下 pathData，我们可以看到返回了一个包含 chunk 内容等信息的对象。

![2.png](https://pic.leetcode-cn.com/1655455164-gvBnpN-2.png)

filename 可以不仅仅是 bundle 的名字，还可以使用像 'js/[name]/bundle.js' 这样的文件路径，即便路径中的目录不存在也没关系，webpack 会在输出资源时创建该目录。例子如下：

``` javascript
module.exports = {
  ...
  output: {
    filename: 'js/[name]/bundle.js'
  }
};
```
![3.png](https://pic.leetcode-cn.com/1655455238-APpelQ-3.png)

当通过多个入口起点(entry point)、代码拆分(code splitting)或各种插件(plugin)创建多个 bundle，应该使用以下一种替换方式，来赋予每个 bundle 一个唯一的名称

|  替换方式  |  变量名称  |   功能描述  |        使用方式         |    打包结果  |
| --------- | ----------- | ----------- | ---------- | ----------- | 
|  入口名称  |  [name]    | 如果设置，则为此 chunk 的名称，否则使用 chunk 的 ID  |  filename: '[name].bundle.js' | ![4.png](https://pic.leetcode-cn.com/1655455277-rmXrzq-4.png)
|  chunk id  |  [id]  | 指代 此 chunk 的 id  |  filename: '[id].bundle.js' | ![5.png](https://pic.leetcode-cn.com/1655455277-XjORkS-5.png)
|  chunk hash  |  [chunkhash]  | 此 chunk 的 hash 值，包含该 chunk 的所有元素 |  filename: '[chunkhash].bundle.js' | ![6.png](https://pic.leetcode-cn.com/1655455277-XrOcco-6.png)
| content hash  |  [contenthash]  | 指代由生成的内容产生的 hash  |  filename: '[contenthash].bundle.js' | ![7.png](https://pic.leetcode-cn.com/1655455277-HqewjZ-7.png)

上面的配置除了可以对不同的 bundle 进行名称区分，还能起到一个控制客户端缓存的作用，表中的[chunkhash] 和 [contenthash] 都与文件内容直接相关，在 filename 中使用了这些变量后，当对文件内容做了修改，可以引起 bundle 文件名的修改，从而用户在下一次请求文件资源时会重新加载文件，而不会直接命中缓存资源。

在实际的工程中，我们一般使用较多的是[name]，一般与定义的 chunk 一一对应，可读性较高，为了控制客户端缓存，我们一般还加上 [contenthash]，如：

``` javascript
module.exports = {
  ...
  output: {
    filename: '[name]-[contenthash].js'
  }
};
```
打包结果如下
![8.png](https://pic.leetcode-cn.com/1655455351-gcqeym-8.png)

<br>
## path 

path 可以指定资源输出位置，要求必须使用绝对路径，如

```javascript
const path = require('path');
module.exports = {
  mode: 'development',
  entry: {
    index: './src/index.js',
  },
  output: {
    path: path.resolve(__dirname, 'dist')
  }
};
```
上述配置将工程的dist目录设置为资源的输出目录，在 webpack 4 之后，output.path 已经默认为 dist 目录，除非我们需要修改他，否则可以不用单独配置。
<br>
## publicPath

publicPath 从功能上来说，用于指定资源的请求位置。页面中的资源分为两种，一种是由 HTML 页面直接请求的，比如通过 script 标签加载 js，通过 link 标签加载 css。另一种是由 js 或 css 请求的，如加载图片字体文件等。 publicPath 就用来指定第二种间接资源的请求位置。如果指定了一个错误的值，则在加载这些资源时会收到 404 错误。

publicPath 有以下三种形式
1. 相对于 HTML
2. 相对于 HOST
3. 相对于 CDN
<br>
### 相对于 HTML
在请求资源时，会以当前 html 页面所在路径加上 publicPath 的相对路径来构成实际请求的 URL，如

```javascript
// 假设当前 html 页面地址为 http://demo.com/webpack/index.html
// 需要请求文件名为 demo.png
module.exports = {
  ...
  output: {
    publicPath: '' // 实际请求路径 http://demo.com/webpack/demo.png
    publicPath: './css' // 实际请求路径 http://demo.com/webpack/css/demo.png
    publicPath: '../assets/' // 实际请求路径 http://demo.com/assets/demo.png
  }
};
```
<br>
### 相对于 HOST
若 publicPath 的值以 “/” 开始，则代表此时 publicPath 是以当前页面的域名加上 publicPath 的相对路径来构成实际请求的 URL，如

```javascript
// 假设当前 html 页面地址为 http://demo.com/webpack/index.html
// 需要请求文件名为 demo.png
module.exports = {
  ...
  output: {
    publicPath: '/' // 实际请求路径 http://demo.com/demo.png
    publicPath: '/css' // 实际请求路径 http://demo.com/css/demo.png
    publicPath: '../assets/' // 实际请求路径 http://demo.com/assets/demo.png
  }
};
```
<br>
### 相对于 CDN
上面两种配置都是相对路径，我们也可以使用绝对路径的形式配置 publicPath，这种情况一般发生在将静态资源放在 CDN 上面，如

```javascript
// 假设当前 html 页面地址为 http://demo.com/webpack/index.html
// 需要请求文件名为 demo.png
module.exports = {
  ...
  output: {
    publicPath: 'http://cdn.example.com/assets/' // 实际请求路径 http://cdn.example.com/assets/demo.png
    publicPath: 'https://cdn.example.com/assets/' // 实际请求路径 https://cdn.example.com/assets/demo.png
    publicPath: '//cdn.example.com/assets/' // 实际请求路径 //cdn.example.com/assets/demo.png
  }
};
```
webpack-dev-server 也会默认从 publicPath 为基准，使用它来决定在哪个目录下启用服务，来访问 webpack 输出的文件。
<br>
## library

library 的作用是将打包的内容生成一个库，可以供其他工程加载使用。这一点在目前流行的微前端架构实战上面很有用，如子应用通过输出类库的形式将内容输出到一个对象上，这样主应用就可以通过加载 js 的方式去引入子应用，并且可以通过子应用输出的对象名称来加载子应用的内容。library 具体的使用方法，我们来看下面的例子：

webpack.config.js
```javascript
module.exports = {
  ...
  entry: './src/index.js',
  output: {
    library: 'DemoLibrary'
  }
};
```
src/index.js 的入口中导出了如下函数
```javascript
export function hello(webpack) {
  console.log(`hello ${webpack}`);
}
```
此时，变量 DemoLibrary 将与入口文件所导出的文件进行绑定，下面是如何使用打包生成的index.js文件：
index.html
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>测试DemoLibrary库</title>
</head>
<body>
    <script src='./dist/index.js'></script>
    <script>
    DemoLibrary.hello('webpack');
    </script>
</body>
</html>
```
在浏览器中可以看到成功输出 hello webpack。

![9.png](https://pic.leetcode-cn.com/1655455351-EBIJbq-9.png)

library 的类型可以为字符串、数组、和对象，字符串的参数类型则直接指代库的名称，与对象中设置 name 属性作用相同。如果 entry 入口设置为 object，所有入口都可以通过 library 的 array 语法暴露：

```javascript
module.exports = {
  // …
  entry: {
    a: './src/a.js',
    b: './src/b.js',
  },
  output: {
    filename: '[name].js',
    library: ['DemoLibrary', '[name]'], // [name] 为 chunk name
  },
};
```
假设 a.js 与 b.js 导出名为 hello 的函数，下面就是如何使用这些库的方法：

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>测试DemoLibrary库</title>
</head>
<body>
    <script src='./dist/a.js'></script>
    <script src='./dist/b.js'></script>
    <script>
    DemoLibrary.a.hello('webpack');
    DemoLibrary.b.hello('webpack');
    </script>
</body>
</html>
```
请注意，如果你打算在每个入口点配置 library 配置项的话，以上配置将不能按照预期执行。这里是如何 在每个入口点下 做的方法：

```javascript
module.exports = {
  // …
  entry: {
    main: {
      import: './src/index.js',
      library: {
        // `output.library` 下的所有配置项可以在这里使用
        name: 'MyLibrary',
        type: 'umd',
        umdNamedDefine: true,
      },
    },
    another: {
      import: './src/another.js',
      library: {
        name: 'AnotherLibrary',
        type: 'commonjs2',
      },
    },
  },
};
```

library 包含以下可配置参数

|  参数名称  |   功能描述  |        支持类型         |   
| --------- | ----------- | ----------- |
|  name  |  指定库的名称   | 字符串、数组、对象  | 
|  type  |  配置将库暴露的方式  | 字符串  | 
|  export  |  指定哪一个导出应该被暴露为一个库  | 字符串、数组 |  
| auxiliaryComment  |  在 UMD 包装器中添加注释  | 字符串、对象  |  
| umdNamedDefine  |  将 AMD 模块命名为 UMD 构建  | 布尔  |  

这里我们说下 type 类型，在实际的使用中，我们可能根据工程运行环境的需要，而需要将类库暴露为不同的类型，如 支持 esModule、amd、cmd、umd 等，type 配置就可以帮我们完成不同输出方式。

type 类型默认包括 'var'、'module'、'assign'、'assign-properties'、'this'、'window'、'self'、'global'、'commonjs'、'commonjs2'、'commonjs-module'、'commonjs-static'、'amd'、'amd-require'、'umd'、'umd2'、'jsonp' 以及 'system'，除此之外也可以通过插件添加。官方文档对每种类型给了详细说明和事例，具体我们可查看官方文档，[output.target.type 配置](https://webpack.docschina.org/configuration/output/#outputlibrarytype)
<br>
# 总结

以上为我们在实际开发中使用的 output 配置，包含 path、filename、publicPath、library，日常使用中可能还会用到 libraryTarget ，不过 webpack 未来会放弃对 output.libraryTarget 的支持，所以可以使用 output.library.type 替代 output.libraryTarget。

## 输出配置实例
# output 输出配置实例

到目前为止，我们都是在 index.html 文件中手动引入打包生成的资源，然而随着应用程序增长，并且一旦开始在文件名中使用 hash 并输出 多个 bundle，如果继续手动管理 index.html 文件，就会变得困难起来。然而，通过一些插件可以使这个过程更容易管控。HtmlWebpackPlugin 可以帮我们解决这个问题。
<br>
## 设置 HtmlWebpackPlugin

继续使用之前的工程文件，目录结构为：

![1.png](https://pic.leetcode-cn.com/1655455531-GLJkvW-1.png)

首先安装插件，并且调整 webpack.config.js 文件：
安装 html-webpack-plugin 插件 

```javascript
npm install --save-dev html-webpack-plugin
```
webpack.config.js
```javascript
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
  mode: 'development',
  entry: {
    index: './src/index.js',
    hello: './src/hello.js'
  },
  output: {
    filename: '[name].js'
  },
  plugins: [
    new HtmlWebpackPlugin({
      title: '管理输出',
    }),
  ],
};
```

执行构建命令 npm run build，我们看下打包后的结果，我们可以看到，打包文件包含两个入口文件对应的 js 文件，还包含一个 index.html 文件

![2.png](https://pic.leetcode-cn.com/1655455531-mkBBWv-2.png)

在 dist 目录下我们看下打包的 index.html 文件，我们可以看到 HtmlWebpackPlugin 创建了一个全新的 index.html 文件，所有的 bundle 会自动添加到 html 中。

![3.png](https://pic.leetcode-cn.com/1655455531-YxKehy-3.png)

<br>
## 清理 /dist 文件夹

你可能已经注意到，由于遗留了之前指南中的代码示例，我们的 /dist 文件夹显得相当杂乱。webpack 将生成文件并放置在 /dist 文件夹中，但是它不会追踪哪些文件是实际在项目中用到的。

通常比较推荐的做法是，在每次构建前清理 /dist 文件夹，这样 /dist 文件夹中只有最近一次生成的文件。让我们使用 output.clean（ webpack 5.20.0 及以上版本支持）配置项实现这个需求。

webpack.config.js
```javascript
module.exports = {
  ...
  output: {
    clean: true
  }
};
```

现在，执行 npm run build，检查 /dist 文件夹。如果一切顺利，现在只会看到构建后生成的文件，而没有旧文件！
<br>
## 总结

本章我们介绍了一个优化开发效率的插件和一个配置项，使用 HtmlWebpackPlugin 插件可以动态的生成 index.html 文件，以及动态的向 index.html 文件插入 bundle。了解了如何在编译时清空 dist 文件内容。


# 核心概念-Loader


## 概述
# loader 概述

到目前为止，我们的案例都是都是介绍的如何打包 js 文件，对于工程中的其他类型资源，如 CSS、图片、字体等， webpack 会如何处理呢？在实际的项目开发中，我们经常会用到 Sass 或者 Less 来编写样式，我们使用 Typescript 增加静态类型检查，我们使用浏览器不支持的 ECMAScript 新特性，如何让 webpack 来对所有的编译进行统一管理呢？

本章我们会介绍 loader（预处理器），它赋予了 webpack 可以处理不同资源的能力，极大丰富了其可扩展性。
<br>
## loader 作用

在 webpack 中，一切皆模块，我们可以使用 import、require 等方式 在JavaScript 模块中导入 JS、CSS、图片、字体等多种类型的静态资源，loader 用于对模块的源代码进行转换。loader 可以使我们在导入模块时预处理文件。loader 可以将文件从不同的语言（如 TypeScript）转换为 JavaScript。loader 甚至允许我们直接在 JavaScript 模块中 import CSS 文件！

loader 本质上是 node module 导出的一个函数，当资源需要被转换时，调用这个函数。下面我们通过自定义 loader，来看 loader 的使用方法。

src/index.js
```javascript
const demoName = 'webpack loader'
console.log(demoName)
```

webpack 默认支持解析 js 文件，我们增加解析 js 的 loader 只为展示 loader 是如何工作的

src/js-loader.js 
```javascript
module.exports = function (source) {
  console.log(source)
  return `module.exports=${JSON.stringify(source)}`
}
```

webpack.config.js
```javascript
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
  mode: 'development',
  entry: {
    index: './src/index.js'
  },
  output: {
    filename: '[name].js',
    clean: true
  },
  plugins: [
    new HtmlWebpackPlugin({
      title: 'loader',
    }),
  ],
  module: {
    rules: [
      {
        test: /\.js$/,
        use: "./src/js-loader.js"
      }
    ]
  }
};
```

执行构建命令，在控制台可以看到 js-loader 文件的 console.log 输出了 index.js 文件内容，从上面的 简易版 js-loader.js 文件中可以看出，loader 本身就是一个函数，在该函数中对接收的内容进行转换，然后返回转换后的结果。

![1.png](https://pic.leetcode-cn.com/1655456019-nGbqaR-1.png)

<br>
## loader 使用方式配置

在我们的应用中，有两种使用 loader 的方式，分别是 配置方式（推荐），内联方式。
<br>
### 配置方式（推荐）

module.rules 允许我们在 webpack 配置中指定多个 loader。 这种方式是展示 loader 的一种简明方式，并且有助于使代码变得简洁和易于维护。同时让我们对各个 loader 有个全局概览：

loader 从右到左（或从下到上）地取值(evaluate)/执行(execute)。在下面的示例中，从 css-loader 开始执行，最后以 style-loader 为结束。

webpack.config.js
```javascript
module.exports = {
  ...
  module: {
    rules: [
      {
        test: /\.css$/,
        use: ['style-loader','css-loader']
      }
    ]
  }
};
```

src/index.js
```javascript
import './index.css';
```

src/index.css
``` css
body {
    color: red;
    padding: 20px;
    text-align: center;
}
```

index.html
```html
...
<body>
    <div>import css</div>
    <script src='./dist/index.js'></script>
</body>
```

webpack 无法处理 CSS 语法，此时我们执行打包命令 控制台会报 “请使用合适的loader来处理这个文件类型”

![2.png](https://pic.leetcode-cn.com/1655456019-nygaex-2.png)

下面我们将 css-loader，style-loader 加到工程中，loader 都是一些第三方 npm 模块，webpack 本身不包含任何 loader, 所以使用前我们需要先安装这些 loader，在工程中执行以下命令安装。

```javascript
npm install css-loader style-loader
```

安装成功后，在控制台执行打包命令，我们可以看到错误已经消失了，在浏览器打开index.html 文件我们可以看到，样式正常展示。

![3.png](https://pic.leetcode-cn.com/1655456019-xKzhzK-3.png)
<br>
### 内联方式

loader 除了使用配置的方式，还有一种内联的用法，可以在 import 语句或任何 与 "import" 方法同等的引用方式 中指定 loader。使用 ! 将资源中的 loader 分开。每个部分都会相对于当前目录解析。

在上面的例子中，我们注释掉 webpack.config.js 中 module.rules 的配置，将引入方式改为内联方式。

src/index.js
```javascript
import '!style-loader!css-loader!./index.css';
```

执行打包命令后，我们在浏览器中打开 index.html 文件，可以看到样式正常显示。我们在工程中尽可能使用 module.rules，因为这样可以减少源码中的代码量，并且可以在出错时，更快地调试和定位 loader 中的问题。
<br>
## loader 特性

- loader 支持链式调用。链中的每个 loader 会将转换应用在已处理过的资源上。一组链式的 loader 将按照相反的顺序执行。链中的第一个 loader 将其结果（也就是应用过转换后的资源）传递给下一个 loader，依此类推。最后，链中的最后一个 loader，返回 webpack 所期望的 JavaScript。
- loader 可以是同步的，也可以是异步的。
- loader 运行在 Node.js 中，并且能够执行任何操作。
- loader 可以通过 options 对象配置（仍然支持使用 query 参数来设置选项，但是这种方式已被废弃）。
- 除了常见的通过 package.json 的 main 来将一个 npm 模块导出为 loader，还可以在 module.rules 中使用 loader 字段直接引用一个模块。
- 插件(plugin)可以为 loader 带来更多特性。
- loader 能够产生额外的任意文件。

## HTML-Loader
# html-loader

html-loader 用于将 html 文件转换为字符串，支持压缩、导出、对内容预处理。下面让我们来看一个例子。
<br>
## 使用

index.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>html-loader</title>
</head>
<body>
    <img src="./src/assets/card-mark.png" />
</body>
</html>
```
webpack.config.js
```javascript
const HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      // 使用 index.html 内容作为输出模版 
      template: "./index.html", 
    }),
  ],
```


在index.html 中我们使用 img 标签展示一张图片，图片为相对路径，在 src/assets 文件夹下增加名为 card-mark.png 的图片，在浏览器直接打开 index.html 我们可以看到，图片可以正常展示。

![1.png](https://pic.leetcode-cn.com/1655456744-FeKOzS-1.png)

此时我们在控制台执行打包命令 npm run build，在 dist 文件夹中 输出了 index.html 文件，我们直接在浏览器打开 index.html 文件，此时图片无法打开。

![2.png](https://pic.leetcode-cn.com/1655456744-qKyiJP-2.png)

图片打不开的原因为 src 地址使用了相对路径，dist 文件夹与 src 文件夹同目录，所以 src="./src/assets/card-mark.png" 这个地址无法找到图片，导致图片无法展示。此时我们就可以借助 html-loader 来帮我们解决这个问题。

安装 html-loader

```javascript
npm install html-loader -D
```

安装成功后，将 html-loader 配置到 webpack.config.js 中

```javascript
const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      template: "./index.html",
    }),
  ],
  module: {
    rules: [
      {
        test: /\.html$/,
        use: {
          loader: 'html-loader',
        }
      }
    ]
  }
};
```

此时在执行打包命令，可以看到在 dist 文件夹下除了index.html 文件和 index.js 文件，又多了一个 扩展名为 .png 的文件，我们打开 dist 文件夹下的 index.html 发现 src 的引用地址已修改，此时在浏览器中直接打开 dist 文件夹下的 index.html 发现图片可以正常显示。

![3.png](https://pic.leetcode-cn.com/1655456744-siwEwv-3.png)
<br>
## 配置项

html-loader 包含下面四个配置项

|  参数名称  |  支持类型   |       默认值          |   功能描述 
| --------- | ----------- | ----------- | ----------- |
|  sources  |  {Boolean、Object}   |  true | 启用/禁用 sources 处理 
|  preprocessor  |  {Function}  | undefined  | 允许在处理前对内容进行预处理 
|  minimize  |  {Boolean、Object}  | 在生产模式下为 true，其他情况为 false | 通知 html-loader 压缩 HTML 
| esModule  |  {Boolean}  | true  |  启用/禁用 ES modules 语法 |
<br>
### sources

#### sources 默认值为 true

webpack.config.js
```javascript
module.exports = {
  module: {
    rules: [
      {
        test: /\.html$/,
        loader: "html-loader",
        options: {
          // 设置为 false 则不会对可加载属性做任何处理
          sources: false,
        },
      },
    ],
  },
};
```

默认情况下，每个可加载属性（例如 img 图片导入）都将被导入（ const img = require ('./image.png') 或 import img from "./image.png" ）。 你可能需要为配置中的图片指定 loader（我们前面的例子，如果配置 html-loader 的参数 esModule: false，则需要使用 loader 对图片进行处理，否则打包报错）。

html-loader 支持处理的 可加载属性 包括：
- audio 标签的 src 属性
- img 标签的 src 属性
- img 标签的 srcset 属性
- [剩余标签和属性可查看文档](https://webpack.docschina.org/loaders/html-loader/#sources)
<br>
#### source 设置为 Object

webpack.config.js
```javascript
module.exports = {
  module: {
    rules: [
      {
        test: /\.html$/,
        loader: "html-loader",
       options: {
            sources: {
              list: [
                {
                  tag: "img",
                  attribute: "data-src",
                  type: "src",
                }
              ]
            },
          },
      },
    ],
  },
};
```

index.html
```html
<body>
    <img data-src="./src/assets/card-mark.png" src="./src/assets/card-mark.png" />
</body>
```

执行打包命令，看下 dist 文件夹下的 index.html 文件，发现 html-loader 只对 img 标签的 data-src 属性做了转换。

![4.png](https://pic.leetcode-cn.com/1655456744-dAdrmF-4.png)

sources 对象中 支持 list 和 urlFilter 属性，[详情可查看文档](https://webpack.docschina.org/loaders/html-loader/#sources)
<br>
### preprocessor

允许在处理之前对内容进行预处理。

webpack.config.js
```javascript
const Handlebars = require("handlebars");
module.exports = {
  module: {
    rules: [
      {
        test: /\.html$/,
        use: {
          loader: 'html-loader',
          options: {
            preprocessor: (content, loaderContext) => {
              let result;
  
              try {
                result = Handlebars.compile(content)({
                  firstname: "Value",
                  lastname: "OtherValue",
                });
              } catch (error) {
                loaderContext.emitError(error);
  
                return content;
              }
              return result;
            }
          }
        }
       },
      },
    ],
  },
};
```

index.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>html-loader</title>
</head>
<body>
    <p>{{firstname}} {{lastname}}</p>  
    <img src="./src/assets/card-mark.png" />
</body>
</html>
```

在 webpack.config.js 中我们使用了 handlebars ，需要先安装 handlebars。

[Handlebars](https://handlebarsjs.com/) 是一种简单的模板语言。
它使用模板和输入对象来生成 HTML 或其他文本格式。Handlebars 模板看起来像带有嵌入式 Handlebars 表达式的常规文本。

```html
<p>{{firstname}} {{lastname}}</p> 
```

执行打包命令后，查看 dist 文件夹下的 index.html 文件，可以看到 p 标签内容已被替换。

![5.png](https://pic.leetcode-cn.com/1655456744-wtxzhT-5.png)
<br>
### minimize

告诉 html-loader 编译时需要压缩 HTML 字符串。
默认情况下，启用压缩的规则如下：

```javascript
({
  caseSensitive: true,
  collapseWhitespace: true,
  conservativeCollapse: true,
  keepClosingSlash: true,
  minifyCSS: true,
  minifyJS: true,
  removeComments: true,
  removeRedundantAttributes: true,
  removeScriptTypeAttributes: true,
  removeStyleLinkTypeAttributes: true,
});
```

webpack.config.js

```javascript
module.exports = {
  module: {
    rules: [
      {
        test: /\.html$/i,
        loader: "html-loader",
        options: {
          // boolean
          minimize: true,
          // 对象
          minimize: {
            removeComments: false,
            collapseWhitespace: false,
          },
        },
      },
    ],
  },
};
```
<br>
### esModule
默认情况下， html-loader 生成使用 ES modules 语法的 JS 模块。 在某些情况下，使用 ES modules 会更好，例如在进行模块合并和 tree shaking 时。

你可以使用以下方法启用 CommonJS 模块语法：
webpack.config.js

```javascript
module.exports = {
  module: {
    rules: [
      {
        test: /\.html$/i,
        loader: "html-loader",
        options: {
          esModule: false,
        },
      },
    ],
  },
};
```
<br>
# 总结

本节我们介绍了 html-loader 的使用方法和 html-loader 包含的 4 个参数 sources、preprocessor、minimize、esModule, 它们分别对应 html-loader 在项目实践中的 4 个重要功能：

1. 将 HTML 中标签的可加载属性引入的文件作为模块导入
2. 预处理 HTML，常用来支持模板引擎
3. 压缩 HTML
4. 默认导出 ES modules 便于模块合并和 tree shaking

## URL-Loader
# url-loader

当我们在文件中加载图片、字体等资源时，webpack 无法直接处理以上资源，在 webpack 5 之前需要使用相应 loader 来处理资源文件，url-loader 可以将一个文件转换为 base64 编码来代替访问地址，这样做的好处是可以减少一次网络请求，下面我们来看看如何使用 url-loader 及 url-loader 有哪些常用配置。
<br>
## 使用

index.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>url-loader</title>
</head>
<body>
</body>
</html>
```

index.js

index.js 文件中引入一张图片，创建image标签后，将导入的图片赋值给 image 标签的 src 属性，将 image 标签添加到页面中

```javascript
import Back from './img/back.png';

function component() {
  var element = document.createElement('img'); 
  element.src=Back
  return element;
}

document.body.appendChild(component());
```

安装 url-loader

```javascript
npm install url-loader -D
```

安装成功后，将 url-loader 配置到 webpack.config.js 中

```javascript
module.exports = {
  ...
   module: {
    rules: [
      {
        test: /\.(png|jpg)$/,
        use: [
          {
            loader: 'url-loader'
          }
        ]
      }
    ]
  }
};
```

此时在执行打包命令，此时在浏览器中直接打开 dist 文件夹下的 index.html 发现页面中展示一张图片。
<br>
## 配置项

url-loader 包含下面 3 个配置项

|  参数名称  |  支持类型   |       默认值          |   功能描述 
| --------- | ----------- | ----------- | ----------- |
|  limit  |  Boolean、Number、String   |  true | 需要转换为 base64 的资源大小限制
|  mimetype  |  Boolean、String  |  基于mime-types 查找  | 为文件指定MIME类型
|  fallback  |  String  | file-loader | 文件大小等于或者超过 limit 限制后使用的资源处理 loader
<br>
### limit

webpack.config.js
```javascript
module.exports = {
  module: {
    rules: [
      {
        test: /\.(png|jpg)$/,
        use: [
          {
            loader: 'url-loader',
            options: {
              limit: 2048 // 2Kb
            }
          }
        ]
      }
    ]
  }
};
```
一般情况下，当资源文件大小小于 2Kb 时，我们需要将资源路径转换为 base64 的格式将资源打包到 bundle 中，这样可以减少一次网络请求，当一个页面中引入多个资源文件时可以明显减少请求次数，但这种方式带来了另外一个问题，如果资源文件体积较大，就会导致 bundle 的体积增大，体积大的情况下网络请求时间变长，会导致页面白屏时间变长，非常影响用户体验。所以在处理资源文件时，一般会加上 limit 配置，文件资源体积超过配置的大小后，更改资源文件的处理方式，默认使用 file-loader 来处理。

上面的配置在执行打包命令时会报 “Cannot find module 'file-loader'” 的错误，所以在使用 limit 配置时，我们先下载安装 file-loader。

安装 file-loader

```javascript
npm install file-loader -D
```
再次执行打包命令，在 dist 文件夹下输出了一个扩展名为 .png 的图片，让我们来对比下增加 limit 配置前和增加 limit 配置后 dist 文件夹和 index.js 文件的变化。

增加 limit 配置前

dist 文件夹

![3.png](https://pic.leetcode-cn.com/1655702983-rBTYab-3.png)

index.js 

![4.png](https://pic.leetcode-cn.com/1655702983-VEfXJw-4.png)

增加 limit 配置后

dist 文件夹 

![5.png](https://pic.leetcode-cn.com/1655702983-btTkSZ-5.png)
index.js 

![6.png](https://pic.leetcode-cn.com/1655702983-ypgcON-6.png)
<br>
### mimetype

设置文件的转换类型。如果未指定，将使用文件扩展名来查找MIME 类型。

webpack.config.js
```javascript
 rules: [
      {
        test: /\.(png|jpg)$/,
        use: [
          {
            loader: 'url-loader',
            options: {
              mimetype: 'image/jpg'
            }
          }
        ]
      }
    ]
```
<br>
### fallback

指定当目标文件的大小等于或超过限制选项中设置的限制时，使用的替代加载 loader，默认为 file-loader。

```javascript
module: {
    rules: [
      {
        test: /\.(png|jpg)$/,
        use: [
          {
            loader: 'url-loader',
            options: {
              limit: 2048,
              fallback: 'responsive-loader'
            }
          }
        ]
      }
    ]
  }
```
<br>
# 总结

本节我们介绍了 url-loader 的使用方法和 url-loader 包含的 3 个参数 limit、minitype、fallback, url-loader 设置了 limit 参数后，超过设置的限制大小后，默认使用 file-loader 加载资源文件，所以 file-loader 的可配置参数在 url-loader 中也可配置生效，剩余可配置参数在 file-loader 中继续总结。

## File-Loader
#  file-loader

在 webpack 5 之前处理图片、字体等资源，除了使用 url-loader 之外还经常使用 file-loader，file-loader 的处理方式和 url-loader 有些不同，url-loader 通过 limit 参数判断如果没有超过配置大小，则将文件转做 base64 编码，直接嵌入到 CSS/JS/HTML 代码中。而 file-loader 并不会对文件内容进行任何转换，只是复制一份文件内容，并根据配置为他生成一个唯一的文件名, 下面让我们梳理下 file-loader 如何使用及有哪些可配置参数。我们继续使用 url-loader 的例子, 只是对个别配置做些修改。
<br>
## 使用

index.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>file-loader</title>
</head>
<body>
</body>
</html>
```

index.js

index.js 文件中引入一张图片，创建 image 标签后，将导入的图片赋值给 image 标签的 src 属性，将 image 标签添加到页面中。

```javascript
import Back from './img/back.png';

function component() {
  var element = document.createElement('img'); 
  element.src=Back
  return element;
}

document.body.appendChild(component());
```

安装 file-loader

```javascript
npm install file-loader -D
```

安装成功后，将 file-loader 配置到 webpack.config.js 中

```javascript
module.exports = {
  ...
   module: {
    rules: [
      {
        test: /\.(png|jpg)$/,
        use: [
          {
            loader: 'file-loader'
          }
        ]
      }
    ]
  }
};
```

执行打包命令，此时在浏览器中直接打开 dist 文件夹下的 index.html 发现页面中展示一张图片，此时我们在 dist 目录下可以看到一张扩展名为 .png 的图片，直接点击图片打开，可以看到与我们引入的图片一致。
<br>
## 配置项

file-loader 包含下面几个配置项

|  参数名称  |  支持类型   |       默认值          |   功能描述 
| --------- | ----------- | ----------- | ----------- |
|  name  |  String、Function   |  [contenthash].[ext] | 为文件配置自定义文件名模板
|  context  |  String  |  this.options.context  | 配置自定义文件 context，默认为 webpack.config.js 的 context
|  publicPath  |  String、Function  | output.publicPath + outputPath | 为文件配置自定义 public 发布目录
|  outputPath  |  String、Function  | undefined | 为文件配置自定义 output 输出目录 
|  useRelativePath  |   Boolean  | false | 当设置为 true, 为每个文件生成一个相对 url 的 context
|  emitFile  |  Boolean  | true | 设置为 false, 禁止复制文件
 
<br>
###  name

可以使用查询参数名称为您的文件配置一个自定义的文件名模板。默认情况下，不配置 name 属性生成的文件的文件名就是文件内容的 MD5 哈希值与原始扩展名。name 属性支持传入字符串或函数配置。

webpack.config.js
```javascript
module.exports = {
  module: {
    rules: [
      {
        test: /\.(png|jpg)$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: [name].[ext]
            }
          }
        ]
      }
    ]
  }
};
```
name 参数可以传入以下常用占位符

|  名称  |  类型   |       默认值          |   功能描述 
| --------- | ----------- | ----------- | ----------- |
|  [ext]  |  String   |  file.extname | 资源扩展名
|  [name]  |  String  |  file.basename  | 资源的名称
|  [path]  |  String  | file.dirname | 资源相对于 context 的路径
|  [hash]  |  String  |md5 | 内容的哈希值, [hashes]]https://www.webpackjs.com/loaders/file-loader/#hashes 配置中有更多信息

常见的打包命名方式是：assets/[name]-[hash].[ext]，即将所有 file-loader 处理的图片按照 name 传入的文件名称 + hash 值.扩展名的方式打包到 assets 目录下。其中

1. [ext] 表示是原文件的扩展名，如 back.png 就是指 png
2. [name] 表示原文件的文件名。如 back.png 就是指 back，但一般生产环境不推荐直接使用 [name]，一般和 [hash] 一起使用，这样可以防止命名冲突。
3. [path] 相对于 context 的路径，context 默认是 webpack.config.js 的路径
4. [hash:6]可以控制 hash 值的长度，6 表示长度为 6，默认是 32
<br>
###  context

修改打包文件生成路径，其实影响的 是 path 占位符，context 需要和 path 占位符同时配置才会影响文件生成路径。


webpack.config.js
```javascript
{
  loader: 'file-loader',
  options: {
    name: '[path][name].[ext]',
    context: __dirname + '/../'
  }
}
```

打包后，当前项目根文件夹和图片所在路径形成了打包文件的新路径，如果不设置 context 则打包路径相对于 webpack.config.js 的 context 的路径。

![1.png](https://pic.leetcode-cn.com/1655703446-hNPQck-1.png)
<br>
###  publicPath

publicPath 一般会用 webpack 本身配置的，和那个效果也一样，但假如你想单独配置，就用这个。设置 publicPath 后，文件的请求地址会被打包进 js 文件。

webpack.config.js
```javascript
{
  loader: 'file-loader',
  options: {
    name: '[name].[ext]',
    outputPath: 'https://www.abc.cn/img/'
  }
}
```

![2.png](https://pic.leetcode-cn.com/1655703446-bgMKWl-2.png)
<br>
###  outputPath

outputPath 在文件前增加路径，也就是增加文件夹。

webpack.config.js
```javascript
{
  loader: 'file-loader',
  options: {
    name: '[name].[ext]',
    outputPath: 'images/'
  }
}
```
<br>
# 总结

本节我们介绍了 file-loader 的使用方法和 file-loader 包含的几个常用参数配置。file-loader 的可配置选项在 url-loader 中配置也可生效（limit 生效的情况下），在 webpack5 以前对于资源文件的处理一般使用这两种插件，webpack5 提供了一种模块[Asset Modules](https://webpack.js.org/guides/asset-modules/)，它允许人们在不配置额外加载器的情况下使用资源文件（字体、图标等）

## CSS-Loader
#  css-loader

css-loader 会对 import 和 url() 进行处理，就像 js 解析 import/require() 一样。
<br>
## 使用

index.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>css-loader</title>
</head>
<body>
</body>
</html>
```

index.js

src/index.js 文件中使用 import 导入 index.css 并输出导入的样式内容。

```javascript
import indexCss from "./index.css";

console.log(indexCss.toString())
```

index.css

src/index.css 文件中使用 import 导入 index.css。

```css
body {
  background-color: aqua;
  width: 500px;
  height: 500px;
  border: 1px solid red;
}
```

安装 css-loader

```javascript
npm install css-loader -D
```

安装成功后，将 css-loader 配置到 webpack.config.js 中

```javascript
module.exports = {
  ...
   module: {
    rules: [
      {
        test: /\.(css)$/,
        use: [
          {
            loader: 'css-loader'
          }
        ]
      }
    ]
  }
};
```

执行打包命令，此时在浏览器中打开 dist/index.html 发现页面没有正确展示我们定义的样式，但是控制台中输出了我们定义的样式，到了这一步，css-loader 我们就正确引入并使用了，没有正确展示效果的原因是 css-loader 对 index.js 中的 import 进行处理，默认生成一个数组存放处理后的样式字符串，并将其导出。而 style-loader 负责将 css 插入到 html 中，style-loader 的使用我们在下一节展示。
<br>
## 配置项

css-loader 包含下面几个配置项

|  参数名称  |  支持类型   |       默认值          |   功能描述 
| --------- | ----------- | ----------- | ----------- |
|  url  |  Boolean  |  true  | 启用/禁用 url() 处理 |
|  import  |  Boolean  | true | 启用/禁用 @import 处理 |
|  modules  |   Boolean  | false | 启用/禁用 CSS 模块 |
|  sourceMap  |  Boolean  | 取决于 compiler.devtool 值 | 启用/禁用 Sourcemap |
|  esModule  |  Boolean/String  | true | 是否使用 ES 模块语法 |
|  importLoaders  |  Number  | 0 | 在 css-loader 前应用的 loader 的数量 |
|  exportType  |  "array"/"string"/"css-style-sheet"  | [] | 允许导出样式为模块数组、字符串或者可构造样式（即 CSSStyleSheet） |
<br>
###  url

允许启用/禁用处理 CSS 函数 url 和 image-set。如果设置为false, css-loader 将不会解析 url 或 image-set 中指定的任何路径。还可以通过传递函数来根据资源路径动态地控制这种行为。从版本4.0.0开始，绝对路径是基于服务器根目录进行解析的。

src/index.css

```css
body {
    background: url(./img/1.png);
}
```

webpack.config.js
```javascript
module.exports = {
  ...
   {
      loader: 'css-loader',
      options: {
          url: false,
          // url: true
      }
    }
};
```
在控制台我们在 index.js 中输出了 index.css 导出的字符串，我们来看下 url 设置为 false 和 true 的 background 区别。

![1.png](https://pic.leetcode-cn.com/1655709629-GTgEyK-1.png)
![2.png](https://pic.leetcode-cn.com/1655709629-RPGYMd-2.png)

当 url 设置为 false 时， url 中的图片地址没做任何处理，当 url 值为 true 时，编译后地址为图片的路径，并且 dist 文件夹下会生成一张图片。
<br>
###  import

允许启用/禁用 @import 处理。

src/index.css

```css
@import url('./main.css');

body {
  border: 1px solid red;
}
```

src/main.css

```css
body {
  width: 200px;
  height: 200px;
}
```

webpack.config.js
```javascript
module.exports = {
...
  {
    loader: 'css-loader',
    options: {
        import: false
        // import: true
    }
  }
};
```

为了方便看到样式，我这安装了 style-loader 并添加到了 loader 中，我们来看下 import 设置为 false 和 true 的区别。

![3.png](https://pic.leetcode-cn.com/1655709644-gvVFJh-3.png)
![4.png](https://pic.leetcode-cn.com/1655709644-EOifyM-4.png)


当设置为 false 时 index.css 中的 @import 没有解析导致运行代码时找不到 main.css。
<br>
###  modules

查询参数 modules 会启用 CSS 模块规范。

默认情况下，这将启用局部作用域 CSS。（你可以使用 :global(...) 或 :global 关闭选择器 and/or 规则。详情可查看 [modules](https://www.webpackjs.com/loaders/css-loader/#modules)

webpack.config.js
```javascript
{
  loader: 'css-loader',
  options: {
      modules: true
  }
}
```

<br>
###  sourceMap

设置 sourceMap 选项查询参数来引入 source map。

例如 extract-text-webpack-plugin 能够处理它们。

默认情况下取决于compiler.devtool 值，值为 false 和 eval 时，不会生成 source map，一般情况下不启用它，因为它们会导致运行时的额外开销，并增加了 bundle 大小 (JS source map 不会)。此外，相对路径是错误的，你需要使用包含服务器 URL 的绝对公用路径。

webpack.config.js
```javascript
{
  ...
  loader: 'css-loader',
  options: {
      sourceMap: true
  }
}
```
<br>
###  esModule

css-loader 中有时生成 esModule 模块化的形式是有益的，比如 module-concatenation 和 tree-shaking 时必须使用 esModule 模式才会生效。如果想启用 CommonJS 模块语法，则 esModule 设置为 false。

webpack.config.js
```javascript
{
  ...
  options: {
    esModule: true
  }
}
```
<br>
###  importLoaders

在 src/index.css 中使用的 @import './main.css'，importLoaders 选项可以定义在 @import 时使用哪些插件编译。

webpack.config.js
```javascript
{
  ...
  use: [
    "style-loader",
    {
      loader: "css-loader",
      options: {
        // 0 => no loaders (default);
        // 1 => postcss-loader;
        // 2 => postcss-loader, sass-loader
        importLoaders: 2,
      },
    },
    "postcss-loader",
    "sass-loader",
  ],
}
```
<br>
###  exportType

允许将样式导出为带有模块的数组、字符串或可构造样式表(如CSSStyleSheet)。默认值是 'array'。

webpack.config.js
``` javascript
{
  ...
  use: [
    {
      loader: 'css-loader',
      options: {
          exportType: 'string'
      }
    }
    ]
  }
}
```

src/index.js
```javascript
import indexCss from "./index.css";

console.log(indexCss)
```

打包后，执行 dist/index.html 可以看到控制台输出了 index.css 中定义的样式字符串。
<br>
# 总结

本节我们介绍了 css-loader 的使用方法和 css-loader 包含的几个常用参数配置。css-loader 可以将 js 中的 import 导入样式文件进行编译并且拿到导出内容供其他插件使用。

## Style-Loader
#  style-loader

style-loader 一般和 css-loader 配合使用，css-loader 识别模块，通过特定的语法规则进行内容转换最后导出，style-loader 将 css-loader 导出的内容插入到 DOM。 
<br>
## 使用

index.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>style-loader</title>
</head>
<body>
</body>
</html>
```

index.js

src/index.js 文件中使用 import 导入 index.css。

```javascript
import indexCss from './index.css';
```

index.css

设置一个长宽均为 200 像素的带红色边框的正方形

```css
body {
    border: 1px solid red;
    width: 200px;
    height: 200px;
}
```

安装 style-loader

```javascript
npm install style-loader -D
```

安装成功后，将 style-loader 配置到 webpack.config.js 中，配置中我们使用 css-loader 和 style-loader 两个加载器，webpack 中 loader 的解析一般由右向左，由下向上解析，所以 webpack 会先执行 css-loader，css-loader 导出内容传给 style-loader，最后在执行 style-loader。

```javascript
module.exports = {
  ...
   module: {
    rules: [
      {
        test: /\.css$/,
        use: ['style-loader','css-loader']
      }
    ]
  }
};
```

执行打包命令，此时在浏览器中打开 dist/index.html 发现页面可以正常展示我们设置的样式，我们在控制台可以看到样式被插入到 head 标签中。

![1.png](https://pic.leetcode-cn.com/1655715388-rMhlfZ-1.png)
![2.png](https://pic.leetcode-cn.com/1655710417-NiFgBX-2.png)
<br>
## 配置项

style-loader 包含下面几个配置项

|  参数名称  |  支持类型   |       默认值          |   功能描述 
| --------- | ----------- | ----------- | ----------- |
|  injectType  |  String   |  styleTag  | 如何将样式注入到 DOM 中
|  attributes  |  Object  | {} | 向标签添加自定义属性
|  insert  |   String、Function  | head | 在 DOM 中给定的位置插入标签
|  styleTagTransform  |  String、Function  | undefined | 当插入 style 标签到 DOM 时转换标签和 css
|  esModule  |  Boolean  | true | 使用 ES 模块语法
|  base  |  Number  | true | 设置模块ID基数(DLLPlugin)
<br>
###  injectType

设置样式如何注入 DOM，默认为 styleTag，即使用多个<style></style> 模式。

|  模式配置  |   功能描述 
| --------- | ----------- |
|  styleTag  |  多个 <style></style> 模式
|  singletonStyleTag | 单个 <style></style> 模式
|  autoStyleTag  | 与 styleTag 相同，但如果在 IE6-9 中执行，则打开 singletonStyleTag 模式。
|  lazyStyleTag | 按需加载模式插入多个 <style></style> 模式 
|  lazySingletonStyleTag  | 按需加载模式插入单个 <style></style> 模式
|  lazyAutoStyleTag  | 与 lazyStyleTag 相同，但如果在 IE6-9 中执行，则打开 lazySingletonStyleTag 模式。
| linkTag | 多个 <link rel="stylesheet" href="path/to/file.css"> 形式插入 DOM

<br>
#### styleTag

src/index.css

```css
@import url('style.css');
.bar {
    color: blue;
}
```

src/style.css

```css
.foo {
    color: red;
}
```

webpack.config.js

```javascript
module.exports = {
  ...
  {
    test: /\.(css)$/,
    use: [
      {
        loader: 'style-loader',
        options: { injectType: "styleTag" }
      }, 'css-loader'
    ]
  }
};
```

index.js

```javascript
import index from "./index.css";

const divElement = document.createElement("div");
divElement.className = "foo";
divElement.innerHTML = 'style-loader'
document.body.appendChild(divElement)
```
执行打包命令，在浏览器中打开 dist/index.html 文件，我们可以看到 head 中插入了两个 style 标签，div 中的文字颜色可以正常显示。

![3.png](https://pic.leetcode-cn.com/1655704064-BOjtxr-3.png)
<br>
#### singletonStyleTag

将多个样式文件内容在一个 style 标签中插入 DOM。

webpack.config.js

```javascript
module.exports = {
  ...
  {
    test: /\.(css)$/,
    use: [
      {
        loader: 'style-loader',
        options: { injectType: "singletonStyleTag" }
      }, 'css-loader'
    ]
  }
};
```

![4.png](https://pic.leetcode-cn.com/1655704064-QFOJaJ-4.png)
<br>
####  lazyStyleTag

<style></style> 按需注入到 DOM 。建议遵循 .lazy.css 惰性样式的命名约定和 .css 基本style-loader用法。当使用 lazyStyleTag 时，可以通过 style-loader 的 style.use()、style.unuse() 按需使用。

src/style.lazy.css

```css
.foo {
    color: red;
}
```

src/index.js

```javascript
import styles from "./style.lazy.css";
styles.use();
const divElement = document.createElement("div");
divElement.className = "foo";
divElement.innerHTML = 'style-loader'
document.body.appendChild(divElement)
```

webpack.config.js
```javascript
module.exports = {
...
 {
    test: /\.(css)$/,
    use: [
      {
        loader: 'style-loader',
        options: { injectType: "lazyStyleTag" }
      }, 'css-loader'
    ]
  }
};
```

打包后，可以看到样式被插入到 DOM，并且颜色已生效，如果 index.js 中没有调用 styles.use()，则样式不会被插入到 DOM。
<br>
###  attributes

将指定的属性值附加到 <style> 或 <link> 标签

webpack.config.js
```javascript
{
  loader: 'style-loader',
  options: { attributes: {id: 'styleLoader'} }
}
```

![5.png](https://pic.leetcode-cn.com/1655704064-PSQoUz-5.png)

<br>
###  insert

默认情况下 style-loader 会将<style>、<link> 标签插入到 <head> 标签尾部，设置 insert 后，可以将样式标签插入到其他位置。

webpack.config.js
```javascript
{
  loader: 'style-loader',
  options: { insert: 'body' }
}
```

![6.png](https://pic.leetcode-cn.com/1655704064-YppEjv-6.png)
<br>
###  styleTagTransform

当插入 style 标签到 DOM 时转换标签和 css，可以设置自定义方法解析 style 标签插入方式。

webpack.config.js
```javascript
{
  ...
    loader: 'style-loader',
    options: { styleTagTransform: function(css, style) {
      style.innerHTML = `${css}.modify{}\n`
      document.head.appendChild(style)
    } 
}
```

打包后，在浏览器中打开 dist/index.html，我们可以看到 css 样式后面添加了我们在方法中书写的内容。

![7.png](https://pic.leetcode-cn.com/1655704064-uATShJ-7.png)
<br>
###  esModule

style-loader 中生成 esModule 模块化的形式是有益的，比如 tree-shacking 时必须使用 esModule 模式才会生效。如果想启用 CommonJS 模块语法，则 esModule 设置为 false。

webpack.config.js
```javascript
{
  ...
  options: {
    esModule: true
  }
}
```
<br>
###  base

当使用一个或多个 DllPlugin 时，此设置主要用作 css 冲突的解决方法。允许您通过指定大于 DllPlugin1 使用的范围的 css 模块 ID 基数来防止 app 的 css（或DllPlugin2 的 css）覆盖 DllPlugin1 的 css

webpack.dll1.config.js
``` javascript
{
  ...
  use: ["style-loader", "css-loader"],
}
```

webpack.dll2.config.js
``` javascript
{
  ...
  use: [
    { loader: "style-loader", options: { base: 1000 } },
    "css-loader",
  ],
}
```

webpack.app.config.js
``` javascript
{
  ...
  use: [
    { loader: "style-loader", options: { base: 2000 } },
    "css-loader",
  ],
}
```
<br>
# 总结

本节我们介绍了 style-loader 的使用方法和 style-loader 包含的几个常用参数配置。style-loader 一般和 css-loader 配合使用。

## Postcss-Loader
#  postcss-loader

在使用 postcss-loader 之前，我们先来了解下 [PostCSS](https://postcss.org/)。以下摘自 PostCSS 简介。

```text
PostCSS 是一个允许使用 JS 插件转换样式的工具。 这些插件可以检查（lint）你的 CSS，支持 CSS Variables 和 Mixins， 编译尚未被浏览器广泛支持的先进的 CSS 语法，内联图片，以及其它很多优秀的功能。PostCSS 的 Autoprefixer 插件是最流行的 CSS 处理工具之一。
```

由此我们可以知道通过使用 PostCSS 和 相应的插件，我们可以完成样式格式化、自动根据浏览器的支持情况增加样式前缀、使用先进的 CSS 特性等很多优秀的功能，截止到目前，PostCSS 有 200 多个插件。你可以在 [插件列表](https://github.com/postcss/postcss/blob/main/docs/plugins.md) 找到他们。如果我们想在 webpack 中使用 PostCSS 及 相应插件完成我们想要的功能，这时就需要通过 postcss-loader 来处理。
<br>
## 使用

index.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>postcss-loader</title>
</head>
<body>
</body>
</html>
```

index.js

src/index.js 文件中使用 import 导入 index.css 并输出导入的样式内容。

```javascript
import indexCss from "./index.css";
```

index.css

```css
body {
 display: flex;
}
```

安装 postcss-loader 和 postcss

```javascript
npm install postcss-loader postcss -D
```

安装成功后，将 postcss-loader 配置到 webpack.config.js 中，postcss-loader 通过加载插件转换 css 内容，转换后的内容虽然是 .css 文件，但是仍需传递给 css-loader 做后续处理。

```javascript
module.exports = {
  ...
   module: {
    rules: [
      {
        test: /\.(css)$/,
        use: ['style-loader', 'css-loader', 'postcss-loader']
      }
    ]
  }
};
```

以上只是将 postcss-loader 配置到了 webpack 中，执行打包命令可以正常打包，但 css 内容不会发生变化，postcss-loader 需要通过插件来达到我们想要的效果，下面我们以自动添加前缀为例看下效果。

安装 autoprefixer

```javascript
npm install autoprefixer -D
```

postcss.config.js

项目根目录下新建 postcss.config.js 文件，配置 autoprefixer 插件，和要对应的浏览器版本。其中 browsers 的配置可以配置到 package.json 或者 .browserslistrc 文件下，如果配置到 postcss.config.js 中打包时会有警告，不过我们为了演示 autoprefixer 效果，不对此做处理。

```javascript
module.exports = {
    plugins: [
      require('autoprefixer')({
        'browsers': ['> 1%', 'last 2 versions']
      })
    ]
};
```

配置完成后，执行打包命令，打包成功后在浏览器中打开 dist/index.html 文件，在控制台中我们可以看到，样式代码已经自动增加前缀。

![1.png](https://pic.leetcode-cn.com/1655704774-Lklqfv-1.png)
<br>
## 配置项

postcss-loader 包含下面几个配置项

- execute
- postcssOptions
- sourceMap
- implementation

<br>
###  execute

默认：undefined

值类型：Boolean

作用：在 CSS-in-JS 中，如果您想要处理在 JavaScript 中书写的样式，需要使用 postcss-js 解析器，添加 execute 选项并设置为 true。

webpack.config.js
```javascript
module.exports = {
  ...
   {
      loader: "postcss-loader",
      options: {
        postcssOptions: {
          parser: "postcss-js",
        },
        execute: true,
      },
    }
};
```
<br>
###  postcssOptions

默认：undefined

值类型：Object | Function

作用：允许设置 PostCSS options 和插件。支持所有PostCSS选项。

webpack.config.js
```javascript
module.exports = {
  ...
   {
      loader: "postcss-loader",
      options: {
        // object
        postcssOptions: {
          ...
        }
        // function
        postcssOptions: (loaderContext) => {
          return {
            ...
          }
        }
      },
    }
};
```
<br>
###  sourceMap

默认：取决于 [devtool](https://webpack.js.org/configuration/devtool/) 选项

值类型：Boolean

作用：是否开启 sourceMap

webpack.config.js
```javascript
module.exports = {
  ...
   {
      loader: "postcss-loader",
      options: {
        sourceMap: true
      },
    }
};
```
<br>
###  implementation

默认：postcss

值类型：Function | String

作用：implementation 选项决定使用哪个 PostCSS 实现。覆盖本地安装的 postcss 的 peerDependency 版本

webpack.config.js
```javascript
module.exports = {
  ...
   {
      loader: "postcss-loader",
      options : {  implementation : require ( "postcss" )  }
    }
};
```

<br>
# 总结

本节我们介绍了 postcss-loader 的使用方法，postcss-loader 主要是 PostCSS 在 webpack 环境下的使用方法，通过加载不同的插件来达到处理样式文件的效果，PostCSS 支持的插件非常丰富，本文只是通过自动添加前缀的例子做一个展示，想看其他插件的使用方法可以去 PostCSS 官网查看。

## Sass-Loader
#  sass-loader

## [Sass](https://www.sasscss.com/documentation)

```text
sass 是一种 css 的预编译语言。它提供了 变量（variables）、嵌套（nested rules）、 混合（mixins）、 函数（functions）等功能，并且完全兼容 css，sass 能够帮助复杂的样式表更有条理，并且易于在项目内部或跨项目共享设计。
```

当 css 变得越来越臃肿、 越来越复杂、越来越难以维护时 sass 为我们提供了 css 中不存在的特性辅助我们编写健壮、 可维护的 css 代码。

在使用 sass 之前，需要在项目中安装它，而 sass-loader 的作用是加载 sass/scss 文件并将其编译为 css，通过将 style-loader 和 css-loader 与 sass-loader 链式调用，可以立刻将样式作用在 DOM 元素。
<br>
## 使用

index.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <title>sass-loader</title>
</head>
<body>
  <p>hello sass</p>
</body>
</html>
```

index.js

src/index.js 文件中使用 import 导入 index.scss。

```javascript
import indexCss from "./index.scss";
```

index.scss

sass 和 scss 其实是同一种东西，我们平时都称之为 sass，不过两者之间写法也存在些区别，感兴趣的小伙伴儿可自行查阅，我们本案例都以 scss 为例。

```scss
$primary-color: #f00;

body {
  color: $primary-color;
}
```

安装 sass-loader 和 sass

```javascript
npm install sass-loader sass --save-dev
```

安装成功后，将 sass-loader 配置到 webpack.config.js 中。

```javascript
module.exports = {
  ...
   module: {
    rules: [
      {
        test: /\.scss$/,
        use: ['style-loader', 'css-loader', 'sass-loader']
      }
    ]
  }
};
```

执行打包命令后，在浏览器打开 dist/index.html 文件，我们可以看到我们在 index.scss 文件中定义的颜色常量被正确的显示到了标签上面，在控制台可以看到，color 的颜色属性已由定义的变量转换成了定义的颜色值。

![4.png](https://pic.leetcode-cn.com/1655972361-xCPFRy-4.png)
![5.png](https://pic.leetcode-cn.com/1655972355-lPHDnq-5.png)

<br>
## 配置项

sass-loader 可以通过指定 options 参数，向 sass 传递选项参数。

- implementation
- sassOptions
- sourceMap
- additionalData
- webpackImporter
- warnRuleAsWarning

<br>
###  implementation

默认值：sass

值类型：Object | String

作用：sass-loader 要使用的 sass 实现。默认情况下，sass-loader 会根据你的依赖解析需要使用的实现。 只需将必需的实现添加到 package.json（sass 或 node-sass 包）中并安装依赖项即可。

package.json

```javascript
// sass-loader 将会使用 sass 实现
{
  "devDependencies": {
    "sass-loader": "^7.2.0",
    "sass": "^1.22.10"
  }
}
```

package.json

```javascript
// sass-loader 将会使用 node-sass 实现
{
  "devDependencies": {
    "sass-loader": "^7.2.0",
    "node-sass": "^5.0.0"
  }
}
```

同时安装 node-sass 和 sass 的情况下，sass-loader 默认会选择 sass。 为了避免这种情况，你可以使用 implementation 选项。

webpack.config.js
```javascript
module.exports = {
  ...
   {
      loader: "sass-loader",
      options: {
        // Object
        implementation: require('sass')
        // String
        implementation: require.resolve('sass')
      },
    }
};
```
<br>
###  sassOptions

默认值：sass 实现的默认值

值类型：Object | Function

作用：设置 sass 实现的启动选项。

在使用他们之前，请查阅有关文档：[Dart Sass](https://github.com/sass/dart-sass#javascript-api) 文档提供了所有可用的 sass 选项。

webpack.config.js
```javascript
module.exports = {
  ...
  {
    {
      loader: "sass-loader",
      options: {
        // Object
        sassOptions: {
          includePaths: ['absolute/a', 'absolute/b'],
        },
        // Function
        sassOptions: (loaderContext) => {
          // 有关可用属性的更多信息 https://webpack.js.org/api/loaders/
          ...
          return {
            includePaths: ['absolute/a', 'absolute/b'],
          };
        },
      },
    }
  }
};
```
<br>
###  sourceMap

默认值：取决于 complier.devtool值，值为 false 和 eval 时，不会生成 source map。

值类型：Boolean

作用：是否开启 sourceMap

webpack.config.js
```javascript
module.exports = {
  ...
   {
      loader: "sass-loader",
      options: {
        sourceMap: true
      },
    }
};
```
<br>
###  additionalData

默认值：undefined

值类型： String | Function

作用：在实际的文件之前要添加的 sass / scss 代码。下面的示例中，$width、$value 可以在 index.scss 中直接引用。

webpack.config.js
```javascript
module.exports = {
  ...
  {
    loader: "sass-loader",
    options : {  
      // String
      additionalData: '$width:' + process.env.NODE_ENV + ';',
      // Function sync
      additionalData: (content, loaderContext) => {
        ...
        return '$value: 100px;' + content;
      }
      // Function async 
      additionalData: async (content, loaderContext) => {
        ...
        return '$value: 100px;' + content;
      }
    }
  }
};
```
<br>
###  webpackImporter

默认值：true

值类型： Boolean

作用：开启 / 关闭默认的 Webpack importer。在某些情况下，可以提高性能。但是请谨慎使用，因为 aliases 和以 〜 开头的 @import 规则将不起作用。 你可以传递自己的 importer 来解决这个问题（参阅 [importer docs](https://github.com/sass/node-sass#importer--v200---experimental)）。

webpack.config.js
```javascript
module.exports = {
  ...
  {
    loader: "sass-loader",
    options : {  
      webpackImporter: false,
    }
  }
};
```
<br>
###  warnRuleAsWarning

默认值：false (在下一个大版本发布中它将默认设置为 true)

值类型： Boolean

作用：将 @warn 规则视为 webpack 警告而不是日志。

index.scss

```scss
$known-prefixes: webkit, moz, ms, o;

@mixin prefix($property, $value, $prefixes) {
  @each $prefix in $prefixes {
    @if not index($known-prefixes, $prefix) {
      @warn "Unknown prefix #{$prefix}.";
    }

    -#{$prefix}-#{$property}: $value;
  }
  #{$property}: $value;
}

body {
  @include prefix('display', 'flex', 'a');
}
```

webpack.config.js
```javascript
module.exports = {
  ...
   {
      loader: "sass-loader",
      options : {  
        warnRuleAsWarning: true,
      }
    }
};
```

在上面的例子中，我们 $prefixes 值传入 a，执行打包命令，虽然可以打包成功，但是控制台会输出警告，如果我们将 $prefixes 值传入 $known-prefixes 中定义的 o，则控制台不会显示警告。
<br>
# 总结

本节我们介绍了 sass-loader 的使用方法和一些配置参数。通过使用 sass-loader 和 sass 可以让我们让我们的样式表更有条理并且易于维护。

## Svg-URL-Loader
#  svg-url-loader

svg-url-loader 可以将 svg 文件加载为 utf-8 编码的 data-uri 字符串。url-loader 也可以加载 svg 文件，和 svg-url-loader 的区别是 url-loader 将 svg 文件加载为 base64 编码的字符串。

utf-8 编码相对于 base64 编码有一些优势。

- 编译结果字符串更短（对于 2K 大小的图标，可以缩短约 2 倍）；
- 使用 gzip 压缩时，生成的字符串将被更好地压缩；
- 浏览器解析 utf-8 编码的字符串比 base64 编码的字符串更快；
<br>
## 使用

index.html 

```html
<!DOCTYPE html>
<html lang="en">
    <header>
        <title>svg-url-loader</title>
    </header>
    <body>
        <img id="svg-loader" />
    </body>
</html>
```

index.js

```javascript
import svgContent from './img/headIcon.svg';

window.document.getElementById('svg-loader').src = svgContent;
```

安装 svg-url-loader

```javascript
npm install svg-url-loader --save-dev
```

安装成功后，将 svg-url-loader 配置到 webpack.config.js 中。

```javascript
module.exports = {
  ...
   module: {
    rules: [
      {
        test: /\.svg/,
        use: {
          loader: "svg-url-loader",
        },
      }
    ]
  }
};
```

执行打包命令后，在浏览器打开 dist/index.html 文件，我们可以看到 svg 图片被展示在页面是上，打开 dist/main-[hash].js 文件可以看到 svg 图片被编译成了 utf-8 编码的字符串。
<br>
## 配置项

svg-url-loader 包含下面参数。

- limit
- stripdeclarations
- iesafe
- encoding
<br>
###  limit

默认值：无

值类型：Number

作用：当设置 limit，如果源文件的内容大于这个限制，svg-url-loader 将不编码源文件。如果文件大于 limit 设置的限制，将使用 file-loader 加载文件，svg-url-loader 中设置的参数会传递给 file-loader。

webpack.config.js
```javascript
module.exports = {
  ...
  {
    test: /\.svg/,
    use: {
      loader: "svg-url-loader",
      options: {
        limit: 1024 // 文件大小 1M
      }
    }
  }
};
```
<br>
###  stripdeclarations

默认值：true

值类型：Boolean

作用：它将在下一个主要版本中被删除，删除所有 XML 声明。例如：svg 图片开头的 <?xml version="1.0" encoding="UTF-8"?>。

webpack.config.js
```javascript
module.exports = {
  ...
  {
    test: /\.svg/,
    use: {
      loader: "svg-url-loader",
      options: {
        stripdeclarations: false
      }
    }
  }
};
```
<br>
###  iesafe

默认值：无

值类型：Boolean

作用：当 iesafe 选项设置为 true，svg-url-loader 在编译文件时，如果文件包含一个样式元素并且编码大小超过 4kB，则无论指定的限制如何，都使用 file-loader 编译。因为 ie 浏览器包括 ie11 已经停止解析 svg 数据中的样式元素和大小超过 4kb 的文件，会导致所有样式的形状都是黑色填充。

webpack.config.js
```javascript
module.exports = {
  ...
   {
      loader: "svg-url-loader",
      options: {
        iesafe: true
      },
    }
};
```
<br>
###  encoding

默认值："none"

值类型："none" ｜ "base64"

作用：设置 svg-url-loader 构造数据 URI 时要使用的编码。

webpack.config.js
```javascript
module.exports = {
  ...
  {
    loader: "svg-url-loader",
    options: {
      encoding: "base64"
    },
  }
};
```
<br>
# 总结

本节我们介绍了 svg-url-loader 的使用方法和一些配置参数。svg-url-loader 主要用来编译 svg 格式文件，默认采用 utf-8 编码。

## Svg-Sprite-Loader
#  svg-sprite-loader

svg-sprite-loader 作用是合并多个单个的 svg 图片为一个 sprite 雪碧图，并把合成好的内容，插入到 html 内，其原理是利用 svg 的 symbol 元素，将每个 svg 图片 包括在 symbol 中，通过 use 元素使用该 symbol。[svg](https://developer.mozilla.org/zh-CN/docs/Web/SVG/Element) 元素参考。
<br>
## 使用

index.html 

在 index.html 中，通过使用 svg 的 use 元素渲染两张 svg 图片，分别对应 img 文件夹下的 headIcon.svg 和 home.svg。

```html
<!DOCTYPE html>
<html>
  <header>
    <title>svg-sprite-loader</title>
  </header>
  <body>
    <svg>
      <use xlink:href="#headIcon"></use>
    </svg>    
    <svg>
      <use xlink:href="#home"></use>
    </svg>        
  </body>
</html>
```

index.js

导入 index.html 中 use 元素加载的两张 svg 图片。

```javascript
import svgContent from './img/headIcon.svg';
import svgHome from './img/home.svg';
```

安装 svg-sprite-loader

```javascript
npm install svg-sprite-loader --save-dev
```

安装成功后，将 svg-sprite-loader 配置到 webpack.config.js 中。

```javascript
module.exports = {
  ...
   module: {
    rules: [
      {
        test: /\.svg/,
        use: {
          loader: "svg-sprite-loader"
        },
      }
    ]
  }
};
```

执行打包命令后，在浏览器打开 dist/index.html 文件，我们可以看到 svg 图片被展示在页面上，在控制台查看 elements 选项，可以看到两个 svg 图片被包裹在 两个 symbol 标签中，使用时通过 use 标签传入 symbol 元素 id 来显示不同的 svg 图片。
<br>
## 配置项

svg-sprite-loader 包含下面基础参数配置。

- symbolId
- symbolRegExp
- esModule
<br>
###  symbolId

默认值：[name]

值类型：String | Function

作用：设置 svg 标签中 symbol 元素的 id 值。

html
```html
<svg>
    <use xlink:href="#icon-headIcon"></use>
</svg> 
```

webpack.config.js
```javascript
module.exports = {
  ...
  {
    test: /\.svg/,
    use: {
      loader: "svg-sprite-loader",
      options: {
        // string
        symbolId: 'icon-[name]'
        // function
        symbolId: filePath => path.basename(filePath)
      }          
    }
  }
};
```
<br>
###  symbolRegExp

默认值：''

值类型：String

作用：传递给 symbolId 插值器以支持 loader-utils 名称插值器中的 [N] 模式。
<br>
###  esModule

默认值：true

值类型：Boolean

作用：是否使用 esModule 语法。如果使用 CommonJS 语法则参数设置为 false。

webpack.config.js
```javascript
module.exports = {
  ...
   {
      loader: "svg-sprite-loader",
      options: {
        esModule: true
      },
    }
};
```

svg-sprite-loader 还支持[运行时配置](https://github.com/JetBrains/svg-sprite-loader#runtime-configuration)和[提取配置](https://github.com/JetBrains/svg-sprite-loader#extract-configuration)，想了解的小伙伴儿可自行查阅文档。
<br>
# 总结

本节我们介绍了 svg-sprite-loader 的使用方法和一些配置参数。svg-sprite-loader 主要用来将从 css/scss/sass/less/styl/html 导入的图像生成外部 sprite 文件，通过使用 svg 的 use 元素展示 图像内容。达到统一管理的目的。

## VUE-Loader
#  vue-loader

Vue Loader 是一个 webpack 的 loader，它允许你以一种名为单文件组件 (SFCs)的格式撰写 Vue 组件。

Vue Loader 还提供了很多酷炫的特性：
- 允许为 Vue 组件的每个部分使用其它的 webpack loader，例如在 <style> 的部分使用 Sass 和在 <template> 的部分使用 Pug；
- 允许在一个 .vue 文件中使用自定义块，并对其运用自定义的 loader 链；
- 使用 webpack loader 将 <style> 和 <template> 中引用的资源当作模块依赖来处理；
- 为每个组件模拟出 scoped CSS；
- 在开发过程中使用热重载来保持状态；

<br>
## 使用

在下面的例子中，正常要使用 [Vue.js](https://cn.vuejs.org/) 将组件渲染到页面上。但是这样会增加一些额外的代码，容易混淆，所以下面的例子只是完成打包不报错即认为 vue-loader 起到了作用。

index.html 

```html
<!DOCTYPE html>
<html>
    <head>
        <title>vue-loader</title>
    </head>
    <body>
    </body>
</html>
```

index.vue

```javascript
<template>
  <div class="demo">{{ msg }}</div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'Hello world!'
    }
  }
}
</script>

<style>
.demo {
  color: blue;
}
</style>
```

安装 vue-loader

vue-loader 需要配合 [vue-template-compiler](https://www.npmjs.com/package/vue-template-compiler) 一起使用。

```javascript
npm install vue-loader vue-template-compiler --save-dev
```

安装成功后，将 vue-loader 配置到 webpack.config.js 中。

```javascript
module.exports = {
...
// webpack.config.js
const { VueLoaderPlugin } = require('vue-loader');

module.exports = {
    ...
    module: {
        rules: [
            {
                test: /\.vue$/,
                loader: 'vue-loader',
            },
            // 它会应用到普通的 `.css` 文件
            // 以及 `.vue` 文件中的 `<style>` 块
            {
                test: /\.css$/,
                use: [
                    'style-loader',
                    'css-loader'
                ]
            }
        ]
    },
    plugins: [
         // 请确保引入这个插件！
         // 这个插件是必须的！它的职责是将你定义过的其它规则复制并应用到 .vue 文件里相应语言的块。例如，如果你有一条匹配 /\.js$/ 的规则，那么它会应用到 .vue 文件里的 <script> 块。
         new VueLoaderPlugin()
    ]
};
```

执行打包命令后，控制台显示编译成功。
<br>
## 配置项

vue-loader 参数配置。

- transformAssetUrls
- compiler
- compilerOptions
- transpileOptions
- optimizeSSR
- hotReload
- productionMode
- shadowMode
- cacheDirectory / cacheIdentifier
- prettify
- exposeFilename

vue-loader 的配置项官网显示很清楚，大家可以去官网查看，[vue-loader配置](https://vue-loader.vuejs.org/zh/options.html#transformasseturls)。
<br>
# 总结

vue-loader 的总结大部分源自[官网介绍](https://vue-loader.vuejs.org/)，通过上面的使用我们可以完成一个简单的 vue-loader 配置及使用。

## VUE-Style-Loader
#  vue-style-loader

vue-style-loader 是基于 style-loader 的分支，功能与 style-loader 类似，都可以与 css-loader 链接将 style 标签注入到文档中，vue-style-loader 一般不需要自己配置加载，因为他已经作为依赖项包含在 vue-loader 中。vue-style-loader 除了将 style 注入到文档中，还做了一些服务端渲染的支持，所以如果我们 vue 项目中需要做服务端渲染，可能就要使用 vue-style-loader 来插入样式了。

<br>
## 使用

vue-style-loader 的使用方法与 style-loader 类似。都是与 css-loader 链接起来使用。

index.html 

```html
<!DOCTYPE html>
<html>
    <head>
        <title>vue-style-loader</title>
    </head>
    <body>
    </body>
</html>
```

index.js

```javascript
import indexCss from "./index.css";
const divElement = document.createElement("div");
divElement.className = "demo";
divElement.innerHTML = 'vue-style-loader';
document.body.appendChild(divElement);
```

index.css

```css
.demo {
    color: red;
}
```

安装 vue-style-loader

```javascript
npm install vue-style-loader --save-dev
```

安装成功后，将 vue-style-loader 配置到 webpack.config.js 中。

```javascript
module.exports = {
...
  rules: [
    {
      test: /\.css$/,
      use: [
          'vue-style-loader',
          'css-loader'
      ]
    }
  ]
};
```

打包成功后，打开 dist/index.html 可以看到浏览器中文字颜色已经变成红色，在控制台 element 中可以看到 index.css 中的样式属性已经被包裹了 style 标签并插入到 head 中。
<br>
## 配置项

vue-style-loader 参数配置。

- manualInject
- ssrId
<br>
### manualInject

默认值：无

值类型：Boolean

作用：当 manualInject 参数值为 true 时，导入的样式对象会提供一个__inject__方法，然后可以在适当的时间手动调用该方法。此方法接收一个对象参数，最后将样式文件内容绑定到传入的对象上。
```text
注意：只有运行环境为 Node.js 且 manualInject 为 true 时，样式对象才会提供__inject__方法。
```

webpack.config.js
```javascript
module.exports = {
  ...
  {
    test: /\.svg/,
    use: [
      {
        loader: 'vue-style-loader',
        options: {
          manualInject: true,
        }
      },
    ]
  }
};
```
<br>
### ssrId

默认值：无

值类型：Boolean

作用：向 style 标签添加 data-vue-ssr-id 属性，可以用作预渲染避免样式重复注入。

webpack.config.js
```javascript
module.exports = {
  ...
  {
    test: /\.svg/,
    use: [
      {
        loader: 'vue-style-loader',
        options: {
          ssrId: true
        }
      },
    ]
  }
};
```
![1.png](https://pic.leetcode-cn.com/1655707832-TLxisk-1.png)
<br>
## 区别于 style-loader

- 如果你正在构建一个 Vue SSR 应用程序，你可能也应该使用这个加载器来处理从 JavaScript 文件导入的 CSS
- 不支持 url 模式和引用计数模式。还删除了 singleton 和insertAt 查询选项。不支持样式懒加载。如果您需要这些功能，您可能应该使用原始功能 style-loader。

<br>
# 总结

本章节我们介绍了 vue-style-loader 的使用、配置和它与 style-loader 的区别，vue-style-loader 支持 vue 中的 ssr（服务端渲染），所以如果需要支持服务端渲染的 vue 项目，就需要用到 vue-style-loader 了。但是如果是一般的项目，style-laoder 的功能会更多些。


# 核心概念-Plugin


## DefinePlugin
#  DefinePlugin

```text
DefinePlugin 允许在编译时将你代码中的变量替换为其他值或表达式。这在需要根据开发模式与生产模式进行不同的操作时，非常有用。例如，如果想在开发构建中进行日志记录，而不在生产构建中进行，就可以定义一个全局常量去判断是否记录日志。这就是 DefinePlugin 的发光之处，设置好它，就可以忘掉开发环境和生产环境的构建规则。
```
<br>
## 使用

index.html 

```html
<!DOCTYPE html>
<html>
    <head>
        <title>DefinePlugin</title>
    </head>
    <body>
    </body>
</html>
```

index.js

我们将 webpack 中传入 DefinePlugin 中的参数打印出来。

```javascript
console.log(PRODUCTION)
console.log(DEVELOPMENT)
console.log(VERSION)
console.log(BROWSER_SUPPORTS_HTML5)
console.log(TWO)
console.log(typeof window)
console.log(process.env.NODE_ENV)
```

webpack.config.js

DefinePlugin 是 webpack 提供的插件，所以不需要单独安装，直接在 webpack 包中引入即可。

```javascript
...
const webpack = require('webpack');

module.exports = {
  ...
  plugins: [
        ...
        new webpack.DefinePlugin({
            PRODUCTION: function() {console.log(111)},
            DEVELOPMENT: {
                name: 1,
                value: 2
            },
            VERSION: JSON.stringify('5fa3b9'),
            BROWSER_SUPPORTS_HTML5: true,
            'TWO': '1+1',
            'typeof window': JSON.stringify('object'),
            'process.env.NODE_ENV': JSON.stringify("development")
        })
    ]
};
```

执行打包命令后，我们在浏览器查看输出结果。

```javascript
console.log(PRODUCTION) // ƒ () {console.log(111)}
console.log(DEVELOPMENT) // {name: 1, value: 2}
console.log(VERSION) // 5fa3b9 
console.log(BROWSER_SUPPORTS_HTML5) // true
console.log(TWO) // 2
console.log(typeof window) // object
console.log(process.env.NODE_ENV) // development
```
<br>
## 使用规则

传递给 DefinePlugin 的每个键都是一个标识符或多个以 . 连接的标识符。
  - 如果该值为字符串，它将被作为代码片段来使用。
  - 如果该值不是字符串，则将被转换成字符串（包括函数方法）。
  - 如果值是一个对象，则它所有的键将使用相同方法定义。
  - 如果键添加 typeof 作为前缀，它会被定义为 typeof 调用。

```text
警告：在为 process 定义值时，'process.env.NODE_ENV': JSON.stringify('production') 会比 process: { env: { NODE_ENV: JSON.stringify('production') } } 更好，后者会覆盖 process 对象，这可能会破坏与某些模块的兼容性，因为这些模块会在 process 对象上定义其他值。
```

DefinePlugin 插件提供的功能在实际项目中将非常实用，通过传入标识符可以在生产/开发构建中开启/关闭不同特性。通过标识符传入的参数经过 webpack 压缩后可以只保留标识符为 true 的代码片段。可以通过传入服务地址来区分生产/开发。

开启/关闭特性

```javascript
// NICE_FEATURE: JSON.stringify(true),
if (!NICE_FEATURE) {
  console.log('bad feature info');
}
if (NICE_FEATURE) {
  console.log('nice feature log');
}
// 经过压缩后：
console.log('nice feature log');
```

区分服务地址

```javascript
if (process.env.NODE_ENV === 'development') {
  console.log('development service url');
}

if (process.env.NODE_ENV === 'product') {
  console.log('product service url');
}
```
<br>
# 总结

通过上面的例子，我们可以看到 DefinePlugin 就是帮助我们将传入的参数值替换到代码中，通过传入的内容做判断，最后保留下正确的代码片段。可以让我们针对不同环境和不同特性做不同的处理。

## HtmlWebpackPlugin
#  DllPlugin

DllPlugin 是一个 webpack 插件，html-webpack-plugin 可以自动创建 html 文件，也支持使用 html 文件模版。html-webpack-plugin 会自动将所有必要的 css、javascript、manifest 和 favicon 文件注入到生成的 html 文件中。html-webpack-plugin 还提供了 [hooks](https://github.com/jantimon/DllPlugin#events) 来扩展功能。已经有很多零配置的插件可以继承进来。[插件列表](https://github.com/jantimon/DllPlugin)。
<br>
## 使用

使用下面的例子我们完成使用 DllPlugin 插件自动生成 index.html 文件。

安装 DllPlugin

```javascript
npm install DllPlugin --save-dev
```

index.js

```javascript
console.log('DllPlugin');
```

webpack.config.js

```javascript
module.exports = {
...
  const HtmlWebpackPlugin = require('DllPlugin');
  entry: {
      index: './src/index.js',
  },
  output: {
    ...
    filename: '[name]-[hash].js'
  }
  plugins: [
        ...
        new HtmlWebpackPlugin()
    ]
};
```

执行打包命令后，在 dist 文件及下可以看到生成了一个 index.html 文件，入口文件 index.js 被编译成 index-[hash].js 文件名的文件，并且在 index-[hash].js 通过 script 标签插入到了 index.html 中。

<br>
## 配置

###  title | filename | template

默认值：Webpack App ｜ 'index.html' ｜ ''

值类型：String | String、Function | String

作用：title 配置项传入的内容会插入到生成的 html 文件的 title 标签中，即 html 文件的标题。filename 配置项传入的内容为生成的 html 文件的名字，默认为 index.html。template 配置项传入的内容为使用的模版 html，如本地存在 index.html 则 DllPlugin 将以本地 index.html 作为模版生成新的 html 文件。

webpack.config.js
```javascript
module.exports = {
  ...
module: {
  loaders: [
    { test: /\.hbs$/, loader: "handlebars-loader" }
  ]
},
  plugins: [
    new HtmlWebpackPlugin({
        // string
        filename: 'index.[contenthash].html',
        // function
        filename: (entryName) => entryName + '-test.html',
        title: 'DllPlugin',
        template: './index.html',
        // 使用 handlebars-loader 加载器解析 hbs 模版
        template: 'index.hbs'
    })
  ]
};
```

在使用本地模版并且定义了 title 的情况下，本地模版的 html 文件中的 title 标签要使用下面的写法，生成的 html 文件中 title 才会生效。

本地 index.html 模版

```html
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><%= htmlWebpackPlugin.options.title %></title>
  <body>
  </body>
</html>
```
<br>
###  templateContent

默认值：false

值类型：string | Function | false

作用：templateContent 传入内容可作为生成的 html 文件的模版，可替换 template 使用，但是 templateContent 不允许为您的模板使用 webpack 加载器，并且不会监视模板文件的更改。

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      title: 'DllPlugin',
      templateContent: `
          <html>
          <title><%= htmlWebpackPlugin.options.title %></title>
          <body>
              <h1>Hello World</h1>
          </body>
          </html>
      `
    })
  ]
};
```
<br>
###  templateParameters

默认值：false

值类型：Boolean | Object | Function

作用：覆盖模板中使用的参数。

本地 index.html 模版

```html
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><%= foo %></title>
  <body>
  </body>
</html>
```

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
        template: './index.html',
        templateParameters: {
            'foo': 'DllPlugin'
        },
    })
  ]
};
```

打包成功后，生成的 index.html 文件中的 <%= foo %> 被替换成了 ”html-webpack-plugin“。
<br>
###  inject

默认值：true

值类型：Boolean | String

作用：通过设置 inject 不同的参数，来指定 CSS、JS、manifest 和 favicon 等文件注入到模版文件的位置。

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
        inject: false // 不注入
        inject: 'head' // 注入到 head 标签中
        inject: 'body' // 注入到 body 标签中
    })
  ]
};
```
<br>
###  publicPath

默认值：'auto'

值类型：'auto' | String

作用：脚本文件注入到模版中时，增加 publicPath 传入的路径

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      // <script defer src="/javascript/index-059c24f59da85973176b.js"></script>
      publicPath: '/javascript' 
    })
  ]
};
```
<br>
###  scriptLoading

默认值：'defer'

值类型：'blocking' | 'defer' | 'module'

作用：现代浏览器支持非阻塞 javascript 加载 ('defer') 以提高页面启动性能。传入 scriptLoading 配置可以给 script 标签设置 type 属性。设置为 'module' 添加属性 type="module"

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      scriptLoading: 'module' // <script type="module" src="index-059c24f59da85973176b.js"></script>
      scriptLoading: 'defer' // <script defer src="index-059c24f59da85973176b.js"></script>
      scriptLoading: 'blocking' // <script src="index-059c24f59da85973176b.js"></script>
    })
  ]
};
```
<br>
###  favicon

默认值：''

值类型：String

作用：将给定的 favicon 路径添加到输出的 HTML 中。

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      // 生成的 index.html 中增加了 <link rel="icon" href="headIcon.svg">
      favicon: './src/headIcon.svg'
    })
  ]
};
```
<br>
###  meta

默认值：{}

值类型：Object

作用：允许注入 meta-tags。例如 meta: {viewport: 'width=device-width, initial-scale=1, shrink-to-fit=no'}

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      // 生成的 index.html 中增加了 <meta name="keywords" content="HTML,CSS,XML,JavaScript">
      meta: {
        keywords: 'HTML,CSS,XML,JavaScript'
      }
    })
  ]
};
```
<br>
###  base

默认值：false

值类型：Object | String | false

作用：允许注入注入 base 标签

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      // 生成的 index.html 中增加了 <base href="http://www.example.com/">
      base: {
          href: "http://www.example.com/"
      }
    })
  ]
};
```
<br>
###  minify

默认值：mode 是 'production' 为 true，否则为 false

值类型：Boolean | Object

作用：是否压缩输出内容，并且以何种方式压缩。当 minify 值为 true，生成的 HTML 将使用 html-minifier-terser 和以下选项进行缩小：
```javascript
{
  collapseWhitespace: true,
  keepClosingSlash: true,
  removeComments: true,
  removeRedundantAttributes: true,
  removeScriptTypeAttributes: true,
  removeStyleLinkTypeAttributes: true,
  useShortDoctype: true
}
```

要使用自定义 [html-minifier](https://github.com/terser/html-minifier-terser#options-quick-reference) 选项，请将对象传递给minify。此对象不会与上述默认值合并。

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      minify: false // 生产环境不做压缩
    })
  ]
};
```
<br>
###  hash

默认值：false

值类型：Boolean

作用：如果 hash 值为 true，将哈希值附加到所有包含的脚本和 CSS 文件路径后。这对更新静态文件很有效。

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      // 生成的 index.html 中 script 文件地址后面增加了 hash
      // <script defer src="index-77c62f233f4dc40c523c.js?77c62f233f4dc40c523c"></script>
      hash: true
    })
  ]
};
```
<br>
###  cache

默认值：true

值类型：Boolean

作用：传入参数为 true，将调用 webpack 生成资源方法，传入缓存中之前生成的 html，反之，总是重新编译并更新缓存，调用 webpack 生成资源方法，传入生成的 html。

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      cache: false
    })
  ]
};
```
<br>
###  showErrors

默认值：true

值类型：Boolean

作用：将错误信息输出到 html 文件中。

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      showErrors: false
    })
  ]
};
```
<br>
###  chunks

默认值：? | ''

值类型：{?} | {Array.<string>}

作用：允许生成的 html 文件中包含哪些 chunk。

webpack.config.js
```javascript
module.exports = {
    entry: {
        index: './src/index.js',
        main: './src/main.js'
    },
    output: {
        path: path.resolve(__dirname, "dist"), 
        filename: '[name].js'
    },
    plugins: [
        ...
        new HtmlWebpackPlugin({ 
            chunks: ['main']
        })
    ]
};
```
上面的代码中，我们使用多入口打包，打包后生成 index.js 和 main.js 两个文件，chunks 传入 main，则生成的 html 模版中只插入了 main.js。
<br>
###  excludeChunks

默认值：''

值类型：{Array.<string>}

作用：允许生成的 html 文件中不包含哪些 chunk。

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      excludeChunks: ['main'] // 生成的 html 文件中没有插入 main.js 文件
    })
  ]
};
```
<br>
###  xhtml

默认值：false

值类型：Boolean

作用：如果传入 xhtml 为 true，则生成的 html 文件兼容 xhtml 规则。

webpack.config.js
```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      xhtml: true
    })
  ]
};
```
<br>
## hooks

DllPlugin 还为其他插件提供了一些 [hooks](https://github.com/jantimon/DllPlugin#events)，感兴趣的小伙伴可自行查看。
<br>
# 总结

DllPlugin 帮助我们自动生成 html 模版，并且会自动将脚本样式等文件插入到模版，同时又提供了很多配置让我们修改生成的模版，这在项目中将非常实用。

## DllPlugin
#  DllPlugin

```text
DllPlugin 和 DllReferencePlugin 用某种方法实现了拆分 bundles，同时还大幅度提升了构建的速度。"DLL" 一词代表微软最初引入的动态链接库。
```

通过使用 DllPlugin 可以拆分项目中版本不经常变更的或者包大小比较大的三方依赖。将依赖拆分成单独的 bundles，这样可以提升项目打包速度、减少包体积来加快加载速度。
<br>
## 使用

本章中主要介绍 DllPlugin 的使用及配置，由于需要打包第三方依赖库，所以下面以 lodash 为例。

安装 lodash 

```javascript
npm install loadsh --save-dev
```

webpack.config.dll.js

新建一个 webpack.config.dll.js 文件，用来添加 dll 配置，在执行打包命令之前先生成 dll 文件。

```javascript
const webpack = require('webpack');
const path = require('path');
module.exports = {
    entry: {
        lodash: ['lodash']
    },
    output: {
        filename: '[name]_dll.js',
        library: "[name]",
        path: path.resolve(__dirname, 'dist/dll')
    },
    plugins: [
        new webpack.DllPlugin({
            context: __dirname,
            path: path.join(__dirname, 'dist/dll', '[name]-mainfest.json'),
            name: '[name]'
        }),
    ]
}
```

在上面的配置中，entry 为项目入库文件，output 为项目输出文件名称及输出目录。其中要注意的是 output 中的 library 参数，增加 library 配置后 mainfest.json 会暴露 dll 库的全局名称。此参数定义的名称要与 DllPlugin 插件中的 name 属性定义名称一致。

在命令行执行 npx webpack --config webpack.config.dll.js 命令，打包成功后在 dist 文件下可以看到生成了一个 dll.js 一个 mainfest.json 文件。
<br>
## 配置

###  context

默认值：webpack 的 context

值类型：String

作用：生成的 manifest.json 文件中 content 对象中的文件映射地址。

webpack.config.dll.js
```javascript
module.exports = {
  plugins: [
    new webpack.DllPlugin({
      // {"name":"vendors","content":{"./node_modules/lodash/lodash.js":{"id":486,"buildMeta":{}}}}
      context: __dirname // 根目录地址
      // 下面的 mainfest.json 文件将找不到 lodash.js，映射地址错误
      // {"name":"vendors","content":{"../node_modules/lodash/lodash.js":{"id":486,"buildMeta":{}}}}
      // context: 'src'
    }),
  ]
};
```
<br>
###  format

默认值：false

值类型：Boolean

作用：如果值为 true，生成的 mainfest.json 文件将被格式化。

webpack.config.dll.js

```javascript
module.exports = {
  plugins: [
    new webpack.DllPlugin({
      // {"name":"vendors","content":{"./node_modules/lodash/lodash.js":{"id":486,"buildMeta":{}}}}
      format: false,
      // {
      //   "name": "vendors",
      //   "content": {
      //     "./node_modules/lodash/lodash.js": {
      //       "id": 486,
      //       "buildMeta": {}
      //     }
      //   }
      // }
      format: true
    }),
  ]
};
```
<br>
###  name

默认值：''

值类型：String

作用：生成的 mainfest.json 文件中的 name 属性值。

webpack.config.dll.js

```javascript
module.exports = {
  ...
  plugins: [
    new webpack.DllPlugin({
      // {"name":"lodash-name","content":{"./node_modules/lodash/lodash.js":{"id":486,"buildMeta":{}}}}
      name: "lodash-name"
    })
  ]
};
```
<br>
###  path

默认值：无（必须）

值类型：String

作用：生成 mainfest.json 文件的路径。

webpack.config.dll.js

```javascript
module.exports = {
  ...
  plugins: [
    new webpack.DllPlugin({
      // 在根目录的 dist/dll 文件夹下生成 [name]-mainfest.json
      path: path.join(__dirname, 'dist/dll', '[name]-mainfest.json'),
    })
  ]
};
```
<br>
###  entryOnly

默认值：true

值类型：Boolean

作用：如果为 true，则仅暴露入口。

webpack.config.dll.js
```javascript
module.exports = {
  ...
  plugins: [
    new DllPlugin({
      entryOnly: false
    })
  ]
};
```
```text
建议 DllPlugin 只在 entryOnly: true 时使用，否则 DLL 中的 tree shaking 将无法工作，因为所有 exports 均可使用。
```
<br>
###  type

类型："var" | "module" | "assign" |"assign-properties" | "this" | "window" | "self" | "global" | "commonjs" | "commonjs2" | "commonjs-module" |"commonjs-static" | "amd" | "amd-require" | "umd" | "umd2" | "jsonp" | "system"

作用：配置 dll 库暴露的方式。

webpack.config.dll.js
```javascript
module.exports = {
  ...
  plugins: [
    new DllPlugin({
      // {"name":"lodash-name","type":"window","content":{"./node_modules/lodash/lodash.js":{"id":486,"buildMeta":{}}}}
      type: 'window'
    })
  ]
};
```
<br>
# 总结

此章节演示了 DllPlugin 的用法和包含的配置参数。生成的 dll.js 和 mainfest.json 文件，在下个 DllReferencePlugin 章节来展示如何使用。

## DllReferencePlugin
#  DllReferencePlugin

在上一章节的 DllPlugin 插件中，DllPlugin 插件会将第三方依赖生成一个 [name]-dll.js 文件和一个 [name]-manifest.json 文件，其中 [name]-dll.js 文件包含第三方依赖所有的源码，[name]-manifest.json 文件包含所有第三方依赖的名称位置和与 [name]-dll.js 映射的索引 ID，执行相应命令生成了 [name]-dll.js 和 [name]-manifest.json 后，就可以执行工程的打包命令。在 webpack 打包过程中，通过 DllReferencePlugin 插件，可以将 [name]-manifest.json 文件中的第三方依赖的映射关系进行解析，当检索到有第三方依赖的映射关系时，会将三方依赖索引 ID 值注入到使用依赖的文件中。如果没有检索到三方依赖映射关系，将去 node_modules 或者项目中查找并将检索内容添加到需要使用依赖的文件中。
<br>
## 使用

index.js

```javascript
import _ from 'lodash';
import { name } from './main.js';
console.log(_.join(['hello', 'world'], '-'))
console.log(name);
```

main.js

```javascript
export const name = 'dll';
```

webpack.config.dll.js

```javascript
const webpack = require('webpack');
const path = require('path');
module.exports = {
    entry: {
        vendors: ['lodash', './src/main.js'],
    },
    output: {
        filename: '[name]-dll.js',
        library: "[name]",
        path: path.resolve(__dirname, 'dist/dll')
    },
    plugins: [
        new webpack.DllPlugin({
            context: __dirname,
            path: path.join(__dirname, 'dist/dll', '[name]-manifest.json'),
            name: '[name]',
            format: true
        }),
    ]
}
```

在上面的配置中，将 lodash 和本地 main.js 生成 dll 文件。

webpack.config.js

```javascript
const path = require('path');
const webpack = require('webpack');


module.exports = {
    mode: 'development',
    entry: {
        index: './src/index.js',
    },
    output: {
        path: path.resolve(__dirname, "dist"), 
        filename: '[name].js'
    },
    plugins: [
        new webpack.DllReferencePlugin({
            // 对动态链接库的文件内容的描述或者映射关系，非 dll 本身
            manifest: require('./dist/dll/vendors-manifest.json'),
        })
    ]
}
```

在 webpack.config.js 的 DllReferencePlugin 插件中引入 DllPlugin 插件生成的 manifest.json 文件。执行 npm run build 打包命令。我们看下生成的 index.js 文件内容。

![1.png](https://pic.leetcode-cn.com/1655707974-pZSKII-1.png)
![2.png](https://pic.leetcode-cn.com/1655708324-MmeVkB-2.png)

从上面的截图我们可以看到 DllReferencePlugin 插件解析了 manifest.json 中的第三方依赖对应的映射关系，将 ID 值传入到 index.js 的方法中，我们接下来需要手动将 dll/vendors-dll.js 通过 `<script>` 标签添加到 index.html 中。vendors-dll.js 文件中包含第三方依赖的代码和 manifest.json 中的 ID 值，index.js 中通过加载 ID 值来使用第三方依赖方法。

```html
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Webpack App</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script defer src="./dll/vendors-dll.js"></script>
  <script defer src="index.js"></script></head>
  <body>
  </body>
</html>
```

在浏览器中打开 index.html 文件，在控制台可以看到输出的内容，main.js 和 lodash 方法均可正常使用。

DllReferencePlugin 在解析 manifest.json 文件时，虽然 manifest.json 包含多个第三方依赖的映射关系，但是插件会根据 index.js 中的引用来注入对应的代码。即当 index.js 中只引用了 main.js 文件时，打包后生成的 index.js 文件则只包含 main.js 的映射关系。在实际的项目中，就可以将不常改动的第三方依赖打包成 dll，将 dll 的链接通过 CDN 等方式引入到项目中，这样可以减少主包的大小，加快打包速度。

  ```text
  注意：[name]-dll.js 可以通过插件动态插入到 index.html，小伙伴儿可自行查阅。
  ```
<br>
## 配置

###  context

类型：String

默认值：webpack 的 context

作用：(绝对路径) manifest 中请求的上下文。

webpack.config.js
```javascript
module.exports = {
  plugins: [
    new webpack.DllReferencePlugin({
      ...
      context: __dirname // 根目录地址
      // 下面的配置会在 dist 文件夹下查找 manifest 的地址，当找不到 manifest.json 文件时，会将依赖代码打包到 bundle.js 中
      // path.resolve(__dirname, "dist")
    }),
  ]
};
```

![4.png](https://pic.leetcode-cn.com/1655709393-wsvekM-4.png)
![3.png](https://pic.leetcode-cn.com/1655709393-nMFiXo-3.png)

<br>
###  manifest

类型：String

作用：用于加载 manifest.json 路径。

webpack.config.js

```javascript
module.exports = {
  plugins: [
    new webpack.DllReferencePlugin({
      // 动态链接库的文件内容
      manifest: require('./dist/dll/vendors-manifest.json'),
    }),
  ]
};
```
<br>
###  name

类型：String

默认值：manifest.json 的 name 属性。

作用：[name]-dll.js 暴露的全局变量方法名称，将 manifest.json 中的 索引 ID 传入全局方法中，可返回对应模块方法。

index.js

其中的 vendors(225)，vendors 为 dll 暴露的全局变量，225 为 manifest.json 中 main.js 依赖的 ID 索引值。

```javascript
import _ from 'lodash';
import { name } from './main.js';
console.log(_.join(['hello', 'world'], '-'))
console.log(vendors(225));
console.log(vendors(225).plugin);
```

main.js

```javascript
export const plugin = 'dll';
```

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    new webpack.DllReferencePlugin({
      ...
      name: 'vendors'
    })
  ]
};
```

打包成功后，控制台打开 dist/index.html，可以看到 输出了 hello-world、 main.js 模块代码和 main.js 代码中的 plugin 变量。

![5.png](https://pic.leetcode-cn.com/1655708137-OwpPBR-5.png)
<br>
###  content

类型：Object

默认值：manifest.json 的 content 属性。

作用：传入请求依赖到模块 ID 的映射关系。

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    new webpack.DllReferencePlugin({
      content: {
        "./src/main.js": {
          "id": 225,
          "exports": [
            "plugin"
          ]
        },
      }
    })
  ]
};
```
<br>
###  sourceType

类型："var" | "assign" | "this" | "window" | "global" | "commonjs" | "commonjs2" | "commonjs-module" | "amd" | "amd-require" | "umd" | "umd2" | "jsonp" | "system"

作用：dll 中的模块代码以哪种模式暴露给外部调用 [output.library.type](https://webpack.js.org/configuration/output/#outputlibrarytype)

index.js

```javascript
import { name } from './main.js';
console.log(window.vendors(225));
```

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    new HtmlWebpackPlugin({
      ...
      sourceType: 'window'
    })
  ]
};
```
<br>
# 总结

此章节演示了 DllReferencePlugin 的用法和包含的配置参数。DllReferencePlugin 通过解析 manifest.json 将依赖的映射索引注入到需要的依赖中。通过将不常变动的依赖打包成 dll 的方式，可以减少 bundle 的大小，同时能加快打包速度。

## MiniCssExtractPlugin
#  MiniCssExtractPlugin

MiniCssExtractPlugin 插件会将 CSS 提取到单独的文件中，为每个包含 CSS 的 JS 文件创建一个 CSS 文件。这个插件需要在 webpack 5 中才能正常工作，webpack 4 中使用 extract-text-webpack-plugin 插件做 CSS 分离。之前的文章中我们介绍了 style-loader 的使用，style-loader 是将 JS 中包含的 CSS 内容以 `<style>` 标签的形式插入到 DOM 中，而 MiniCssExtractPlugin 插件则是将 JS 中包含的 CSS 创建一个新的文件，并且以 `<link>` 标签的形式插入链接到加载依赖的文件中。MiniCssExtractPlugin 作用与 style-loader 类似，但是实现方式却完全不同。MiniCssExtractPlugin 一般与 css-loader 同时使用。

```text
注意：下面【使用】模块的案例，index.css 分离是 MiniCssExtractPlugin 做的，而通过 `<link>` 标签插入index.html 是 HtmlWebpackPlugin 插件做的，MiniCssExtractPlugin 插件可以将非入口文件通过 `<link>` 标签插入到加载依赖的文件中，即 MiniCssExtractPlugin 插入 `<link>` 仅适用于非初始（异步）块。
```
<br>
## 使用

index.js

```javascript
import styles from "./index.css";
import main from "./main.css";

const divElement = document.createElement("div");
divElement.className = "demo";
divElement.innerHTML = 'mini-css-extract-plugin';
document.body.appendChild(divElement);
```

index.css

```style
.demo {
    color: red;
}
```

main.css

```style
.demo {
    font-size: 20px;
}
```


安装 mini-css-extract-plugin

```javascript
npm install mini-css-extract-plugin -D
```

安装成功后，将 mini-css-extract-plugin 配置到 webpack.config.js 的 plugins 和 module 中。 

webpack.config.js

```javascript
...
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

module.exports = {
    ...
    module: {
        rules: [
          {
            test: /\.css$/i,
            use: [MiniCssExtractPlugin.loader, "css-loader"],
          },
        ],
    },
    plugins: [
        ...
        new MiniCssExtractPlugin()
    ]
}
```

我们在入口文件 index.js 中导入了 main.css 和 index.css 两个样式文件。一个改变字体，一个改变字体颜色。执行打包命令，可以看到在 dist 文件夹下除了 index.js 和 index.html 文件之外还生成了一个 index.css 文件。index.css 文件中包含 main.css 和 index.css 的内容。在 index.html 中通过 `<link>` 标签的形式引入了 index.css 文件。在浏览器中打开 dist/index.html 可以看到样式被正常展示。

![1.png](https://pic.leetcode-cn.com/1658132739-yLUVon-1.png)
![2.png](https://pic.leetcode-cn.com/1658132739-bWqEsK-2.png)

上面的例子中在 index.js 中导入了两个样式文件，接下来我们试一下在入口文件 index.js 中导入 main.js 和 index.css，其中 main.js 中导入 main.css。其他配置保持不变。

index.js

```javascript
import styles from "./index.css";
import { default as mainElement } from './main';

const divElement = document.createElement("div");
divElement.className = "demo";
divElement.innerHTML = 'mini-css-extract-plugin';
divElement.appendChild(mainElement);
document.body.appendChild(divElement);
```

main.js

```javascript
import main from "./main.css";

const divElement = document.createElement("div");
divElement.className = "demo-main";
divElement.innerHTML = 'demo-main';

export default divElement;
```

main.css

```style
.demo-main {
    font-size: 20px;
}
```

执行打包命令后，dist 文件夹下依然只有 index.html，index.js，index.css 文件。查看后发现虽然在 main.js 中导入的 main.css，但由于 main.js 被 index.js 依赖。所以 css 文件内容依然都打包到了 index.css 中。

<br>
## 配置

MiniCssExtractPlugin 包含两部分配置，plugin 配置和 loader 配置。
<br>
### Plugin Options

####  filename

类型：string | ((pathData: PathData, assetInfo?: AssetInfo) => string);

默认值：[name].css

作用：输出的 css 文件的名称，默认为 chunkName 值。

webpack.config.js
```javascript
module.exports = {
  plugins: [
    new MiniCssExtractPlugin({
      ...
       filename: '[name].css' // index.css
      //  filename: (pathData) => {
      //     return pathData.hash + '-index.css';
      //  }, // 8de455759e47e7f4d53b-index.css
    }),
  ]
};
```
<br>
####  chunkFilename

类型：string | ((pathData: PathData, assetInfo?: AssetInfo) => string);

默认值：基于 filename

作用：修改非入口文件的打包后的名称。

index.js

```javascript
import styles from "./index.css";
// 将 main.js 打包到单独文件
const mainElement = import(/* webpackChunkName: "main" */ './main');
...
```

webpack.config.js

```javascript
module.exports = {
  plugins: [
    new MiniCssExtractPlugin({
      chunkFilename: 'chunk-[id].css', // chunk-main.css
    }),
  ]
};
```

![3.png](https://pic.leetcode-cn.com/1658132739-gWZpeT-3.png)

打开 dist 我们可以看到 main.js 文件已经单独打包，并且生成了一个 chunk-name.css 文件。

<br>
####  ignoreOrder

类型：boolean

默认值：false

作用：模块中加载 css 文件顺序不一致是否发出警告，例如：1.js 中加载 css 的顺序是 a.css、b.css，2.js 中加载顺序是 b.css、a.css，就会发出警告，详细可看下官网 [issue](https://github.com/webpack-contrib/mini-css-extract-plugin/issues/250)

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    new MiniCssExtractPlugin({
      ignoreOrder: false,
    })
  ]
};
```
<br>
####  insert

类型：string | ((linkTag: HTMLLinkElement) => void)

默认值：document.head.appendChild(linkTag)，即默认插入到 DOM 文件的 head 中

作用：打包的 CSS 文件，通过 `<link>` 标签插入的位置。

index.js

```javascript
import styles from "./index.css";
const divElement = document.createElement("div");
// import 方法导入的模块为异步加载
import(/* webpackChunkName: "main" */ './main').then(res => {
  divElement.appendChild(res.default)
});

divElement.className = "demo";
divElement.innerHTML = 'mini-css-extract-plugin';
document.body.appendChild(divElement);
```

index.html

```html
...
<body>
  <div id="div-element"></div>
</body>
```

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    new MiniCssExtractPlugin({
      insert: '#div-element'
    })
  ]
};
```

执行打包命令后，在 dist/index.html 文件中，只包含了 index.css 的 `<link>` 标签，在浏览器中运行 index.html，在控制台可以看到 chunk-main.css 的 `<link>` 标签被插入到选择器为 `#div-element` 元素的后面。在生成的 index.js 文件中可以看到创建 link 标签的源码。

![5.png](https://pic.leetcode-cn.com/1658132739-xZlArH-5.png)
![6.png](https://pic.leetcode-cn.com/1658132739-jgrsql-6.png)
<br>
####  attributes

类型：object

默认值：{}

作用：在 `<link>` 标签中添加属性

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    ...
    new MiniCssExtractPlugin({
        attributes: {
            "data-target": "data" // <link data-target="data" rel="stylesheet" type="text/css" href=".../dist/main.css">
        },
    })
  ]
};
```
<br>
####  linkType

类型：string | boolean

默认值：text/css

作用：修改 `<link>` 标签中 type 属性，type 的默认值为 text/css。

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    ...
    new MiniCssExtractPlugin({
        linkType: "text/css" // <link type="text/css" ...>
        // linkType: false // <link rel="stylesheet" href=".../dist/main.css">
    })
  ]
};
```
<br>
####  runtime

类型：boolean

默认值：true

作用：允许启用/禁用运行时生成。

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    ...
    new MiniCssExtractPlugin({
        runtime: false // 运行 index.html 时，main.css 不会被插入到 DOM 中。
    })
  ]
};
```
<br>
### Loader Options

####  publicPath

类型：string | ((resourcePath: string, rootContext: string) => string)

默认值：webpackOptions.output 选项的值

作用：输出的 CSS 文件中，为图像、文件等外部资源指定自定义公共路径。

main.css
```style
.demo-main {
    font-size: 20px;
    background: url(./img/1.png);
}
```

webpack.config.js

```javascript
module.exports = {
  ...
  module: {
        rules: [
          {
            test: /\.css$/i,
            use: [
                {
                    loader: MiniCssExtractPlugin.loader,
                    options: {
                      publicPath: "/public/path/to/", // main.css background: url(/public/path/to/e30cb9c395cbb5ae00e9.png);
                    },
                }, "css-loader"],
          },
        ],
    },
};
```

打包成功后，查看生成的 main.css 文件，background 地址已经被替换成传入的 publicPath，通过传入 publicPath 可以引用外部资源。
<br>
####  emit

类型：boolean

默认值：true

作用：提取的 CSS 是否生成对应文件。当 emit 值为 true 会生成 CSS 文件，值为 false 不生成 CSS 文件。

webpack.config.js

```javascript
module.exports = {
  ...
  module: {
        rules: [
          {
            test: /\.css$/i,
            use: [
                {
                    loader: MiniCssExtractPlugin.loader,
                    options: {
                      emit: false, // 打包后的 dist 中没有生成 index.css 和 main.css，运行 index.html 样式不生效
                    },
                }, "css-loader"],
          },
        ],
    },
};
```
<br>
####  esModule

类型：boolean

默认值：true

作用：生成的文件是否使用 ES 模块语法，开启 ES 语法对 tree-shaking 将非常有用。

webpack.config.js

```javascript
module.exports = {
  ...
  module: {
        rules: [
          {
            test: /\.css$/i,
            use: [
                {
                    loader: MiniCssExtractPlugin.loader,
                    options: {
                      esModule: false, // 启用CommonJS 语法
                    },
                }, "css-loader"],
          },
        ],
    },
};
```
<br>
# 总结

此章节演示了 MiniCssExtractPlugin 的用法和包含的配置参数。MiniCssExtractPlugin 还有一些推荐的例子，感兴趣的同学可查看[官方](https://www.npmjs.com/package/mini-css-extract-plugin)。

## WebpackManifestPlugin
#  WebpackManifestPlugin

WebpackManifestPlugin 是一个 webpack 插件，此插件的作用是生成资产清单即 manifest.json 文件，在使用此插件前，我们先看下什么是 manifest 以及 manifest 的作用，以下引自 webpack 官网。

> 一旦你的应用在浏览器中以 index.html 文件的形式被打开，一些 bundle 和应用需要的各种资源都需要用某种方式被加载与链接起来。在经过打包、压缩、>为延迟加载而拆分为细小的 chunk 这些 webpack 优化 之后，你精心安排的 /src 目录的文件结构都已经不再存在。所以 webpack 如何管理所有所需模 >块之间的交互呢？这就是 manifest 数据用途的由来……

总结来说，manifest.json 就是记录项目中生成的 bundle 之间的映射关系。有了这份清单，我们可以通过特定的方法加载资源，如服务端渲染或通过遍历 manifest.json 将记录输出到页面上等。在当前流行的微前端框架中，通过引入不同子项目的 manifest.json 文件，并遍历文件内容动态输出到 DOM 中，从而实现加载不同子项目工程，这会比手动获取子项目资源清单减少出错概率和省事的多。
<br>
## 使用

index.js

```javascript
import styles from "./index.css";
const divElement = document.createElement("div");
divElement.className = "demo";
divElement.innerHTML = 'webpack-manifest-plugin';
document.body.appendChild(divElement);
```

index.css

```style
.demo {
    color: red;
    background: url(./img/1.png);
}
```

安装 webpack-manifest-plugin

```javascript
npm install webpack-manifest-plugin -D
```

安装成功后，将 webpack-manifest-plugin 配置到 webpack.config.js 的 plugins 中。 

webpack.config.js

```javascript
...
const { WebpackManifestPlugin } = require('webpack-manifest-plugin');

module.exports = {
    ...
    plugins: [
        ...
        new WebpackManifestPlugin({
            publicPath: './'
        })
    ]
}
```

我们在 index.js 文件中创建了一个 div 标签，在 index.css 中设置了 div 标签的字体颜色和背景图片，此时执行打包命令，打包成功后在 dist 中可以看到除了项目资源文件外还有一个 manifest.json 文件。打开 manifest.json 文件看下内容。

![1.png](https://pic.leetcode-cn.com/1658132966-dqklgB-1.png)

manifest.json 包含了资源的映射关系，我们需要遍历 manifest.json 对象的内容，将需要的如 js 资源通过 createElement 等方式挂载到 index.html 中项目即可正常使用。

<br>
## 配置

以下为包含部分常用配置，全部配置可查看[官网](https://github.com/shellscape/webpack-manifest-plugin)
<br>
###  basePath

类型：String

默认值：''

作用：生成的 manifest.json 文件中，basePath 参数传入的值将添加到对象的 key 值前面。 

webpack.config.js
```javascript
module.exports = {
  plugins: [
    new WebpackManifestPlugin({
      ...
      basePath: 'src' // "src/index.js": ".../index.js",
      basePath: '' // "index.js": ".../index.js",
    }),
  ]
};
```
<br>
###  fileName

类型：String

默认值：manifest.json

作用：fileName 传入的值作为输出的文件清单的名称。

webpack.config.js

```javascript
module.exports = {
  plugins: [
    new WebpackManifestPlugin({
        fileName: 'manifest-filename.json' // manifest.json -> manifest-filename.json
    })
  ]
};
```
<br>
###  filter

类型：(file: FileDescriptor) => Boolean

默认值：undefined

作用：执行 filter 回调函数，返回 true 则 manifest.json 中包含 bundle 的映射关系，返回 false 则不包含此 bundle 映射关系。

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    new WebpackManifestPlugin({
      filter: (file) => {
          return file?.name?.endsWith('.js') // manifest.json 中只包含 js 拓展名的文件
      }
    })
  ]
};
```

![2.png](https://pic.leetcode-cn.com/1658132966-mPOfFh-2.png)
<br>
###  generate

类型：(seed: Object, files: FileDescriptor[], entries: string[]) => Object

默认值：undefined

作用：自定义修改生成的 manifest.json 中的键值对内容，generate 传入的函数返回值需要为对象。

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    new WebpackManifestPlugin({
      generate: (seed, files, entries) => {
          console.log(seed, 'seed')
          console.log(files, 'files')
          console.log(entries, 'entries')
          return { 'main-index': 'index.js' }
      }
    }) // manifest.json 中内容 { "main-index": "index.js" }
  ]
};
```
<br>
###  map

类型：(file: FileDescriptor) => FileDescriptor

默认值：undefined

作用：自定义修改生成的 manifest.json 中的键值对内容。

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    ...
    new WebpackManifestPlugin({
        map: (file) => {
            const fileName = file?.name;
            if (file?.name?.endsWith('.js')) {
                file.name = 'assets.' + fileName
            }
            return file
        }
    }) 
    // { "assets.main.js": "auto/main.js" ... }
  ]
};
```
<br>
###  publicPath

类型：String

默认值：webpack.config.js 中的 output.publicPath 值

作用：publicPath 传入的内容将添加到 manifest.json 对象的值前面。

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    ...
     new WebpackManifestPlugin({
        // {
        //   "index.js": "./dist-public/index.js",
        //   "1.png": "./dist-public/2b2001bb98465dd14a87.png",
        //   "index.html": "./dist-public/index.html"
        // }
        publicPath: './dist-public'  
      })
  ]
};
```
<br>
###  serialize

类型：(Object) => string

默认值：undefined

作用：格式化 manifest.json 中的内容。

webpack.config.js

```javascript
module.exports = {
  ...
  plugins: [
    ...
    new WebpackManifestPlugin({
        serialize: (obj) => {
            console.log(obj)
            return JSON.stringify(obj) // {"index.js":"auto/index.js","1.png":"auto/2b2001bb98465dd14a87.png","index.html":"auto/index.html"}
        }
    })
  ]
};
```

<br>
# 总结

此章节演示了 WebpackManifestPlugin 的用法和包含的部分常用配置参数，通过 WebpackManifestPlugin 生成的资源清单可以让我们在项目中快速找到引用的依赖文件路径，这对于服务端渲染或微前端等将非常有用。


# 配置


## 开发环境
#  开发环境调优

在之前的章节中我们介绍了 Webpack 的基础配置，一些 Loader 和 Plugin 的使用方法，到此我们应该对 Webpack 有了一定的认识，Webpack 作为打包工具的重要使命之一就是提升效率，下面我们介绍一些对日常开发有一定帮助的 Webpack 插件、配置。

- source map
- 插件介绍
- 使用 webpack-dev-server
- 模块热替换
<br>
##  source map

Webpack 打包编译后的代码基本不具备可读性，工程发布或启动后此时若代码跑出一个错误，想要回溯它的调用栈是非常困难的。而有了 source map 在加上浏览器的调试工具，要做到追踪错误和警告就容易的多了。source map 指的是将编译、打包、压缩等操作后的代码映射回原文件的过程。开发环境通过 source map 我们可以直接看到源代码调试，生产环境通过 source map 我们可以通过工具回溯到报错的代码位置。为我们进一步分析错误提供了便利。

在开发环境即 mode 选项设置为 development 模式下，Webpack 将自动生成映射文件，source map 除了将 Javascript 映射回原文件外，还同样适用于样式文件。
<br>
### source map 配置

Javascript 的 source map 通过配置项 devtool 来启用，只要在 webpack.config.js 中添加 devtool 即可。

index.js

```javascript
const divElement = document.createElement("div");
divElement.className = "demo";
divElement.innerHTML = 'mini-css-extract-plugin';
document.body.appendChild(divElement);
```

webpack.config.js

```javascript
const path = require('path');
module.exports = {
    // ...
    devtool: 'source-map',
}
```

对于 CSS、SCSS、Less 来说，需要在 loader 中添加 source map 配置。

webpack.config.js

```javascript
const path = require('path');
module.exports = {
    // ...
     module: {
        rules: [
            {
            test: /\.(css)$/,
            use: [
                'style-loader',
                {
                    loader: 'css-loader',
                    options: {
                        sourceMap: true
                    }
                }
              ]
            }
        ]
    },
}
```

打包后，在 dist 文件夹下除了 index.js 外还生成了一个 index.js.map 文件。在生成 mapping 文件的同时，还为 index.js 添加了一个引用注释，以便开发工具知道在哪里可以找到它。

dist/index.js

```javascript
(function() {
  // 内容
})();
//# sourceMappingURL=index.js.map
```

当我们打开浏览器的开发者工具时，map 文件会同时被加载，这时浏览器会使用它来对打包后的 bundle 进行解析。分析出源码的内容。当我们打断点进行调试时，可以直接调试源码。

![1.png](https://pic.leetcode-cn.com/1658133154-bhTBwe-1.png)
<br>
### source map 分类

Webpack 支持的 source map 大概分为两种，inline（内连） 和 separate（独立）两种方式。inline 类型即生成的映射关系内容保存在 bundle 中不生成单独的文件，separate 类型即可生成单独的 map 文件可以独立使用。source map 支持类型很多，下面只介绍其中几种，详细信息可官网查看，[source map官网](https://webpack.docschina.org/configuration/devtool)
<br>
#### inline source map 类型

Webpack 提供了多种内联映射文件类型。通常 eval 是起点，因为它是速度和质量之间的良好折衷，同时在 Chrome 和 Firefox 浏览器中可以可靠地工作。下面我们介绍两个内连类型的例子。

```text
注意：为了查看效果我们去掉 webpack.config.js 中的 mode 配置。
```
<br>
##### devtool: "eval"

eval生成代码，其中每个模块都包装在一个eval函数中。并且都包含 //# sourceURL，此选项会非常快的构建。

```javascript
(()=>{var __webpack_modules__={
  138:()=>{
    eval('const divElement = document.createElement("div");\ndivElement.className = "demo";\ndivElement.innerHTML = \'mini-css-extract-plugin\';\ndocument.body.appendChild(divElement);\n\n//# sourceURL=webpack://6.1/./src/index.js?')
  }
},__webpack_exports__={};__webpack_modules__[138]()})();
```
<br>
#####  devtool: "eval-source-map"

每个模块使用 eval() 执行，并且 source map 转换为 DataUrl 后添加到 eval() 中。初始化 source map 时比较慢，但是会在重新构建时提供比较快的速度，并且生成实际的文件。

```javascript
(() =>
  {var __webpack_modules__={
    138: ()=>{
      eval('const divElement = document.createElement("div");\ndivElement.className = "demo";\ndivElement.innerHTML = \'mini-css-extract-plugin\';\ndocument.body.appendChild(divElement);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTM4LmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vNi4xLy4vc3JjL2luZGV4LmpzP2I2MzUiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgZGl2RWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG5kaXZFbGVtZW50LmNsYXNzTmFtZSA9IFwiZGVtb1wiO1xuZGl2RWxlbWVudC5pbm5lckhUTUwgPSAnbWluaS1jc3MtZXh0cmFjdC1wbHVnaW4nO1xuZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChkaXZFbGVtZW50KTsiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///138\n')
  }
},__webpack_exports__={};__webpack_modules__[138]()})();
```
<br>
#### separate source map 类型

Webpack 提供了多种独立映射文件类型。我们常用的为 source-map 类型，source-map 类型可以生成单独的 map 文件，有了 source map 也就意味着任何人都可以通过浏览器调试工具看到工程源码，这对于安全性来说有了极大隐患。那么如何能保证线上问题可以追踪又能防止源码泄漏，Webpack 提供了 hidden-source-map 和 nosources-source-map 两种策略来提升 source map 的安全性。


<br>
##### devtool: "hidden-source-map"

hidden-source-map 与 source-map 作用相同都会生成一个 map 文件，唯一区别是不会为 bundle 添加引用注释。我们在浏览器中直接打开工程，是看不到原文件的，生成的 map 文件只是作为我们追踪错误信息的依据。

```javascript
(()=>{const e=document.createElement("div");e.className="demo",e.innerHTML="mini-css-extract-plugin",document.body.appendChild(e)})();
```

```text
警告：你不应将 source map 文件部署到 web 服务器。而是只将其用于错误报告工具。
```
<br>
#####  devtool: "nosources-source-map"

nosources-source-map 创建的 source map 不包含 sourcesContent(源代码内容)。虽然在 bundle 中增加了 //# sourceMappingURL，但是当我们在浏览器中打开源码文件时是看不到源码内容的。

index.js 

```javascript
(()=>{const e=document.createElement("div");e.className="demo",e.innerHTML="mini-css-extract-plugin",document.body.appendChild(e)})();
//# sourceMappingURL=index.js.map
```

```text
这仍然会暴露反编译后的文件名和结构，但它不会暴露原始代码。
```

![2.png](https://pic.leetcode-cn.com/1658132966-mPOfFh-2.png)![2.png](https://pic.leetcode-cn.com/1658133154-IlbFXK-2.png)
<br>
## 插件介绍

Webpack 拥有非常强大的生态系统，社区中相关的工具也是数不胜数，这里我们介绍两个项目中常用的插件，可以节省开发效率和减少我们操作步骤。
<br>
### html-webpack-plugin

html-webpack-plugin 可以自动创建 html 文件，也支持使用 html 文件模版。html-webpack-plugin 会自动将所有必要的 css、javascript、manifest 和 favicon 文件注入到生成的 html 文件中。之前在 5.2 章节做过 html-webpack-plugin 的介绍，所以这里不在详细介绍。


安装 html-webpack-plugin

```javascript
npm install html-webpack-plugin --save-dev
```

webpack.config.js

```javascript
const HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
...
  plugins: [
        ...
        new HtmlWebpackPlugin()
    ]
};
```
<br>
### clean-webpack-plugin

clean-webpack-plugin 插件用于在每次构建工程时清除上次构建生成的文件，有了这个插件我们再也不用手动清除构建目录了。


安装 clean-webpack-plugin

```javascript
npm install clean-webpack-plugin --save-dev
```

webpack.config.js

```javascript
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
module.exports = {
...
  plugins: [
        ...
        new CleanWebpackPlugin()
    ]
};
```
<br>
## 使用 webpack-dev-server

在之前的案例中，我们一直都是更改代码后执行打包命令，然后手动去打包文件中打开 html 文件查看效果，这种方式在实际的项目发开中会增加很多额外的重复工作，并且打包后的内容需要发布到服务上才能被其他伙伴访问。为了提升开发效率，在构建代码并部署到生产环境之前，我们需要一个本地环境，用于运行我们开发的代码。这个环境相当于提供了一个简单的服务器，用于访问 webpack 构建好的静态文件，我们日常开发时可以使用它来调试前端代码。webpack-dev-server 可以很好的帮我们解决这个需求，webpack-dev-server 是 webpack 官方提供的一个工具，可以基于当前的 webpack 构建配置快速启动一个静态服务。当 mode 为 development 时，会具备 hot reload 的功能，即当源码文件变化时，会即时更新当前页面，以便我们实时看到效果。webpack-dev-server 仅应用于开发环境。下面简单介绍下 [webpack-dev-server](https://github.com/webpack/webpack-dev-server#readme) 的使用，详细配置可查看官网。

安装

```javascript
npm install webpack-dev-server -D
```

package.json 中增加 scripts

```javascript
  "scripts": {
    ...
    "serve": "webpack serve"
  },
```

配置成功后，命令行执行 npm run serve，项目启动成功并在控制台输出了网址，打开此网址即可运行我们现有代码。当我们修改 index.js 内容时页面会自动刷新。

![3.png](https://pic.leetcode-cn.com/1658133154-wZhRjN-3.png)
<br>
## 模块热替换

当项目功能体量很大页面元素较多时，使用 webpack-dev-server 实现页面整体刷新会影响开发体验，这时我们会考虑使用模块热替换。

模块热替换(Hot Module Replacement 或 HMR)是 webpack 提供的最有用的功能之一。HMR 功能会在应用程序运行过程中，替换、添加或删除模块，而无需重新加载整个页面。主要是通过以下几种方式，来显著加快开发速度：

- 重新加载页面期间保留应用程序状态。
- 只更新变更部分内容，节省开发时间。
- 在源代码 CSS/JS 内容产生修改时，会立刻在浏览器中进行更新，这几乎相当于在浏览器 devtools 直接更改样式。

<br>
### 使用 HMR

HMR 是 Webpack 内置的插件，我们可以通过 webpack-dev-server 配置来开启 HMR。

webpack.config.js

```javascript
module.exports = {
    ...
    devServer: {
        hot: true,
    }
}
```

上面的配置产生的结果是 Webpack 为每个模块绑定一个 module.hot 对象，这个对象可以调用 HMR 的 API。通过这些 API 我们可以对特定模块开启或关闭热替换。

index.js

```javascript
const add = (a, b) => {
  return a + b;
};

const addRes = add(3, 5);
const divElement = document.createElement('div');
divElement.innerHTML = addRes;
document.body.appendChild(divElement);

if (module.hot) {
  module.hot.accept()
}
```

启动项目后可以在页面上看到结果 8，当修改 add 函数中的参数时，页面上 8 并没有清空，HMR 会使应用在当前浏览器环境下又执行来一遍 index.js (包括其依赖的模块)内容，但是页面本身并没有刷新。

![4.png](https://pic.leetcode-cn.com/1658133154-debqqW-4.png)

调用 HMR API 可以如上面例子中手动调用，我们还可以借助现成的工具去调用，如 react-hot-loader、vue-loader 等。喜欢的小伙伴可以自行研究。
<br>
# 总结

本章我们介绍了 Webpack 开发环境下的常用的配置和插件以及如何使用 HMR。篇幅有限只写了些项目中用到的，Webpack 周边实用插件很多，感兴趣的小伙伴儿可以选择一些去使用一下，这对于了解 Webpack 也会有很大帮助。

## 生产环境
#  生产环境调优

## 配置文件

在实际的项目中，我们经常会有区分环境的需求，如本地环境、测试环境、生产环境。不同的环境往往对应一些不同的配置，如 mode、环境变量等，如何通过 webpack 按照不同环境采用不同配置呢？一般有以下两种方式。

1、使用同一个配置文件，不同环境传入不同变量来控制配置

webpack.config.js

```javascript
...
const NODE_ENV = process.env.NODE_ENV;
const isDev = NODE_ENV === 'development';

module.exports = {
    mode: NODE_ENV,
    devtool: isDev ? 'source-map' : 'inline-source-map',
    ...
}
```

package.json 

```javascript
{
  ...
  "scripts": {
    "dev": "NODE_ENV=development webpack", // 开发环境
    "build": "NODE_ENV=production webpack" // 生产环境
  }
}
```

上面的配置中，通过在 package.json 中修改 NPM Scripts，传入 NODE_ENV 变量。开发环境参数值为 development，生产环境参数值为 production。在 webpack 配置文件中使用 Node.js 的 process 对象获取传入的参数。执行 npm run dev 即执行开发环境配置，生成的打包文件中包含 source map 文件同时 index.js 中包含 source map 映射路径。执行 npm run build 同理执行生产环境配置，生成的打包文件中 index.js 文件不包含 source map 映射路径。至此我们成功的区分了不同环境。

2、为不同环境创建各自的配置文件

生产环境创建一个 prod.config.js 文件，开发环境配置一个 dev.config.js 文件，修改 package.json 中的 scripts，不同命令执行不同的配置文件。

prod.config.js

```javascript
const path = require('path');

module.exports = {
  mode: 'production',
  devtool: 'hidden-source-map',
  entry: {
    index: './src/index.js',
  },
  output: {
    path: path.join(__dirname, 'dist'),
    filename: '[name].js',
  },
}
```

dev.config.js

```javascript
const path = require('path');

module.exports = {
  mode: 'development',
  devtool: 'source-map',
  entry: {
    index: './src/index.js',
  },
  output: {
    path: path.join(__dirname, 'dist'),
    filename: '[name].js',
  },
}
```

package.json 

```javascript
{
  ...
  "scripts": {
    "dev": "webpack --config=dev.config.js", // 开发环境
    "build": "webpack --config=prod.config.js" // 生产环境
  }
}
```

上面的两个配置文件中，项目入口出口都一样，只有打包模式和 source map 模式不同，分别执行 npm run dev 和 npm run build 可以看到生成文件内容不同。对于需要多种环境配置的文件中，我们可以将环境中共用的部分如入口、出口等配置提取出来放在一个公共配置中，将公共配置提取到 common.config.js 中，个性化配置放在不同环境对应的配置中，通过 webpack-merge 插件将配置组合起来。下面以生产环境配置为例。

prod.config.js

```javascript
const commonConfig = require('./common.config.js');
const { merge } = require('webpack-merge');

module.exports = merge(commonConfig, {
  mode: 'production',
  devtool: 'hidden-source-map'
});
```

common.config.js

```javascript
...
module.exports = {
  entry: {
    index: './src/index.js',
  },
  output: {
    path: path.join(__dirname, 'dist'),
    filename: '[name].js',
  },
  ...
};
```

执行打包命令后查看输出文件，可以看到输出内容与单独配置无异。
<br>
## 区分环境变量

通常我们需要为生产环境和本地环境添加不同的环境变量，在 Webpack 中可以使用 DefinePlugin 进行设置，在 5.1 章节我们已经对 DefinePlugin 配置做过详细的介绍，所以下面我们只加一个区分服务地址的配置。

prod.config.js

```javascript
...
const webpack = require('webpack');

module.exports = {
   ...
    plugins: [
        ...
        new webpack.DefinePlugin({
            BASE_URL: 'http://ip:8201'
        })
    ]
}
```

dev.config.js

```javascript
...
const webpack = require('webpack');

module.exports = {
   ...
    plugins: [
        ...
        new webpack.DefinePlugin({
            BASE_URL: 'http://localhost:8201'
        })
    ]
}
```

index.js

```javascript
...
console.log(BASE_URL)
```

执行不同环境的打包命令，即可区分不同的服务地址。
<br>
## 资源压缩

在将项目资源发布到线上环境前，我们通常会进行代码压缩，或者叫 uglify，意思是移除空格并混淆代码，一般在压缩后代码体积会变小同时代码变得不可读，在一定程度上增加了安全性。
<br>
### 压缩 JavaScript 

Webpack 5 中已经集成了 terser-webpack-plugin 来压缩我们的代码，当我们在 webapck.config.js 中 mode 设置为 production 时，打包后的代码会被压缩。如果想自定义添加压缩配置，我们需要安装 [terser-webpack-plugin](https://www.npmjs.com/package/terser-webpack-plugin)，下面以删除代码中 console.log 为例。

安装 terser-webpack-plugin

```javascript
npm install terser-webpack-plugin -D
```

prod.config.js

```javascript
const TerserPlugin = require('terser-webpack-plugin');
...
module.exports = merge(commonConfig, {
  ...
  optimization: {
    // 在不设置 mode 的情况下，minimize 设置为 true 也会开启压缩
    // minimize: true,
    minimizer: [
      new TerserPlugin({
        terserOptions: {
          compress: {
            pure_funcs: ['console.log'],
          },
        },
      }),
    ],
  },
});
```

index.js

```javascript
const add = (a, b) => {
   return a + b
}
const addRes = add(3, 7);
const divElement = document.createElement('div');
divElement.innerHTML = addRes;
document.body.appendChild(divElement);
console.log(addRes);
```

执行打包命令后，可以看到生成的 bundle 文件中已经移除了 console.log 代码。
<br>
### 压缩 CSS

在压缩 CSS 文件之前，我们要先使用 MiniCssExtractPlugin 插件将样式文件提取出来，接着使用 [css-minimizer-webpack-plugin](https://github.com/webpack-contrib/css-minimizer-webpack-plugin) 插件进行压缩。

css-minimizer-webpack-plugin 插件开启压缩的配置方式也是传入到 minimizer 中，与 terser-webpack-plugin 类似，只是传入压缩插件本身的配置不同。

安装 css-minimizer-webpack-plugin

```javascript
npm install css-minimizer-webpack-plugin -D
```

prod.config.js

```javascript
...
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
module.exports = merge(commonConfig, {
  devtool: 'hidden-source-map',
  module: {
    rules: [
      {
        test: /\.css$/i,
        use: [
          {
            loader: MiniCssExtractPlugin.loader,
            options: {
              esModule: true,
            },
          },
          'css-loader',
        ],
      },
    ],
  },
  optimization: {
    minimizer: [
      new CssMinimizerPlugin(),
    ],
  },
  plugins: [new MiniCssExtractPlugin()],
});
```

index.js

```javascript
import styles from './index.css';
const divElement = document.createElement('div');
divElement.innerHTML = 'demo';
divElement.className = 'demo';
document.body.appendChild(divElement);
```

index.css

```css
.demo {
    color: red;
}
```

执行 npm run build，可以看到打包文件中的 index.css 文件内容已被压缩。
<br>
## 资源体积监控

在实际的项目开发中，webpack 打包的体积速度往往是我们比较关注的问题，我们可以通过打包后输出文件包的大小来分析每个模块的体积，但这种反向分析往往会花费很多时间。VS Code 中有一个插件 Import Cost 可以帮助我们持续监控引入模块（主要是node_module中的模块）的大小。它会为我们计算该模块压缩后及 gzip 后将占多大体积。

![1.png](https://pic.leetcode-cn.com/1658308914-XbQYTe-1.png)

当我们发现某些包过大就可以采取一些措施，比如 lodash 中只引入使用到的子模块。

另外一个很有用的工具是 [webpack-bundle-analyzer](https://github.com/webpack-contrib/webpack-bundle-analyzer)，它能帮助我们分析 bundle 的构成，webpack-bundle-analyzer 可以帮我们生成一张 bundle 的模块组成结构图，每个模块所占的体积一目了然。


安装 webpack-bundle-analyzer

```javascript
npm install webpack-bundle-analyzer -D
```

prod.config.js

```javascript
...
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
module.exports = merge(commonConfig, {
  ...
  plugins: [
    new BundleAnalyzerPlugin()
  ]
});
```

执行打包命令后，浏览器中会启动 bundle 组成结构图，包括各模块体积。 

最后我们还可以自动化的对资源体积进行监控，[bundlesize](https://github.com/siddharthkp/bundlesize) 可以帮我们做到这一点。

安装 bundlesize

```javascript
npm install bundlesize -D
```

package.json

```javascript
{
  ...
  "scripts": {
    "test": "bundlesize",
    "dev": "webpack --config dev.config.js",
    "build": "webpack  --config prod.config.js"
  },
  "bundlesize": [
    {
      "path": "./dist/index.js",
      "maxSize": "1 kB"
    }
  ],
}
```

执行 npm test 控制台中可以看到检测结果。

![2.png](https://pic.leetcode-cn.com/1658308914-tVnWpa-2.png)
<br>
# 总结

本章我们介绍了在生产环境下可以做哪些配置。我们介绍了使用配置文件区分环境、传入不同环境变量、如何开启压缩并且如何做自定义压缩、监控输出资源体积等方法。对于使用的插件都只是简单介绍了如何使用，详细的配置可以参照官网。


# 优化


## Tree Shaking
#  tree-shaking

所谓 tree-shaking 就是 “摇树” 的意思，可以将应用程序想象成一棵树。绿色表示实际用到的 source code(源码) 和 library(库)，是树上活的树叶。灰色表示未引用代码，是秋天树上枯萎的树叶。为了除去死去的树叶，你必须摇动这棵树，使它们落下。

```text
tree shaking 是一个术语，通常用于描述移除 JavaScript 上下文中的未引用代码(dead-code)。它依赖于 ES2015 模块语法的静态结构特性，例如 import 和 export。这个术语和概念实际上是由 ES2015 模块打包工具 rollup 普及起来的。

webpack 2 正式版本内置支持 ES2015 模块（也叫做 harmony modules）和未使用模块检测能力。新的 webpack 4 正式版本扩展了此检测能力，通过 package.json 的 "sideEffects" 属性作为标记，向 compiler 提供提示，表明项目中的哪些文件是 "pure(纯正 ES2015 模块)"，由此可以安全地删除文件中未使用的部分。
```
<br>
## 例子

tree shaking 会在编译过程中将未使用的代码进行标记，在 uglify 时移除被标记的无效代码，在 mode 设置为 production 时，webpack 会开启压缩和 tree-shaking 等优化，下面的例子如果配置为生产模式，打包后未使用的引用会被移除掉。

1、将 mode 设置为 none（不使用任何打包优化），optimization 配置中增加 usedExports 。

index.js

```javascript
// add 只是导入没有使用
import { add } from './util.js';

const divElement = document.createElement('div');
divElement.innerHTML = addRes;
divElement.className = 'demo';
document.body.appendChild(divElement);
```

util.js

```javascript
// 导出 add 函数
export const add = (a, b) => {
   return a + b
}
```

webpack.config.js

```javascript
...
module.exports = {
  ...
  mode: 'none', // 不使用任何默认优化选项
  optimization: {
    // 告诉 Webpack 去决定每一个模块所用到的导出
    usedExports: true,
  },
};
```

执行打包命令后，查看 dist/index.js 中的代码。可以看到 index.js 中只做了导入但是没有调用的方法 add 被打了 unused harmony export 的注释。

![1.png](https://pic.leetcode-cn.com/1658133349-fQAuwK-1.png)
2、package.json 中增加 sideEffects: false

```javascript
  "sideEffects": false,
```

webpack.config.js 中移除 optimization 配置，index.js 与 util.js 中内容不变，执行打包命令后，可以看到打包后的 index.js 中 add 函数已经被移除。

![2.png](https://pic.leetcode-cn.com/1658133349-VbRkfR-2.png)
<br>
## sideEffects 与 usedExports

在了解上面两个参数区别之前，我们先来看下函数的副作用。

```text
函数副作用是指函数在正常工作任务之外对外部环境所施加的影响。具体地说，函数副作用是指函数被调用，完成了函数既定的计算任务，但同时因为访问了外部数据，尤其是因为对外部数据进行了写操作，从而一定程度地改变了系统环境。
```

在上面例子中我们在 index.js 中导入的 util.js 中导出了一个 add 函数，我们来看下这个函数。

```javascript
export const add = (a, b) => {
  return a + b
}
```

add 函数中接收了 a 和 b 两个参数，函数体中返回了 a 与 b 的和，此函数返回的结果只依赖于传入的值并且没有其他影响，如修改全局变量等操作，则此函数即为无副作用函数。

```javascript
export const add = (a, b) => {
  window.userName = '***'
  return a + b
}
```

上面的 add 函数除了返回了 a 与 b 的和的同时还修改了 window对象中属性的值，则此函数即为有副作用的函数。

简单了解了函数副作用，我们来看下 sideEffects 和 usedExports（更多被认为是 tree shaking）的两种不同的优化方式。

- usedExports 依赖于 terser 去检测语句中的副作用，对未使用的函数增加标记，之后交由压缩工具去移除死代码。

webpack.config.js

```javascript
...
module.exports = {
  ...
  mode: 'none', // 不使用任何默认优化选项
  optimization: {
    // 告诉 Webpack 去决定每一个模块所用到的导出
    usedExports: true,
    // 开启压缩
    minimize: true
  },
};
```

index.js 与 util.js 内容保持不变，在 webpack.config.js 的 optimization 配置中增加参数 minimize 为 true，打包成功后查看输出文件，可以看到之前被打了 unused harmony export 注释的代码被移除掉了。

下面我们来写一个带有副作用的方法，看看 usedExports 会如何处理。

index.js

```javascript
import './util.js';

const divElement = document.createElement('div');
divElement.innerHTML = 'demo';
divElement.className = 'demo';
document.body.appendChild(divElement);
```

util.js

```javascript
Array.prototype.custom = function () {
  console.log('custom');
};
export const add = (a, b) => {
  return a + b;
};
``` 

util.js 中修在 Array 原型链上增加了方法，所以是  util.js 是有副作用的，在 index.js 中我们不只导入 add 方法而是导入整个 util.js 文件，执行打包命令后可以查看 dist/index.js 文件中 add 方法已被删除，有副作用的部分依然在打包文件中。

![3.png](https://pic.leetcode-cn.com/1658133349-ptzduw-3.png)

- sideEffects 更为有效 是因为它允许跳过整个模块/文件和整个文件子树

在一个纯粹的 ESM 模块世界中，很容易识别出哪些文件有副作用。然而，我们的项目无法达到这种纯度，所以，此时有必要提示 webpack compiler 哪些代码是“纯粹部分”。

通过 package.json 的 "sideEffects" 属性，来实现这种方式。如果所有代码都不包含副作用，我们就可以将 sideEffects 标记为 false，来告诉 webpack 它可以跳过安全检测删除未用到的 export。

依然使用上面包含副作用的代码。来看下增加 sideEffects: false 的效果。

package.json

```json
{
  // ...
  "sideEffects": false,
  // ...
}
```

webpack.config.js

```javascript
module.exports = {
  mode: 'none',
  entry: {
    index: './src/index.js',
  },
  output: {
    path: path.join(__dirname, 'dist'),
    filename: '[name].js',
  }
};
```

执行打包命令后查看 dist/index.js 文件，可以看到包含副作用的代码也被移除，即 util.js 导入部分被全部移除。

项目中包含副作用的函数被移除在打包后会导致部分功能不可用，所以 sideEffects 支持传入参数，告知 webpack 传入的文件包含副作用不要移除。

上面的例子中修改 package.json 的配置，将包含副作用的文件传入进去。此数组支持简单的 glob 模式匹配相关文件。其内部使用了 glob-to-regexp（支持：*，**，{a,b}，[a-z]）。如果匹配模式为 *.css，且不包含 /，将被视为 **/\*.css。

package.json

```json
{
 // ...
  "sideEffects": ["./src/util.js" ], 
 // ...
}
```

执行打包命令后查看输出文件，可以看到只有导入但是没使用的 add 函数和 Array 方法都被保留了下来。

![4.png](https://pic.leetcode-cn.com/1658133349-FHjQKm-4.png)
<br>
## tree shaking 开启条件

tree shaking 需要使用 ES2015 模块语法（即 import 和 export）才能生效，有时我们会发现只引用了某个库中的一个方法，却把整个库都加载进来了，同时 bundle 的体积也并没有因为 tree shaking 而减少。这可能是该库不是使用 ESModule 模式导出的，所以在使用某个库时，我们尽量引入 es 版，按需加载，这样 tree shaking 才能将无用代码删除掉。

<br>
# 总结

为了利用 tree shaking 的优势， 我们必须

- 使用 ES2015 模块语法（即 import 和 export）。
- 确保没有编译器将您的 ES2015 模块语法转换为 CommonJS 的（顺带一提，这是现在常用的 @babel/preset-env 的默认行为，详细信息请参阅文档）。
- 在项目的 package.json 文件中，添加 "sideEffects" 属性。
- 使用 mode 为 "production" 的配置项以启用更多优化项，包括压缩代码与 tree shaking。

## 代码分离及懒加载
# 代码分离及懒加载

前端性能优化一直是围绕在每一个前端周围的话题，减少网络请求、减少加载 bundle 体积、外部资源放在 CDN 等等。对于性能优化 webpack 也提供了一些手段。下面让我们来了解下代码分离、缓存和懒加载。
<br>
## 代码分离

代码分离是 webpack 最引人注目的特性之一，试想如果项目中所有代码都打包到一个 bundle 中，那 bundle 的体积将会变大，这对首次访问页面来说，加载资源的请求时间会变长，将影响用户体验。所以前端性能优化的一个方向是将代码按照一定规则拆分到不同的 bundle 中，触发不同的功能加载不同的资源，这样除了减少资源体积外还能增快请求响应速度。不过拆分的粒度大小还是要看实际的项目需求，无限拆分资源包也会造成资源请求过多。所以对于代码分离我们要结合项目情况合理使用，这会极大影响加载时间。

常用的代码分离方法有三种：

- 入口分离：使用 entry 配置手动地分离代码。
- 去重分离：使用 Entry dependencies 或者 SplitChunksPlugin 去重和分离 chunk。
- 动态导入：通过模块的内联函数调用来分离代码。
<br>
### 入口分离

入口分离即从 webpack 入口文件配置处分离 bundle。这种分离方式根据项目的多个入口拆分出多个 bundle，这是所有分离方式中最简单的分离方式，不过这种方式也存在弊端即 输出的 bundle 会同时包含导入的三方依赖代码（重复代码），在后面的分离方式讲解中会解决这个问题。我们先来看看入口分离的例子。

src/index.js

index.js 文件中引入依赖包 lodash 的 join 方法。创建 div 标签并将内容添加到 body 中。

```javascript
import { join } from 'lodash';
const divElement = document.createElement('div');
divElement.innerHTML = join(['hello', 'index'], '-');
document.body.appendChild(divElement);
```

src/main.js

main.js 文件中同样引入依赖包 lodash 的 join 方法。创建 div 标签并将内容添加到 body 中，只是展示内容与 index.js 不一致。

```javascript
import { join } from 'lodash';
const divElement = document.createElement('div');
divElement.innerHTML = join(['hello', 'main'], '-');
document.body.appendChild(divElement);
```

webpack.config.js

在 entry 配置中传入两个入口，chunk 的名字分别是 index 和 main。

```javascript
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
...

module.exports = {
  mode: 'development',
  entry: {
    index: './src/index.js',
    main: './src/main.js'
  },
  output: {
    path: path.join(__dirname, 'dist'),
    filename: '[name].js',
  },
  plugins: [
    ...
    new HtmlWebpackPlugin({
      template: './index.html',
    }),
  ],
};
```

执行打包命令后，在 dist 文件夹下可以看到，同时输出了 mian.js 和 index.js 文件，通过配置 entry 实现了代码分离。我们分别打开 dist/index.js 和 dist/main.js 后可以看到两个 bundle 中都包含了 lodash 的源码。

![1.png](https://pic.leetcode-cn.com/1658133449-RzyRnm-1.png)
<br>
### 去重分离

在入口分离的基础上，我们继续优化将重复的部分单独分离出一个 bundle，在 entry 中配置 dependOn 选项，这样可以在多个 chunk 之间共享模块。

webpack.config.js

在 entry 配置中将两个入口文件按照对象的形式定义，除定义入口之外，增加了一个 dependOn 选项，传入的 vendor 为共享模块的 chunk 名称。

```javascript
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
...

module.exports = {
 ...
 entry: {
    index: {
      import: './src/index.js',
      dependOn: 'vendor',
    },
    main: {
      import: './src/main.js',
      dependOn: 'vendor',
    },
    vendor: 'lodash'
  },
};
```

执行打包命令后，在 dist 文件夹下除了两个入口文件外还多了一个 vendor.js 文件，文件的内容即为 lodash 源码。HtmlWebpackPlugin 插件将三个 js 文件都注入到了 index.html 中。项目可以正常运行。

通过在入口配置 dependOn 属性，虽然可以实现公共代码抽离，但是还存在一个问题是，在我们的项目中会有很多公共代码，难道我们要手动的都添加到 dependOn 中吗？这将会增加非常多的工作量并且容易出错。这时我们可以考虑使用 webpack 的 SplitChunksPlugin 插件了。
<br>
#### SplitChunksPlugin

[SplitChunksPlugin](https://webpack.docschina.org/plugins/split-chunks-plugin) 插件不需要单独安装，是 webpack 提供的开箱即用的插件。我们通过 optimization 配置即可。

默认情况下，SplitChunksPlugin 它只会影响到按需加载的 chunks，不过我们可以通过传入 chunks 属性不同变量来决定影响哪些 chunk 。

webpack 将根据以下条件自动拆分 chunks：

- 新的 chunk 可以被共享，或者模块来自于 node_modules 文件夹
- 新的 chunk 体积大于 20kb（在进行压缩和 gzip 之前的体积）
- 当按需加载 chunks 时，并行请求的最大数量小于或等于 30
- 当加载初始化页面时，并发请求的最大数量小于或等于 30

我们使用 SplitChunksPlugin 来拆分下上个例子中的 lodash，关于 SplitChunksPlugin 的各项配置参数含义，感兴趣的伙伴可以查看[官网](https://webpack.docschina.org/plugins/split-chunks-plugin)

webpack.config.js

```javascript
...

module.exports = {
  entry: {
    index: './src/index.js',
    main: './src/main.js',
  },
  optimization: {
    splitChunks: {
      // 设置为 all 意味着 chunk 可以在异步和非异步 chunk 之间共享
      chunks: 'all',
    },
  },
  ...
};
```

执行打包命令后，在 dist 文件夹下可以看到除了 index.js 和 main.js 外还输出了一个文件，打开文件可以看到内容正是 lodash。

![2.png](https://pic.leetcode-cn.com/1658133449-TQNPfm-2.png)
<br>
## 动态导入

动态导入也叫资源异步加载，当模块数量过多时，可以把一些暂时用不到的模块延迟加载，以此来减少用户初次加载页面的体积，后续模块等到恰当的时机再去加载，因此也把这种加载方式叫懒加载。

在 webpack 中提供了两种类似的技术来实现动态加载。import 函数及 require.ensure。require.ensure 是 Webpack 1 支持的异步加载方式，从 Webpack 2 开始引入了 import 函数，并且官方更推荐使用 import 函数的方式实现异步加载，因此下面我们只介绍 import 函数的使用。

通过 import 函数加载的模块会被异步的进行加载，并且返回一个 Primise 对象。

main.js

```javascript
export const add = (a, b) => {
  console.log(a + b);
}
```

index.js

index 文件中通过 import 函数导入 main 文件内容并赋值给 addFunc，在 index 中通过 setTimeout 定时任务 2 秒钟后执行 addFunc 回调函数，在回调函数返回值中通过 ES6 的对象解构语法获取到 add 函数。

```javascript
const addFunc = import('./main');

setTimeout(() => {
  addFunc.then(({add}) => {
    add(3, 8);
  });
}, 2000);
```

webpack.config.js

```javascript
...

module.exports = {
  mode: 'development',
  entry: {
    index: './src/index.js'
  },
  output: {
    path: path.join(__dirname, 'dist'),
    filename: '[name].js',
  },
  ...
};
```

通过 webpack.config.js 配置我们可以看到入口文件只有 index.js，执行打包命令后在生成的 dist 文件夹中可以看到除了入口文件 index.js 外，还生成了一个 src_main_js.js 的文件，内容即为 src/main.js 中内容对应的编译后代码。

通过 import 函数异步加载文件也可以实现拆分代码的功能，这种方式在实际的项目开发中非常实用，非主页面加载的内容都可以通过 import 函数动态加载，在点击到对应页面时在加载相应资源。

上面的例子中还可以进一步优化下异步加载文件的 chunk 名称。其他配置不变，我们修改下 import 导入函数部分。


index.js

```javascript
const addFunc = import(/* webpackChunkName: "main" */ './main');

setTimeout(() => {
  addFunc.then(({add}) => {
    add(3, 8);
  });
}, 2000);
```

通过在 import 函数中增加注释 /* webpackChunkName: "main" */  其中的 main 即为生成的 chunk 名称。这样在项目中通过定义语义化的名称，可以增加代码的可读性。

![3.png](https://pic.leetcode-cn.com/1658133449-eDWOYE-3.png)

<br>
# 总结

上面的示例中，我们总结了代码分离的几种方式，分别是入口分离、去重分离、动态导入，其中的动态导入就是我们常说的懒加载。代码分离对于减少主包体积，优化项目加载速度，减少白屏时间来说将非常有用。

