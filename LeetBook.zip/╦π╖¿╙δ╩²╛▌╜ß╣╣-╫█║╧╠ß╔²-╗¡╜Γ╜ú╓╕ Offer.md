
# 画在前面
![宣传视频.mp4](a5ee89e5-2ff7-4805-b75e-ec30d427ad3f)

# 数组和字符串
<p><a href="/circle/discuss/X6Oj0x/"><img alt="画解剑指 Offer" src="https://pic.leetcode-cn.com/b04af6fd9c21f097f14418471f5fea7c35ae9ecfcdc4805b5a8af2807a0ebaa8-leetbook_discussion.png" style="height: 80px;" /></a></p>

## 剑指 Offer 04. 二维数组中的查找

>https://leetcode.cn/problems/er-wei-shu-zu-zhong-de-cha-zhao-lcof/
<p>在一个 n * m 的二维数组中，每一行都按照从左到右&nbsp;<strong>非递减&nbsp;</strong>的顺序排序，每一列都按照从上到下&nbsp;<strong>非递减&nbsp;</strong>的顺序排序。请完成一个高效的函数，输入这样的一个二维数组和一个整数，判断数组中是否含有该整数。</p>

<p>&nbsp;</p>

<p><strong>示例:</strong></p>

<p>现有矩阵 matrix 如下：</p>

<pre>
[
  [1,   4,  7, 11, 15],
  [2,   5,  8, 12, 19],
  [3,   6,  9, 16, 22],
  [10, 13, 14, 17, 24],
  [18, 21, 23, 26, 30]
]
</pre>

<p>给定 target&nbsp;=&nbsp;<code>5</code>，返回&nbsp;<code>true</code>。</p>

<p>给定&nbsp;target&nbsp;=&nbsp;<code>20</code>，返回&nbsp;<code>false</code>。</p>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>0 &lt;= n &lt;= 1000</code></p>

<p><code>0 &lt;= m &lt;= 1000</code></p>

<p>&nbsp;</p>

<p><strong>注意：</strong>本题与主站 240 题相同：<a href="https://leetcode-cn.com/problems/search-a-2d-matrix-ii/">https://leetcode-cn.com/problems/search-a-2d-matrix-ii/</a></p>


### 剑指 Offer 04. 二维数组中的查找 - 解决方案
## 题目描述

在一个 `n * m` 的二维数组中，每一行都按照从左到右递增的顺序排序，每一列都按照从上到下递增的顺序排序。请完成一个函数，输入这样的一个二维数组和一个整数，判断数组中是否含有该整数。

**示例：**

现有矩阵 matrix 如下：

```
[
  [1,   4,  7, 11, 15],
  [2,   5,  8, 12, 19],
  [3,   6,  9, 16, 22],
  [10, 13, 14, 17, 24],
  [18, 21, 23, 26, 30]
]
```

给定 target = `5`，返回  `true`。

给定  target = `20`，返回  `false`。

**限制：**

`0 <= n <= 1000`

`0 <= m <= 1000`

## 解题方案

### 思路

- 标签：数组遍历
- 从矩阵的左下角看，上方的数字都比其小，右方的数字都比其大，所以依据该规律去判断数字是否存在
- 设当前数字为 `cur`，目标数字为 `target`，当 `target` < `cur` 时，`cur` 更新为其上面的数字，当 `target` > `cur` 时，`cur` 更新为其右侧的数字，直到相等则返回 `true`，否则到了矩阵边界返回 `false`
- 时间复杂度：$O(m+n)$

### 代码

```Java []
class Solution {
    public boolean findNumberIn2DArray(int[][] matrix, int target) {
        if(matrix.length == 0)
            return false;

        int x = 0;
        int y = matrix.length - 1;

        while(x < matrix[0].length && y >= 0){
            if(matrix[y][x] > target) {
                y--;
            } else if(matrix[y][x] < target) {
                x++;
            } else {
                return true;
            }
        }

        return false;
    }
}
```

```JavaScript []
/**
 * @param {number[][]} matrix
 * @param {number} target
 * @return {boolean}
 */
var findNumberIn2DArray = function(matrix, target) {
    if(matrix.length == 0)
        return false;

    let x = 0;
    let y = matrix.length - 1;

    while(x < matrix[0].length && y >= 0){
        if(matrix[y][x] > target) {
            y--;
        } else if(matrix[y][x] < target) {
            x++;
        } else {
            return true;
        }
    }

    return false;
};
```

### 画解
<![offer4-1.png](https://pic.leetcode-cn.com/658d813d066d465f5eacc438aba4869420eb7b106776d49c5ca0b8cf16383a30-offer4-1.png),![offer4-2.png](https://pic.leetcode-cn.com/d5a3779eee525105ae3e710067d6eaddf3a6e1cf3ff926d40999ab0dedc49235-offer4-2.png),![offer4-3.png](https://pic.leetcode-cn.com/a35261ece9305b6c26fe5c5cc9e7a6a05cf3a089c8c42e23b34419bdbaa6e2ae-offer4-3.png),![offer4-4.png](https://pic.leetcode-cn.com/b35d069471580e3964b0b35f74d3bd1596847b9973b47b6c1f4584a164ca6a59-offer4-4.png),![offer4-5.png](https://pic.leetcode-cn.com/529eed89e648eaeffa1d3b535558136820ac622903aaef4ef27b5761cb6e2176-offer4-5.png),![offer4-6.png](https://pic.leetcode-cn.com/d39d3fbfc5a38b1c507fcc5d5820289b0e3f1e00dbd431cb7d15ac8d4860b14f-offer4-6.png),![offer4-7.png](https://pic.leetcode-cn.com/29aa17d172d475e671987c2d2987a94d759a5ebe04f5d995f8eb67b15a5953a6-offer4-7.png),![offer4-8.png](https://pic.leetcode-cn.com/520e1ae66d16f74a6f5dcb30a0dc8cde7a2de14b303b8e374dd7a445c507d5ff-offer4-8.png),![offer4-9.png](https://pic.leetcode-cn.com/a1d26479cef18a3b60c655dbe6b93c1f39bba2594308024bb3e351a248e7d3fb-offer4-9.png),![offer4-10.png](https://pic.leetcode-cn.com/ca753e6e1f9c34489b1f02b6b69c98decd7cfda166472397463f11b233e1ddfe-offer4-10.png)>


## 剑指 Offer 05. 替换空格

>https://leetcode.cn/problems/ti-huan-kong-ge-lcof/
<p>请实现一个函数，把字符串 <code>s</code> 中的每个空格替换成&quot;%20&quot;。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>s = &quot;We are happy.&quot;
<strong>输出：</strong>&quot;We%20are%20happy.&quot;</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>0 &lt;= s 的长度 &lt;= 10000</code></p>


### 剑指 Offer 05. 替换空格 - 解决方案
## 题目描述

请实现一个函数，把字符串 s 中的每个空格替换成"%20"。

示例 1：

```bash
输入：s = "We are happy."
输出："We%20are%20happy."
```

限制：

`0 <= s 的长度 <= 10000`

## 解题方案

### 思路

- 标签：字符串
- 最简单的方案自然是直接使用库函数啦！当然题目肯定是不希望我们这样做的！
- 增加一个新字符串，遍历原来的字符串，遍历过程中，如果非空格则将原来的字符直接拼接到新字符串中，如果遇到空格则将`%20`拼接到新字符串中
- 时间复杂度：$O(n)$，空间复杂度：$O(n)$

### 代码

```Java []
class Solution {
    public String replaceSpace(String s) {
        StringBuilder sb = new StringBuilder();
        for(int i = 0 ; i < s.length(); i++){
            char ch = s.charAt(i);
            if(ch == ' ') {
                sb.append("%20");
            }
            else {
                sb.append(ch);
            }
        }
        return sb.toString();
    }
}
```

```JavaScript []
/**
 * @param {string} s
 * @return {string}
 */
var replaceSpace = function(s) {
    let res = '';
    for(let i = 0 ; i < s.length; i++){
        const ch = s[i];
        if(ch == " ") {
            res += "%20";
        }
        else {
            res += ch;
        }
    }
    return res;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/02595f80a03e121b0655d469c15b9896def8d63733aaf3ac57e4f9e1858cd898-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/e8bec4f66bca843407079984bf383bdac1afba40e956289c605f939986cd596f-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/c7995803bdc651c8c3b237b8bbf4d0bf5069f10e1659543c2bee17be1d00b9bc-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/d337e3e2dce0aa3a2b550fdb8214b6280f983fd027572e2fb407b089da4951fb-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/39f1a8d848eb9cd52c48cbf61fca6d83ead5c0876c3dbb339032dcee9e6acd09-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/9dbe21a8b3ccf42f5207431412ea168917a4c5359f8a0ae3f02ba6a60ae4f657-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/4e7235dd81552c21ead248afbfcd2da7026c08a7743e4c4ab5cfd1555d6cfe9f-frame_00007.png)>


## 剑指 Offer 11. 旋转数组的最小数字

>https://leetcode.cn/problems/xuan-zhuan-shu-zu-de-zui-xiao-shu-zi-lcof/
<p>把一个数组最开始的若干个元素搬到数组的末尾，我们称之为数组的旋转。</p>

<p>给你一个可能存在&nbsp;<strong>重复</strong>&nbsp;元素值的数组&nbsp;<code>numbers</code>&nbsp;，它原来是一个升序排列的数组，并按上述情形进行了一次旋转。请返回旋转数组的<strong>最小元素</strong>。例如，数组&nbsp;<code>[3,4,5,1,2]</code> 为 <code>[1,2,3,4,5]</code> 的一次旋转，该数组的最小值为 1。&nbsp;&nbsp;</p>

<p>注意，数组 <code>[a[0], a[1], a[2], ..., a[n-1]]</code> 旋转一次 的结果为数组 <code>[a[n-1], a[0], a[1], a[2], ..., a[n-2]]</code> 。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre>
<strong>输入：</strong><code>numbers = </code>[3,4,5,1,2]
<strong>输出：</strong>1
</pre>

<p><strong>示例 2：</strong></p>

<pre>
<strong>输入：</strong><code>numbers = </code>[2,2,2,0,1]
<strong>输出：</strong>0
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>n == numbers.length</code></li>
	<li><code>1 &lt;= n &lt;= 5000</code></li>
	<li><code>-5000 &lt;= numbers[i] &lt;= 5000</code></li>
	<li><code>numbers</code> 原来是一个升序排序的数组，并进行了 <code>1</code> 至 <code>n</code> 次旋转</li>
</ul>

<p>注意：本题与主站 154 题相同：<a href="https://leetcode-cn.com/problems/find-minimum-in-rotated-sorted-array-ii/">https://leetcode-cn.com/problems/find-minimum-in-rotated-sorted-array-ii/</a></p>


### 剑指 Offer 11. 旋转数组的最小数字 - 解决方案
## 题目描述

把一个数组最开始的若干个元素搬到数组的末尾，我们称之为数组的旋转。输入一个递增排序的数组的一个旋转，输出旋转数组的最小元素。例如，数组 `[3,4,5,1,2]` 为 `[1,2,3,4,5]` 的一个旋转，该数组的最小值为1。  

示例 1：

```text
输入：[3,4,5,1,2]
输出：1
```

示例 2：

```text
输入：[2,2,2,0,1]
输出：0
```

注意：本题与主站 [154 题](https://leetcode-cn.com/problems/find-minimum-in-rotated-sorted-array-ii/) 相同

## 解题方案

### 思路

- 标签：二分查找
- 整体思路：首先数组是一个有序数组的旋转，从这个条件可以看出，数组是有大小规律的，可以使用二分查找利用存在的规律快速找出结果
- 时间复杂度：$O(logn)$，空间复杂度：$O(1)$

### 算法流程

1. 初始化下标 `left` 和 `right`
2. 每次计算中间下标 `mid = (right + left) / 2​`，这里的除法是取整运算，不能出现小数
3. 当 `numbers[mid] < numbers[right]​` 时，说明最小值在 ​`[left, mid]​` 区间中，则令 `right = mid`，用于下一轮计算
4. 当 `numbers[mid] > numbers[right]​` 时，说明最小值在 `[mid, right]​` 区间中，则令 `left = mid + 1`，用于下一轮计算
5. 当 `numbers[mid] == numbers[right]​` 时，无法判断最小值在哪个区间之中，此时让 `right--`，缩小区间范围，在下一轮进行判断

- 为什么是 `right--` 缩小范围，而不是 `left++`？
  - 因为数组是升序的，所以最小值一定靠近左侧，而不是右侧
  - 比如，当存在 `[1,2,2,2,2]` 这种情况时，`left = 0`，`right = 4`，`mid = 2`，数值满足 `numbers[mid] == numbers[right]` 这个条件，如果 `left++`，则找不到最小值


### 代码

```Java []
class Solution {
    public int minArray(int[] numbers) {
        int left = 0;
        int right = numbers.length - 1;
        while (left < right) {
            int mid = (right + left) / 2;
            if (numbers[mid] < numbers[right]) {
                right = mid;
            } else if (numbers[mid] > numbers[right]) {
                left = mid + 1;
            } else {
                right --;
            }
        }
        return numbers[left];
    }
}
```

```JavaScript []
/**
 * @param {number[]} numbers
 * @return {number}
 */
var minArray = function(numbers) {
    let left = 0;
    let right = numbers.length - 1;
    while (left < right) {
        let mid = parseInt((right + left) / 2);
        if (numbers[mid] < numbers[right]) {
            right = mid;
        } else if (numbers[mid] > numbers[right]) {
            left = mid + 1;
        } else {
            right --;
        }
    }
    return numbers[left];
};
```

### 画解

<![offer11-1.png](https://pic.leetcode-cn.com/cadf6df725a5e808fe1304e938ee474ff9c857ebf8e99cd64ed4e34d87526f15-offer11-1.png),![offer11-2.png](https://pic.leetcode-cn.com/6a8f648c6a358ef5610a3294887bc06b18259ce2478837378d6b0e18ae035e52-offer11-2.png),![offer11-3.png](https://pic.leetcode-cn.com/562612db6bcdf4e12d98779bc957959fe9c46eeaabc53510c48baa54a2cca962-offer11-3.png),![offer11-4.png](https://pic.leetcode-cn.com/99d63015d327b09d60c95d72d46fd503420b9616e928457a108c2347a14fad57-offer11-4.png),![offer11-5.png](https://pic.leetcode-cn.com/9c5f31972cbb2892d815b5c301178f58d6dfd622586117ab41807c4193d8da3a-offer11-5.png),![offer11-6.png](https://pic.leetcode-cn.com/c45be77b72986b4566c58dbb4b05ee0141d53bff4014dbadd13d60be2d5380b7-offer11-6.png),![offer11-8.png](https://pic.leetcode-cn.com/44c4ece7b97857e8d4b5bfd23fe69d4f98c442c71197bdc500d8e755b4db8f5e-offer11-8.png)>

### 花絮

![offer11.mp4](8c648154-a2d0-4ec1-8708-876e9a97bd9f)


## 剑指 Offer 17. 打印从 1 到最大的 n 位数

>https://leetcode.cn/problems/da-yin-cong-1dao-zui-da-de-nwei-shu-lcof/
<p>输入数字 <code>n</code>，按顺序打印出从 1 到最大的 n 位十进制数。比如输入 3，则打印出 1、2、3 一直到最大的 3 位数 999。</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入:</strong> n = 1
<strong>输出:</strong> [1,2,3,4,5,6,7,8,9]
</pre>

<p>&nbsp;</p>

<p>说明：</p>

<ul>
	<li>用返回一个整数列表来代替打印</li>
	<li>n 为正整数</li>
</ul>


### 剑指 Offer 17. 打印从 1 到最大的 n 位数 - 解决方案
## 题目描述

输入数字 `n`，按顺序打印出从 1 到最大的 `n` 位十进制数。比如输入 3，则打印出 1、2、3 一直到最大的 3 位数 999。

示例 1:

```
输入: n = 1
输出: [1,2,3,4,5,6,7,8,9]
```

说明：

- 用返回一个整数列表来代替打印
- `n` 为正整数

## 解题方案

### 思路 1

- 标签：数组
- 整体思路：首先求出要打印的数字范围，然后再从 1 开始打印到最大的数字
- 时间复杂度：$O(10^n)$，空间复杂度：$O(10^n)$

### 算法流程 1

1. 初始化 `sum = 1`
2. 循环遍历乘 10 让 `sum` 变为边界值
3. 新建 `res` 数组，大小为 `sum-1`
4. 从 1 开始打印，直到 `sum-1` 为止

### 代码 1
```Java []
class Solution {
    public int[] printNumbers(int n) {
        int sum = 1;
        for (int i = 0; i < n; i++) {
            sum *= 10;
        }
        int[] res = new int[sum - 1];
        for(int i = 0; i < sum - 1; i++){
            res[i] = i + 1;
        }
        return res;
    }
}
```

```JavaScript []
/**
 * @param {number} n
 * @return {number[]}
 */
var printNumbers = function(n) {
    let sum = 1;
    for (let i = 0; i < n; i++) {
        sum *= 10;
    }
    let res = [];
    for(let i = 0; i < sum - 1; i++){
        res[i] = i + 1;
    }
    return res;
};
```

### 思路 2

- 标签：字符串
- 整体思路：原题的题意其实是希望考察大数计算，因为 int 数组有可能会溢出，所以用字符串处理可以保证一定不会溢出，但是呢，由于返回值规定是 int 数组，所以其实从返回值上来看，是一定不会溢出的，比较矛盾。所以给出个思路 2，学习下如何用字符串处理大数即可，不用特别纠结溢出这件事情
- 时间复杂度：$O(10^n)$，空间复杂度：$O(10^n)$

### 算法流程 2

1. 初始化字符串 `str`，另其初始值为 n-1 个 "0"
2. 递增 `str`，使用字符去递增，递增过程中判断是否存在进位，存在进位则进位处 +1，直到达到最大值为止，结束循环
3. 每获取到一个值之后，遍历前方多余的 `"0"`，将多余的 `"0"` 去掉，转换为 int 存到结果数组中

### 代码 2

```Java []
class Solution {
    public int[] printNumbers(int n) {
        int[] res = new int[(int)Math.pow(10, n) - 1];
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < n; i++) {
            str.append('0');
        }
        int count = 0;
        while(!increment(str)){
            int index = 0;
            while (index < str.length() && str.charAt(index) == '0'){
                index++;
            }
            res[count] = Integer.parseInt(str.toString().substring(index));
            count++;
        }
        return res;
    }

    public boolean increment(StringBuilder str) {
        boolean isCarry = false;
        for (int i = str.length() - 1; i >= 0; i--) {
            char s = (char)(str.charAt(i) + 1);
            if (s > '9') {
                str.replace(i, i + 1, "0");
                if (i == 0) {
                    isCarry = true;
                }
            }
            else {
                str.replace(i, i + 1, String.valueOf(s));
                break;
            }
        }
        return isCarry;
    }
}
```

### 画解 2
<![frame_00001.png](https://pic.leetcode-cn.com/01c4897d78f04f76fec17c1ddaa27de79f580b2b68ce5df253f7f04977f5babb-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/b840604732b77c9470a493298a928002b48fe4d379ce2644586d137f60ad395d-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/7f2e1ce60d3cb35c493325408f3f415a516490450a17c9863682f51e6d785fb3-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/202d397e4d3bf07d54047f10eae230dad7afdba79a8cd84bdadc8adc0cfff258-frame_00004.png)>


## 剑指 Offer 21. 调整数组顺序使奇数位于偶数前面

>https://leetcode.cn/problems/diao-zheng-shu-zu-shun-xu-shi-qi-shu-wei-yu-ou-shu-qian-mian-lcof/
<p>输入一个整数数组，实现一个函数来调整该数组中数字的顺序，使得所有奇数在数组的前半部分，所有偶数在数组的后半部分。</p>

<p>&nbsp;</p>

<p><strong>示例：</strong></p>

<pre>
<strong>输入：</strong>nums =&nbsp;[1,2,3,4]
<strong>输出：</strong>[1,3,2,4] 
<strong>注：</strong>[3,1,2,4] 也是正确的答案之一。</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ol>
	<li><code>0 &lt;= nums.length &lt;= 50000</code></li>
	<li><code>0 &lt;= nums[i] &lt;= 10000</code></li>
</ol>


### 剑指 Offer 21. 调整数组顺序使奇数位于偶数前面 - 解决方案
## 题目描述

输入一个整数数组，实现一个函数来调整该数组中数字的顺序，使得所有奇数位于数组的前半部分，所有偶数位于数组的后半部分。

示例：

```
输入：nums = [1,2,3,4]
输出：[1,3,2,4]
注：[3,1,2,4] 也是正确的答案之一。
```

提示：

1. `1 <= nums.length <= 50000`
2. `1 <= nums[i] <= 10000`

## 解题方案

### 思路

- 标签：双指针
- 整体思路：首先指定前指针 `start` 和后指针 `end`，然后前指针定位偶数，后指针定位奇数，定位到之后将两个值互换，直到数组遍历完成
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程

1. 初始化前指针 `start = 0`，后指针 `end = nums.length - 1`
2. 当 `start < end` 时表示该数组还未遍历完成，则继续进行奇数和偶数的交换
3. 当 `nums[start]` 为奇数时，则 `start++`，直到找到不为奇数的下标为止
4. 当 `nums[end]` 为偶数时，则 `end--`，直到找到不为偶数的下标为止
5. 交换 `nums[start]` 和 `nums[end]`，继续下一轮交换
6. 返回 `nums`，即为交换后的结果

### 代码

```Java []
class Solution {
    public int[] exchange(int[] nums) {
        int start = 0;
        int end = nums.length - 1;
        while(start < end) {
            while(start < end && (nums[start] % 2) == 1) {
                start++;
            }
            while(start < end && (nums[end] % 2) == 0) {
                end--;
            }
            int tmp = nums[start];
            nums[start] = nums[end];
            nums[end] = tmp;
        }
        return nums;
    }
}
```

```JavaScript []
/**
 * @param {number[]} nums
 * @return {number[]}
 */
var exchange = function(nums) {
    let start = 0;
    let end = nums.length - 1;
    while(start < end) {
        while(start < end && (nums[start] % 2) == 1) {
            start++;
        }
        while(start < end && (nums[end] % 2) == 0) {
            end--;
        }
        let tmp = nums[start];
        nums[start] = nums[end];
        nums[end] = tmp;
    }
    return nums;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/5b7f056cca458f1a86e4d901288c97d76a3e8304f853fee2ff0ee0569d862c24-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/4d465e99b4ceaef284ced115c20ce3a332831168bd6a55e1940043bafdc5f702-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/d0e29f073f9022b212cacc44fa2474a34634f9711e476a6731f807985b0c76f8-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/db17b0f64ff0b180ee33132b9d0bc033485f046d7419f4ca53efc280aa554159-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/4f516d2d59932b4373248d0d319f85626eba593e5911f9796b47bcaeaba76a3d-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/fac33c16d0cf4ea1be80355c4508b6bc2bb361ea631e2c79750964541b3a901a-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/9309b9a46c8ed89a0493e049df814e770af2e7305ecb82a77b149eae91ab24dd-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/e8622fb8c9a6037e55a4c56e5c9da431d780b1275fb0310afd45906a9772e323-frame_00008.png),![frame_00009.png](https://pic.leetcode-cn.com/482ac99e90853f8f100133a90ff3dfb9338405796bab2b1f2e23d49eb326e221-frame_00009.png),![frame_00010.png](https://pic.leetcode-cn.com/46d090ae1d06247159b7349e7f21506fe9513d6381917dc9c7c86d0ceba49e48-frame_00010.png),![frame_00011.png](https://pic.leetcode-cn.com/9c1080fd5e29b1276a00e1ae593fb40d885c72e7ec288367183fcf08e4af21f9-frame_00011.png)>


## 剑指 Offer 29. 顺时针打印矩阵

>https://leetcode.cn/problems/shun-shi-zhen-da-yin-ju-zhen-lcof/
<p>输入一个矩阵，按照从外向里以顺时针的顺序依次打印出每一个数字。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>matrix = [[1,2,3],[4,5,6],[7,8,9]]
<strong>输出：</strong>[1,2,3,6,9,8,7,4,5]
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>matrix =&nbsp;[[1,2,3,4],[5,6,7,8],[9,10,11,12]]
<strong>输出：</strong>[1,2,3,4,8,12,11,10,9,5,6,7]
</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<ul>
	<li><code>0 &lt;= matrix.length &lt;= 100</code></li>
	<li><code>0 &lt;= matrix[i].length&nbsp;&lt;= 100</code></li>
</ul>

<p>注意：本题与主站 54 题相同：<a href="https://leetcode-cn.com/problems/spiral-matrix/">https://leetcode-cn.com/problems/spiral-matrix/</a></p>


### 剑指 Offer 29. 顺时针打印矩阵 - 解决方案
## 题目描述

输入一个矩阵，按照从外向里以顺时针的顺序依次打印出每一个数字。

示例 1：

```text
输入：matrix = [[1,2,3],[4,5,6],[7,8,9]]
输出：[1,2,3,6,9,8,7,4,5]
```

示例 2：

```text
输入：matrix = [[1,2,3,4],[5,6,7,8],[9,10,11,12]]
输出：[1,2,3,4,8,12,11,10,9,5,6,7]
```

限制：

- `0 <= matrix.length <= 100`
- `0 <= matrix[i].length <= 100`

注意：本题与主站 [54 题](https://leetcode-cn.com/problems/spiral-matrix/) 相同

## 解题方案

### 思路

- 标签：二维数组
- 整体思路：循环遍历整个数组，循环中再嵌套四个循环，分别是从左至右，从上至下，从右至左，从下至上这几个方向，按照题意将整个数组遍历完成，控制好边界
- $m$ 为行数，$n$ 为列数，时间复杂度：$O(mn)$，空间复杂度：$O(1)$

### 算法流程

1. 题目中 `matrix` 有可能为空，直接返回空数组即可
2. 初始化边界 `left`、`right`、`top`、`bottom` 四个值，初始化结果数组 `res` 和数组下标 `x`
3. 按照遍历方向循环取出数字放入结果数组中

- 从左至右：遍历完成后 `++top`，如果 `top > bottom​`，到达边界循环结束
- 从上至下：遍历完成后 `--right`，如果 `left > right​`，到达边界循环结束
- 从右至左：遍历完成后 `--bottom`，如果 `top > bottom​`，到达边界循环结束
- 从下至上：遍历完成后 `++left`，如果 `left > right​`，到达边界循环结束

### 代码

```Java []
class Solution {
    public int[] spiralOrder(int[][] matrix) {
        if(matrix.length == 0) return new int[0];
        int left = 0, right = matrix[0].length - 1, top = 0, bottom = matrix.length - 1, x = 0;
        int[] res = new int[(right + 1) * (bottom + 1)];
        while(true) {
            for(int i = left; i <= right; i++) res[x++] = matrix[top][i];
            if(++top > bottom) break;
            for(int i = top; i <= bottom; i++) res[x++] = matrix[i][right];
            if(left > --right) break;
            for(int i = right; i >= left; i--) res[x++] = matrix[bottom][i];
            if(top > --bottom) break;
            for(int i = bottom; i >= top; i--) res[x++] = matrix[i][left];
            if(++left > right) break;
        }
        return res;
    }
}
```

```JavaScript []
/**
 * @param {number[][]} matrix
 * @return {number[]}
 */
var spiralOrder = function(matrix) {
    if(matrix.length == 0) return [];
    let left = 0, right = matrix[0].length - 1, top = 0, bottom = matrix.length - 1, x = 0;
    let res = [];
    while(true) {
        for(let i = left; i <= right; i++) res[x++] = matrix[top][i];
        if(++top > bottom) break;
        for(let i = top; i <= bottom; i++) res[x++] = matrix[i][right];
        if(left > --right) break;
        for(let i = right; i >= left; i--) res[x++] = matrix[bottom][i];
        if(top > --bottom) break;
        for(let i = bottom; i >= top; i--) res[x++] = matrix[i][left];
        if(++left > right) break;
    }
    return res;
};
```

### 画解

<![offer29-1.png](https://pic.leetcode-cn.com/51fba240d0dad03d1c6634c9fe7e7209e9d32d3ba2c90970dc5ac0bfafbdab91-offer29-1.png),![offer29-2.png](https://pic.leetcode-cn.com/2e60c5d9fcc15364d4c0ffcf6066f093f8f17712003081eee9bfca75bb67129f-offer29-2.png),![offer29-3.png](https://pic.leetcode-cn.com/8d339ca83408aade017a9b98f6631b53c28bc450dff5573003ccf829edf085a2-offer29-3.png),![offer29-4.png](https://pic.leetcode-cn.com/8dc4dc4f7466fb34ddf25921193c396476c85c4af188fbb80c6c08a0aef299d9-offer29-4.png),![offer29-5.png](https://pic.leetcode-cn.com/631d6b4a3637a1e38965f9af23ab0569b871136fa79bfdb284979424b232a356-offer29-5.png),![offer29-6.png](https://pic.leetcode-cn.com/93f0a14d78c9727686ba08f3634cadc99ca99c799e67b84dc82dc040a65aa085-offer29-6.png)>

### 花絮

![offer29.mp4](3fed7a9f-54aa-4264-b13f-912e0752c840)


## 剑指 Offer 39. 数组中出现次数超过一半的数字

>https://leetcode.cn/problems/shu-zu-zhong-chu-xian-ci-shu-chao-guo-yi-ban-de-shu-zi-lcof/
<p>数组中有一个数字出现的次数超过数组长度的一半，请找出这个数字。</p>

<p>&nbsp;</p>

<p>你可以假设数组是非空的，并且给定的数组总是存在多数元素。</p>

<p>&nbsp;</p>

<p><strong>示例&nbsp;1:</strong></p>

<pre><strong>输入:</strong> [1, 2, 3, 2, 2, 2, 5, 4, 2]
<strong>输出:</strong> 2</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>1 &lt;= 数组长度 &lt;= 50000</code></p>

<p>&nbsp;</p>

<p>注意：本题与主站 169 题相同：<a href="https://leetcode-cn.com/problems/majority-element/">https://leetcode-cn.com/problems/majority-element/</a></p>

<p>&nbsp;</p>


### 剑指 Offer 39. 数组中出现次数超过一半的数字 - 解决方案
## 题目描述

数组中有一个数字出现的次数超过数组长度的一半，请找出这个数字。

你可以假设数组是非空的，并且给定的数组总是存在多数元素。

示例  1:

```
输入: [1, 2, 3, 2, 2, 2, 5, 4, 2]
输出: 2
```

限制：

`1 <= 数组长度 <= 50000`

## 解题方案

### 思路

- 标签：摩尔投票
- 本题常见解法共有 3 种
  - 数组排序：首先将 `nums` 排序，由于该数字超过数组长度的一半，所以数组的中间元素就是答案，时间复杂度为 $O(nlogn)$
  - 哈希计数：遍历 `nums` 数组，将数字存在 `HashMap` 中，统计数字出现次数，统计完成后再遍历一次 `HashMap`，找到超过一半计数的数字，时间复杂度为 $O(n)$
  - 摩尔投票：遍历 `nums` 数组，使用 `count` 进行计数，记录当前出现的数字为 `cur`，如果遍历到的 `num` 与 `cur` 相等，则 `count` 自增，否则自减，当其减为 0 时则将 `cur` 修改为当前遍历的 `num`，通过增减抵消的方式，最终达到剩下的数字是结果的效果，时间复杂度为 $O(n)$
- 摩尔投票是最优解法，时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程

1. 初始化：预期结果 `cur = 0` 和计数器 `count = 0`
2. 遍历数组 `nums`，遍历过程中取到的数字为 `num`
3. 当 `count` 为 0 时，表示不同的数字已经将当前的结果抵消掉了，可以换新的数字进行尝试，则 `cur = num`
4. 当 `num == cur` 时，表示遍历数字和预期结果相同，则计数器 `count++`
5. 当 `num != cur` 时，表示遍历数字和预期结果不同，则计数器 `count--`
6. 最终留下的数字 `cur` 就是最终的结果，出现次数超过一半的数字一定不会被抵消掉，最终得到了留存

### 代码

```Java []
class Solution {
    public int majorityElement(int[] nums) {
        int cur = 0;
        int count = 0;
        for(int num : nums){
            if(count == 0) {
                cur = num;
            }
            if(num == cur) {
                count++;
            } else {
                count--;
            }
        }
        return cur;
    }
}
```

```JavaScript []
/**
 * @param {number[]} nums
 * @return {number}
 */
var majorityElement = function(nums) {
    let cur = 0;
    let count = 0;
    for(const num of nums){
        if(count == 0) {
            cur = num;
        }
        if(num == cur) {
            count++;
        } else {
            count--;
        }
    }
    return cur;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/e75abfd21ce1f2be9a0a17ba72bf288da547a11afddebd0031084bc8612e63cb-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/0a35a36b8cb3966edbab9d75d6786e3a71ecd8940dba69ba0ca7ed1fec10b5e7-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/4181fd247470280870e4320f890be0d119959f9321f5067444878e944a97cd20-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/74de59a8bcc8ad03443c105061b3d2a59c6454feb72bdd27b2a3a439efe3c2a7-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/a21cc12b19e6bd5bc9e5fd09e209ff047f117c612219bb04af7859389e037b92-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/e38e41e81cba5e02886615f7d709acc7ed8d5293aec7d2b7868a8d268749bfad-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/28718e65f22fae081979ab7d9fc74aac1b9d6c40e2a9fb210b8bb2a388150062-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/707c369801a945f19ac56fe649c1fbac49975393ccc55feb50f5490802f41886-frame_00008.png),![frame_00009.png](https://pic.leetcode-cn.com/eb0241c647d41cae0c8b056eef077c66b6cb5023e34ac0a95122e525996b9fa4-frame_00009.png),![frame_00010.png](https://pic.leetcode-cn.com/72abe422ef3ab353ebd8e1b37a60c23100db58074d27d56a7b3f7dcf07170fef-frame_00010.png),![frame_00011.png](https://pic.leetcode-cn.com/a3e1704067adc47143021f7657ec2d72ce74b129459e5197565251911b9fb6c3-frame_00011.png)>


## 剑指 Offer 45. 把数组排成最小的数

>https://leetcode.cn/problems/ba-shu-zu-pai-cheng-zui-xiao-de-shu-lcof/
<p>输入一个非负整数数组，把数组里所有数字拼接起来排成一个数，打印能拼接出的所有数字中最小的一个。</p>

<p>&nbsp;</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入:</strong> <code>[10,2]</code>
<strong>输出:</strong> &quot;<code>102&quot;</code></pre>

<p><strong>示例&nbsp;2:</strong></p>

<pre><strong>输入:</strong> <code>[3,30,34,5,9]</code>
<strong>输出:</strong> &quot;<code>3033459&quot;</code></pre>

<p>&nbsp;</p>

<p><strong>提示:</strong></p>

<ul>
	<li><code>0 &lt; nums.length &lt;= 100</code></li>
</ul>

<p><strong>说明: </strong></p>

<ul>
	<li>输出结果可能非常大，所以你需要返回一个字符串而不是整数</li>
	<li>拼接起来的数字可能会有前导 0，最后结果不需要去掉前导 0</li>
</ul>


### 剑指 Offer 45. 把数组排成最小的数 - 解决方案
## 题目描述

输入一个非负整数数组，把数组里所有数字拼接起来排成一个数，打印能拼接出的所有数字中最小的一个。

**示例 1:**

```text
输入: [10,2]
输出: "102"
```

**示例 2:**

```text
输入: [3,30,34,5,9]
输出: "3033459"
```

提示: $0 < nums.length <= 100$

## 解题方案

### 思路

- 标签：排序
- 整体思路：

  - 拼接数组内所有元素使结果最小，本质上是排序
  - 若字符串拼接 a + b > b + a，那么排序上 b < a;
  - 根据这个规则对数组内的元素排序

- 复杂度：

  - 时间复杂度：$O(nlog_n)$。 n 为 strList 列表长度，使用 java 内置函数的平均时间复杂度为 $O(nlog_n)$， 最差为$O(nlogn)$

  - 空间复杂度：$O(n)$： 字符串列表 strList 占用线性大小的额外空间。

### 算法流程

1. 将数组内的元素存入字符串列表 strList
2. 根据上述排序规则，对列表进行排序
3. 最后返回拼接的字符串

### 代码

```Java []
class Solution {
    public String minNumber(int[] nums) {
        List<String> strList = new ArrayList<>();
        for (int num : nums) {
            strList.add(String.valueOf(num));
        }
        strList.sort((a, b) -> (a + b).compareTo(b + a));
        StringBuilder sb = new StringBuilder();
        for (String str : strList) {
            sb.append(str);
        }
        return sb.toString();
    }
}
```

### 画解

<![offer45-1.png](https://pic.leetcode-cn.com/1609854498-BmuZhO-offer45-1.png),![offer45-2.png](https://pic.leetcode-cn.com/1609854498-DXrJnY-offer45-2.png),![offer45-3.png](https://pic.leetcode-cn.com/1609854498-qXyYtI-offer45-3.png),![offer45-4.png](https://pic.leetcode-cn.com/1609854498-lTazdU-offer45-4.png)>


### 花絮

![offer45.mp4](39a214e5-207a-45c8-abf1-63606ebd3e7b)


## 剑指 Offer 53 - I. 在排序数组中查找数字 I

>https://leetcode.cn/problems/zai-pai-xu-shu-zu-zhong-cha-zhao-shu-zi-lcof/
<p>统计一个数字在排序数组中出现的次数。</p>

<p> </p>

<p><strong>示例 1:</strong></p>

<pre>
<strong>输入:</strong> nums = [<code>5,7,7,8,8,10]</code>, target = 8
<strong>输出:</strong> 2</pre>

<p><strong>示例 2:</strong></p>

<pre>
<strong>输入:</strong> nums = [<code>5,7,7,8,8,10]</code>, target = 6
<strong>输出:</strong> 0</pre>

<p> </p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>0 <= nums.length <= 10<sup>5</sup></code></li>
	<li><code>-10<sup>9</sup> <= nums[i] <= 10<sup>9</sup></code></li>
	<li><code>nums</code> 是一个非递减数组</li>
	<li><code>-10<sup>9</sup> <= target <= 10<sup>9</sup></code></li>
</ul>

<p> </p>

<p><strong>注意：</strong>本题与主站 34 题相同（仅返回值不同）：<a href="https://leetcode-cn.com/problems/find-first-and-last-position-of-element-in-sorted-array/">https://leetcode-cn.com/problems/find-first-and-last-position-of-element-in-sorted-array/</a></p>


### 剑指 Offer 53 - I. 在排序数组中查找数字 I - 解决方案
## 题目描述

统计一个数字在排序数组中出现的次数。

**示例 1:**

```text
输入: nums = [5,7,7,8,8,10], target = 8
输出: 2
```

**示例  2:**

```text
输入: nums = [5,7,7,8,8,10], target = 6
输出: 0
```

**限制：**

`0 <= 数组长度 <= 50000`

## 解题方案

### 思路

- 标签：数组、二分查找
- 整体思路：
  - 因为数组本身是有序的，所以利用二分查找可以降低时间复杂度，但是因为数组中的数字存在重复，所以找到 target 在数组中对应的左右边界非常重要
  - 容易想到的方式就是分别用二分查找的方式去查找 target 在数组的左边界和右边界，然后将右边界减左边界即可得到结果
  - 分别查找 target 左边界和右边界的逻辑会有差异，这里可以取巧，变成分别查找 target-1 的右边界和 target 的右边界，结果是一样的，但是代码可以进行复用了
- 复杂度：
  - 时间复杂度：$O(logn)$。二分查找的时间复杂度是$O(logn)$
  - 空间复杂度：$O(1)$。只需要保存左右边界和中间值即可

### 算法流程

1. 首先初始化二分查找的左边界`left = 0`，右边界`right = nums.length - 1`
2. 当左边界不大于右边界时进行查找
3. 计算 ` mid = (left + right) / 2`
4. 如果 `nums[mid] <= target`，则右边界在 [mid + 1, right] 中间，令 `left = mid + 1`
5. 如果 `nums[mid] > target`，则右边界在 [left, mid - 1] 中间，令 `right = mid - 1`

### 代码

```Java []
class Solution {
    public int search(int[] nums, int target) {
        return getRightMargin(nums, target) - getRightMargin(nums, target - 1);
    }
    int getRightMargin(int[] nums, int target) {
        int left = 0;
        int right = nums.length - 1;
        while(left <= right) {
            int mid = (left + right) / 2;
            if(nums[mid] <= target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return left;
    }
}
```

```JavaScript []
/**
 * @param {number[]} nums
 * @param {number} target
 * @return {number}
 */
var search = function(nums, target) {
return getRightMargin(nums, target) - getRightMargin(nums, target - 1);
};

var getRightMargin = function(nums, target) {
    let left = 0;
    let right = nums.length - 1;
    while(left <= right) {
        let mid = parseInt((left + right) / 2);
        if(nums[mid] <= target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return left;
}
```

### 画解

<![offer53-1-1.png](https://pic.leetcode-cn.com/1601344882-ZadVXU-offer53-1-1.png),![offer53-1-2.png](https://pic.leetcode-cn.com/1601344882-sGozyj-offer53-1-2.png),![offer53-1-3.png](https://pic.leetcode-cn.com/1601344882-lfkasY-offer53-1-3.png),![offer53-1-4.png](https://pic.leetcode-cn.com/1601344882-fVvkny-offer53-1-4.png),![offer53-1-5.png](https://pic.leetcode-cn.com/1601344882-KsEfAw-offer53-1-5.png),![offer53-1-6.png](https://pic.leetcode-cn.com/1601344882-UAtilz-offer53-1-6.png),![offer53-1-7.png](https://pic.leetcode-cn.com/1601344882-mLdNHc-offer53-1-7.png),![offer53-1-8.png](https://pic.leetcode-cn.com/1601344882-nIeXnx-offer53-1-8.png),![offer53-1-9.png](https://pic.leetcode-cn.com/1601344882-NrOgwe-offer53-1-9.png)>

### 花絮

![offer53-1.mp4](a8d6fa66-72fd-4903-8219-056ee746785d)


## 剑指 Offer 53 - II. 0～n-1 中缺失的数字

>https://leetcode.cn/problems/que-shi-de-shu-zi-lcof/
<p>一个长度为n-1的递增排序数组中的所有数字都是唯一的，并且每个数字都在范围0～n-1之内。在范围0～n-1内的n个数字中有且只有一个数字不在该数组中，请找出这个数字。</p>

<p>&nbsp;</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入:</strong> [0,1,3]
<strong>输出:</strong> 2
</pre>

<p><strong>示例&nbsp;2:</strong></p>

<pre><strong>输入:</strong> [0,1,2,3,4,5,6,7,9]
<strong>输出:</strong> 8</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>1 &lt;= 数组长度 &lt;= 10000</code></p>


### 剑指 Offer 53 - II. 0～n-1中缺失的数字 - 解决方案
## 题目描述

一个长度为 n-1 的递增排序数组中的所有数字都是唯一的，并且每个数字都在范围 0～n-1 之内。在范围 0～n-1 内的 n 个数字中有且只有一个数字不在该数组中，请找出这个数字。


**示例 1:**

``` 
输入: [0,1,3]
输出: 2 

```

**示例  2:**

```
输入: [0,1,2,3,4,5,6,7,9]
输出: 8
```

**限制：**

`1 <= 数组长度 <= 10000`

## 解题方案

### 思路

- 标签：数组、二分查找
- 整体思路：
  - 缺失的数字等于 “右子数组的首位元素” 对应的索引，因此考虑使用二分法查找 “右子数组的首位元素”。
  - 左子数组： nums[i] == i 
  - 右子数组： nums[i] != i 
- 复杂度：
  - 时间复杂度：$O(logn)$
  - 空间复杂度：$O(1)$

### 算法流程

1. 首先初始化二分查找的左边界 `left = 0`，右边界 `right = nums.length - 1`
2. 当左边界不大于右边界时进行查找
3. 计算  `mid = (left + right) / 2`
4. 如果  `nums[mid] == mid` 则缺失的元素，即右子数组的首位元素在  [mid + 1, right] 中间，令  `left = mid + 1`
5. 如果 `nums[mid] != mid` 则缺失的元素，即右子数组的首位元素在  [left, mid] 中间，令 `right = mid - 1`

### 代码

```Golang [] 

func missingNumber(nums []int) int {
    left, right := 0, len(nums)-1
    for left <= right {  
        mid := (left+right) / 2
        if nums[mid] == mid {
            left = mid+1
        }else {
            right = mid-1
        }
    }
    return left
}

```

### 画解

<![offer53-2-1.png](https://pic.leetcode-cn.com/1609056212-RHeqrF-offer53-2-1.png),![offer53-2-2.png](https://pic.leetcode-cn.com/1609056212-EqnTzo-offer53-2-2.png),![offer53-2-3.png](https://pic.leetcode-cn.com/1609056212-VRurAA-offer53-2-3.png),![offer53-2-4.png](https://pic.leetcode-cn.com/1609056212-IyqeGi-offer53-2-4.png),![offer53-2-5.png](https://pic.leetcode-cn.com/1609056212-nYhtnX-offer53-2-5.png),![offer53-2-6.png](https://pic.leetcode-cn.com/1609056212-grkKbf-offer53-2-6.png),![offer53-2-7.png](https://pic.leetcode-cn.com/1609056212-uuYPMQ-offer53-2-7.png),![offer53-2-8.png](https://pic.leetcode-cn.com/1609056212-flvAfY-offer53-2-8.png),![offer53-2-9.png](https://pic.leetcode-cn.com/1609056212-pluqnT-offer53-2-9.png),![offer53-2-10.png](https://pic.leetcode-cn.com/1609056212-SFfByZ-offer53-2-10.png)>

### 花絮

![offer53-2.mp4](fbb615c5-f266-4378-8adc-a3392740a152)


## 剑指 Offer 57. 和为 s 的两个数字

>https://leetcode.cn/problems/he-wei-sde-liang-ge-shu-zi-lcof/
<p>输入一个递增排序的数组和一个数字s，在数组中查找两个数，使得它们的和正好是s。如果有多对数字的和等于s，则输出任意一对即可。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>nums = [2,7,11,15], target = 9
<strong>输出：</strong>[2,7] 或者 [7,2]
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>nums = [10,26,30,31,47,60], target = 40
<strong>输出：</strong>[10,30] 或者 [30,10]
</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<ul>
	<li><code>1 &lt;= nums.length &lt;= 10^5</code></li>
	<li><code>1 &lt;= nums[i]&nbsp;&lt;= 10^6</code></li>
</ul>


### 剑指 Offer 57. 和为 s 的两个数字 - 解决方案
## 题目描述

输入一个递增排序的数组和一个数字 `s`，在数组中查找两个数，使得它们的和正好是 `s`。如果有多对数字的和等于 `s`，则输出任意一对即可。

示例 1：

```
输入：nums = [2,7,11,15], target = 9
输出：[2,7] 或者 [7,2]
```

示例 2：

```
输入：nums = [10,26,30,31,47,60], target = 40
输出：[10,30] 或者 [30,10]
```

限制：

- `1 <= nums.length <= 10^5`
- `1 <= nums[i] <= 10^6`

## 解题方案

### 思路

- 标签：双指针
- 整体思路：因为数组本身是有序的，那么完全可以在数组的开头 `start` 和结尾 `end` 位置各设置一个指针，通过二者的加和 `sum` 来找到目标值 `target`，如果 `sum < target`，则 `start++`，这样可以让下一次的 `sum` 变大，如果 `sum > target`，则 `end--`，这样可以让下一次的 `sum` 变小，找到结果
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程

1. 首先初始化 `start = 0`，`end = nums.length - 1`，作为双指针
2. 当 `start < end` 时，始终进行循环遍历
3. 计算 `sum = nums[start] + nums[end]`，并将 `sum` 与 `target` 进行比较
4. 如果 `sum < target`，则需要将下一次的 `sum` 值变大，因为数组有序，故而 `start++`
5. 如果 `sum > target`，则需要将下一次的 `sum` 值变小，因为数组有序，故而 `end--`
6. 如果 `sum == target`，则找到了最终的结果，将结果返回即可

### 代码

```Java []
class Solution {
    public int[] twoSum(int[] nums, int target) {
        int start = 0;
        int end = nums.length - 1;
        while(start < end) {
            int sum = nums[start] + nums[end];
            if(sum < target) {
                start++;
            } else if(sum > target) {
                end--;
            } else {
                return new int[] { nums[start], nums[end] };
            }
        }
        return new int[0];
    }
}
```

```JavaScript []
/**
 * @param {number[]} nums
 * @param {number} target
 * @return {number[]}
 */
var twoSum = function(nums, target) {
    let start = 0;
    let end = nums.length - 1;
    while(start < end) {
        const sum = nums[start] + nums[end];
        if(sum < target) {
            start++;
        } else if(sum > target) {
            end--;
        } else {
            return [nums[start], nums[end]];
        }
    }
    return [];
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/07020428676aeb9bc231450fdc062b1fb75452858dca1021f16f6d4614a615f2-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/d99c2e22b48efd48dd6fd8fe69d6ea8cff6296f9ea1c89eb5f895250af15ff17-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/6314e1e3ff19e693d648183b75f09f4a44467037974764e1bc81f1cad8203b0d-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/4be927e9508fa838d4f9c1ae30476b3a7ac1ff26077a6ed6200d99500218e4a5-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/242a94d1306a0a13d57db47fa0f30f338e62bcf0a705e463f34e3ec7bd66b728-frame_00005.png)>


## 剑指 Offer 57 - II. 和为 s 的连续正数序列

>https://leetcode.cn/problems/he-wei-sde-lian-xu-zheng-shu-xu-lie-lcof/
<p>输入一个正整数 <code>target</code> ，输出所有和为 <code>target</code> 的连续正整数序列（至少含有两个数）。</p>

<p>序列内的数字由小到大排列，不同序列按照首个数字从小到大排列。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>target = 9
<strong>输出：</strong>[[2,3,4],[4,5]]
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>target = 15
<strong>输出：</strong>[[1,2,3,4,5],[4,5,6],[7,8]]
</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<ul>
	<li><code>1 &lt;= target &lt;= 10^5</code></li>
</ul>

<p>&nbsp;</p>


### 剑指 Offer 57 - II. 和为 s 的连续正数序列 - 解决方案
## 题目描述

输入一个正整数 target ，输出所有和为 target 的连续正整数序列（至少含有两个数）。

序列内的数字由小到大排列，不同序列按照首个数字从小到大排列。

示例 1：

```text
输入：target = 9
输出：[[2,3,4],[4,5]]
```

示例 2：

```text
输入：target = 15
输出：[[1,2,3,4,5],[4,5,6],[7,8]]
```

限制：

- `1 <= target <= 10^5`

## 解题方案

### 思路

- 标签：滑动窗口、指针
- 整体思路：
  - 最容易想到的思路就是暴力枚举，因为题目条件要求至少含有两个数，所以枚举到 target/2 即可停止，时间复杂度较高
  - 更好的方式是使用滑动窗口，设立左右指针，从开始位置维护一个子数组作为窗口，判断该窗口是否求和为 target，如果是则将结果加入，如果小于 target 则窗口右移，大于 target 则窗口左移
- 复杂度：
  - 时间复杂度：$O(target)$。滑动窗口最多移动 target/2 次
  - 空间复杂度：$O(1)$。排除必要的存储结果数组之外，只需要保存左右指针

### 算法流程

1. 首先初始化窗口，left=1 和 right=2
2. 当 left < right 时始终维护该窗口，只有当到达边界位置时，窗口和 sum > target，left 始终右移，才会结束窗口维护
3. 根据求和公式 $sum = (left + right) * (right - left + 1) / 2$ 可以直接算出滑动窗口和
4. 当 `sum == target` 时，将窗口放入结果数组中
5. 当 `sum < target` 时，说明窗口结果需要变大，right++
6. 当 `sum > target` 时，说明窗口结果需要变小，left++

### 代码

```Java []
class Solution {
    public int[][] findContinuousSequence(int target) {
        int left = 1;
        int right = 2;
        List<int[]> res = new ArrayList<>();

        while (left < right) {
            int sum = (left + right) * (right - left + 1) / 2;
            if (sum == target){
                int[] arr = new int[right - left + 1];
                for (int k = left; k <= right; k++) {
                    arr[k - left] = k;
                }
                res.add(arr);
                left++;
            }
            else if (sum < target) {
                right++;
            }
            else {
                left++;
            }
        }

        return res.toArray(new int[res.size()][]);
    }
}
```

```JavaScript []
/**
 * @param {number} target
 * @return {number[][]}
 */
var findContinuousSequence = function(target) {
    let left = 1;
    let right = 2;
    let res = [];

    while (left < right) {
        let sum = (left + right) * (right - left + 1) / 2;
        if (sum == target){
            let arr = [];
            for (let k = left; k <= right; k++) {
                arr[k - left] = k;
            }
            res.push(arr);
            left++;
        }
        else if (sum < target) {
            right++;
        }
        else {
            left++;
        }
    }

    return res;
};
```

### 画解

<![offer57-2-1.png](https://pic.leetcode-cn.com/1599801580-SMCQvq-offer57-2-1.png),![offer57-2-2.png](https://pic.leetcode-cn.com/1599801580-rUgcfH-offer57-2-2.png),![offer57-2-3.png](https://pic.leetcode-cn.com/1599801580-yGJbII-offer57-2-3.png),![offer57-2-4.png](https://pic.leetcode-cn.com/1599801580-vyEenP-offer57-2-4.png),![offer57-2-5.png](https://pic.leetcode-cn.com/1599801580-zAaAuz-offer57-2-5.png),![offer57-2-6.png](https://pic.leetcode-cn.com/1599801580-YbrcKa-offer57-2-6.png),![offer57-2-7.png](https://pic.leetcode-cn.com/1599801580-Yvclst-offer57-2-7.png),![offer57-2-8.png](https://pic.leetcode-cn.com/1599801580-OhfTri-offer57-2-8.png),![offer57-2-9.png](https://pic.leetcode-cn.com/1599801580-SAjZNc-offer57-2-9.png)>

### 花絮

![offer57-2.mp4](9dc41ed6-e154-4426-b5a4-832d6ccb4e6e)


## 剑指 Offer 58 - I. 翻转单词顺序

>https://leetcode.cn/problems/fan-zhuan-dan-ci-shun-xu-lcof/
<p>输入一个英文句子，翻转句子中单词的顺序，但单词内字符的顺序不变。为简单起见，标点符号和普通字母一样处理。例如输入字符串&quot;I am a student. &quot;，则输出&quot;student. a am I&quot;。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入:</strong> &quot;<code>the sky is blue</code>&quot;
<strong>输出:&nbsp;</strong>&quot;<code>blue is sky the</code>&quot;
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入:</strong> &quot; &nbsp;hello world! &nbsp;&quot;
<strong>输出:&nbsp;</strong>&quot;world! hello&quot;
<strong>解释: </strong>输入字符串可以在前面或者后面包含多余的空格，但是反转后的字符不能包括。
</pre>

<p><strong>示例 3：</strong></p>

<pre><strong>输入:</strong> &quot;a good &nbsp; example&quot;
<strong>输出:&nbsp;</strong>&quot;example good a&quot;
<strong>解释: </strong>如果两个单词间有多余的空格，将反转后单词间的空格减少到只含一个。
</pre>

<p>&nbsp;</p>

<p><strong>说明：</strong></p>

<ul>
	<li>无空格字符构成一个单词。</li>
	<li>输入字符串可以在前面或者后面包含多余的空格，但是反转后的字符不能包括。</li>
	<li>如果两个单词间有多余的空格，将反转后单词间的空格减少到只含一个。</li>
</ul>

<p><strong>注意：</strong>本题与主站 151 题相同：<a href="https://leetcode-cn.com/problems/reverse-words-in-a-string/">https://leetcode-cn.com/problems/reverse-words-in-a-string/</a></p>

<p><strong>注意：</strong>此题对比原题有改动</p>


### 剑指 Offer 58 - I. 翻转单词顺序 - 解决方案
## 题目描述

输入一个英文句子，翻转句子中单词的顺序，但单词内字符的顺序不变。为简单起见，标点符号和普通字母一样处理。例如输入字符串 `"I am a student. "`，则输出 `"student. a am I"`。

示例 1：

```text
输入: "the sky is blue"
输出: "blue is sky the"
```

示例 2：

```text
输入: "  hello world!  "
输出: "world! hello"
解释: 输入字符串可以在前面或者后面包含多余的空格，但是反转后的字符不能包括。
```

示例 3：

```text
输入: "a good   example"
输出: "example good a"
解释: 如果两个单词间有多余的空格，将反转后单词间的空格减少到只含一个。
```

**说明：**

- 无空格字符构成一个单词。
- 输入字符串可以在前面或者后面包含多余的空格，但是反转后的字符不能包括。
- 如果两个单词间有多余的空格，将反转后单词间的空格减少到只含一个。

## 解题方案

### 思路

- 标签：双指针
- 整体思路：先将开头和结尾处多余的空格去掉，从后向前遍历，通过前后指针锁定单词，跳过中间空格，最终将整个句子中的单词反转
- 时间复杂度：$O(n)$，空间复杂度：$O(n)$

### 算法流程

1. 首先将原始字符串去掉开头和结尾的空格得到 `tmp`，便于之后直接从单词处理开始
2. 初始化单词起始位置 `start` 和单词结束位置 `end` 指针，位置在字符串结尾处
3. 初始化结果字符串 `res` 为空字符串
4. 当 `start >= 0` 时，说明字符串未遍历结束，作为循环条件
5. 在 `tmp[start]` 位置如果不为空格，说明还没有获取到完整的单词，则 `start--`
6. 获取到完整单词之后，截取 `[start+1, end+1]` 这一段字符串加入结果字符串中，反转单词
7. 在 `tmp[start]` 位置如果为空格，说明还没有到下一个单词的结尾位置，则 `start--`
8. 到单词结尾位置之后，`end = start`，往复进行上述流程，将单词全部反转
9. 将结果字符串 `res` 去掉开头和结尾多余的空格

### 代码

```Java []
class Solution {
    public String reverseWords(String s) {
        String tmp = s.trim();
        int start = tmp.length() - 1;
        int end = tmp.length() - 1;
        String res = "";
        while(start >= 0) {
            while(start >= 0 && tmp.charAt(start) != ' ') {
                start--;
            }
            res += tmp.substring(start + 1, end + 1) + " ";
            while(start >= 0 && tmp.charAt(start) == ' ') {
                start--;
            }
            end = start;
        }
        return res.trim();
    }
}
```

```JavaScript []
/**
 * @param {string} s
 * @return {string}
 */
var reverseWords = function(s) {
    let tmp = s.trim();
    let start = tmp.length - 1;
    let end = tmp.length - 1;
    let res = "";
    while(start >= 0) {
        while(start >= 0 && tmp[start] != ' ') {
            start--;
        }
        res += tmp.substring(start + 1, end + 1) + " ";
        while(start >= 0 && tmp[start] == ' ') {
            start--;
        }
        end = start;
    }
    return res.trim();
};
```

### 画解

<![offer58-1-1.png](https://pic.leetcode-cn.com/29cb5b104cdbbddb102671e6583fd905c54aba4c0a9575636f854efa6bd68e14-offer58-1-1.png),![offer58-1-2.png](https://pic.leetcode-cn.com/b0569a12b7869663891b2396b9f01d7012f3a5456ccbb43f7e2c0f976c6e9cb5-offer58-1-2.png),![offer58-1-3.png](https://pic.leetcode-cn.com/f26bdbbcf6ef08f72f6223b7e0c7f8aa41197b2185c56d0836994a380a11b7a4-offer58-1-3.png),![offer58-1-4.png](https://pic.leetcode-cn.com/5f5c4bdd74382527051df622b9fcb39823138e97a38d35c9dc46549ea0fc25be-offer58-1-4.png),![offer58-1-5.png](https://pic.leetcode-cn.com/043ef8f5e1828d0b5c1b9828696c848f2c131f30b9e8b028389f285e6c3b1d07-offer58-1-5.png),![offer58-1-6.png](https://pic.leetcode-cn.com/1ac07fcd55968dc2f279b587db7b5c225b7768eeb28d6f50beebe4302608fd54-offer58-1-6.png),![offer58-1-7.png](https://pic.leetcode-cn.com/c02f8e4bb91b70b9fdfce9b4aa15b017ad853066fceed7ddb5083eb8c34ece18-offer58-1-7.png),![offer58-1-8.png](https://pic.leetcode-cn.com/1d17cfb6afc683b2d7ebd5ab4b27e7b27ee15ea8249fc068473b8dd638c98fc0-offer58-1-8.png),![offer58-1-9.png](https://pic.leetcode-cn.com/3ba3a0a03ce2e2c69d32bdc0dc2306eeb037669f83630a37c2fa3d44829670a6-offer58-1-9.png),![offer58-1-10.png](https://pic.leetcode-cn.com/103b280d26771266a3a77a4c7bd8d60a23941250cdd757698aef4a2726df82a7-offer58-1-10.png),![offer58-1-11.png](https://pic.leetcode-cn.com/a3f32d81e75be885b1894076e49785c95fb8c3f7e391cb28020350e9c999eb4f-offer58-1-11.png)>

### 花絮

![offer58-1.mp4](7e8f1b00-2171-4f6c-baad-40b42dbeea7f)


## 剑指 Offer 58 - II. 左旋转字符串

>https://leetcode.cn/problems/zuo-xuan-zhuan-zi-fu-chuan-lcof/
<p>字符串的左旋转操作是把字符串前面的若干个字符转移到字符串的尾部。请定义一个函数实现字符串左旋转操作的功能。比如，输入字符串&quot;abcdefg&quot;和数字2，该函数将返回左旋转两位得到的结果&quot;cdefgab&quot;。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入:</strong> s = &quot;abcdefg&quot;, k = 2
<strong>输出:&nbsp;</strong>&quot;cdefgab&quot;
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入:</strong> s = &quot;lrloseumgh&quot;, k = 6
<strong>输出:&nbsp;</strong>&quot;umghlrlose&quot;
</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<ul>
	<li><code>1 &lt;= k &lt; s.length &lt;= 10000</code></li>
</ul>


### 剑指 Offer 58 - II. 左旋转字符串 - 解决方案
## 题目描述

字符串的左旋转操作是把字符串前面的若干个字符转移到字符串的尾部。请定义一个函数实现字符串左旋转操作的功能。比如，输入字符串"abcdefg"和数字2，该函数将返回左旋转两位得到的结果"cdefgab"。

**示例 1：**

```text
输入: s = "abcdefg", k = 2
输出: "cdefgab"
```

**示例 2：**

```text
输入: s = "lrloseumgh", k = 6
输出: "umghlrlose"
```

**限制：**

- 1 <= k < s.length <= 10000

## 解题方案

### 思路

- 标签：字符串遍历
- 整体思路：在原字符串处从需要反转的位置 `n` 开始向后遍历，并保存到结果字符串中，然后再从原字符串的初始位置遍历到位置 `n`，继续添加到结果字符串
- 时间复杂度：$O(n)$，空间复杂度：$O(n)$

### 算法流程

1. 初始化结果字符串 `res = ""`，获取字符串长度 `len`
2. 从下标 `n` 开始遍历，遍历到字符串 `s` 结尾，将区间 `[n, len]` 的字符添加到 `res` 中
3. 从下标 `0` 开始遍历，遍历到下标 `n` 位置，将区间 `[0, n]` 的字符添加到 `res` 中

### 代码

```Java []
class Solution {
    public String reverseLeftWords(String s, int n) {
        String res = "";
        int len = s.length();
        for(int i = n; i < len; i++) {
            res += s.charAt(i);
        }
        for(int i = 0; i < n; i++) {
            res += s.charAt(i);
        }
        return res;
    }
}
```

```JavaScript []
/**
 * @param {string} s
 * @param {number} n
 * @return {string}
 */
var reverseLeftWords = function(s, n) {
    let res = "";
    let len = s.length;
    for(let i = n; i < len; i++) {
        res += s[i];
    }
    for(let i = 0; i < n; i++) {
        res += s[i];
    }
    return res;
};
```

### 画解

<![offer58-2-1.png](https://pic.leetcode-cn.com/1e0b73a72f6f117d589cb38e78d1dc37dcdf4795557425f7a8c76a149f2c1816-offer58-2-1.png),![offer58-2-2.png](https://pic.leetcode-cn.com/16168c837f8008ab8872a753d9ebb5804a021e8e1fd20b7df8a275b77a6e6ca7-offer58-2-2.png),![offer58-2-3.png](https://pic.leetcode-cn.com/9594402a9a73e43a93f2461d70e9419678d15f6136d1be823e2054afa14e6157-offer58-2-3.png),![offer58-2-4.png](https://pic.leetcode-cn.com/18d43de26f08a98776cff78acbd9b36c44cd5de085459b4011aed71b460b7fe0-offer58-2-4.png),![offer58-2-5.png](https://pic.leetcode-cn.com/8171d3f170df742f3b4f0ba1af497116c35cc9d852491cb3665a79802488b661-offer58-2-5.png),![offer58-2-6.png](https://pic.leetcode-cn.com/e2f21f78d21d23a45a47ebe3cce4339d72ce0b207f46ae81231522b115693bfd-offer58-2-6.png),![offer58-2-7.png](https://pic.leetcode-cn.com/6f51bab5f7740c38d690d63a43dd755eb6c689f98481be76e7490e4927cb80ef-offer58-2-7.png),![offer58-2-8.png](https://pic.leetcode-cn.com/090241739f4ff0de585d2e69cb400a6b3411bb8e55e3ce6f64802d7ad20b52fc-offer58-2-8.png)>

### 花絮

![offer58-2.mp4](973607b7-35b6-480e-9750-13ba2a491cb7)


## 剑指 Offer 61. 扑克牌中的顺子

>https://leetcode.cn/problems/bu-ke-pai-zhong-de-shun-zi-lcof/
<p>从<strong>若干副扑克牌</strong>中随机抽 <code>5</code> 张牌，判断是不是一个顺子，即这5张牌是不是连续的。2～10为数字本身，A为1，J为11，Q为12，K为13，而大、小王为 0 ，可以看成任意数字。A 不能视为 14。</p>

<p>&nbsp;</p>

<p><strong>示例&nbsp;1:</strong></p>

<pre>
<strong>输入:</strong> [1,2,3,4,5]
<strong>输出:</strong> True</pre>

<p>&nbsp;</p>

<p><strong>示例&nbsp;2:</strong></p>

<pre>
<strong>输入:</strong> [0,0,1,2,5]
<strong>输出:</strong> True</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p>数组长度为 5&nbsp;</p>

<p>数组的数取值为 [0, 13] .</p>


### 剑指 Offer 61. 扑克牌中的顺子 - 解决方案
## 题目描述

从扑克牌中随机抽 5 张牌，判断是不是一个顺子，即这 5 张牌是不是连续的。

2 ～ 10 为数字本身，A 为 1，J 为 11，Q 为 12，K 为 13，而大、小王为 0 ，可以看成任意数字。A 不能视为 14。

示例 1：

```
输入: [1,2,3,4,5]
输出: True

```

示例 2：

```
输入: [0,0,1,2,5]
输出: True
```

限制：

```
数组长度为 5

数组的数取值为 [0, 13]
```

## 解题方案

### 思路

- 标签：数组
- 整体思路：
  - 需要对数组升序排序
  - 如果数组中有重复数据，则返回 false
  - 令 minVal 为不包含大小王的最小值，如果 maxVal-minVal > 5，则返回 false
- 复杂度：
  时间复杂度 O(Nlog N)
  空间复杂度 O(1)

### 算法流程

1. 顺子牌的定义

- 牌数量为 5
- 牌间的顺序为递增，且差值为 1
- 牌间不可以有重复数据，（大小王除外）。（扑克牌术语：如果一副牌里含有对子，则不可能是顺子）
- 大小王可以作为任意牌，即可以作为牌间空隙插入。且数量不限
- 牌之间的空隙个数为，maxVal-minVal
- 由于牌数量为 5，所以 maxVal-minVal <= 5

### 代码 1

- Golang 版本

```Golang
func isStraight(nums []int) bool {
	var jkCnt int
	sort.Ints(nums)
	if len(nums) != 5 {
		return false
	}
	for i := 0; i < len(nums); i++ {
		if nums[i] == 0 {
			jkCnt++
			continue
		}
		if i != len(nums)-1 {
			if nums[i] == nums[i+1] {
				return false
			}
		}
	}
	return nums[len(nums)-1]-nums[jkCnt] < 5
}
```

### 画解

<![offer61-1.png](https://pic.leetcode-cn.com/1609050997-vhqDty-offer61-1.png),![offer61-2.png](https://pic.leetcode-cn.com/1609050997-ryRSqU-offer61-2.png),![offer61-3.png](https://pic.leetcode-cn.com/1609050997-hHnfjz-offer61-3.png),![offer61-4.png](https://pic.leetcode-cn.com/1609050997-HEvOYc-offer61-4.png),![offer61-5.png](https://pic.leetcode-cn.com/1609050997-EElugH-offer61-5.png),![offer61-6.png](https://pic.leetcode-cn.com/1609050997-OkZSnT-offer61-6.png),![offer61-7.png](https://pic.leetcode-cn.com/1609050997-CvwNUW-offer61-7.png),![offer61-8.png](https://pic.leetcode-cn.com/1609050997-mPZvmp-offer61-8.png)>

### 花絮

![offer61.mp4](f681cf32-9065-4e18-a580-467dc6e58145)


## 剑指 Offer 66. 构建乘积数组

>https://leetcode.cn/problems/gou-jian-cheng-ji-shu-zu-lcof/
<p>给定一个数组 <code>A[0,1,…,n-1]</code>，请构建一个数组 <code>B[0,1,…,n-1]</code>，其中 <code>B[i]</code> 的值是数组 <code>A</code> 中除了下标 <code>i</code> 以外的元素的积, 即 <code>B[i]=A[0]×A[1]×…×A[i-1]×A[i+1]×…×A[n-1]</code>。不能使用除法。</p>

<p> </p>

<p><strong>示例:</strong></p>

<pre>
<strong>输入:</strong> [1,2,3,4,5]
<strong>输出:</strong> [120,60,40,30,24]</pre>

<p> </p>

<p><strong>提示：</strong></p>

<ul>
	<li>所有元素乘积之和不会溢出 32 位整数</li>
	<li><code>a.length <= 100000</code></li>
</ul>


### 剑指 Offer 66. 构建乘积数组 - 解决方案
## 题目描述

给定一个数组 `A[0,1,…,n-1]`，请构建一个数组 `B[0,1,…,n-1]`，其中 `B` 中的元素 `B[i]=A[0]×A[1]×…×A[i-1]×A[i+1]×…×A[n-1]`。不能使用除法。

示例:

```text
输入: [1,2,3,4,5]
输出: [120,60,40,30,24]
```

提示：

- 所有元素乘积之和不会溢出 32 位整数
- `a.length <= 100000`

## 解题方案

### 思路

- 标签：数组遍历
- 整体思路：
  - 这道题如果可以使用除法，那么就很简单了，先求出来所有数的乘积，然后再依次除掉每个对应的值即可
  - 不让使用除法，那么最简单的思路就是将`B[i]`每个位置都把所有需要的数乘一遍，但是这样的时间复杂度非常高
  - 降低时间复杂度的方式就是以`A[i]`为界线，分割出左右三角形，其中每个三角形从尖部到底部都是可以累积的，这样就可以减少时间复杂度（具体见画）
- 复杂度：
    - 时间复杂度：$O(n)$。因为左右三角遍历求乘积的时间复杂度都是$O(n)$
    - 空间复杂度：$O(1)$。不将结果数组算入的话，只需要常量的空间复杂度

### 算法流程

1. 首先申请结果数组 `res`
2. 求出左侧三角从上到下的值，依次存入 `res[i]` 中
3. 求出右侧三角从下到上的值，并且和之前的 `res[i]` 做乘积存入，即可得到结果

### 代码

```Java []
class Solution {
    public int[] constructArr(int[] a) {
        int[] res = new int[a.length];
        int left = 1;
        for (int i = 0; i < a.length; i++) {
            res[i] = left;
            left *= a[i];
        } 
        int right = 1;
        for (int i = a.length - 1; i >= 0; i--) {
            res[i] *= right;
            right *= a[i];
        }
        return res;
    }
}
```

```JavaScript []
/**
 * @param {number[]} a
 * @return {number[]}
 */
var constructArr = function(a) {
    let res = [];
    let left = 1;
    for (let i = 0; i < a.length; i++) {
        res[i] = left;
        left *= a[i];
    } 
    let right = 1;
    for (let i = a.length - 1; i >= 0; i--) {
        res[i] *= right;
        right *= a[i];
    }
    return res;
};
```

### 画解

<![offer66-1.png](https://pic.leetcode-cn.com/1599052123-OHoyPM-offer66-1.png),![offer66-2.png](https://pic.leetcode-cn.com/1599052123-vfKBVp-offer66-2.png),![offer66-3.png](https://pic.leetcode-cn.com/1599052123-kmCGTR-offer66-3.png),![offer66-4.png](https://pic.leetcode-cn.com/1599052123-hAPSPr-offer66-4.png),![offer66-5.png](https://pic.leetcode-cn.com/1599052123-kOqjiQ-offer66-5.png),![offer66-6.png](https://pic.leetcode-cn.com/1599052123-KmaTnF-offer66-6.png),![offer66-7.png](https://pic.leetcode-cn.com/1599052123-TIIjUt-offer66-7.png),![offer66-8.png](https://pic.leetcode-cn.com/1599052123-wCnzzk-offer66-8.png),![offer66-9.png](https://pic.leetcode-cn.com/1599052123-IAgcUG-offer66-9.png),![offer66-10.png](https://pic.leetcode-cn.com/1599052123-eoBTty-offer66-10.png),![offer66-11.png](https://pic.leetcode-cn.com/1599052123-aQTTYt-offer66-11.png)>

### 花絮

![offer66.mp4](cf24105e-386a-4ed3-9662-a2bd7d8d7945)


## 剑指 Offer 67. 把字符串转换成整数

>https://leetcode.cn/problems/ba-zi-fu-chuan-zhuan-huan-cheng-zheng-shu-lcof/
<p>写一个函数 StrToInt，实现把字符串转换成整数这个功能。不能使用 atoi 或者其他类似的库函数。</p>

<p>&nbsp;</p>

<p>首先，该函数会根据需要丢弃无用的开头空格字符，直到寻找到第一个非空格的字符为止。</p>

<p>当我们寻找到的第一个非空字符为正或者负号时，则将该符号与之后面尽可能多的连续数字组合起来，作为该整数的正负号；假如第一个非空字符是数字，则直接将其与之后连续的数字字符组合起来，形成整数。</p>

<p>该字符串除了有效的整数部分之后也可能会存在多余的字符，这些字符可以被忽略，它们对于函数不应该造成影响。</p>

<p>注意：假如该字符串中的第一个非空格字符不是一个有效整数字符、字符串为空或字符串仅包含空白字符时，则你的函数不需要进行转换。</p>

<p>在任何情况下，若函数不能进行有效的转换时，请返回 0。</p>

<p><strong>说明：</strong></p>

<p>假设我们的环境只能存储 32 位大小的有符号整数，那么其数值范围为&nbsp;[&minus;2<sup>31</sup>,&nbsp; 2<sup>31&nbsp;</sup>&minus; 1]。如果数值超过这个范围，请返回 &nbsp;INT_MAX (2<sup>31&nbsp;</sup>&minus; 1) 或&nbsp;INT_MIN (&minus;2<sup>31</sup>) 。</p>

<p><strong>示例&nbsp;1:</strong></p>

<pre><strong>输入:</strong> &quot;42&quot;
<strong>输出:</strong> 42
</pre>

<p><strong>示例&nbsp;2:</strong></p>

<pre><strong>输入:</strong> &quot;   -42&quot;
<strong>输出:</strong> -42
<strong>解释: </strong>第一个非空白字符为 &#39;-&#39;, 它是一个负号。
&nbsp;    我们尽可能将负号与后面所有连续出现的数字组合起来，最后得到 -42 。
</pre>

<p><strong>示例&nbsp;3:</strong></p>

<pre><strong>输入:</strong> &quot;4193 with words&quot;
<strong>输出:</strong> 4193
<strong>解释:</strong> 转换截止于数字 &#39;3&#39; ，因为它的下一个字符不为数字。
</pre>

<p><strong>示例&nbsp;4:</strong></p>

<pre><strong>输入:</strong> &quot;words and 987&quot;
<strong>输出:</strong> 0
<strong>解释:</strong> 第一个非空字符是 &#39;w&#39;, 但它不是数字或正、负号。
     因此无法执行有效的转换。</pre>

<p><strong>示例&nbsp;5:</strong></p>

<pre><strong>输入:</strong> &quot;-91283472332&quot;
<strong>输出:</strong> -2147483648
<strong>解释:</strong> 数字 &quot;-91283472332&quot; 超过 32 位有符号整数范围。 
&nbsp;    因此返回 INT_MIN (&minus;2<sup>31</sup>) 。
</pre>

<p>&nbsp;</p>

<p>注意：本题与主站 8 题相同：<a href="https://leetcode-cn.com/problems/string-to-integer-atoi/">https://leetcode-cn.com/problems/string-to-integer-atoi/</a></p>


### 剑指 Offer 67. 把字符串转换成整数 - 解决方案
## 题目描述

写一个函数 StrToInt，实现把字符串转换成整数这个功能。不能使用 atoi 或者其他类似的库函数。

首先，该函数会根据需要丢弃无用的开头空格字符，直到寻找到第一个非空格的字符为止。

当我们寻找到的第一个非空字符为正或者负号时，则将该符号与之后面尽可能多的连续数字组合起来，作为该整数的正负号；假如第一个非空字符是数字，则直接将其与之后连续的数字字符组合起来，形成整数。

该字符串除了有效的整数部分之后也可能会存在多余的字符，这些字符可以被忽略，它们对于函数不应该造成影响。

注意：假如该字符串中的第一个非空格字符不是一个有效整数字符、字符串为空或字符串仅包含空白字符时，则你的函数不需要进行转换。

在任何情况下，若函数不能进行有效的转换时，请返回 0。

说明：

假设我们的环境只能存储 32 位大小的有符号整数，那么其数值范围为  [−231,  231 − 1]。如果数值超过这个范围，请返回  INT_MAX (231 − 1) 或  INT_MIN (−231) 。

**示例 1:**

```text
输入: "42"
输出: 42
```

**示例 2:**

```text
输入: "   -42"
输出: -42
解释: 第一个非空白字符为 '-', 它是一个负号。
     我们尽可能将负号与后面所有连续出现的数字组合起来，最后得到 -42 。
```

**示例 3:**

```text
输入: "4193 with words"
输出: 4193
解释: 转换截止于数字 '3' ，因为它的下一个字符不为数字。
```

**示例 4:**

```text
输入: "4193 with words"
输出: 4193
解释: 转换截止于数字 '3' ，因为它的下一个字符不为数字。
```

**示例 5:**

```text
输入: "-91283472332"
输出: -2147483648
解释: 数字 "-91283472332" 超过 32 位有符号整数范围。
     因此返回 INT_MIN (−231) 。
```

## 解题方案

### 思路

- 标签：处理数字越界
- 整体思路：

  - 前端空格
  - “+”，“-”正负号
  - 首个字符为非数字
  - 数字字符处理

- 复杂度：

  - 时间复杂度：$O(n)$ ：其中 n 为字符串长度，线性遍历字符串占用 $O(n)$ 时间
  - 空间复杂度：$O(n)$ ： 删除首尾空格后需建立新字符串，最差情况下占用 $O(n)$ 额外空间。

### 算法流程

1. 删除首位空格
2. 声明一个变量保存符号位
3. 首位字符非数字直接返回
4. 若为数字字符，从左向右遍历字符集，若当前数字为 x， 数字结果为 res，则遍历中 res 结果为 res = res \* 10 + x
5. 获得下一次遍历结果前判断是否越界，如果超过 2147483647，直接返回
6. 返回结果

### 代码

```Java []
class Solution {
    public int strToInt(String str) {
        char[] c = str.trim().toCharArray();
        if(c.length == 0) return 0;
        int res = 0, boundry = Integer.MAX_VALUE / 10;
        int start = 1, sign = 1;
        if(c[0] == '-') sign = -1;
        else if(c[0] != '+') start = 0;
        for(int i = start; i < c.length; i++) {
            if(c[i] < '0' || c[i] > '9') break;
            if(res > boundry || res == boundry && c[i] > '7') return sign == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE;
            res = res * 10 + (c[i] - '0');
        }
        return sign * res;
    }
}
```

### 画解

<![offer67-1.png](https://pic.leetcode-cn.com/1609048075-gLDgzs-offer67-1.png),![offer67-2.png](https://pic.leetcode-cn.com/1609048075-SWlPrJ-offer67-2.png),![offer67-3.png](https://pic.leetcode-cn.com/1609048075-ozeoqz-offer67-3.png),![offer67-4.png](https://pic.leetcode-cn.com/1609048075-bdJUWx-offer67-4.png),![offer67-5.png](https://pic.leetcode-cn.com/1609048075-GIuZhe-offer67-5.png),![offer67-6.png](https://pic.leetcode-cn.com/1609048075-IdqGwW-offer67-6.png)>

### 花絮

![offer67.mp4](5bd783d1-acd4-46e7-a89c-3d6ef28ad1e7)



# 栈和队列
<p><a href="/circle/discuss/X6Oj0x/"><img alt="画解剑指 Offer" src="https://pic.leetcode-cn.com/b04af6fd9c21f097f14418471f5fea7c35ae9ecfcdc4805b5a8af2807a0ebaa8-leetbook_discussion.png" style="height: 80px;" /></a></p>

## 剑指 Offer 06. 从尾到头打印链表

>https://leetcode.cn/problems/cong-wei-dao-tou-da-yin-lian-biao-lcof/
<p>输入一个链表的头节点，从尾到头反过来返回每个节点的值（用数组返回）。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>head = [1,3,2]
<strong>输出：</strong>[2,3,1]</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>0 &lt;= 链表长度 &lt;= 10000</code></p>


### 剑指 Offer 06. 从尾到头打印链表 - 解决方案
## 题目描述

输入一个链表的头节点，从尾到头反过来返回每个节点的值（用数组返回）。

示例 1：

```bash
输入：head = [1,3,2]
输出：[2,3,1]
```

限制：

`0 <= 链表长度 <= 10000`

## 解题方案

### 思路

- 标签：栈
- 栈的特点是先进后出，因为题目要求从尾到头打印元素，所以符合栈的特性
  - 先遍历一遍链表，将链表中的元素存入到栈中
  - 再不断弹出栈内元素，将弹出元素存放到结果数组中
- 也有使用递归来进行解题的，在此提出一个思考，递归和栈的关系是什么？其实递归的本质也是在使用栈，只不过是程序调用栈，因为没有显式在代码中体现出来，所以常常被忽略了
- 时间复杂度：$O(n)$，空间复杂度：$O(n)$

### 代码

```Java []
/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
class Solution {
     public int[] reversePrint(ListNode head) {
        Stack<ListNode> stack = new Stack<ListNode>();
        ListNode pointer = head;
        while (pointer != null) {
            stack.push(pointer);
            pointer = pointer.next;
        }
        int length = stack.size();
        int[] res = new int[length];
        for (int i = 0; i < length; i++) {
            res[i] = stack.pop().val;
        }
        return res;
    }
}
```

```JavaScript []
/**
 * Definition for singly-linked list.
 * function ListNode(val) {
 *     this.val = val;
 *     this.next = null;
 * }
 */
/**
 * @param {ListNode} head
 * @return {number[]}
 */
var reversePrint = function(head) {
    let stack = [];
    let pointer = head;
    while (pointer != null) {
        stack.push(pointer.val);
        pointer = pointer.next;
    }
    const length = stack.length;
    let res = [];
    for (let i = 0; i < length; i++) {
        res.push(stack.pop());
    }
    return res;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/ff30d8108dbe5beb227a0ba569959bbcb8e7bf2ef3ab18711870c9556a41666f-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/a7b44c9ae0bd0c217b099ab84f2e43cf1a0a9842b1f0900e5e92449827768c83-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/7738ea16d13983ff3b53a3c298cba94c3f51ad9d47ef41356bd403b555ede5f5-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/1612a8caeac1373aa58cc0a07cbdca270c534747e64caa31cd00460550e96ecb-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/fe36ccc42ddecc32bca4945904d0c3a8711040b93f8e9b3a6e5e32f43c1b3930-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/5ac73e493c28e57239e19ce30073cb2e5d3863ddcfbdb160a3b0975bd7ee29ac-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/1f59644c9d00bb046c2bc641003c31af72b6abf8ae5914c9b13e80e4327773de-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/03cf6182d1b80ed6a5594a1f6919a8d380ea99e52438b3108c7c51ff3a96cb9c-frame_00008.png)>


## 剑指 Offer 09. 用两个栈实现队列

>https://leetcode.cn/problems/yong-liang-ge-zhan-shi-xian-dui-lie-lcof/
<p>用两个栈实现一个队列。队列的声明如下，请实现它的两个函数 <code>appendTail</code> 和 <code>deleteHead</code> ，分别完成在队列尾部插入整数和在队列头部删除整数的功能。(若队列中没有元素，<code>deleteHead</code>&nbsp;操作返回 -1 )</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre>
<strong>输入：</strong>
["CQueue","appendTail","deleteHead","deleteHead","deleteHead"]
[[],[3],[],[],[]]
<strong>输出：</strong>[null,null,3,-1,-1]
</pre>

<p><strong>示例 2：</strong></p>

<pre>
<strong>输入：</strong>
["CQueue","deleteHead","appendTail","appendTail","deleteHead","deleteHead"]
[[],[],[5],[2],[],[]]
<strong>输出：</strong>[null,-1,null,null,5,2]
</pre>

<p><strong>提示：</strong></p>

<ul>
	<li><code>1 &lt;= values &lt;= 10000</code></li>
	<li>最多会对<code>&nbsp;appendTail、deleteHead </code>进行<code>&nbsp;10000</code>&nbsp;次调用</li>
</ul>


### 剑指 Offer 09. 用两个栈实现队列 - 解决方案
## 题目描述

用两个栈实现一个队列。队列的声明如下，请实现它的两个函数 `appendTail` 和 `deleteHead` ，分别完成在队列尾部插入整数和在队列头部删除整数的功能。（若队列中没有元素，`deleteHead` 操作返回 -1）

示例 1：

```
输入：
["CQueue","appendTail","deleteHead","deleteHead"]
[[],[3],[],[]]
输出：[null,null,3,-1]
```

示例 2：

```
输入：
["CQueue","deleteHead","appendTail","appendTail","deleteHead","deleteHead"]
[[],[],[5],[2],[],[]]
输出：[null,-1,null,null,5,2]
```

提示：

- `1 <= values <= 10000`
- `最多会对 appendTail、deleteHead 进行 10000 次调用`

## 解题方案

### 思路

- 标签：栈和队列
- 整体思路：栈实现队列的本质就是负负得正，两次先进后出的结果就是先进先出了。在构造函数中完成两个栈的初始化工作，在 `appendTail` 函数中向其中一个栈 `stack1` 结尾插入整数，在 `deleteHead` 函数中如果 `stack2` 为空，则将 `stack1` 的值全部弹出放到 `stack2` 中，再从 `stack2` 中取值，这样达到了负负为正的队列效果
- 时间复杂度：$O(1)$，空间复杂度：$O(n)$

### 算法流程

1. `CQueue` 构造函数，初始化 `stack1` 和 `stack2`
2. `appendTail` 函数，将 `value` 加到 `stack1` 里面，先进后出
3. `deleteHead` 函数，判断 `stack2` 是否为空，如果为空则将当前 `stack1` 中的所有值都弹出放入 `stack2` 中。此时由于 `stack2` 也是先进后出，所以如果 `stack2` 不为空，则将其尾部值弹出，实现了先进先出队列的效果，如果 `stack2` 为空，则返回 -1

### 代码

```Java []
class CQueue {
    Stack<Integer> stack1;
    Stack<Integer> stack2;

    public CQueue() {
        stack1 = new Stack<Integer>();
        stack2 = new Stack<Integer>();
    }

    public void appendTail(int value) {
        stack1.push(value);
    }

    public int deleteHead() {
        if (stack2.isEmpty()) {
            while (!stack1.isEmpty()) {
                stack2.push(stack1.pop());
            }
        }
        if (stack2.isEmpty()) {
            return -1;
        } else {
            return stack2.pop();
        }
    }
}

/**
 * Your CQueue object will be instantiated and called as such:
 * CQueue obj = new CQueue();
 * obj.appendTail(value);
 * int param_2 = obj.deleteHead();
 */
```

```JavaScript []
var CQueue = function() {
    this.stack1 = [];
    this.stack2 = [];
};

/**
 * @param {number} value
 * @return {void}
 */
CQueue.prototype.appendTail = function(value) {
    this.stack1.push(value);
};

/**
 * @return {number}
 */
CQueue.prototype.deleteHead = function() {
    if (this.stack2.length == 0) {
        while (this.stack1.length != 0) {
            this.stack2.push(this.stack1.pop());
        }
    }
    if (this.stack2.length == 0) {
        return -1;
    } else {
        return this.stack2.pop();
    }
};

/**
 * Your CQueue object will be instantiated and called as such:
 * var obj = new CQueue()
 * obj.appendTail(value)
 * var param_2 = obj.deleteHead()
 */
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/65319a086732aafc061f56798d2dd65c01166c710e169509918e6eeec653b89b-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/3e0f6f952c3be030dd6d0de19b30178f3c8563c7ae7942a02d588d139071050b-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/ad1ca8b5f0d11910f47cda6386521a0b8182ebb5900ff65dbe454501a5637316-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/b4bf53cceb677520e6766153c1511b827e647a71d65edfd59bc9eb18f3deb0e9-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/4f022382f1b69946dece3bb5e352cfe08908157cb21de167737d5d9fb3aabb6e-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/9d5cf4f02e8e5aeffd21202774dac6fbce3cde8450013ab2817836b89989169b-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/e6da7d1780a9d3fc59afbe1b8f8784bbdbe836311184b59b46b2a38bc1525e57-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/6f46c1a5d4551b40d3782a478ca639afa1ee5e409fe7bd00997f4dbf35fac09d-frame_00008.png),![frame_00009.png](https://pic.leetcode-cn.com/98998034d643ca41e942b1178744a9837384c243bee0bfbeb1443637004eb584-frame_00009.png)>


## 剑指 Offer 30. 包含 min 函数的栈

>https://leetcode.cn/problems/bao-han-minhan-shu-de-zhan-lcof/
<p>定义栈的数据结构，请在该类型中实现一个能够得到栈的最小元素的 min 函数在该栈中，调用 min、push 及 pop 的时间复杂度都是 O(1)。</p>

<p>&nbsp;</p>

<p><strong>示例:</strong></p>

<pre>MinStack minStack = new MinStack();
minStack.push(-2);
minStack.push(0);
minStack.push(-3);
minStack.min();   --&gt; 返回 -3.
minStack.pop();
minStack.top();      --&gt; 返回 0.
minStack.min();   --&gt; 返回 -2.
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ol>
	<li>各函数的调用总次数不超过 20000 次</li>
</ol>

<p>&nbsp;</p>

<p>注意：本题与主站 155 题相同：<a href="https://leetcode-cn.com/problems/min-stack/">https://leetcode-cn.com/problems/min-stack/</a></p>


### 剑指 Offer 30. 包含 min 函数的栈 - 解决方案
## 题目描述

定义栈的数据结构，请在该类型中实现一个能够得到栈的最小元素的 `min` 函数在该栈中，调用 `min`、`push` 及 `pop` 的时间复杂度都是 $O(1)$。

示例:

```
MinStack minStack = new MinStack();
minStack.push(-2);
minStack.push(0);
minStack.push(-3);
minStack.min();   --> 返回 -3.
minStack.pop();
minStack.top();      --> 返回 0.
minStack.min();   --> 返回 -2.
```

提示：

1. `各函数的调用总次数不超过 20000 次`

## 解题方案

### 思路

- 标签：辅助栈
- 整体思路：`push`、`pop`、`top` 操作可以通过建立普通的栈结构完成操作，对于取最小值 `min` 函数则需要建立辅助栈，辅助栈中降序存储 `push` 过程中的值
- 时间复杂度：$O(1)$，空间复杂度：$O(n)$

### 算法流程

1. `MinStack` 构造函数中初始化数据栈 `stack1` 和辅助栈 `stack2`
2. `push` 函数中将 `x` 正常添加到 `stack1` 中，如果 `stack2` 为空或者 `stack2` 栈顶值大于等于 `x` 时，则将 `x` 加入 `stack2` 中，这样保证了 `stack2` 中的值一定是降序的，存储的数量会小于等于 `stack1`
3. `pop` 函数中首先 `stack1` 需要将值 `pop` 出去，如果 `stack2` 栈顶数据与 `stack1` 栈顶数据相等，则将 `stack2` 的值也 `pop` 出去，保证数据栈和辅助栈的数据一致性
4. `top` 函数则直接取 `stack1` 栈顶值即可
5. `min` 函数则直接取 `stack2` 栈顶值即可

### 代码

```Java []
class MinStack {
    Stack<Integer> stack1;
    Stack<Integer> stack2;

    /** initialize your data structure here. */
    public MinStack() {
        stack1 = new Stack<>();
        stack2 = new Stack<>();
    }

    public void push(int x) {
        stack1.add(x);
        if(stack2.empty() || stack2.peek() >= x) {
            stack2.add(x);
        }

    }

    public void pop() {
        if(stack1.pop().equals(stack2.peek())) {
            stack2.pop();
        }
    }

    public int top() {
        return stack1.peek();
    }

    public int min() {
        return stack2.peek();
    }
}

/**
 * Your MinStack object will be instantiated and called as such:
 * MinStack obj = new MinStack();
 * obj.push(x);
 * obj.pop();
 * int param_3 = obj.top();
 * int param_4 = obj.min();
 */
```

```JavaScript []
/**
 * initialize your data structure here.
 */
var MinStack = function() {
    this.stack1 = [];
    this.stack2 = [];
};

/**
 * @param {number} x
 * @return {void}
 */
MinStack.prototype.push = function(x) {
    this.stack1.push(x);
    if(this.stack2.length == 0 || this.stack2[this.stack2.length - 1] >= x) {
        this.stack2.push(x);
    }
};

/**
 * @return {void}
 */
MinStack.prototype.pop = function() {
    if(this.stack1.pop() == this.stack2[this.stack2.length - 1]) {
        this.stack2.pop();
    }
};

/**
 * @return {number}
 */
MinStack.prototype.top = function() {
    return this.stack1[this.stack1.length - 1];
};

/**
 * @return {number}
 */
MinStack.prototype.min = function() {
    return this.stack2[this.stack2.length - 1];
};

/**
 * Your MinStack object will be instantiated and called as such:
 * var obj = new MinStack()
 * obj.push(x)
 * obj.pop()
 * var param_3 = obj.top()
 * var param_4 = obj.min()
 */
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/2237ead6b560f7be7be90099c9477a8bcb7df1bfff5c650017dc1b4733c8b758-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/f87ea3171f2a45337ef3b3bb5d27f31ac9ef0a93f576102fac153556c351017e-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/ba2b682880a1b1361f53225b110670042cde19b7f7d122ee58d302fca2c4e4ba-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/0179c6adba90d69b93aa2d95aae4e845378c6425c282d49587367318677ceca4-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/fb4734e795e37bad44141f8c81b0a0ba7ec98238db685b1138f46459086026ad-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/205ee8da50caf761543305ed7dc3c94095c3c7709151f02e1b0118b16f42ef9d-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/6c5373da05911fb3e5be9edadb9c4607ef7f3c8faff4e5990215d92b5fb62468-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/d80ebd9e9c452c96a0acee9e96234bd3838095f56ef030ad4b8a98c4a0afbf5b-frame_00008.png),![frame_00009.png](https://pic.leetcode-cn.com/3e92c831e0ae575eb9090dd345e0e52f058b577f3686efa22cf74f5ff57a9c5d-frame_00009.png)>


## 剑指 Offer 31. 栈的压入、弹出序列

>https://leetcode.cn/problems/zhan-de-ya-ru-dan-chu-xu-lie-lcof/
<p>输入两个整数序列，第一个序列表示栈的压入顺序，请判断第二个序列是否为该栈的弹出顺序。假设压入栈的所有数字均不相等。例如，序列 {1,2,3,4,5} 是某栈的压栈序列，序列 {4,5,3,2,1} 是该压栈序列对应的一个弹出序列，但 {4,3,5,1,2} 就不可能是该压栈序列的弹出序列。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>pushed = [1,2,3,4,5], popped = [4,5,3,2,1]
<strong>输出：</strong>true
<strong>解释：</strong>我们可以按以下顺序执行：
push(1), push(2), push(3), push(4), pop() -&gt; 4,
push(5), pop() -&gt; 5, pop() -&gt; 3, pop() -&gt; 2, pop() -&gt; 1
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>pushed = [1,2,3,4,5], popped = [4,3,5,1,2]
<strong>输出：</strong>false
<strong>解释：</strong>1 不能在 2 之前弹出。
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ol>
	<li><code>0 &lt;= pushed.length == popped.length &lt;= 1000</code></li>
	<li><code>0 &lt;= pushed[i], popped[i] &lt; 1000</code></li>
	<li><code>pushed</code>&nbsp;是&nbsp;<code>popped</code>&nbsp;的排列。</li>
</ol>

<p>注意：本题与主站 946 题相同：<a href="https://leetcode-cn.com/problems/validate-stack-sequences/">https://leetcode-cn.com/problems/validate-stack-sequences/</a></p>


### 剑指 Offer 31. 栈的压入、弹出序列 - 解题思路
## 题目描述

输入两个整数序列，第一个序列表示栈的压入顺序，请判断第二个序列是否为该栈的弹出顺序。假设压入栈的所有数字均不相等。例如，序列 {1,2,3,4,5} 是某栈的压栈序列，序列 {4,5,3,2,1} 是该压栈序列对应的一个弹出序列，但 {4,3,5,1,2} 就不可能是该压栈序列的弹出序列。

**示例 1:**

```text
输入：pushed = [1,2,3,4,5], popped = [4,5,3,2,1]
输出：true
解释：我们可以按以下顺序执行：
push(1), push(2), push(3), push(4), pop() -> 4,
push(5), pop() -> 5, pop() -> 3, pop() -> 2, pop() -> 1
```

**示例 2:**

```text
输入：pushed = [1,2,3,4,5], popped = [4,3,5,1,2]
输出：false
解释：1 不能在 2 之前弹出。
```

限制：

1. `0 <= pushed.length == popped.length <= 1000`
2. `0 <= pushed[i], popped[i] < 1000`
3. `pushed` 是 `popped` 的排列。

## 解题方案

### 思路

- 标签：模拟
- 整体思路：

借用一个辅助栈 `stackstack`，模拟 压入 / 弹出操作的排列。根据是否模拟成功，即可得到结果。

- 复杂度：

  - 时间复杂度：$O(n)$。 $n$ 为入栈序列的长度

  - 空间复杂度：$O(n)$： 辅助栈最多存储 $n$ 个元素

### 算法流程

1. 建立一个辅助栈
2. 遍历入栈序列
   - 元素入栈
   - 若辅助栈栈顶元素等于弹出序列元素，则执行出栈操作
3. 返回结果

### 代码

```Java []
class Solution {
    public boolean validateStackSequences(int[] pushed, int[] popped) {
        Stack<Integer> stack = new Stack<>();
        int i = 0;
        for(int element : pushed) {
            stack.push(element); // num 入栈
            while(!stack.isEmpty() && stack.peek() == popped[i]) { // 循环判断与出栈
                stack.pop();
                i++;
            }
        }
        return stack.isEmpty();
    }
}
```

### 画解

<![offer31-1.png](https://pic.leetcode-cn.com/1607999386-cQoGKn-offer31-1.png),![offer31-2.png](https://pic.leetcode-cn.com/1607999386-xdopKk-offer31-2.png),![offer31-3.png](https://pic.leetcode-cn.com/1607999386-xvtYGd-offer31-3.png),![offer31-4.png](https://pic.leetcode-cn.com/1607999386-FWgFrC-offer31-4.png),![offer31-5.png](https://pic.leetcode-cn.com/1607999386-ZdaXAH-offer31-5.png),![offer31-6.png](https://pic.leetcode-cn.com/1607999386-jukAZb-offer31-6.png),![offer31-7.png](https://pic.leetcode-cn.com/1607999386-TfYRQy-offer31-7.png),![offer31-8.png](https://pic.leetcode-cn.com/1607999386-ZBytvZ-offer31-8.png),![offer31-9.png](https://pic.leetcode-cn.com/1607999386-WMlyxT-offer31-9.png),![offer31-10.png](https://pic.leetcode-cn.com/1607999386-nPqMMT-offer31-10.png),![offer31-11.png](https://pic.leetcode-cn.com/1607999386-khiHqR-offer31-11.png),![offer31-12.png](https://pic.leetcode-cn.com/1607999386-DyDGES-offer31-12.png),![offer31-13.png](https://pic.leetcode-cn.com/1607999386-bvWjKe-offer31-13.png)>

### 花絮

![offer31.mp4](39f2aea1-05c9-4200-95b5-70a21dff3e64)


## 剑指 Offer 59 - I. 滑动窗口的最大值

>https://leetcode.cn/problems/hua-dong-chuang-kou-de-zui-da-zhi-lcof/
<p>给定一个数组 <code>nums</code> 和滑动窗口的大小 <code>k</code>，请找出所有滑动窗口里的最大值。</p>

<p><strong>示例:</strong></p>

<pre>
<strong>输入:</strong> <em>nums</em> = <code>[1,3,-1,-3,5,3,6,7]</code>, 和 <em>k</em> = 3
<strong>输出: </strong><code>[3,3,5,5,6,7] 
<strong>解释: 
</strong></code>
  滑动窗口的位置                最大值
---------------               -----
[1  3  -1] -3  5  3  6  7       3
 1 [3  -1  -3] 5  3  6  7       3
 1  3 [-1  -3  5] 3  6  7       5
 1  3  -1 [-3  5  3] 6  7       5
 1  3  -1  -3 [5  3  6] 7       6
 1  3  -1  -3  5 [3  6  7]      7</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<p>你可以假设 <em>k </em>总是有效的，在输入数组&nbsp;<strong>不为空&nbsp;</strong>的情况下，<code>1 ≤ k ≤&nbsp;nums.length</code>。</p>

<p>注意：本题与主站 239 题相同：<a href="https://leetcode-cn.com/problems/sliding-window-maximum/">https://leetcode-cn.com/problems/sliding-window-maximum/</a></p>


### 剑指 Offer 59 - I. 滑动窗口的最大值 - 解决方案
## 题目描述

给定一个数组 `nums` 和滑动窗口的大小 `k`，请找出所有滑动窗口里的最大值。

示例:

```text
输入: nums = [1,3,-1,-3,5,3,6,7], 和 k = 3
输出: [3,3,5,5,6,7] 
解释: 

  滑动窗口的位置                最大值
---------------               -----
[1  3  -1] -3  5  3  6  7       3
 1 [3  -1  -3] 5  3  6  7       3
 1  3 [-1  -3  5] 3  6  7       5
 1  3  -1 [-3  5  3] 6  7       5
 1  3  -1  -3 [5  3  6] 7       6
 1  3  -1  -3  5 [3  6  7]      7
```

**提示：**

你可以假设 k 总是有效的，在输入数组不为空的情况下，1 ≤ k ≤ 输入数组的大小。

## 解题方案

### 思路

- 标签：单调队列
- 整体思路：
  - 从题目上来看是通过维护滑动窗口，然后每次求滑动窗口中的最大值即可，设数组长度为 n，窗口长度为 k，则时间复杂度为 $O(k*(n-k+1)) = O(kn)$
  - 很显然使用暴力解法的话，时间复杂度会随着 k 变大不断变大，而其中有很多元素在不同的滑动窗口中都存在着，所以必然存在重复计算的逻辑
  - 考虑使用单调队列，队列内只存在窗口内的元素，队列内元素递减。可以保证所有的数据只会入队和出队一次，减少时间复杂度
- 复杂度：
  - 时间复杂度：$O(n)$。遍历数组需要 $O(n)$ 的时间复杂度，数组中的元素最多入队和出队一次，队列内元素维护最多需要 $O(2n)$ ，所以总体时间复杂度为 $O(n)$
  - 空间复杂度：$O(k)$。维护一个最多元素个数为 k 个的队列

### 算法流程

1. 初始化滑动窗口的 left 和 right 位置，从下标为 [1-k, 0] 范围开始
2. 如果 left > 0 说明窗口已经在数组中了，并且单调队列的第一个元素和 nums[left - 1] 相等时，说明该元素已经不在滑动窗口中，需要移除
3. 如果单调队列不为空且最后一个元素小于新加入的 nums[right] 元素，则需要维护单调队列为递减状态，所以将最后一个元素移除，直到其大于新加入元素
4. 将新加入的 nums[right] 元素加入单调队列，因为上一步的操作，当前单调队列一定是递减的
5. 如果 left >= 0，说明窗口在数组中，因为单调队列递减，所以第一个元素一定是当前滑动窗口最大值

### 代码

```Java []
class Solution {
    public int[] maxSlidingWindow(int[] nums, int k) {
        if(nums.length == 0 || k == 0) {
            return new int[0];
        }
        Deque<Integer> queue = new LinkedList<>();
        int[] res = new int[nums.length - k + 1];
        for(int right = 0, left = 1 - k; right < nums.length; left++, right++) {
            if(left > 0 && queue.peekFirst() == nums[left - 1]) {
                queue.removeFirst();
            }
            while(!queue.isEmpty() && queue.peekLast() < nums[right]) {
                queue.removeLast();
            }
            queue.addLast(nums[right]);
            if(left >= 0) {
                res[left] = queue.peekFirst();
            }
        }
        return res;
    }
}
```

```JavaScript []
/**
 * @param {number[]} nums
 * @param {number} k
 * @return {number[]}
 */
var maxSlidingWindow = function(nums, k) {
    if(nums.length == 0 || k == 0) {
        return [];
    }
    let queue = [];
    let res = [];
    for(let right = 0, left = 1 - k; right < nums.length; left++, right++) {
        if(left > 0 && queue[0] == nums[left - 1]) {
            queue.shift();
        }
        while(queue.length != 0 && queue[queue.length - 1] < nums[right]) {
            queue.pop();
        }
        queue.push(nums[right]);
        if(left >= 0) {
            res[left] = queue[0];
        }
    }
    return res;
};
```

### 画解

<![offer59-1-1.png](https://pic.leetcode-cn.com/1600741432-PJQdIq-offer59-1-1.png),![offer59-1-2.png](https://pic.leetcode-cn.com/1600741432-GiGBFc-offer59-1-2.png),![offer59-1-3.png](https://pic.leetcode-cn.com/1600741432-PsUIUw-offer59-1-3.png),![offer59-1-4.png](https://pic.leetcode-cn.com/1600741432-mkjocW-offer59-1-4.png),![offer59-1-5.png](https://pic.leetcode-cn.com/1600741432-VjOLlf-offer59-1-5.png),![offer59-1-6.png](https://pic.leetcode-cn.com/1600741432-tVDZri-offer59-1-6.png),![offer59-1-7.png](https://pic.leetcode-cn.com/1600741432-ViYxFF-offer59-1-7.png),![offer59-1-8.png](https://pic.leetcode-cn.com/1600741432-FjFgel-offer59-1-8.png),![offer59-1-9.png](https://pic.leetcode-cn.com/1600741432-tNZPGv-offer59-1-9.png)>

### 花絮

![offer59-1.mp4](0758f65b-4a86-4c37-a11d-b29278268f1f)


## 剑指 Offer 59 - II. 队列的最大值

>https://leetcode.cn/problems/dui-lie-de-zui-da-zhi-lcof/
<p>请定义一个队列并实现函数 <code>max_value</code> 得到队列里的最大值，要求函数<code>max_value</code>、<code>push_back</code> 和 <code>pop_front</code> 的<strong>均摊</strong>时间复杂度都是O(1)。</p>

<p>若队列为空，<code>pop_front</code> 和 <code>max_value</code>&nbsp;需要返回 -1</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入:</strong> 
[&quot;MaxQueue&quot;,&quot;push_back&quot;,&quot;push_back&quot;,&quot;max_value&quot;,&quot;pop_front&quot;,&quot;max_value&quot;]
[[],[1],[2],[],[],[]]
<strong>输出:&nbsp;</strong>[null,null,null,2,1,2]
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入:</strong> 
[&quot;MaxQueue&quot;,&quot;pop_front&quot;,&quot;max_value&quot;]
[[],[],[]]
<strong>输出:&nbsp;</strong>[null,-1,-1]
</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<ul>
	<li><code>1 &lt;= push_back,pop_front,max_value的总操作数&nbsp;&lt;= 10000</code></li>
	<li><code>1 &lt;= value &lt;= 10^5</code></li>
</ul>


### 剑指 Offer 59 - II. 队列的最大值 - 解决方案
## 题目描述

请定义一个队列并实现函数 `max_value` 得到队列里的最大值，要求函数 `max_value`、`push_back` 和 `pop_front` 的均摊时间复杂度都是 $O(1)$。

若队列为空，`pop_front` 和 `max_value`  需要返回 -1

示例 1：

```text
输入:
["MaxQueue","push_back","push_back","max_value","pop_front","max_value"]
[[],[1],[2],[],[],[]]
输出: [null,null,null,2,1,2]
```

示例 2：

```text
输入:
["MaxQueue","pop_front","max_value"]
[[],[],[]]
输出: [null,-1,-1]
```

限制：

- `1 <= push_back,pop_front,max_value的总操作数 <= 10000`
- `1 <= value <= 10^5`

## 解题方案

### 思路

- 标签：单调队列、辅助队列
- 整体思路：
  - 这道题和 59 - I 的思路很像，最难的地方在于取出最大值函数的时间复杂度如何降为 $O(1)$，如果每次入队的时候都维护一个最大值，那么时间复杂度很明显不满足条件
  - 使用一个额外的辅助单调队列，该队列单调递减即可，保证最大值在队列头部，这样的话就可以在取出最大值的时候时间复杂度减低
- 复杂度：
  - 时间复杂度：$O(1)$。取 `max_value` 时只需要取单调队列头部即可
  - 空间复杂度：$O(n)$。一共需要维护两个队列，普通队列和辅助单调队列，最差的情况是两个队列里面 $n$ 个数字

### 算法流程

1. 构造函数中初始化一个普通队列 `queue` 和一个辅助单调队列 `deque`
2. `max_value` 函数中只需要每次从辅助单调队列 `deque` 取头部值即可，如果没有则返回 -1
3. `push_back` 函数中首先将值放入 `queue` 中，然后将 `deque` 尾部所有小于该值的元素都剔除，最后将该值放入尾部，保证单调队列递减
4. `pop_front` 函数中首先获取 `queue` 头部值 `head`，如果不存在则返回 -1，然后判断 `deque` 的头部值是否和 `head` 相等，如果相等则将其头部值也移除

### 代码

```Java []
class MaxQueue {
    Queue<Integer> queue;
    Deque<Integer> deque;

    public MaxQueue() {
        queue = new LinkedList<>();
        deque = new LinkedList<>();
    }

    public int max_value() {
        return deque.size() > 0 ? deque.peek() : -1;
    }

    public void push_back(int value) {
        queue.offer(value);
        while(deque.size() > 0 && deque.peekLast() < value){
            deque.pollLast();
        }
        deque.offerLast(value);
    }

    public int pop_front() {
        int head = queue.size() > 0 ? queue.poll() : -1;
        if(deque.size() > 0 && deque.peek().equals(head)){
            deque.poll();
        }
        return head;
    }
}
/**
 * Your MaxQueue object will be instantiated and called as such:
 * MaxQueue obj = new MaxQueue();
 * int param_1 = obj.max_value();
 * obj.push_back(value);
 * int param_3 = obj.pop_front();
 */
```

```JavaScript []
var MaxQueue = function() {
    this.queue = [];
    this.deque = [];
};

/**
 * @return {number}
 */
MaxQueue.prototype.max_value = function() {
    return this.deque.length > 0 ? this.deque[0] : -1;
};

/**
 * @param {number} value
 * @return {void}
 */
MaxQueue.prototype.push_back = function(value) {
    this.queue.push(value);
    while(this.deque.length > 0 && this.deque[this.deque.length - 1] < value){
        this.deque.pop();
    }
    this.deque.push(value);
};

/**
 * @return {number}
 */
MaxQueue.prototype.pop_front = function() {
    let head = this.queue.length > 0 ? this.queue.shift() : -1;
    if(this.deque.length > 0 && this.deque[0] === head){
        this.deque.shift();
    }
    return head;
};

/**
 * Your MaxQueue object will be instantiated and called as such:
 * var obj = new MaxQueue()
 * var param_1 = obj.max_value()
 * obj.push_back(value)
 * var param_3 = obj.pop_front()
 */
```

### 画解

<![offer59-2-1.png](https://pic.leetcode-cn.com/1600909358-URvkZp-offer59-2-1.png),![offer59-2-2.png](https://pic.leetcode-cn.com/1600909358-AMojqt-offer59-2-2.png),![offer59-2-3.png](https://pic.leetcode-cn.com/1600909358-YKXWBa-offer59-2-3.png),![offer59-2-4.png](https://pic.leetcode-cn.com/1600909358-HlwsBj-offer59-2-4.png),![offer59-2-5.png](https://pic.leetcode-cn.com/1600909358-tCcuFZ-offer59-2-5.png),![offer59-2-6.png](https://pic.leetcode-cn.com/1600909358-qeDlXJ-offer59-2-6.png),![offer59-2-7.png](https://pic.leetcode-cn.com/1600909358-TbwHXR-offer59-2-7.png),![offer59-2-8.png](https://pic.leetcode-cn.com/1600909358-BrYQpU-offer59-2-8.png),![offer59-2-9.png](https://pic.leetcode-cn.com/1600909358-iqibMc-offer59-2-9.png),![offer59-2-10.png](https://pic.leetcode-cn.com/1600909358-zLrOZq-offer59-2-10.png),![offer59-2-11.png](https://pic.leetcode-cn.com/1600909358-qHdkEs-offer59-2-11.png),![offer59-2-12.png](https://pic.leetcode-cn.com/1600909358-FREVDd-offer59-2-12.png),![offer59-2-13.png](https://pic.leetcode-cn.com/1600909358-QSJpmW-offer59-2-13.png)>


### 花絮

![offer59-2.mp4](de81bc46-65c5-4c2d-9855-18f4cdecf355)



# 哈希表
<p><a href="/circle/discuss/X6Oj0x/"><img alt="画解剑指 Offer" src="https://pic.leetcode-cn.com/b04af6fd9c21f097f14418471f5fea7c35ae9ecfcdc4805b5a8af2807a0ebaa8-leetbook_discussion.png" style="height: 80px;" /></a></p>

## 剑指 Offer 03. 数组中重复的数字

>https://leetcode.cn/problems/shu-zu-zhong-zhong-fu-de-shu-zi-lcof/
<p>找出数组中重复的数字。</p>

<p><br>
在一个长度为 n 的数组 nums 里的所有数字都在 0～n-1 的范围内。数组中某些数字是重复的，但不知道有几个数字重复了，也不知道每个数字重复了几次。请找出数组中任意一个重复的数字。</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>
[2, 3, 1, 0, 2, 5, 3]
<strong>输出：</strong>2 或 3 
</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>2 &lt;= n &lt;= 100000</code></p>


### 剑指 Offer 03. 数组中重复的数字 - 解决方案
## 题目描述

在一个长度为 n 的数组 nums 里的所有数字都在 0 ～ n-1 的范围内。数组中某些数字是重复的，但不知道有几个数字重复了，也不知道每个数字重复了几次。请找出数组中任意一个重复的数字。

**示例 1：**

```
输入：
[2, 3, 1, 0, 2, 5, 3]
输出：2 或 3
```

**限制：**

`2 <= n <= 100000`

## 解题方案

### 思路 1

- 标签：哈希
- 使用 HashSet 来进行处理，因为 HashSet 本身不允许出现重复元素，所以**当添加元素失败或已经包含该数字时**，则表示出现了重复元素，将其返回即可。思路较为简单，就不给图了
- 时间复杂度：$O(n)$，空间复杂度：$O(n)$

### 代码 1

```Java []
class Solution {
    public int findRepeatNumber(int[] nums) {
        Set<Integer> numsSet = new HashSet<>();
        for(int num: nums) {
            if(!numsSet.add(num)) {
                return num;
            }
        }
        return -1;
    }
}
```

```JavaScript []
/**
 * @param {number[]} nums
 * @return {number}
 */
var findRepeatNumber = function(nums) {
    const numsSet = new Set();
    for(const num of nums) {
        if(numsSet.has(num)) {
            return num;
        } else {
            numsSet.add(num);
        }
    }
    return -1;
};
```

### 思路 2

- 标签：哈希
- 从题目描述中我们可以看出，因为所有数字都在 0 ～ n-1 的范围内，其实完全可以省掉额外的空间开辟，将每个位置的数交换映射到其对应的数组下标下面，当出现新的元素与其对应的下标中的数字相等时，即为重复数字
- 这本质还是哈希的思想，思路 1 是使用库函数申请额外空间，思路 2 则是数组本身做哈希表，达到了节省空间的目的
- 此处会用到 while 循环，原因是保证交换过来的新元素位置也要正确
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 代码 2

```Java []
class Solution {
    public int findRepeatNumber(int[] nums) {
        int len = nums.length;
        for (int i = 0; i < len; i++) {
            while (nums[i] != i) {
                if (nums[i] == nums[nums[i]]) {
                    return nums[i];
                }
                int temp = nums[i];
                nums[i] = nums[temp];
                nums[temp] = temp;
            }
        }
        return -1;
    }
}
```

```JavaScript []
/**
 * @param {number[]} nums
 * @return {number}
 */
var findRepeatNumber = function(nums) {
    const len = nums.length;
    for (let i = 0; i < len; i++) {
        while (nums[i] != i) {
            if (nums[i] == nums[nums[i]]) {
                return nums[i];
            }
            const temp = nums[i];
            nums[i] = nums[temp];
            nums[temp] = temp;
        }
    }
    return -1;
};
```

### 画解 2
<![offer3-1.png](https://pic.leetcode-cn.com/6e0f826c0410ca0b11845d94efe9df2bedd27b0d9113b89d7e8e57cf74f8ab34-offer3-1.png),![offer3-2.png](https://pic.leetcode-cn.com/7ca2986c445e5e570b5992febf2e7ac7c8a9a5272d51bea434940d261840a54d-offer3-2.png),![offer3-3.png](https://pic.leetcode-cn.com/4669855443c2def1f61088f475fd1b94376fbfc93279b482214c55e51b443f59-offer3-3.png),![offer3-4.png](https://pic.leetcode-cn.com/496d1507e43c8ea55a8951255cfb9c58bd0b08f9962794764eff1b21781162b3-offer3-4.png)>


## 剑指 Offer 48. 最长不含重复字符的子字符串

>https://leetcode.cn/problems/zui-chang-bu-han-zhong-fu-zi-fu-de-zi-zi-fu-chuan-lcof/
<p>请从字符串中找出一个最长的不包含重复字符的子字符串，计算该最长子字符串的长度。</p>

<p>&nbsp;</p>

<p><strong>示例&nbsp;1:</strong></p>

<pre><strong>输入: </strong>&quot;abcabcbb&quot;
<strong>输出: </strong>3 
<strong>解释:</strong> 因为无重复字符的最长子串是 <code>&quot;abc&quot;，所以其</code>长度为 3。
</pre>

<p><strong>示例 2:</strong></p>

<pre><strong>输入: </strong>&quot;bbbbb&quot;
<strong>输出: </strong>1
<strong>解释: </strong>因为无重复字符的最长子串是 <code>&quot;b&quot;</code>，所以其长度为 1。
</pre>

<p><strong>示例 3:</strong></p>

<pre><strong>输入: </strong>&quot;pwwkew&quot;
<strong>输出: </strong>3
<strong>解释: </strong>因为无重复字符的最长子串是&nbsp;<code>&quot;wke&quot;</code>，所以其长度为 3。
&nbsp;    请注意，你的答案必须是 <strong>子串 </strong>的长度，<code>&quot;pwke&quot;</code>&nbsp;是一个<em>子序列，</em>不是子串。
</pre>

<p>&nbsp;</p>

<p>提示：</p>

<ul>
	<li><code>s.length &lt;= 40000</code></li>
</ul>

<p>注意：本题与主站 3 题相同：<a href="https://leetcode-cn.com/problems/longest-substring-without-repeating-characters/">https://leetcode-cn.com/problems/longest-substring-without-repeating-characters/</a></p>


### 剑指 Offer 48. 最长不含重复字符的子字符串 - 解决方案
## 题目描述

请从字符串中找出一个最长的不包含重复字符的子字符串，计算该最长子字符串的长度。

**示例 1:**

```text
输入: "abcabcbb"
输出: 3
解释: 因为无重复字符的最长子串是、 "abc"，所以其长度为 3。
```

**示例 2:**

```text
输入: "bbbbb"
输出: 1
解释: 因为无重复字符的最长子串是 "b"，所以其长度为 1。
```

**示例 3:**

```text
输入: "pwwkew"
输出: 3
解释: 因为无重复字符的最长子串是 "wke"，所以其长度为 3。
     请注意，你的答案必须是 子串 的长度，"pwke" 是一个子序列，不是子串。
```

提示: $s.length <= 40000$

## 解题方案

### 思路

- 标签：滑动窗口
- 整体思路：

暴力解法时间复杂度较高，会达到 $O(n^2)$，故而采取滑动窗口的方法降低时间复杂度

- 复杂度：

  - 时间复杂度：$O(n)$。

### 算法流程

1. 定义一个 map 数据结构存储 (k, v)，其中 key 值为字符，value 值为字符位置 +1，加 1 表示从字符位置后一个才开始不重复
2. 我们定义不重复子串的开始位置为 start，结束位置为 end
3. 随着 end 不断遍历向后，会遇到与 [start, end] 区间内字符相同的情况，此时将字符作为 key 值，获取其 value 值，并更新 start，此时 [start, end] 区间内不存在重复字符
4. 无论是否更新 start，都会更新其 map 数据结构和结果 ans。

### 代码

```Java []
class Solution {
    public int lengthOfLongestSubstring(String s) {
        int n = s.length(), ans = 0;
        Map<Character, Integer> map = new HashMap<>();
        for (int end = 0, start = 0; end < n; end++) {
            char alpha = s.charAt(end);
            if (map.containsKey(alpha)) {
                start = Math.max(map.get(alpha), start);
            }
            ans = Math.max(ans, end - start + 1);
            map.put(s.charAt(end), end + 1);
        }
        return ans;
    }
}
```

### 画解

<![frame_00001.png](https://pic.leetcode-cn.com/2847c2d9fb9a6326fecfcf8831ed1450046f1e10967cde9d8681c42393d745ff-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/159cc7509e4a5acbfaf5c59b4b5cb1674f1a31fb87cc41528ca6e6df6132b1dc-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/a62a6d9c878b4c856db1467b4282b936ee677d02a3b47ac4c67dfb4269a158f6-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/7b672e389b1659d3ff2ba77101cf49de120a21732dd7aed5a707d8b33d6b2fb6-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/ff8f38005f548beb5bd45a2e5e327f71acf069c8ad6e9680caeee655af71533a-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/2f054f105ebcbe7a1cf3cce1a4ab8c0d85cef70fe674bb90a1c83e92dc6b1274-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/018b08f276a746262cf64fa1cf0748d815f3cabe9c29c61f4973b6e6dd44e2c8-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/385c6b1623b2d686e42e11882be13e6e717975fd0399712113992a318d7ca1e5-frame_00008.png)>


## 剑指 Offer 50. 第一个只出现一次的字符

>https://leetcode.cn/problems/di-yi-ge-zhi-chu-xian-yi-ci-de-zi-fu-lcof/
<p>在字符串 s 中找出第一个只出现一次的字符。如果没有，返回一个单空格。 s 只包含小写字母。</p>

<p><strong>示例 1:</strong></p>

<pre>
输入：s = "abaccdeff"
输出：'b'
</pre>

<p><strong>示例 2:</strong></p>

<pre>
输入：s = "" 
输出：' '
</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>0 &lt;= s 的长度 &lt;= 50000</code></p>


### 剑指 Offer 50. 第一个只出现一次的字符 - 解决方案
## 题目描述

在字符串 `s` 中找出第一个只出现一次的字符。如果没有，返回一个单空格。 `s` 只包含小写字母。

示例：

```
s = "abaccdeff"
返回 "b"

s = ""
返回 " "
```

限制：

`0 <= s 的长度 <= 50000`

## 解题方案

### 思路

- 标签：哈希
- 首先遍历字符串将每个字符串映射到固定的位置，并且该位置存储字符串的出现次数，然后再遍历一次字符串，找到第一个只出现一次的字符
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程

1. 初始化哈希表 `map`，大小为 26，因为只有 26 个小写字符
2. 遍历字符串 `s`，将遍历到的单个字符与 `'a'` 做减法，作为下标映射到哈希表中，比如 `'b' - 'a' = 1`，则位置为 `map[1]`
3. 再次遍历字符串 `s`，当出现次数为 1 的时候，返回该字符

### 代码

```Java []
class Solution {
    public char firstUniqChar(String s) {
        int[] map = new int[26];
        for(char ch : s.toCharArray()){
            map[ch - 'a']++;
        }
        for(char ch : s.toCharArray()){
            if(map[ch - 'a'] == 1) {
                return ch;
            }
        }
        return ' ';
    }
}
```

```JavaScript []
/**
 * @param {string} s
 * @return {character}
 */

//由于 JS 无法做字符间减法，所以直接采用现有的 map 结构进行计算
var firstUniqChar = function(s) {
    let map = new Map();
    for(const ch of s) {
        map.set(ch, !map.has(ch));
    }
    for(const ch of s) {
        if(map.get(ch)) {
            return ch;
        }
    }
    return ' ';
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/c7296391cd7c8a46aa22665088e1aa559a2905755ff515e59cb43b4791fb108c-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/725c538b6dbba2a6a8065c6cde7bc1a09670cd357f216b10de7a879809175e80-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/344fe9d67cf2e0e60ad9002d47ad05f7f68fdecb65c16ca3c4c8f06fedec4ba7-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/c832c34227f69ba23207ed7c7cac89c950410fc12f72a2bdb49aafd4bc239dcd-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/d67d50124e99e704384244d10f412252b2ea347e8d012be92d2f9d23e72095b6-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/001d552c37badaf3170708eb4065960253054e0dd3a0d43e860d34b95de71849-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/652d645a695d1ac57f035c3d1034b874a5c835ab71bce7d00633d12637f17ddc-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/981a484d1acc772ba12fcc3f5a9f9c89102712b2d7bc73daa2e67af78071e885-frame_00008.png),![frame_00009.png](https://pic.leetcode-cn.com/c376d709ec7e01b91a34833ea131c4919fb42214dd398d22b4ae83a663fd70d5-frame_00009.png),![frame_00010.png](https://pic.leetcode-cn.com/0e3f48aee659cb14f002b1a9edf10acd8146c1a69079e5e534044d104b55ba46-frame_00010.png),![frame_00011.png](https://pic.leetcode-cn.com/b06bdfa583bf4820d2a03a751aa1954dddb0427186533855a772cb3c9fdb8801-frame_00011.png),![frame_00012.png](https://pic.leetcode-cn.com/4c7ea9fa13904683516d189cf56f5a167ed0644bd3bf2a5c5c551ece497bd18f-frame_00012.png)>



# 链表
<p><a href="/circle/discuss/X6Oj0x/"><img alt="画解剑指 Offer" src="https://pic.leetcode-cn.com/b04af6fd9c21f097f14418471f5fea7c35ae9ecfcdc4805b5a8af2807a0ebaa8-leetbook_discussion.png" style="height: 80px;" /></a></p>

## 剑指 Offer 18. 删除链表的节点

>https://leetcode.cn/problems/shan-chu-lian-biao-de-jie-dian-lcof/
<p>给定单向链表的头指针和一个要删除的节点的值，定义一个函数删除该节点。</p>

<p>返回删除后的链表的头节点。</p>

<p><strong>注意：</strong>此题对比原题有改动</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入:</strong> head = [4,5,1,9], val = 5
<strong>输出:</strong> [4,1,9]
<strong>解释: </strong>给定你链表中值为&nbsp;5&nbsp;的第二个节点，那么在调用了你的函数之后，该链表应变为 4 -&gt; 1 -&gt; 9.
</pre>

<p><strong>示例 2:</strong></p>

<pre><strong>输入:</strong> head = [4,5,1,9], val = 1
<strong>输出:</strong> [4,5,9]
<strong>解释: </strong>给定你链表中值为&nbsp;1&nbsp;的第三个节点，那么在调用了你的函数之后，该链表应变为 4 -&gt; 5 -&gt; 9.
</pre>

<p>&nbsp;</p>

<p><strong>说明：</strong></p>

<ul>
	<li>题目保证链表中节点的值互不相同</li>
	<li>若使用 C 或 C++ 语言，你不需要 <code>free</code> 或 <code>delete</code> 被删除的节点</li>
</ul>


### 剑指 Offer 18. 删除链表的节点 - 解决方案
## 题目描述

给定单向链表的头指针和一个要删除的节点的值，定义一个函数删除该节点。

返回删除后的链表的头节点。

注意：此题对比原题有改动

示例 1:

```
输入: head = [4,5,1,9], val = 5
输出: [4,1,9]
解释: 给定你链表中值为 5 的第二个节点，那么在调用了你的函数之后，该链表应变为 4 -> 1 -> 9.
```

示例 2:

```
输入: head = [4,5,1,9], val = 1
输出: [4,5,9]
解释: 给定你链表中值为 1 的第三个节点，那么在调用了你的函数之后，该链表应变为 4 -> 5 -> 9.
```

说明：

- 题目保证链表中节点的值互不相同
- 若使用 C 或 C++ 语言，你不需要 `free` 或 `delete` 被删除的节点

## 解题方案

### 思路

- 标签：链表遍历
- 整体思路是使用挨着的前后 2 个指针，当前方指针遇到要删除的值时，则使用后方指针重新构造连接并跳过该值
  - 首先判断头指针是否为 `null`，如果为空则直接返回 `null`
  - 如果头指针 `head.val` 即为要删除的值，则直接返回 `head.next` 即可
  - 初始化前指针 `pre` 和后指针 `post`，两个指针紧挨着，距离为 1
  - 前后指针一直遍历链表，直到遍历到链表结尾或等于要删除的值时则跳出循环
  - 如果找到要删除的值，则令 `post.next = pre.next`，相当于将链表中的值删除
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 代码

```Java []
/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
class Solution {
    public ListNode deleteNode(ListNode head, int val) {
        if(head == null) {
            return null;
        }
        if(head.val == val) {
            return head.next;
        }
        ListNode post = head;
        ListNode pre = head.next;
        while(pre != null && pre.val != val) {
            post = pre;
            pre = pre.next;
        }
        if(pre != null) {
            post.next = pre.next;
        }
        return head;
    }
}
```

```JavaScript []
/**
 * Definition for singly-linked list.
 * function ListNode(val) {
 *     this.val = val;
 *     this.next = null;
 * }
 */
/**
 * @param {ListNode} head
 * @param {number} val
 * @return {ListNode}
 */
var deleteNode = function(head, val) {
    if(head === null) {
        return null;
    }
    if(head.val === val) {
        return head.next;
    }
    let post = head;
    let pre = head.next;
    while(pre !== null && pre.val !== val) {
        post = pre;
        pre = pre.next;
    }
    if(pre !== null) {
        post.next = pre.next;
    }
    return head;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/688fcd2e2164db5376c8745b0ecc6b9fb295f9140a4ae374209006c0479412b2-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/4199d55c97e5c43b368a6e709f50979f5ff93dde34acb4fb18bd31b41e7c11c8-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/099fd2b09d2f8b178f19d5f7a4dd4f81de3f1bfb8ea0491728f21e00e057997c-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/cfb517070b4b8d862d7d4f5996727e8da693dbeaf7547a878b6a05b36cb91bb5-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/ae1c886e8ad135e73bd11c54c1acfef1f2c080a230dfa7603e1b9d3c0937440c-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/91646df45925a98991903a0b3ff644359d700f9d33525a0acc0f8687564904da-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/53cb26baef306ded08d14a2fb2222aa1611c94e0edb8cf4e9ad9c87cc14ed99a-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/10048e6697b6fa3640e9298bf7cf27f0bb02d95ec8235f6bda98dff60ff44b1f-frame_00008.png)>


## 剑指 Offer 22. 链表中倒数第 k 个节点

>https://leetcode.cn/problems/lian-biao-zhong-dao-shu-di-kge-jie-dian-lcof/
<p>输入一个链表，输出该链表中倒数第k个节点。为了符合大多数人的习惯，本题从1开始计数，即链表的尾节点是倒数第1个节点。</p>

<p>例如，一个链表有 <code>6</code> 个节点，从头节点开始，它们的值依次是 <code>1、2、3、4、5、6</code>。这个链表的倒数第 <code>3</code> 个节点是值为 <code>4</code> 的节点。</p>

<p> </p>

<p><strong>示例：</strong></p>

<pre>
给定一个链表: <strong>1->2->3->4->5</strong>, 和 <em>k </em><strong>= 2</strong>.

返回链表 4<strong>->5</strong>.</pre>


### 剑指 Offer 22. 链表中倒数第 k 个节点 - 解决方案
## 题目描述

输入一个链表，输出该链表中倒数第 k 个节点。为了符合大多数人的习惯，本题从 1 开始计数，即链表的尾节点是倒数第 1 个节点。例如，一个链表有 6 个节点，从头节点开始，它们的值依次是 1、2、3、4、5、6。这个链表的倒数第 3 个节点是值为 4 的节点。

示例：

```bash
给定一个链表: 1->2->3->4->5, 和 k = 2.

返回链表 4->5.
```

## 解题方案

### 思路

- 标签：链表遍历
- 整体思路是使用双指针，间隔 `k` 个位置，同时向后移动，当前方指针移动到尾部时，后方指针的位置就是倒数第 `k` 个数字
  - 首先构建前指针 `pre`，后指针 `post`
  - 前指针 `pre` 向前移动 `k` 个位置
  - 前指针 `pre` 和后指针 `post` 同时向前移动，直到前指针为 `null` 时停止
  - 后指针 `post` 即为倒数第 `k` 个数字
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 代码

```Java []
/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
class Solution {
    public ListNode getKthFromEnd(ListNode head, int k) {
        ListNode pre = head;
        ListNode post = head;
        for(int i = 0; i < k; i++) {
            pre = pre.next;
        }
        while(pre != null) {
            pre = pre.next;
            post = post.next;
        }
        return post;
    }
}
```

```JavaScript []
/**
 * Definition for singly-linked list.
 * function ListNode(val) {
 *     this.val = val;
 *     this.next = null;
 * }
 */
/**
 * @param {ListNode} head
 * @param {number} k
 * @return {ListNode}
 */
var getKthFromEnd = function(head, k) {
    let pre = head;
    let post = head;
    for(let i = 0; i < k; i++) {
        pre = pre.next;
    }
    while(pre != null) {
        pre = pre.next;
        post = post.next;
    }
    return post;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/f0cc5cd926daff0bf3dbe2e732c725f9f1abb53023d7007ce8b1e0dc68ddb613-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/7a704cf2a8fc96115aa7669ae0c6f239bb2d8c3f9291642f31bfd449875b7075-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/437633972384eefad88297a700e9315aebc6e66634f02b66fb49b171b263ac92-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/97eb509edfcd32beb8a3be41e4edc5e7b3db83e3e1ba1b862bb77f1eb66a3418-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/ebd56d81e418c010b0fb738fce74a5753d4a793527db873b14eda43aaec0ef85-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/bea296c3f367585caf4da66cbc8b8844fc4a03e73ae02ddfefe7c321398a32db-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/373963dfde7542ca847a706d2ae2ac47e48a808a6b5cbd98ac848395e914d679-frame_00007.png)>


## 剑指 Offer 24. 反转链表

>https://leetcode.cn/problems/fan-zhuan-lian-biao-lcof/
<p>定义一个函数，输入一个链表的头节点，反转该链表并输出反转后链表的头节点。</p>

<p>&nbsp;</p>

<p><strong>示例:</strong></p>

<pre><strong>输入:</strong> 1-&gt;2-&gt;3-&gt;4-&gt;5-&gt;NULL
<strong>输出:</strong> 5-&gt;4-&gt;3-&gt;2-&gt;1-&gt;NULL</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>0 &lt;= 节点个数 &lt;= 5000</code></p>

<p>&nbsp;</p>

<p><strong>注意</strong>：本题与主站 206 题相同：<a href="https://leetcode-cn.com/problems/reverse-linked-list/">https://leetcode-cn.com/problems/reverse-linked-list/</a></p>


### 剑指 Offer 24. 反转链表 - 解决方案
## 题目描述

定义一个函数，输入一个链表的头节点，反转该链表并输出反转后链表的头节点。

示例:

```
输入: 1->2->3->4->5->NULL
输出: 5->4->3->2->1->NULL
```

限制：

`0 <= 节点个数 <= 5000`

## 解题方案

### 思路

- 标签：链表遍历
- 整体思路：通过前指针、当前指针和临时指针进行位置交换，从头部开始 2 个节点为一组进行倒序交换，直到遍历到链表结尾将链表反转完成
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程

1. 初始化当前指针 `cur = null`，前指针 `pre = head`
2. 当 `pre != null` 时，说明还未到达链表结尾，则不断进行遍历交换
3. `tmp = pre.next`，保存下一次要进行倒转的指针位置
4. `pre.next = cur`，实现链表中 2 个节点的反转
5. `cur = pre`，`cur` 指针后移一个位置
6. `pre = tmp`，`pre` 指针后移一个位置
7. 进行下一轮的倒转，直到结束时最终的链表头结点为 `cur`，返回 `cur` 即可

### 代码

```Java []
/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
class Solution {
    public ListNode reverseList(ListNode head) {
        ListNode cur = null;
        ListNode pre = head;
        while (pre != null) {
            ListNode tmp = pre.next;
            pre.next = cur;
            cur = pre;
            pre = tmp;
        }
        return cur;
    }
}
```

```JavaScript []
/**
 * Definition for singly-linked list.
 * function ListNode(val) {
 *     this.val = val;
 *     this.next = null;
 * }
 */
/**
 * @param {ListNode} head
 * @return {ListNode}
 */
var reverseList = function(head) {
    let cur = null;
    let pre = head;
    while (pre != null) {
        let tmp = pre.next;
        pre.next = cur;
        cur = pre;
        pre = tmp;
    }
    return cur;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/8c14dff788de35d61c41f31ce7bad0b52878f9ad09b32a3858c7b50eb08922f0-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/62e61dbc14fcd23dd77b8762df73cda838b8f1097c8cb2de986145c19cd37c10-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/fa9a988114e5ee23b33521891f90c5bba3f72e87cadde818c97e16f354f42a98-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/ec7fc64a7534f4efcaede2ececdcc756055499303016f8fbc06a0022c39b8165-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/e4d2029659c9ac9d8b03498a63aa454552d06bd3e7c2b384a898069b02deacbe-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/250d23677bf9e529720e0ecd4f450c4ff718f92564384ace89c54a58390929fc-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/4c414b587b171efba6cc4ca97dd77e73f7b0853472e46cba661e6f18ee83bc1e-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/cf683352d6c4d4d7c4156fefc7f49a107f0a6c99684900089eb6b3ddb2da102a-frame_00008.png),![frame_00009.png](https://pic.leetcode-cn.com/a29907d227e956c8bfc53ddb67d7d2161a2ec1f0c7afc69bbeabd4d3cbc30151-frame_00009.png),![frame_00010.png](https://pic.leetcode-cn.com/40d5c5e59b6d4ad199e2243ab43462201788f823b9d6c1fa13c26b5c88eeb02e-frame_00010.png),![frame_00011.png](https://pic.leetcode-cn.com/1ddf0a4dab57adaa63ace7a2c66f55cd417c19e0d0ebfff80b2a72a38bd26b14-frame_00011.png),![frame_00012.png](https://pic.leetcode-cn.com/2aa391805027626faee5f746782ff7ef685ecc454c4fbcd6a95663ba66456ea4-frame_00012.png),![frame_00013.png](https://pic.leetcode-cn.com/e688a27eb6af7d7e95f5b63c419e66b67220c7ced3b7fa5e8e6e73f467771168-frame_00013.png),![frame_00014.png](https://pic.leetcode-cn.com/f9378900ffc50ff1cfa17472fd95822b7cf173017fa8abe83dcf7b2eb5dc9287-frame_00014.png)>


## 剑指 Offer 25. 合并两个排序的链表

>https://leetcode.cn/problems/he-bing-liang-ge-pai-xu-de-lian-biao-lcof/
<p>输入两个递增排序的链表，合并这两个链表并使新链表中的节点仍然是递增排序的。</p>

<p><strong>示例1：</strong></p>

<pre><strong>输入：</strong>1-&gt;2-&gt;4, 1-&gt;3-&gt;4
<strong>输出：</strong>1-&gt;1-&gt;2-&gt;3-&gt;4-&gt;4</pre>

<p><strong>限制：</strong></p>

<p><code>0 &lt;= 链表长度 &lt;= 1000</code></p>

<p>注意：本题与主站 21 题相同：<a href="https://leetcode-cn.com/problems/merge-two-sorted-lists/">https://leetcode-cn.com/problems/merge-two-sorted-lists/</a></p>


### 剑指 Offer 25. 合并两个排序的链表 - 解决方案
## 题目描述

输入两个递增排序的链表，合并这两个链表并使新链表中的节点仍然是递增排序的。

示例 1：

```
输入：1->2->4, 1->3->4
输出：1->1->2->3->4->4
```

限制：

`0 <= 链表长度 <= 1000`

## 解题方案

### 思路

- 标签：链表、递归
- 这道题可以使用递归实现，新链表也不需要构造新节点
- 终止条件：两条链表分别名为 `l1` 和 `l2`，当 `l1` 为空或 `l2` 为空时结束
- 返回值：每一层调用都返回排序好的链表头
- 本级递归内容：如果 `l1` 的 `val` 值更小，则将 `l1.next` 与排序好的链表头相接，`l2` 同理
- $O(m+n)$，$m$ 为 `l1` 的长度，$n$ 为 `l2` 的长度

### 代码

```Java []
/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
class Solution {
    public ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        if(l1 == null) {
            return l2;
        }
        if(l2 == null) {
            return l1;
        }

        if(l1.val < l2.val) {
            l1.next = mergeTwoLists(l1.next, l2);
            return l1;
        } else {
            l2.next = mergeTwoLists(l1, l2.next);
            return l2;
        }
    }
}
```

```JavaScript []
/**
 * Definition for singly-linked list.
 * function ListNode(val) {
 *     this.val = val;
 *     this.next = null;
 * }
 */
/**
 * @param {ListNode} l1
 * @param {ListNode} l2
 * @return {ListNode}
 */
var mergeTwoLists = function (l1, l2) {
  if (l1 === null) {
    return l2;
  }
  if (l2 === null) {
    return l1;
  }
  if (l1.val < l2.val) {
    l1.next = mergeTwoLists(l1.next, l2);
    return l1;
  } else {
    l2.next = mergeTwoLists(l1, l2.next);
    return l2;
  }
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/0b6219a22fe322ad74ae1957f3a21467d567ce692100b8c0ad6dbe91dff6ff40-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/d0060443a48fabd040cfd451669da6cc38388e6ff666f60adb5b1bfa118bae7e-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/6fc2d3eb623fa3462bae78028f1229465a6ee8e862fdac03927548abe091451b-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/9d11f7a3c834679c49f6***12fcdeeba54a8b43205279f40d396beb3498dd22-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/adde60dcc3fc71afda83d6220d07e770721d91fbe17c3049d226e0bd116088a3-frame_00005.png)>


## 剑指 Offer 52. 两个链表的第一个公共节点

>https://leetcode.cn/problems/liang-ge-lian-biao-de-di-yi-ge-gong-gong-jie-dian-lcof/
<p>输入两个链表，找出它们的第一个公共节点。</p>

<p>如下面的两个链表<strong>：</strong></p>

<p><a href="https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/12/14/160_statement.png" target="_blank"><img alt="" src="https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/12/14/160_statement.png" style="height: 130px; width: 400px;"></a></p>

<p>在节点 c1 开始相交。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<p><a href="https://assets.leetcode.com/uploads/2018/12/13/160_example_1.png" target="_blank"><img alt="" src="https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/12/14/160_example_1.png" style="height: 130px; width: 400px;"></a></p>

<pre><strong>输入：</strong>intersectVal = 8, listA = [4,1,8,4,5], listB = [5,0,1,8,4,5], skipA = 2, skipB = 3
<strong>输出：</strong>Reference of the node with value = 8
<strong>输入解释：</strong>相交节点的值为 8 （注意，如果两个列表相交则不能为 0）。从各自的表头开始算起，链表 A 为 [4,1,8,4,5]，链表 B 为 [5,0,1,8,4,5]。在 A 中，相交节点前有 2 个节点；在 B 中，相交节点前有 3 个节点。
</pre>

<p>&nbsp;</p>

<p><strong>示例&nbsp;2：</strong></p>

<p><a href="https://assets.leetcode.com/uploads/2018/12/13/160_example_2.png" target="_blank"><img alt="" src="https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/12/14/160_example_2.png" style="height: 136px; width: 350px;"></a></p>

<pre><strong>输入：</strong>intersectVal&nbsp;= 2, listA = [0,9,1,2,4], listB = [3,2,4], skipA = 3, skipB = 1
<strong>输出：</strong>Reference of the node with value = 2
<strong>输入解释：</strong>相交节点的值为 2 （注意，如果两个列表相交则不能为 0）。从各自的表头开始算起，链表 A 为 [0,9,1,2,4]，链表 B 为 [3,2,4]。在 A 中，相交节点前有 3 个节点；在 B 中，相交节点前有 1 个节点。
</pre>

<p>&nbsp;</p>

<p><strong>示例&nbsp;3：</strong></p>

<p><a href="https://assets.leetcode.com/uploads/2018/12/13/160_example_3.png" target="_blank"><img alt="" src="https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/12/14/160_example_3.png" style="height: 126px; width: 200px;"></a></p>

<pre><strong>输入：</strong>intersectVal = 0, listA = [2,6,4], listB = [1,5], skipA = 3, skipB = 2
<strong>输出：</strong>null
<strong>输入解释：</strong>从各自的表头开始算起，链表 A 为 [2,6,4]，链表 B 为 [1,5]。由于这两个链表不相交，所以 intersectVal 必须为 0，而 skipA 和 skipB 可以是任意值。
<strong>解释：</strong>这两个链表不相交，因此返回 null。
</pre>

<p>&nbsp;</p>

<p><strong>注意：</strong></p>

<ul>
	<li>如果两个链表没有交点，返回 <code>null</code>.</li>
	<li>在返回结果后，两个链表仍须保持原有的结构。</li>
	<li>可假定整个链表结构中没有循环。</li>
	<li>程序尽量满足 O(<em>n</em>) 时间复杂度，且仅用 O(<em>1</em>) 内存。</li>
	<li>本题与主站 160 题相同：<a href="https://leetcode-cn.com/problems/intersection-of-two-linked-lists/">https://leetcode-cn.com/problems/intersection-of-two-linked-lists/</a></li>
</ul>


### 剑指 Offer 52. 两个链表的第一个公共节点 - 解决方案
## 题目描述

输入两个链表，找出它们的第一个公共节点。

如下面的两个链表：

![](https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/12/14/160_statement.png)

在节点 c1 开始相交。

示例 1：

![](https://assets.leetcode.com/uploads/2018/12/13/160_example_1.png)


```
输入：intersectVal = 8, listA = [4,1,8,4,5], listB = [5,0,1,8,4,5], skipA = 2, skipB = 3
输出：Reference of the node with value = 8
输入解释：相交节点的值为 8 （注意，如果两个列表相交则不能为 0）。从各自的表头开始算起，链表 A 为 [4,1,8,4,5]，链表 B 为 [5,0,1,8,4,5]。在 A 中，相交节点前有 2 个节点；在 B 中，相交节点前有 3 个节点。
```

示例 2：

![](https://assets.leetcode.com/uploads/2018/12/13/160_example_2.png)


```
输入：intersectVal = 2, listA = [0,9,1,2,4], listB = [3,2,4], skipA = 3, skipB = 1
输出：Reference of the node with value = 2
输入解释：相交节点的值为 2 （注意，如果两个列表相交则不能为 0）。从各自的表头开始算起，链表 A 为 [0,9,1,2,4]，链表 B 为 [3,2,4]。在 A 中，相交节点前有 3 个节点；在 B 中，相交节点前有 1 个节点。
```

示例  3：

![](https://assets.leetcode.com/uploads/2018/12/13/160_example_3.png)


```
输入：intersectVal = 0, listA = [2,6,4], listB = [1,5], skipA = 3, skipB = 2
输出：null
输入解释：从各自的表头开始算起，链表 A 为 [2,6,4]，链表 B 为 [1,5]。由于这两个链表不相交，所以 intersectVal 必须为 0，而 skipA 和 skipB 可以是任意值。
解释：这两个链表不相交，因此返回 null。
```

**注意**：

- 如果两个链表没有交点，返回 `null`。
- 在返回结果后，两个链表仍须保持原有的结构。
- 可假定整个链表结构中没有循环。
- 程序尽量满足 $O(n)$ 时间复杂度，且仅用 $O(1)$ 内存。
- 本题与 [主站 160 题](https://leetcode-cn.com/problems/intersection-of-two-linked-lists/) 相同。

## 解题方案

### 思路

- 标签：双指针链表遍历
- 分别构造 2 个指针去遍历 2 个链表，无论哪个指针到尾部时，让其重新回到对方的头部，最终会在第一个公共节点相遇，如果没有，则会在 `null` 处相遇
- 时间复杂度：设 A 链表非公共长度为 `m`，B 链表非公共长度为 `n`，公共部分为 `b`，则复杂度为 $O(m+n+b)$，空间复杂度：$O(1)$

### 算法流程

1. 使用 `headA` 和 `headB` 初始化 2 个指针 `curA` 和 `curB`，用来遍历使用
2. 进行循环遍历，直到 `curA` 和 `curB` 相同时结束
3. 遍历过程中如果 `curA` 到尾部则将其重新放回头部 `headB`，如果 `cur`B 到尾部则将其重新放回头部 `headA`
4. 循环结束时在第一个公共节点相遇，返回该节点 `curA`

### 代码

```Java []
/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;
 *     }
 * }
 */
public class Solution {
    public ListNode getIntersectionNode(ListNode headA, ListNode headB) {
        ListNode curA = headA;
        ListNode curB = headB;

        while (curA != curB) {
            curA = curA != null ? curA.next : headB;
            curB = curB != null ? curB.next : headA;
        }
        return curA;
    }
}
```

```JavaScript []
/**
 * Definition for singly-linked list.
 * function ListNode(val) {
 *     this.val = val;
 *     this.next = null;
 * }
 */

/**
 * @param {ListNode} headA
 * @param {ListNode} headB
 * @return {ListNode}
 */
var getIntersectionNode = function(headA, headB) {
    let curA = headA;
    let curB = headB;

    while (curA != curB) {
        curA = curA != null ? curA.next : headB;
        curB = curB != null ? curB.next : headA;
    }
    return curA;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/69a4b884495e0bc4b0ab8f2aab32374232e7e57f286a66aacb8dcf99284e23dd-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/841e5edd7909be2a9c84ad654aff6f691ab7792d43923a13b5458311a16e33db-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/3732f230f21bc151c2cd3d29bc241751efcd5cea4275d361af22566c9dd260a6-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/2933b89126bad37a2d391e32f9c91553267c1471029a47ab06f8b5378bc2b893-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/eabc8cd9575e4a4a100236260ce34e4e220e2c8c2664c603b5fc83d693466dc6-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/248bc49e98f1b3e86f6442c674d732046ed378ce05f05d686ec0257d7f01c9bb-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/7074482a5a4a2b679702cef3ee394f6678b347d0774518f9e47f9ff62a91e546-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/e5a0f5bb51a2f41cd5f5c97b5de14675c4f141fa1a0fd1899d875bfa1047de14-frame_00008.png)>



# DFS
<p><a href="/circle/discuss/X6Oj0x/"><img alt="画解剑指 Offer" src="https://pic.leetcode-cn.com/b04af6fd9c21f097f14418471f5fea7c35ae9ecfcdc4805b5a8af2807a0ebaa8-leetbook_discussion.png" style="height: 80px;" /></a></p>

## 剑指 Offer 12. 矩阵中的路径

>https://leetcode.cn/problems/ju-zhen-zhong-de-lu-jing-lcof/
<p>给定一个&nbsp;<code>m x n</code> 二维字符网格&nbsp;<code>board</code> 和一个字符串单词&nbsp;<code>word</code> 。如果&nbsp;<code>word</code> 存在于网格中，返回 <code>true</code> ；否则，返回 <code>false</code> 。</p>

<p>单词必须按照字母顺序，通过相邻的单元格内的字母构成，其中“相邻”单元格是那些水平相邻或垂直相邻的单元格。同一个单元格内的字母不允许被重复使用。</p>

<p>&nbsp;</p>

<p>例如，在下面的 3×4 的矩阵中包含单词 "ABCCED"（单词中的字母已标出）。</p>

<p><img alt="" src="https://assets.leetcode.com/uploads/2020/11/04/word2.jpg" style="width: 322px; height: 242px;" /></p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre>
<strong>输入：</strong>board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCCED"
<strong>输出：</strong>true
</pre>

<p><strong>示例 2：</strong></p>

<pre>
<strong>输入：</strong>board = [["a","b"],["c","d"]], word = "abcd"
<strong>输出：</strong>false
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>m == board.length</code></li>
	<li><code>n = board[i].length</code></li>
	<li><code>1 &lt;= m, n &lt;= 6</code></li>
	<li><code>1 &lt;= word.length &lt;= 15</code></li>
	<li><code>board </code>和<code> word </code>仅由大小写英文字母组成</li>
</ul>

<p><strong>注意：</strong>本题与主站 79 题相同：<a href="https://leetcode-cn.com/problems/word-search/">https://leetcode-cn.com/problems/word-search/</a></p>


### 剑指 Offer 12. 矩阵中的路径 - 解决方案
## 题目描述

请设计一个函数，用来判断在一个矩阵中是否存在一条包含某字符串所有字符的路径。路径可以从矩阵中的任意一格开始，每一步可以在矩阵中向左、右、上、下移动一格。如果一条路径经过了矩阵的某一格，那么该路径不能再次进入该格子。例如，在下面的3×4的矩阵中包含一条字符串 “bfce” 的路径（路径中的字母用加粗标出）。

[["a","**b**","c","e"],
["s","**f**","**c**","s"],
["a","d","**e**","e"]]

但矩阵中不包含字符串 “abfb” 的路径，因为字符串的第一个字符 b 占据了矩阵中的第一行第二个格子之后，路径不能再次进入这个格子。

**示例 1:**

```text
输入：board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCCED"
输出：true
```
**示例 2:**

```text
输入：board = [["a","b"],["c","d"]], word = "abcd"
输出：false
```

## 解题方案

### 思路

- 标签：深度优先搜索
- 整体思路：
  - 题目可以模拟为 DFS 的过程，即从一个方向搜索到底，再回溯上一个节点，沿另一个方向继续搜索，递归进行。在搜索过程中，若遇到该路径不可能与目标字符串匹配的情况，执行剪枝，立即返回。
- 复杂度：
  - 时间复杂度：$O(3^k IJ)$。 一次搜索完全部矩阵的时间复杂度为 $O(IJ)$ ，共需要 $3^k$ 次搜索
  - 空间复杂度：搜索过程中的递归深度不超过 $K$ ，因此系统因函数调用累计使用的栈空间占用 $O(K)$

### 算法流程

1. 递推参数： 当前元素在矩阵 `board` 中的行列索引 `i` 和 `j` ，当前目标字符在 `word` 中的索引 `k` 。
2. 终止条件：
    - 行或列索引越界 或 当前矩阵元素与目标字符不同 或 当前矩阵元素已访问过，返回 `false`
    - 目标字符串全部匹配成功，返回 `true`
3. - 将当前元素值暂存在 `tmp` 中，修改为字符 `‘/’`，以此标记为该元素已访问。通过 `tmp` 变量存值可以免去新建一个访问过的字符串数组，节省空间。
   - 向其他方向继续搜索， 并记录结果， 遇 `false` 即返回
   - 将 `tmp` 值还原到当前元素
4. 返回结果

### 代码

```Java []
class Solution {
    public boolean exist(char[][] board, String word) {
        char[] words = word.toCharArray();
        for(int i = 0; i < board.length; i++) {
            for(int j = 0; j < board[0].length; j++) {
                if(dfs(board, words, i, j, 0)) return true;
            }
        }
        return false;
    }
    boolean dfs(char[][] board, char[] word, int i, int j, int k) {
        if(i >= board.length || i < 0 || j >= board[0].length || j < 0 || board[i][j] != word[k]) return false;
        if(k == word.length - 1) return true;
        char tmp = board[i][j];
        board[i][j] = '/';
        boolean result = dfs(board, word, i + 1, j, k + 1) || dfs(board, word, i - 1, j, k + 1) || 
                      dfs(board, word, i, j + 1, k + 1) || dfs(board, word, i , j - 1, k + 1);
        board[i][j] = tmp;
        return result;
    }
}
```

### 画解

<![offer12-1.png](https://pic.leetcode-cn.com/1607903252-dyeChR-offer12-1.png),![offer12-2.png](https://pic.leetcode-cn.com/1607903252-lAhQuY-offer12-2.png),![offer12-3.png](https://pic.leetcode-cn.com/1607903252-SiVAYL-offer12-3.png),![offer12-4.png](https://pic.leetcode-cn.com/1607903252-cpOcfk-offer12-4.png),![offer12-5.png](https://pic.leetcode-cn.com/1607903252-Efndnw-offer12-5.png),![offer12-6.png](https://pic.leetcode-cn.com/1607903252-hYZddO-offer12-6.png),![offer12-7.png](https://pic.leetcode-cn.com/1607903252-mTgNWY-offer12-7.png),![offer12-8.png](https://pic.leetcode-cn.com/1607903252-UQiHfU-offer12-8.png),![offer12-9.png](https://pic.leetcode-cn.com/1607903252-ByRbcu-offer12-9.png),![offer12-10.png](https://pic.leetcode-cn.com/1607903252-GIKHdm-offer12-10.png),![offer12-11.png](https://pic.leetcode-cn.com/1607903252-CZHbUc-offer12-11.png),![offer12-12.png](https://pic.leetcode-cn.com/1607903252-QnSOZr-offer12-12.png),![offer12-13.png](https://pic.leetcode-cn.com/1607903252-FDsJsN-offer12-13.png),![offer12-14.png](https://pic.leetcode-cn.com/1607903252-HnWWSC-offer12-14.png),![offer12-15.png](https://pic.leetcode-cn.com/1607903252-kbymzI-offer12-15.png),![offer12-16.png](https://pic.leetcode-cn.com/1607903252-xyVTEp-offer12-16.png),![offer12-17.png](https://pic.leetcode-cn.com/1607903252-qSZYzY-offer12-17.png),![offer12-18.png](https://pic.leetcode-cn.com/1607903252-UuXBSb-offer12-18.png)>

### 花絮

![offer12.mp4](abd79663-a308-4875-a8da-952cc6f9497c)


## 剑指 Offer 13. 机器人的运动范围

>https://leetcode.cn/problems/ji-qi-ren-de-yun-dong-fan-wei-lcof/
<p>地上有一个m行n列的方格，从坐标 <code>[0,0]</code> 到坐标 <code>[m-1,n-1]</code> 。一个机器人从坐标 <code>[0, 0] </code>的格子开始移动，它每次可以向左、右、上、下移动一格（不能移动到方格外），也不能进入行坐标和列坐标的数位之和大于k的格子。例如，当k为18时，机器人能够进入方格 [35, 37] ，因为3+5+3+7=18。但它不能进入方格 [35, 38]，因为3+5+3+8=19。请问该机器人能够到达多少个格子？</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>m = 2, n = 3, k = 1
<strong>输出：</strong>3
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>m = 3, n = 1, k = 0
<strong>输出：</strong>1
</pre>

<p><strong>提示：</strong></p>

<ul>
	<li><code>1 &lt;= n,m &lt;= 100</code></li>
	<li><code>0 &lt;= k&nbsp;&lt;= 20</code></li>
</ul>


### 剑指 Offer 13. 机器人的运动范围 - 解题思路
## 题目描述

地上有一个 m 行 n 列的方格，从坐标 [0,0] 到坐标 [m-1,n-1] 。一个机器人从坐标 [0, 0] 的格子开始移动，它每次可以向左、右、上、下移动一格（不能移动到方格外），也不能进入行坐标和列坐标的数位之和大于 k 的格子。例如，当 k 为 18 时，机器人能够进入方格 [35, 37] ，因为 3+5+3+7=18。但它不能进入方格 [35, 38]，因为 3+5+3+8=19。请问该机器人能够到达多少个格子？

**示例 1:**

```text
输入：m = 2, n = 3, k = 1
输出：3
```

**示例 2:**

```text
输入：m = 3, n = 1, k = 0
输出：1
```

提示：

1 <= n,m <= 100

0 <= k <= 20

## 解题方案

### 思路

- 标签：dfs
- 整体思路：
  从原点出发，沿四个方向（本题中两个方向就行了，因为可行区域在原点的右下方）不断拓展，将可到达并且满足坐标数位和不大于 k 的点加入到队列中，直到所有可到达的点都被访问到。

- 复杂度：
  - 时间复杂度：$O(mn)$。
  - 空间复杂度：$O(mn)$。

### 算法流程

1. 递归参数：当前元素在矩阵中的行列索引 i 和 j，是否被访问的标记，矩阵的行列长度
2. 终止条件：
   - 行列索引越界
   - 数位和大于 k
   - 已被访问过
3. 递推:
   - 标记当前元素已被访问
   - 计算当前元素的 下、右 两个方向元素的数位和，并开启下层递归

### 代码

```Java []
class Solution {
    public int movingCount(int m, int n, int k) {
        boolean[][] visited = new boolean[m][n];
        return dfs(0, 0, m, n, k, visited);
    }

    private int dfs(int i, int j, int m, int n, int k, boolean visited[][]) {
        if (i < 0 || i >= m || j < 0 || j >= n || (i/10 + i%10 + j/10 + j%10) > k || visited[i][j]) {
            return 0;
        }
        visited[i][j] = true;
        return dfs(i + 1, j, m, n, k, visited) +
                dfs(i, j + 1, m, n, k, visited) + 1;
    }
}
```

### 画解

<![offer13-1.png](https://pic.leetcode-cn.com/1607903006-EXjbln-offer13-1.png),![offer13-2.png](https://pic.leetcode-cn.com/1607903006-glWNkd-offer13-2.png),![offer13-3.png](https://pic.leetcode-cn.com/1607903006-BRbsUx-offer13-3.png),![offer13-4.png](https://pic.leetcode-cn.com/1607903006-WyphRS-offer13-4.png),![offer13-5.png](https://pic.leetcode-cn.com/1607903006-BiJRrf-offer13-5.png),![offer13-6.png](https://pic.leetcode-cn.com/1607903006-DbUmTz-offer13-6.png),![offer13-7.png](https://pic.leetcode-cn.com/1607903006-NOyazz-offer13-7.png),![offer13-8.png](https://pic.leetcode-cn.com/1607903006-pwNZpj-offer13-8.png),![offer13-9.png](https://pic.leetcode-cn.com/1607903006-DUpXak-offer13-9.png),![offer13-10.png](https://pic.leetcode-cn.com/1607903006-tRnYda-offer13-10.png),![offer13-11.png](https://pic.leetcode-cn.com/1607903006-lTaaSS-offer13-11.png),![offer13-12.png](https://pic.leetcode-cn.com/1607903006-xrZYWx-offer13-12.png)>

### 花絮

![offer13.mp4](805bbd18-2a31-434c-885e-2aae5d23cec9)


## 剑指 Offer 27. 二叉树的镜像

>https://leetcode.cn/problems/er-cha-shu-de-jing-xiang-lcof/
<p>请完成一个函数，输入一个二叉树，该函数输出它的镜像。</p>

<p>例如输入：</p>

<p><code>&nbsp; &nbsp; &nbsp;4<br>
&nbsp; &nbsp;/ &nbsp; \<br>
&nbsp; 2 &nbsp; &nbsp; 7<br>
&nbsp;/ \ &nbsp; / \<br>
1 &nbsp; 3 6 &nbsp; 9</code><br>
镜像输出：</p>

<p><code>&nbsp; &nbsp; &nbsp;4<br>
&nbsp; &nbsp;/ &nbsp; \<br>
&nbsp; 7 &nbsp; &nbsp; 2<br>
&nbsp;/ \ &nbsp; / \<br>
9 &nbsp; 6 3&nbsp; &nbsp;1</code></p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>root = [4,2,7,1,3,6,9]
<strong>输出：</strong>[4,7,2,9,6,3,1]
</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>0 &lt;= 节点个数 &lt;= 1000</code></p>

<p>注意：本题与主站 226 题相同：<a href="https://leetcode-cn.com/problems/invert-binary-tree/">https://leetcode-cn.com/problems/invert-binary-tree/</a></p>


### 剑指 Offer 27. 二叉树的镜像 - 解决方案
## 题目描述

请完成一个函数，输入一个二叉树，该函数输出它的镜像。

例如输入：

```
     4
   /   \
  2     7
 / \   / \
1   3 6   9
```

镜像输出：

```
     4
   /   \
  7     2
 / \   / \
9   6 3   1
```

示例 1：

```
输入：root = [4,2,7,1,3,6,9]
输出：[4,7,2,9,6,3,1]
```

限制：

`0 <= 节点个数 <= 1000`

## 解题方案

### 思路

- 标签：dfs
- 递归结束条件：
  - 当节点 `root` 为 `null` 时，说明已经到叶子节点了，递归结束
- 递归过程：
  - 初始化当前节点，并且赋值
  - 递归原来树的右子树 `mirrorTree(root.right)`，并将该结果挂到当前节点的左子树上
  - 递归原来树的左子树 `mirrorTree(root.left)`，并将该结果挂到当前节点的右子树上
- 时间复杂度：$O(n)$，空间复杂度：$O(n)$

### 代码

```Java []
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
class Solution {
    public TreeNode mirrorTree(TreeNode root) {
        TreeNode res = null;
        if(root != null) {
            res = new TreeNode(root.val);
            res.left = mirrorTree(root.right);
            res.right = mirrorTree(root.left);
        }
        return res;
    }
}
```

```JavaScript []
/**
 * Definition for a binary tree node.
 * function TreeNode(val) {
 *     this.val = val;
 *     this.left = this.right = null;
 * }
 */
/**
 * @param {TreeNode} root
 * @return {TreeNode}
 */
var mirrorTree = function (root) {
  let res = null;
  if (root != null) {
    res = new TreeNode(root.val);
    res.left = mirrorTree(root.right);
    res.right = mirrorTree(root.left);
  }
  return res;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/efadf9c1bcb8322feccf18c2fbc0d83a8405decf9a1d7fe5203834f9b3dae491-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/4c4f5de937a01948d3aaa8ff3be767c841a88280fd6f059407a3319ca5f968ba-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/844f5afc371d1ba708683b21650d79fa06425f8a0981bcd823cde497dbe99396-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/9fdbbb866bd2b8a1e0d597ee403bcaa3caed042b9ac8c7b2dc82e2833df6a1a8-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/b196fd143c882fa4a6506d3e41005cc11a1a584aae4db73076744be9b4feca13-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/4e7b6f3839467279fd2911b651f7c45bb51befa59d0d2b54c56735a124f5a55b-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/a742ddac1464a51c979ae703ef5799c8dd9832dc8b071ca6f1ddb88e91c6a7d9-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/57d2664c034b5459a1115d3d1e57090cbb830c25c64446b7e56a109f114ed5a4-frame_00008.png),![frame_00009.png](https://pic.leetcode-cn.com/cb0f687f3343933969a45ab3e752aa44f9959e83c6ffc22b9d4a05b3a14acc58-frame_00009.png),![frame_00010.png](https://pic.leetcode-cn.com/abdf4645b59ee29874af4073e27796db33d5c61d042197bb9fe3860f82f050d4-frame_00010.png),![frame_00011.png](https://pic.leetcode-cn.com/9b05b11deb72f8f30484ef2943638726e53512814a48573e89465a6e23ba45a1-frame_00011.png),![frame_00012.png](https://pic.leetcode-cn.com/e3e7e7e0d92d586125fb58cec1a01be6a826fdb47c74ce843ba97bed1dff2bcd-frame_00012.png),![frame_00013.png](https://pic.leetcode-cn.com/59ddf8b8256f1074e783b3ae1e29444ee8f11e31e220ab451d4f6a9110138c3e-frame_00013.png),![frame_00014.png](https://pic.leetcode-cn.com/3db7face7470c676cc6f4749e45b4ba14d159b771627128a87d9b292c019047d-frame_00014.png),![frame_00015.png](https://pic.leetcode-cn.com/24e8cea0b2aeb40c334aa1d1ee4be28886f3e6f2b825491c1193686ddd05d8fe-frame_00015.png)>


## 剑指 Offer 28. 对称的二叉树

>https://leetcode.cn/problems/dui-cheng-de-er-cha-shu-lcof/
<p>请实现一个函数，用来判断一棵二叉树是不是对称的。如果一棵二叉树和它的镜像一样，那么它是对称的。</p>

<p>例如，二叉树&nbsp;[1,2,2,3,4,4,3] 是对称的。</p>

<p><code>&nbsp; &nbsp; 1<br>
&nbsp; &nbsp;/ \<br>
&nbsp; 2 &nbsp; 2<br>
&nbsp;/ \ / \<br>
3 &nbsp;4 4 &nbsp;3</code><br>
但是下面这个&nbsp;[1,2,2,null,3,null,3] 则不是镜像对称的:</p>

<p><code>&nbsp; &nbsp; 1<br>
&nbsp; &nbsp;/ \<br>
&nbsp; 2 &nbsp; 2<br>
&nbsp; &nbsp;\ &nbsp; \<br>
&nbsp; &nbsp;3 &nbsp; &nbsp;3</code></p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>root = [1,2,2,3,4,4,3]
<strong>输出：</strong>true
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>root = [1,2,2,null,3,null,3]
<strong>输出：</strong>false</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>0 &lt;= 节点个数 &lt;= 1000</code></p>

<p>注意：本题与主站 101 题相同：<a href="https://leetcode-cn.com/problems/symmetric-tree/">https://leetcode-cn.com/problems/symmetric-tree/</a></p>


### 剑指 Offer 28. 对称的二叉树 - 解决方案
## 题目描述

给定一个二叉树，检查它是否是镜像对称的。

例如，二叉树 `[1,2,2,3,4,4,3]` 是对称的。

```bash
    1
   / \
  2   2
 / \ / \
3  4 4  3
```

但是下面这个 `[1,2,2,null,3,null,3]` 则不是镜像对称的:

```bash
    1
   / \
  2   2
   \   \
   3    3
```

示例 1：

```
输入：root = [1,2,2,3,4,4,3]
输出：true
```

示例 2：

```
输入：root = [1,2,2,null,3,null,3]
输出：false
```

限制：

`0 <= 节点个数 <= 1000`

## 解题方案

### 思路

- 标签：dfs
- 递归结束条件：
  - 都为空指针则返回 `true`
  - 只有一个为空则返回 `false`
- 递归过程：
  - 判断两个指针当前节点值是否相等
  - 判断 A 的右子树与 B 的左子树是否对称
  - 判断 A 的左子树与 B 的右子树是否对称
- 短路：在递归判断过程中存在短路现象，也就是做`与`操作时，如果前面的值返回 `false` 则后面的不再进行计算
- 时间复杂度：$O(n)$

### 代码

```Java []
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
class Solution {
    public boolean isSymmetric(TreeNode root) {
        return isMirror(root, root);
    }

    public boolean isMirror(TreeNode t1, TreeNode t2) {
        if (t1 == null && t2 == null) return true;
        if (t1 == null || t2 == null) return false;
        return (t1.val == t2.val)
            && isMirror(t1.right, t2.left)
            && isMirror(t1.left, t2.right);
    }
}
```

```JavaScript []
/**
 * Definition for a binary tree node.
 * function TreeNode(val) {
 *     this.val = val;
 *     this.left = this.right = null;
 * }
 */
/**
 * @param {TreeNode} root
 * @return {boolean}
 */
var isSymmetric = function (root) {
  return isMirror(root, root);
};

const isMirror = (t1, t2) => {
  if (t1 == null && t2 == null) return true;
  if (t1 == null || t2 == null) return false;
  return (
    t1.val == t2.val &&
    isMirror(t1.right, t2.left) &&
    isMirror(t1.left, t2.right)
  );
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/c342226c1f076b8936f0b3d48221512a1cd51a72bbca13b5abf0f7229cc2c9ae-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/fd65bc11c5a62eef5be49cad9c3fdcf8dfc790ef856c31ce4d6eda4e3a6c4726-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/2886f8e4f92daaf30a5e55dd201caf23ee223112c78a08179214fa94f7446ecc-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/536277a55ebcd3b2989b2f0dbc0f190fa59ac2c1920c2b2f6df8c2656b211480-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/036f731448d996eaac770dde57feeb3cf6f4628c19c2280a9cbfb4d7858ea4a3-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/047283957cb5ed638b8912d49e3dd4ebf67c4781c3a19abf299653b184428b2e-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/86db79ec4400b52429ff5e445d6a65be6b95c3e3e4b0e89998b39917c5adc689-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/f5bb02f46471cf1fb375b468f138422f3ca8e6539351c1622cc34ccb48b09c03-frame_00008.png)>


## 剑指 Offer 54. 二叉搜索树的第 k 大节点

>https://leetcode.cn/problems/er-cha-sou-suo-shu-de-di-kda-jie-dian-lcof/
<p>给定一棵二叉搜索树，请找出其中第 <code>k</code> 大的节点的值。</p>

<p>&nbsp;</p>

<p><strong>示例 1:</strong></p>

<pre>
<strong>输入:</strong> root = [3,1,4,null,2], k = 1
   3
  / \
 1   4
  \
&nbsp;  2
<strong>输出:</strong> 4</pre>

<p><strong>示例 2:</strong></p>

<pre>
<strong>输入:</strong> root = [5,3,6,2,4,null,null,1], k = 3
       5
      / \
     3   6
    / \
   2   4
  /
 1
<strong>输出:</strong> 4</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<ul>
	<li>1 ≤ k ≤ 二叉搜索树元素个数</li>
</ul>


### 剑指 Offer 54. 二叉搜索树的第 k 大节点 - 解决方案
## 题目描述

给定一棵二叉搜索树，请找出其中第 k 大的节点。

示例 1:

```
输入: root = [3,1,4,null,2], k = 1
   3
  / \
 1   4
  \
   2
输出: 4
```

示例 2:

```
输入: root = [5,3,6,2,4,null,null,1], k = 3
       5
      / \
     3   6
    / \
   2   4
  /
 1
输出: 4
```

限制：

1 ≤ k ≤ 二叉搜索树元素个数

## 解题方案

### 思路

- 标签：树的深度遍历
- 整体思路：二叉搜索树按照中序遍历（左、中、右）可以获得升序数字，题目要找到第 k 大的节点，所以需要数字降序排列，则将中序遍历按照右、中、左遍历即可，遍历的同时找到第 k 个遍历到的值
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程

1. 初始化全局变量 `curK = k`，用于之后计数
2. 进行树的右、中、左深度遍历
   - 终止条件：`root` 节点为 `null`
   - 右子树进行递归遍历
   - `curK` 自减一，用于计数，当 `curK` 为 0 时表示找到第 `k` 大的节点，则可以结束
   - 左子树进行递归遍历

### 代码

```Java []
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
class Solution {

    private int res, curK;

    public int kthLargest(TreeNode root, int k) {
        curK = k;
        dfs(root);
        return res;
    }

    public void dfs(TreeNode root) {
        if(root == null) {
            return;
        }
        dfs(root.right);
        if(curK == 0) {
            return;
        }
        curK--;
        if(curK == 0) {
            res = root.val;
        }
        dfs(root.left);
    }
}
```

```JavaScript []
/**
 * Definition for a binary tree node.
 * function TreeNode(val) {
 *     this.val = val;
 *     this.left = this.right = null;
 * }
 */
/**
 * @param {TreeNode} root
 * @param {number} k
 * @return {number}
 */

let res, curK;

var kthLargest = function(root, k) {
    curK = k;
    dfs(root);
    return res;
};

var dfs = (root) => {
    if(root == null) {
        return;
    }
    dfs(root.right);
    if(curK == 0) {
        return;
    }
    curK--;
    if(curK == 0) {
        res = root.val;
    }
    dfs(root.left);
}
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/d4f6a3bc93d73722f69ea808af686ef20bd8782d8f12781fe0462581a978cc38-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/c6dd00e3dc184d56741222006f9c7b2f8413fcf35477c49031c32916be3c49ed-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/22396976966ab8ce2dd1dc3d55bbd821c9445b1514502055b0c32d4aa8a3b126-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/48b0d024ad1d82ce735940c6b6083f62fb9cf2179d949ecb06635267dae2ff9d-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/5294a1a5f37329d40792a199df5fde9c2de33b74cd0bd14b8e27117ba8a7a560-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/6cf1247ba1b188cd3b6121cdcb1a6651e2c2dae156b008d5420779becee8db1a-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/9cd7de5544a0057452c674be7a8cff5ed1d3c6c991bc0ec6a34bceaaa27fb0b0-frame_00007.png)>


## 剑指 Offer 55 - I. 二叉树的深度

>https://leetcode.cn/problems/er-cha-shu-de-shen-du-lcof/
<p>输入一棵二叉树的根节点，求该树的深度。从根节点到叶节点依次经过的节点（含根、叶节点）形成树的一条路径，最长路径的长度为树的深度。</p>

<p>例如：</p>

<p>给定二叉树 <code>[3,9,20,null,null,15,7]</code>，</p>

<pre>    3
   / \
  9  20
    /  \
   15   7</pre>

<p>返回它的最大深度&nbsp;3 。</p>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ol>
	<li><code>节点总数 &lt;= 10000</code></li>
</ol>

<p>注意：本题与主站 104&nbsp;题相同：<a href="https://leetcode-cn.com/problems/maximum-depth-of-binary-tree/">https://leetcode-cn.com/problems/maximum-depth-of-binary-tree/</a></p>


### 剑指 Offer 55 - I. 二叉树的深度 - 解决方案
## 题目描述

输入一棵二叉树的根节点，求该树的深度。从根节点到叶节点依次经过的节点（含根、叶节点）形成树的一条路径，最长路径的长度为树的深度。

例如：

给定二叉树 `[3,9,20,null,null,15,7]`，

```
    3
   / \
  9  20
    /  \
   15   7
```

返回它的最大深度  3 。

提示：

`节点总数 <= 10000`

注意：本题与 [主站 104](https://leetcode-cn.com/problems/maximum-depth-of-binary-tree/)  题相同

## 解题方案

### 思路

- 标签：树的深度遍历
- 整体思路：二叉树的最大高度，是由其左子树最大高度和右子树的最大高度中取最大值 + 根节点高度 1 计算出来的
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程

1. 终止条件：`root` 节点为 `null` 时，返回高度为 0
2. 求出左子树最大高度、右子树最大高度
3. 计算左子树和右子树高度的最大值
4. 将上一步的最大值 + 根节点高度 1

### 代码

```Java []
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
class Solution {
    public int maxDepth(TreeNode root) {
        if(root == null) {
            return 0;
        }
        return Math.max(maxDepth(root.left), maxDepth(root.right)) + 1;
    }
}
```

```JavaScript []
/**
 * Definition for a binary tree node.
 * function TreeNode(val) {
 *     this.val = val;
 *     this.left = this.right = null;
 * }
 */
/**
 * @param {TreeNode} root
 * @return {number}
 */
var maxDepth = function(root) {
    if(root == null) {
        return 0;
    }
    return Math.max(maxDepth(root.left), maxDepth(root.right)) + 1;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/0cd4d2ff205f7d9ac9ac787d311a820c3371ecaef9bac16534ed42d7d0e3a9f5-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/faccd5e96d15e4a72d23c610028648664f112dc1a6551ff423e88bf9a9ddd9b2-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/0c126700453058118115adfa75a32ff854c18380e5164c621f65c4a6d1f31adb-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/6806c6110b144b1b2e5d3e652b860801f4e0a075947e212000243ec4bf5ed40f-frame_00004.png)>



# BFS
<p><a href="/circle/discuss/X6Oj0x/"><img alt="画解剑指 Offer" src="https://pic.leetcode-cn.com/b04af6fd9c21f097f14418471f5fea7c35ae9ecfcdc4805b5a8af2807a0ebaa8-leetbook_discussion.png" style="height: 80px;" /></a></p>

## 剑指 Offer 32 - I. 从上到下打印二叉树

>https://leetcode.cn/problems/cong-shang-dao-xia-da-yin-er-cha-shu-lcof/
<p>从上到下打印出二叉树的每个节点，同一层的节点按照从左到右的顺序打印。</p>

<p>&nbsp;</p>

<p>例如:<br>
给定二叉树:&nbsp;<code>[3,9,20,null,null,15,7]</code>,</p>

<pre>    3
   / \
  9  20
    /  \
   15   7
</pre>

<p>返回：</p>

<pre>[3,9,20,15,7]
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ol>
	<li><code>节点总数 &lt;= 1000</code></li>
</ol>


### 剑指 Offer 32 - I. 从上到下打印二叉树 - 解决方案
## 题目描述

从上到下打印出二叉树的每个节点，同一层的节点按照从左到右的顺序打印。

例如:

给定二叉树: `[3,9,20,null,null,15,7]`,

```
    3
   / \
  9  20
    /  \
   15   7
```

返回：

```
[3,9,20,15,7]
```

提示：

1. `节点总数 <= 1000`

## 解题方案

### 思路

- 标签：树的广度遍历
- 整体思路：广度遍历的最常见思路，使用队列按层次存储，然后依次取出，达到按层次进行遍历的效果
- 时间复杂度：$O(n)$，空间复杂度：$O(n)$

### 算法流程

1. 判断 `root` 是否为 `null`，如果为 `null` 则直接返回空数组
2. 初始化队列，并将初始的 `root` 节点加入队列之中
3. 当队列不为空时不断广度遍历二叉树，遍历时依次从队列中取出节点，取出后如果该节点存在左节点则将左节点放入队列中，如果该节点存在右节点则将右节点放入队列中
4. 在遍历过程中存储结果，最后将结果按照要求的格式返回

### 代码

```Java []
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
class Solution {
    public int[] levelOrder(TreeNode root) {
        if(root == null) {
            return new int[0];
        }
        Queue<TreeNode> queue = new LinkedList<>();
        queue.add(root);
        ArrayList<Integer> ans = new ArrayList<>();
        while(!queue.isEmpty()) {
            TreeNode node = queue.poll();
            ans.add(node.val);
            if(node.left != null) {
                queue.add(node.left);
            }
            if(node.right != null) {
                queue.add(node.right);
            }
        }
        int[] res = new int[ans.size()];
        for(int i = 0; i < ans.size(); i++) {
            res[i] = ans.get(i);
        }
        return res;
    }
}
```

```JavaScript []
/**
 * Definition for a binary tree node.
 * function TreeNode(val) {
 *     this.val = val;
 *     this.left = this.right = null;
 * }
 */
/**
 * @param {TreeNode} root
 * @return {number[]}
 */
var levelOrder = function(root) {
    if(root == null) {
        return [];
    }
    let queue = [];
    queue.push(root);
    let ans = [];
    while(queue.length != 0) {
        let node = queue.shift();
        ans.push(node.val);
        if(node.left != null) {
            queue.push(node.left);
        }
        if(node.right != null) {
            queue.push(node.right);
        }
    }
    return ans;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/41837f46d2475d6ed20858f495f17dcb82c01f93e3234a5dafd528686d6e9e17-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/81ccf5cf9e5a146195b9ee91642e89b8318dae637f4e70ca02a926db51756601-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/10e55c80d80fae72c04090011cab34a63a2e1da258306dd48f56cd30d8c6dcb5-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/2984526c4931cd31bb3ad08935e4eb99b54d3e375f1ebd1bb133c4ca41fbf5df-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/4669139df8f1baaadd7122984aa7d148e4be07942b2b0622f168c203eb1a5cd4-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/b0798096f8e0bab3b2086c84452775bb054a35b16fc5a9ea1b25eacba74d5962-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/536fd3ab53a75766e0d12bb85ed460d451e764e9ff47521ded0811d6334a5e45-frame_00007.png)>


## 剑指 Offer 32 - II. 从上到下打印二叉树 II

>https://leetcode.cn/problems/cong-shang-dao-xia-da-yin-er-cha-shu-ii-lcof/
<p>从上到下按层打印二叉树，同一层的节点按从左到右的顺序打印，每一层打印到一行。</p>

<p>&nbsp;</p>

<p>例如:<br>
给定二叉树:&nbsp;<code>[3,9,20,null,null,15,7]</code>,</p>

<pre>    3
   / \
  9  20
    /  \
   15   7
</pre>

<p>返回其层次遍历结果：</p>

<pre>[
  [3],
  [9,20],
  [15,7]
]
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ol>
	<li><code>节点总数 &lt;= 1000</code></li>
</ol>

<p>注意：本题与主站 102 题相同：<a href="https://leetcode-cn.com/problems/binary-tree-level-order-traversal/">https://leetcode-cn.com/problems/binary-tree-level-order-traversal/</a></p>


### 剑指 Offer 32 - II. 从上到下打印二叉树 II - 解决方案
## 题目描述

从上到下按层打印二叉树，同一层的节点按从左到右的顺序打印，每一层打印到一行。

例如:
给定二叉树: `[3,9,20,null,null,15,7]`,

```
    3
   / \
  9  20
    /  \
   15   7
```

返回其层次遍历结果：

```
[
  [3],
  [9,20],
  [15,7]
]
```

提示：

`节点总数 <= 1000`

注意：本题与主站 102 题相同：https://leetcode-cn.com/problems/binary-tree-level-order-traversal/

## 解题方案

### 思路

- 标签：树的广度遍历
- 通过广度遍历 BFS 可以进行每一层的节点值获取，通过队列的方式，将当前层节点的下一层子节点放入队列中，用于下一次循环取值，同时将本层的节点放入到本层数组中，当前层循环结束后塞入结果数组中
- 时间复杂度：$O(n)$，空间复杂度：$O(n)$

### 算法流程

1. 初始化队列 `queue` 和结果集 `res`
2. 当 `root == null` 时，直接返回空的结果集 `res`
3. 将 `root` 添加到 `queue` 中，用于下面的第一次循环
4. 当 `queue` 不为空时始终进行循环遍历，新建当前层结果集 `level`，并将 `queue` 中当前层的节点一一取出，将节点值添加到 `level` 中，如果节点存在左子树，则将左子树节点放入 `queue` 中，如果节点存在右子树，则将右子树节点放入 `queue` 中
5. 结束循环，返回结果集 `res`

### 代码

```Java []
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
class Solution {
    public List<List<Integer>> levelOrder(TreeNode root) {
        Queue<TreeNode> queue = new LinkedList<>();
        List<List<Integer>> res = new ArrayList<>();
        if(root == null) {
            return res;
        }
        queue.add(root);
        while(!queue.isEmpty()) {
            List<Integer> level = new ArrayList<>();
            int len = queue.size();
            for(int i = 0; i < len; i++) {
                TreeNode treeNode = queue.poll();
                level.add(treeNode.val);
                if(treeNode.left != null) {
                    queue.add(treeNode.left);
                }
                if(treeNode.right != null) {
                    queue.add(treeNode.right);
                }
            }
            res.add(level);
        }
        return res;
    }
}
```

```JavaScript []
/**
 * Definition for a binary tree node.
 * function TreeNode(val) {
 *     this.val = val;
 *     this.left = this.right = null;
 * }
 */
/**
 * @param {TreeNode} root
 * @return {number[][]}
 */
var levelOrder = function(root) {
    let queue = [];
    let res = [];
    if(root == null) {
        return res;
    }
    queue.push(root);
    while(queue.length != 0) {
        let level = [];
        const len = queue.length;
        for(let i = 0; i < len; i++) {
            let treeNode = queue.shift();
            level.push(treeNode.val);
            if(treeNode.left != null) {
                queue.push(treeNode.left);
            }
            if(treeNode.right != null) {
                queue.push(treeNode.right);
            }
        }
        res.push(level);
    }
    return res;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/2eadb135a1686e9814799644f4129a5bff09d8efa41cb182bac8df8816523caf-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/6de654a6d7c5bc5b0c5def0df692c516b2197c02bfc1f66fffbeb3ffc5a50fd4-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/66854cb9a64911789cfe66b486e12c417dd99817278761432d45ce9eca6a2b00-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/a79ee62bd8d2e5edf35d1443d4ba50a82efe33002a4595d522b556bf19a445c4-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/1afa8948dcb918fd31c1faed7381e166b2461503772f6e648a242a9b6e87a7bb-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/0c89fd4366f85628fd7e320a17f1d20e2c170ca0f0acb75b61597c298a9678b5-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/c913e6d9b7ab2fb356cdd1ce85d12d3bfe0ca238d2b8196e790dda2b36df4a89-frame_00007.png)>


## 剑指 Offer 32 - III. 从上到下打印二叉树 III

>https://leetcode.cn/problems/cong-shang-dao-xia-da-yin-er-cha-shu-iii-lcof/
<p>请实现一个函数按照之字形顺序打印二叉树，即第一行按照从左到右的顺序打印，第二层按照从右到左的顺序打印，第三行再按照从左到右的顺序打印，其他行以此类推。</p>

<p>&nbsp;</p>

<p>例如:<br>
给定二叉树:&nbsp;<code>[3,9,20,null,null,15,7]</code>,</p>

<pre>    3
   / \
  9  20
    /  \
   15   7
</pre>

<p>返回其层次遍历结果：</p>

<pre>[
  [3],
  [20,9],
  [15,7]
]
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ol>
	<li><code>节点总数 &lt;= 1000</code></li>
</ol>


### 剑指 Offer 32 - III. 从上到下打印二叉树 III - 解决方案
## 题目描述

请实现一个函数按照之字形顺序打印二叉树，即第一行按照从左到右的顺序打印，第二层按照从右到左的顺序打印，第三行再按照从左到右的顺序打印，其他行以此类推。

例如:
给定二叉树: `[3,9,20,null,null,15,7]`,

```
    3
   / \
  9  20
    /  \
   15   7
```

返回其层次遍历结果：

```
[
  [3],
  [20,9],
  [15,7]
]
```

提示：

1. `节点总数 <= 1000`

## 解题方案

### 思路

- 标签：双端队列、树的广度遍历
- 整体思路：从 `root` 节点开始，每次取下一层的所有节点放入队列中，放入队列时如果层数为奇数，则依次放到当前层结果的尾部，达到从左到右的顺序打印效果。如果层数为偶数，则依次放到当前层结果的头部，达到从右向左的顺序打印效果。
- 时间复杂度：$O(n)$，空间复杂度：$O(n)$

### 算法流程

1. 初始化结果集合 `res`，如果 `root == null` 则直接返回空的结果集
2. 初始化队列 `queue`，并将 `root` 添加到队列中
3. 当队列不为空时，将当前 `queue` 中的所有值取出，构造每一层的结果 `list`
4. 如果层数为奇数层，则进行尾插法，将结果按顺序在 `list` 尾部进行插入
5. 如果层数为偶数层，则进行头插法，将结果按顺序在 `list` 头部进行插入
6. 将当前层结果 `list` 加入到 `res` 中，最后返回 `res`

### 代码

```Java []
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
class Solution {
    public List<List<Integer>> levelOrder(TreeNode root) {
        List<List<Integer>> res = new ArrayList<>();
        if(root == null) {
            return res;
        }
        Queue<TreeNode> queue = new LinkedList<>();
        queue.add(root);
        while(!queue.isEmpty()) {
            LinkedList<Integer> list = new LinkedList<>();
            int len = queue.size();
            for(int i = 0;i < len;i++) {
                TreeNode treeNode = queue.poll();
                if(res.size() % 2 == 0) {
                    list.addLast(treeNode.val);
                } else {
                    list.addFirst(treeNode.val);
                }
                if(treeNode.left != null) {
                    queue.add(treeNode.left);
                }
                if(treeNode.right != null) {
                    queue.add(treeNode.right);
                }
            }
            res.add(list);
        }
        return res;
    }
}
````

```JavaScript []
/**
 * Definition for a binary tree node.
 * function TreeNode(val) {
 *     this.val = val;
 *     this.left = this.right = null;
 * }
 */
/**
 * @param {TreeNode} root
 * @return {number[][]}
 */
var levelOrder = function(root) {
    let res = [];
    if(root == null) {
        return res;
    }
    let queue = [];
    queue.push(root);
    while(queue.length != 0) {
        let list = [];
        const len = queue.length;
        for(let i = 0;i < len;i++) {
            let treeNode = queue.shift();
            if(res.length % 2 == 0) {
                list.push(treeNode.val);
            } else {
                list.unshift(treeNode.val);
            }
            if(treeNode.left != null) {
                queue.push(treeNode.left);
            }
            if(treeNode.right != null) {
                queue.push(treeNode.right);
            }
        }
        res.push(list);
    }
    return res;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/b857db289b3b342e0382438ed3b05f0261b5a6ee74078d786b8017a1348f7817-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/6f92dcd372113a23ada9bd509b93be8789641e1156abd2dfa3c8a490c53cf033-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/522fcaf5d9d9432d7b5674112aee1aa153732189a1ea7a4dc6e2a2dcc9657590-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/918b7d4ea669e7f9eb4b481c151cfea9b208b936f6d0f4c04533092e707a909f-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/1598931572-GJGCaK-frame_00005%E5%89%AF%E6%9C%AC.png),![frame_00006.png](https://pic.leetcode-cn.com/1598931572-XLFabV-frame_00006%E5%89%AF%E6%9C%AC.png),![frame_00007.png](https://pic.leetcode-cn.com/a031fcda22c288fc1fab8316bc5e5ebd7906583982bca7bccbaa1fbeb02001ad-frame_00007.png)>



# 动态规划
<p><a href="/circle/discuss/X6Oj0x/"><img alt="画解剑指 Offer" src="https://pic.leetcode-cn.com/b04af6fd9c21f097f14418471f5fea7c35ae9ecfcdc4805b5a8af2807a0ebaa8-leetbook_discussion.png" style="height: 80px;" /></a></p>

## 剑指 Offer 10 - I. 斐波那契数列

>https://leetcode.cn/problems/fei-bo-na-qi-shu-lie-lcof/
<p>写一个函数，输入 <code>n</code> ，求斐波那契（Fibonacci）数列的第 <code>n</code> 项（即 <code>F(N)</code>）。斐波那契数列的定义如下：</p>

<pre>
F(0) = 0,   F(1) = 1
F(N) = F(N - 1) + F(N - 2), 其中 N > 1.</pre>

<p>斐波那契数列由 0 和 1 开始，之后的斐波那契数就是由之前的两数相加而得出。</p>

<p>答案需要取模 1e9+7（1000000007），如计算初始结果为：1000000008，请返回 1。</p>

<p> </p>

<p><strong>示例 1：</strong></p>

<pre>
<strong>输入：</strong>n = 2
<strong>输出：</strong>1
</pre>

<p><strong>示例 2：</strong></p>

<pre>
<strong>输入：</strong>n = 5
<strong>输出：</strong>5
</pre>

<p> </p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>0 <= n <= 100</code></li>
</ul>


### 剑指 Offer 10 - I. 斐波那契数列 - 解决方案
## 题目描述

写一个函数，输入 `n`，求斐波那契（Fibonacci）数列的第 `n` 项。斐波那契数列的定义如下：

```bash
F(0) = 0,   F(1) = 1
F(N) = F(N - 1) + F(N - 2), 其中 N > 1.
```

斐波那契数列由 0 和 1 开始，之后的斐波那契数就是由之前的两数相加而得出。

答案需要取模 1e9+7（1000000007），如计算初始结果为：1000000008，请返回 1。

示例 1：

```bash
输入：n = 2
输出：1
```

示例 2：

```bash
输入：n = 5
输出：5
```

提示：

- `0 <= n <= 100`

## 解题方案

### 思路 1

- 标签：动态规划
- 本题是经典的动态规划问题，围绕斐波那契数列方程 $F(n+1) = F(n) + F(n−1)$ 进行解题，所以在求 n+1 元素时，只需要知道第 n 和 n-1 个元素即可
  - 状态定义： F[n] 表示的含义为斐波那契数列中第 n 个数字
  - 转移方程： $F(n+1) = F(n) + F(n−1)$ ，所以在求 n+1 元素时，只需要知道第 n 和 n-1 个元素即可，故而运算过程中不需要保存数组
  - 初始状态： F[0] = 0, F[1] = 1 ，因为在计算 n+1 时需要 2 个元素，所以要初始化 2 个值；
- 其中取模 1000000007 运算主要是为了避免数字溢出，这步运算在每次计算出新的斐波那契数时进行即可，因为模运算的特性，后续再进行加法运算也不会有任何影响
  - 模运算特性：(x + y) % z = ((x % z) + (y % z)) % z
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 代码 1

```Java []
class Solution {
    public int fib(int n) {
        int n1 = 0, n2 = 1, sum;
        for(int i = 0; i < n; i++){
            sum = (n1 + n2) % 1000000007;
            n1 = n2;
            n2 = sum;
        }
        return n1;
    }
}
```

```JavaScript []
/**
 * @param {number} n
 * @return {number}
 */
var fib = function(n) {
    let n1 = 0, n2 = 1, sum;
    for(let i = 0; i < n; i++){
        sum = (n1 + n2) % 1000000007;
        n1 = n2;
        n2 = sum;
    }
    return n1;
};
```

### 画解 1
<![frame_00001.png](https://pic.leetcode-cn.com/edaa765e12967468084c3ed2d6a230c03652a4ca458dcb1933af22a3fa1974c4-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/d3bc1eec3a709c75941a017667038893fb5d3235c0284624a87b70ae316d1a06-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/208ad5a2361589da5b18ece1effabe4a34be8340092b62774d998dd23103bfdf-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/312a4983104b6e03494d6665435af0461131db0f77930a24652f1786dbf52492-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/b5728842f4433bff9686cbcb36fc763910d6dc7634c5fe314c1c8ca165fb9f01-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/cc91ea07441b42cd665c1464c292d31707de3a6e3d411d15592e15aa3d85fadb-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/2608b2a80364418803a80f52c3de3ee5ae18af883699df2108620eabd28e848e-frame_00007.png)>

### 思路 2

- 标签：打表
- 首先从题目中可以得出`0 <= n <= 100`，那么说明结果一共有 101 个数字，如果这 101 个数字可以提前计算好，到时候需要哪个取哪个，就可以最大程度的降低时间复杂度，这个就是打表的思维
- 打表虽然看起来就是将所有结果枚举出来，感觉上扩展性也不好，看着也很繁琐，但是在实际做算法题中确实有着很广泛的应用，不失为一种巧妙的解法
- 时间复杂度：$O(1)$，空间复杂度：$O(1)$

### 代码 2

```Java []
class Solution {
    public int fib(int n) {
        int[] f={0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597,2584,4181,6765,10946,17711,28657,46368,75025,121393,196418,317811,514229,832040,1346269,2178309,3524578,5702887,9227465,14930352,24157817,39088169,63245986,102334155,165580141,267914296,433494437,701408733,134903163,836311896,971215059,807526948,778742000,586268941,365010934,951279875,316290802,267570670,583861472,851432142,435293607,286725742,722019349,8745084,730764433,739509517,470273943,209783453,680057396,889840849,569898238,459739080,29637311,489376391,519013702,8390086,527403788,535793874,63197655,598991529,662189184,261180706,923369890,184550589,107920472,292471061,400391533,692862594,93254120,786116714,879370834,665487541,544858368,210345902,755204270,965550172,720754435,686304600,407059028,93363621,500422649,593786270,94208912,687995182};
        return f[n];
    }
}
```

```JavaScript []
/**
 * @param {number} n
 * @return {number}
 */
var fib = function(n) {
    const f =[0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597,2584,4181,6765,10946,17711,28657,46368,75025,121393,196418,317811,514229,832040,1346269,2178309,3524578,5702887,9227465,14930352,24157817,39088169,63245986,102334155,165580141,267914296,433494437,701408733,134903163,836311896,971215059,807526948,778742000,586268941,365010934,951279875,316290802,267570670,583861472,851432142,435293607,286725742,722019349,8745084,730764433,739509517,470273943,209783453,680057396,889840849,569898238,459739080,29637311,489376391,519013702,8390086,527403788,535793874,63197655,598991529,662189184,261180706,923369890,184550589,107920472,292471061,400391533,692862594,93254120,786116714,879370834,665487541,544858368,210345902,755204270,965550172,720754435,686304600,407059028,93363621,500422649,593786270,94208912,687995182];
    return f[n];
};
```


## 剑指 Offer 10 - II. 青蛙跳台阶问题

>https://leetcode.cn/problems/qing-wa-tiao-tai-jie-wen-ti-lcof/
<p>一只青蛙一次可以跳上1级台阶，也可以跳上2级台阶。求该青蛙跳上一个 <code>n</code>&nbsp;级的台阶总共有多少种跳法。</p>

<p>答案需要取模 1e9+7（1000000007），如计算初始结果为：1000000008，请返回 1。</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>n = 2
<strong>输出：</strong>2
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>n = 7
<strong>输出：</strong>21
</pre>

<p><strong>示例 3：</strong></p>

<pre><strong>输入：</strong>n = 0
<strong>输出：</strong>1</pre>

<p><strong>提示：</strong></p>

<ul>
	<li><code>0 &lt;= n &lt;= 100</code></li>
</ul>

<p>注意：本题与主站 70 题相同：<a href="https://leetcode-cn.com/problems/climbing-stairs/">https://leetcode-cn.com/problems/climbing-stairs/</a></p>

<p>&nbsp;</p>


### 剑指 Offer 10 - II. 青蛙跳台阶问题 - 解决方案
## 题目描述

一只青蛙一次可以跳上 1 级台阶，也可以跳上 2 级台阶。求该青蛙跳上一个 `n`  级的台阶总共有多少种跳法。

答案需要取模 1e9+7（1000000007），如计算初始结果为：1000000008，请返回 1。

示例 1：

```text
输入：n = 2
输出：2
```

示例 2：

```text
输入：n = 7
输出：21
```

提示：

- `0 <= n <= 100`

注意：本题与主站 [70 题](https://leetcode-cn.com/problems/climbing-stairs/) 相同

## 解题方案

### 思路

- 标签：动态规划
- 整体思路：本质是斐波那契数列和循环求余法
  - 令 $F(n)$ 表示为上第 $n$ 层台阶时所需要的跳法
  - 因为一次可以跳上 1 级台阶，也可以跳上 2 级台阶，所以 $F(n)$ 可以从 $F(n-1)$ 跳上来，也可以从 $F(n-2)$ 跳上来
  - 推导出 $F(n) = F(n-1) + F(n-2)$
  - 由于第 $n$ 层的跳法数量只取决于 $n-1$ 和 $n-2$ 层，所以存储时，可以仅存储这三个值，优化空间复杂度
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程

1. 围绕斐波那契数列方程 $F(n) = F(n-1) + F(n−2)$ 进行解题，所以在求 n 元素时，只需要知道第 n-1 和 n-2 个元素即可

- 状态定义： `F[n]` 表示的含义为斐波那契数列中第 n 个数字
- 转移方程： $F(n) = F(n-1) + F(n−2)$，运算过程中仅存储这三个数值即可
- 初始状态： `F[0] = 1`, `F[1] = 1`，因为在计算 n 时需要 2 个元素，所以要初始化 2 个值；

2. 其中取模 `1000000007` 运算主要是为了避免数字溢出，这步运算在每次计算出新的斐波那契数时进行即可，因为模运算的特性，后续再进行加法运算也不会有任何影响

- 模运算特性：$(x + y) \% z = ((x \% z) + (y \% z)) \% z$

3. 为什么要对 `1000000007` 取模

- `1000000007` 是一个质数（素数），对质数取模能最大程度避免冲突
- int32 位的最大值为 `2147483647`，所以对于 int32 位来说 `1000000007` 足够大
- [参考资料](https://www.liuchuo.net/archives/645)

### 代码

```Java []
class Solution {
    public int numWays(int n) {
        int n1 = 1, n2 = 1, sum;
        for(int i = 0; i < n; i++){
            sum = (n1 + n2) % 1000000007;
            n1 = n2;
            n2 = sum;
        }
        return n1; 
    }
}
```

```JavaScript []
/**
 * @param {number} n
 * @return {number}
 */
var numWays = function(n) {
    let n1 = 1, n2 = 1, sum;
    for(let i = 0; i < n; i++){
        sum = (n1 + n2) % 1000000007;
        n1 = n2;
        n2 = sum;
    }
    return n1;
};
```

### 画解

<![offer10-2-1.png](https://pic.leetcode-cn.com/4c79bb823d76d958b6879359cfb0a67bd6b618bac52d6fe7cc6e3d26c4bc4e21-offer10-2-1.png),![offer10-2-2.png](https://pic.leetcode-cn.com/22faee562c0beeae4598bb52e46e3b0e79fd10202287561566a6958e3412cbd7-offer10-2-2.png),![offer10-2-3.png](https://pic.leetcode-cn.com/fc5eeaadc540d4d4877f5253df9376937bb55d9449fd045f7a24a443074a5989-offer10-2-3.png),![offer10-2-4.png](https://pic.leetcode-cn.com/5d099f11bf96e07dea64d501ef7cfccb2fccfb347b089e6ddae8fc20e17719b0-offer10-2-4.png),![offer10-2-5.png](https://pic.leetcode-cn.com/5775440cf8f052754bab23ff3af67ddad246ce7798795355b3507cc927229c6c-offer10-2-5.png),![offer10-2-6.png](https://pic.leetcode-cn.com/1f71b17a1d0a116cdf909041b29dc5d097391fc78cb2e36549bbbfe9ce8e665e-offer10-2-6.png),![offer10-2-7.png](https://pic.leetcode-cn.com/25c6d7d0113370a247927ecf9ca426ed60390e528aa7f1c8db6652f28f1f9b55-offer10-2-7.png),![offer10-2-8.png](https://pic.leetcode-cn.com/b705d996bf3cc8b68fbcc81afba18a3d55b7044fbcb76c87896737fca4527b7c-offer10-2-8.png),![offer10-2-9.png](https://pic.leetcode-cn.com/657d5cbf5f615dafb46fb77404f21ade53074cab27fa673776a41665f2f5fcbe-offer10-2-9.png),![offer10-2-10.png](https://pic.leetcode-cn.com/94ac5435cdcba21f51e99ddefb800cabce107de9d502246683fd1ab24aef5509-offer10-2-10.png)>

### 花絮

![offer10-2.mp4](e09d7791-e003-40e9-a913-954098a9a9f5)


## 剑指 Offer 42. 连续子数组的最大和

>https://leetcode.cn/problems/lian-xu-zi-shu-zu-de-zui-da-he-lcof/
<p>输入一个整型数组，数组中的一个或连续多个整数组成一个子数组。求所有子数组的和的最大值。</p>

<p>要求时间复杂度为O(n)。</p>

<p>&nbsp;</p>

<p><strong>示例1:</strong></p>

<pre><strong>输入:</strong> nums = [-2,1,-3,4,-1,2,1,-5,4]
<strong>输出:</strong> 6
<strong>解释:</strong>&nbsp;连续子数组&nbsp;[4,-1,2,1] 的和最大，为&nbsp;6。</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>1 &lt;=&nbsp;arr.length &lt;= 10^5</code></li>
	<li><code>-100 &lt;= arr[i] &lt;= 100</code></li>
</ul>

<p>注意：本题与主站 53 题相同：<a href="https://leetcode-cn.com/problems/maximum-subarray/">https://leetcode-cn.com/problems/maximum-subarray/</a></p>

<p>&nbsp;</p>


### 剑指 Offer 42. 连续子数组的最大和 - 解决方案
## 题目描述

输入一个整型数组，数组里有正数也有负数。数组中的一个或连续多个整数组成一个子数组。求所有子数组的和的最大值。

要求时间复杂度为 $O(n)$。

示例 1:

```
输入: nums = [-2,1,-3,4,-1,2,1,-5,4]
输出: 6
解释: 连续子数组 [4,-1,2,1] 的和最大，为 6。
```

提示：

- `1 <= arr.length <= 10^5`
- `-100 <= arr[i] <= 100`

## 解题方案

### 思路

- 标签：动态规划
- 整体思路：通过动态规划计算每一步的状态可以在遍历数组结束后得到结果，成为最优解
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程

1. 状态定义：动态规划数组为 `dp`，`dp[i]` 表示以 `nums[i]` 结尾的连续子数组最大和
2. 状态转移方程：

- 当 `dp[i - 1] > 0​` 时，则 ​`dp[i] = dp[i-1] + nums[i]​`，因为此时 ​`dp[i - 1]​` 产生正向增益，所以要加上去
- 当 `dp[i - 1] ≤ 0​` 时，则 ​`dp[i] = nums[i]​`，因为此时 ​`dp[i - 1]​` 产生负向增益，所以不需要添加

3. 初始状态：`dp[0] = nums[0]​`
4. 结果值：`dp` 数组中的最大值，就是最终的结果
5. 其中为了降低空间复杂度，可以将 `dp` 数组与 `nums` 数组合并，避免开辟新的内存空间

### 代码

```Java []
class Solution {
    public int maxSubArray(int[] nums) {
        int res = nums[0];
        for(int i = 1; i < nums.length; i++) {
            if(nums[i - 1] > 0) {
                nums[i] += nums[i - 1];
            }
            res = Math.max(res, nums[i]);
        }
        return res;
    }
}
```

```JavaScript []
/**
 * @param {number[]} nums
 * @return {number}
 */
var maxSubArray = function(nums) {
    let res = nums[0];
    for(let i = 1; i < nums.length; i++) {
        if(nums[i - 1] > 0) {
            nums[i] += nums[i - 1];
        }
        res = Math.max(res, nums[i]);
    }
    return res;
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/41edc96fa999f2bae29388eae72159c4e7747993f4209f79405a1765757d2a9d-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/a493afc64f8e75cd0edeb1b4279681d2d8d3daf3d91237423e9bbac1d18a51a2-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/78b8272666ffd23b43e5d842bb0843874607e669d31ec0bb5a74eef18152d42e-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/9324d5f879dfbe14053c9a202586b65b288b4183dbad636b16b7300af5b12c97-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/bb3da281fcd3c23c39fb90635b72fa3a0e99386b25ae634f81dc4dc12a7ef265-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/a10aa71e353e31c0de61da9a38170b2a96970057ad0ca20430f0bb3acbcc1ddd-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/72e5a04802be4c2aac68225fece4aa7549ec7c4c082b94f1703c6285990a37ab-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/bbfce63977ffcdfe8ef7b012a38b2c24c2f10f47279a0cc6c48c4801e88c643b-frame_00008.png),![frame_00009.png](https://pic.leetcode-cn.com/ceb69916f991df6a7fadc15f756df44874674ef9c8af282da7fffe2c76e9266d-frame_00009.png),![frame_00010.png](https://pic.leetcode-cn.com/addf96d112c363cde012b1cb94ca314bff9626cb4723dfa901da955e2b5f80cb-frame_00010.png),![frame_00011.png](https://pic.leetcode-cn.com/8023717dfd7cfe43104d6543db8ec32bfaf4780e7b54e0f8f0bfeca5dbd9980c-frame_00011.png),![frame_00012.png](https://pic.leetcode-cn.com/d7cc25ad1525ea0d7f5df285dac303172de58cc7408519a43a8225e72ef03b0a-frame_00012.png),![frame_00013.png](https://pic.leetcode-cn.com/ce2369ca66811177ef9f7ada433580c7f2cc5e298520af769a07687f008a399b-frame_00013.png),![frame_00014.png](https://pic.leetcode-cn.com/04d6e9916ecb5b7462bb48cec6c303ccddd7679f852ae3521881df639b8b1a27-frame_00014.png),![frame_00015.png](https://pic.leetcode-cn.com/4086ba85e2d84553f36215aa35e1fbfa2accd08707c57b126b99dcfe1e872ae5-frame_00015.png),![frame_00016.png](https://pic.leetcode-cn.com/d45ae89c21e64a025fe8e19f348de387e6f9affda8f005ea25605c65c1a871f6-frame_00016.png)>


## 剑指 Offer 46. 把数字翻译成字符串

>https://leetcode.cn/problems/ba-shu-zi-fan-yi-cheng-zi-fu-chuan-lcof/
<p>给定一个数字，我们按照如下规则把它翻译为字符串：0 翻译成 &ldquo;a&rdquo; ，1 翻译成 &ldquo;b&rdquo;，&hellip;&hellip;，11 翻译成 &ldquo;l&rdquo;，&hellip;&hellip;，25 翻译成 &ldquo;z&rdquo;。一个数字可能有多个翻译。请编程实现一个函数，用来计算一个数字有多少种不同的翻译方法。</p>

<p>&nbsp;</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入:</strong> 12258
<strong>输出:</strong> <code>5
</code><strong>解释:</strong> 12258有5种不同的翻译，分别是&quot;bccfi&quot;, &quot;bwfi&quot;, &quot;bczi&quot;, &quot;mcfi&quot;和&quot;mzi&quot;</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>0 &lt;= num &lt; 2<sup>31</sup></code></li>
</ul>


### 剑指 Offer 46. 把数字翻译成字符串 - 解决方案
## 题目描述

给定一个数字，我们按照如下规则把它翻译为字符串：0 翻译成 "a" ，1 翻译成 "b"，……，11 翻译成 "l"，……，25 翻译成 "z"。一个数字可能有多个翻译。请编程实现一个函数，用来计算一个数字有多少种不同的翻译方法。

**示例 1:**

```text
输入：12258
输出：5
解释：12258 有 5 种不同的翻译，分别是 "bccfi","bwfi","bczi","mcfi" 和 "mzi"
```

## 解题方案

### 思路

- 标签：动态规划
- 整体思路：
  - 翻译方案可能与前两步骤有关，令 `dp[n]` 表示第 $n$ 个位置方案数量，第 [n] 位与区间 [0:n-1] 位必然可以组成 `dp[n-1]` 个方案，如果前两位 [n-1:n] 组成的数字在区间 10-26 之间，第 [n-1:n] 位与区间 [0:n-2] 位必然可以组成 `dp[n-2]`个方案，所以可以根据该思路写出动态规划方程
- 复杂度：
  - 时间复杂度：$O(n)$。$n$ 代表 `num` 的数字长度，需要遍历 $n$ 次
  - 空间复杂度：$O(n)$。需要将 `num` 转为字符串，所以要消耗字符串长度 $n$ 的空间

### 算法流程

1. 状态定义： `dp[n]` 表示第 $n$ 个位置方案数量
2. 转移方程：

令 [n-1:n] 组成的数字为 $x$

- $dp[n] = dp[n-1] + dp[n-2], x >= 10 && x <= 25$
- $dp[n] = dp[n-1], x < 10 && x > 25$

3. 初始状态：`dp[0] = 1，dp[1] = 1`
4. 因为该动态规划只需要 n-1 和 n-2 步骤的数据即可，所以可以不使用 `dp` 数组存储，使用 2 个变量存储数值即可

### 代码

```Java []
class Solution {
    public int translateNum(int num) {
        String numStr = String.valueOf(num);
        int len = numStr.length();
        int x = 1;
        int y = 1;
        for(int i = 2; i <= len; i++) {
            String sub = numStr.substring(i - 2, i);
            int z = sub.compareTo("10") >= 0 && sub.compareTo("25") <= 0 ? x + y : x;
            y = x;
            x = z;
        }
        return x;
    }
}
```

```JavaScript []
/**
 * @param {number} num
 * @return {number}
 */
var translateNum = function(num) {
    let numStr = num.toString();
    let len = numStr.length;
    let x = 1;
    let y = 1;
    for(let i = 2; i <= len; i++) {
        let sub = numStr.substring(i - 2, i);
        let z = parseInt(sub) >= 10 && parseInt(sub) <= 25 ? x + y : x;
        y = x;
        x = z;
    }
    return x;
};
```

### 画解

<![offer46-1.png](https://pic.leetcode-cn.com/1602483492-LEhidK-offer46-1.png),![offer46-2.png](https://pic.leetcode-cn.com/1602483492-NGSeSj-offer46-2.png),![offer46-3.png](https://pic.leetcode-cn.com/1602483492-xSppVz-offer46-3.png),![offer46-4.png](https://pic.leetcode-cn.com/1602483492-WewPSA-offer46-4.png),![offer46-5.png](https://pic.leetcode-cn.com/1602483492-FLvxFi-offer46-5.png),![offer46-6.png](https://pic.leetcode-cn.com/1602483492-Rpgqes-offer46-6.png)>

### 花絮

![offer46.mp4](89c396ee-bc18-4fa4-afad-76c0947cbf10)


## 剑指 Offer 47. 礼物的最大价值

>https://leetcode.cn/problems/li-wu-de-zui-da-jie-zhi-lcof/
<p>在一个 m*n 的棋盘的每一格都放有一个礼物，每个礼物都有一定的价值（价值大于 0）。你可以从棋盘的左上角开始拿格子里的礼物，并每次向右或者向下移动一格、直到到达棋盘的右下角。给定一个棋盘及其上面的礼物的价值，请计算你最多能拿到多少价值的礼物？</p>

<p>&nbsp;</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入:</strong> 
<code>[
&nbsp; [1,3,1],
&nbsp; [1,5,1],
&nbsp; [4,2,1]
]</code>
<strong>输出:</strong> <code>12
</code><strong>解释:</strong> 路径 1&rarr;3&rarr;5&rarr;2&rarr;1 可以拿到最多价值的礼物</pre>

<p>&nbsp;</p>

<p>提示：</p>

<ul>
	<li><code>0 &lt; grid.length &lt;= 200</code></li>
	<li><code>0 &lt; grid[0].length &lt;= 200</code></li>
</ul>


### 剑指 Offer 47. 礼物的最大价值 - 解决方案
## 题目描述

在一个 m\*n 的棋盘的每一格都放有一个礼物，每个礼物都有一定的价值（价值大于 0）。你可以从棋盘的左上角开始拿格子里的礼物，并每次向右或者向下移动一格、直到到达棋盘的右下角。给定一个棋盘及其上面的礼物的价值，请计算你最多能拿到多少价值的礼物？

示例 1:

```
输入:
[
  [1,3,1],
  [1,5,1],
  [4,2,1]
]
输出: 12
解释: 路径 1→3→5→2→1 可以拿到最多价值的礼物
```

提示：

- `0 < grid.length <= 200`
- `0 < grid[0].length <= 200`

## 解题方案

### 思路

- 标签：动态规划
- 整体思路：在遍历二维数组时，通过状态转移方程计算出当前位置的最大价值，同时通过复用入参来减少空间复杂度
- 时间复杂度：$O(m*n)$，空间复杂度：$O(1)$

### 算法流程

1. 初始化行数 `row` 和列数 `column`，遍历二维数组进行动态规划
2. 状态定义：状态转移二维数组为 `dp`，`dp[i][j]` 表示从 `grid[0][0]` 到 `grid[i][j]` 得到礼物的最大价值
3. 动态转移方程：

- 当 `i=0 && j=0` 时，`dp[0][0] = grid[0`][0]
- 当 `i=0 && j!=0` 时，`dp[i][j] = grid[i][j] + dp[i][j-1]`
- 当 `i!=0 && j=0` 时，`dp[i][j] = grid[i][j] + dp[i-1`][j]
- 当 `i!=0 && j!=0` 时，`dp[i][j] = grid[i][j] + max(dp[i-1][j], dp[i][j-1])`

4. 初始状态：`dp[0][0] = grid[0][0]`
5. 结果值：`dp[row-1][column-1]`，`row` 为二维数组行数，`column` 为二维数组列数
6. 空间上因为 `dp` 与 `grid` 大小一致，可以使用 `grid` 空间作为 `dp` 空间，减少空间复杂度

### 代码

```Java []
class Solution {
    public int maxValue(int[][] grid) {
        int row = grid.length;
        int column = grid[0].length;
        for(int i = 0; i < row; i++) {
            for(int j = 0; j < column; j++) {
                if(i == 0 && j == 0) {
                    continue;
                } else if(i == 0) {
                    grid[i][j] += grid[i][j - 1] ;
                } else if(j == 0) {
                    grid[i][j] += grid[i - 1][j];
                } else {
                    grid[i][j] += Math.max(grid[i][j - 1], grid[i - 1][j]);
                }
            }
        }
        return grid[row - 1][column - 1];
    }
}
```

```Java []
// 还可以考虑另一种方法，就是新增一列和一行为 0 的位置，便于统计逻辑计算 
class Solution {
    public int maxValue(int[][] grid) {
        int row = grid.length;
        int column = grid[0].length;
        int[][] dp = new int[row + 1][column + 1];
        for (int i = 1; i <= row; i++) {
            for (int j = 1; j <= column; j++) {
                dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]) + grid[i - 1][j - 1];
            }
        }
        return dp[row][column];
    }
}
```

```JavaScript []
/**
 * @param {number[][]} grid
 * @return {number}
 */
var maxValue = function(grid) {
    let row = grid.length;
    let column = grid[0].length;
    for(let i = 0; i < row; i++) {
        for(let j = 0; j < column; j++) {
            if(i == 0 && j == 0) {
                continue;
            } else if(i == 0) {
                grid[i][j] += grid[i][j - 1] ;
            } else if(j == 0) {
                grid[i][j] += grid[i - 1][j];
            } else {
                grid[i][j] += Math.max(grid[i][j - 1], grid[i - 1][j]);
            }
        }
    }
    return grid[row - 1][column - 1];
};
```

### 画解
<![frame_00001.png](https://pic.leetcode-cn.com/7f0693b67d49c59302b912e77e4f522b66efd499b1757a2453676559ab53b27d-frame_00001.png),![frame_00002.png](https://pic.leetcode-cn.com/bbea94abe2289ddd051288769b84f034ef12002928cb7d48409744a313e5cc8c-frame_00002.png),![frame_00003.png](https://pic.leetcode-cn.com/4f628a0bd50de6dd6c6a02e57d4366b382c3c9d0b65d6dd5e6f993894c714b86-frame_00003.png),![frame_00004.png](https://pic.leetcode-cn.com/a9743d22f214f27b78c27961dfc7191fb615ecd822ff23067bad65f3f127fcf4-frame_00004.png),![frame_00005.png](https://pic.leetcode-cn.com/7e5bec61f796da63ee7bf19b8dcb417a629d41042c5e7ede5ef41b3a35c39a60-frame_00005.png),![frame_00006.png](https://pic.leetcode-cn.com/e4a78208236f7ad80bc38c5f54b769069c97f5d1518ab126451cc1355c716e82-frame_00006.png),![frame_00007.png](https://pic.leetcode-cn.com/d89c4f74e15f3b11890535015344b5709ab109f688bf114f88094463ae5cc377-frame_00007.png),![frame_00008.png](https://pic.leetcode-cn.com/3f410940166925c0f1161bde84b253f8789968bab176796b37ee50021f1ec24d-frame_00008.png),![frame_00009.png](https://pic.leetcode-cn.com/d78f9ab533216d50d7bdf56a3de728f5c3ff07172bb42ee159fb9368a5c87223-frame_00009.png),![frame_00010.png](https://pic.leetcode-cn.com/f51667874d6fc6a18786e89af896305a20a7bea879915973bdcec4d99ea32600-frame_00010.png)>


## 剑指 Offer 49. 丑数

>https://leetcode.cn/problems/chou-shu-lcof/
<p>我们把只包含质因子 2、3 和 5 的数称作丑数（Ugly Number）。求按从小到大的顺序的第 n 个丑数。</p>

<p>&nbsp;</p>

<p><strong>示例:</strong></p>

<pre><strong>输入:</strong> n = 10
<strong>输出:</strong> 12
<strong>解释: </strong><code>1, 2, 3, 4, 5, 6, 8, 9, 10, 12</code> 是前 10 个丑数。</pre>

<p><strong>说明:&nbsp;</strong>&nbsp;</p>

<ol>
	<li><code>1</code>&nbsp;是丑数。</li>
	<li><code>n</code>&nbsp;<strong>不超过</strong>1690。</li>
</ol>

<p>注意：本题与主站 264 题相同：<a href="https://leetcode-cn.com/problems/ugly-number-ii/">https://leetcode-cn.com/problems/ugly-number-ii/</a></p>


### 剑指 Offer 49. 丑数 - 解决方案
## 题目描述

我们把只包含质因子 2、3 和 5 的数称作丑数（Ugly Number）。求按从小到大的顺序的第 n 个丑数。

示例:

```text
输入: n = 10
输出: 12
解释: 1, 2, 3, 4, 5, 6, 8, 9, 10, 12 是前 10 个丑数。
```

说明:

- `1`  是丑数。
- `n`  不超过 1690。

## 解题方案

### 思路

- 标签：动态规划
- 整体思路：
  - 除了第一个丑数外，所有的丑数都是某一个丑数的 2、3 或 5 倍的数字
  - 因为要从小到大求第 n 个丑数，所以需要按照顺序每次获取下一个最小的丑数，最终获得第 n 个
- 复杂度：
  - 时间复杂度：$O(n)$。只需要 n 次遍历即可求得第 n 个丑数
  - 空间复杂度：$O(n)$。需要保存动态规划的整体状态数组

### 算法流程

1. 状态定义： dp[n] 表示第 n 个丑数，a 表示 2 倍数字的索引用于 `dp[a]*2`,b 表示 3 倍数字的索引用于 `dp[b]*3`,c 表示 5 倍数字的索引用于 `dp[c]*5`
2. 转移方程：

- $dp[n] = min(dp[a]*2, dp[b]*3, dp[c]*5)$
- 每次计算之后，如果 2 倍的数字最小，则 a++，如果 3 倍的数字最小，则 b++，如果 5 倍的数字最小，则 c++

3. 初始状态： dp[0]=1，因为第一个丑数是 1

### 代码

```Java []
class Solution {
    public int nthUglyNumber(int n) {
        int a = 0, b = 0, c = 0;
        int[] dp = new int[n];
        dp[0] = 1;
        for(int i = 1; i < n; i++) {
            int n2 = dp[a] * 2;
            int n3 = dp[b] * 3;
            int n5 = dp[c] * 5;
            dp[i] = Math.min(Math.min(n2, n3), n5);
            if(dp[i] == n2) {
                a++;
            }
            if(dp[i] == n3) {
                b++;
            }
            if(dp[i] == n5) {
                c++;
            }
        }
        return dp[n - 1];
    }
}
```

```JavaScript []
/**
 * @param {number} n
 * @return {number}
 */
var nthUglyNumber = function(n) {
    let a = 0, b = 0, c = 0;
    let dp = [];
    dp[0] = 1;
    for(let i = 1; i < n; i++) {
        let n2 = dp[a] * 2;
        let n3 = dp[b] * 3;
        let n5 = dp[c] * 5;
        dp[i] = Math.min(Math.min(n2, n3), n5);
        if(dp[i] == n2) {
            a++;
        }
        if(dp[i] == n3) {
            b++;
        }
        if(dp[i] == n5) {
            c++;
        }
    }
    return dp[n - 1];
};
```

### 画解

<![offer49-1.png](https://pic.leetcode-cn.com/1599801393-lfFeBv-offer49-1.png),![offer49-2.png](https://pic.leetcode-cn.com/1599801393-LTHYRc-offer49-2.png),![offer49-3.png](https://pic.leetcode-cn.com/1599801393-osBvKA-offer49-3.png),![offer49-4.png](https://pic.leetcode-cn.com/1599801393-KYlEiB-offer49-4.png),![offer49-5.png](https://pic.leetcode-cn.com/1599801393-jdJOob-offer49-5.png),![offer49-6.png](https://pic.leetcode-cn.com/1599801393-uirPLj-offer49-6.png),![offer49-7.png](https://pic.leetcode-cn.com/1599801393-lVjQuJ-offer49-7.png),![offer49-8.png](https://pic.leetcode-cn.com/1599801393-MtvrGo-offer49-8.png),![offer49-9.png](https://pic.leetcode-cn.com/1599801393-yCNExr-offer49-9.png),![offer49-10.png](https://pic.leetcode-cn.com/1599801393-dANQvp-offer49-10.png),![offer49-11.png](https://pic.leetcode-cn.com/1599801393-ruAjHR-offer49-11.png)>


### 花絮

![offer49.mp4](62e2655c-c0f7-4883-8dde-05483287b825)


## 剑指 Offer 62. 圆圈中最后剩下的数字

>https://leetcode.cn/problems/yuan-quan-zhong-zui-hou-sheng-xia-de-shu-zi-lcof/
<p>0,1,···,n-1这n个数字排成一个圆圈，从数字0开始，每次从这个圆圈里删除第m个数字（删除后从下一个数字开始计数）。求出这个圆圈里剩下的最后一个数字。</p>

<p>例如，0、1、2、3、4这5个数字组成一个圆圈，从数字0开始每次删除第3个数字，则删除的前4个数字依次是2、0、4、1，因此最后剩下的数字是3。</p>

<p> </p>

<p><strong>示例 1：</strong></p>

<pre>
<strong>输入:</strong> n = 5, m = 3
<strong>输出: </strong>3
</pre>

<p><strong>示例 2：</strong></p>

<pre>
<strong>输入:</strong> n = 10, m = 17
<strong>输出: </strong>2
</pre>

<p> </p>

<p><strong>限制：</strong></p>

<ul>
	<li><code>1 <= n <= 10^5</code></li>
	<li><code>1 <= m <= 10^6</code></li>
</ul>


### 剑指 Offer 62. 圆圈中最后剩下的数字 - 解决方案
## 题目描述

0,1,n-1 这 n 个数字排成一个圆圈，从数字 0 开始，每次从这个圆圈里删除第 m 个数字。求出这个圆圈里剩下的最后一个数字。

例如，0、1、2、3、4 这 5 个数字组成一个圆圈，从数字 0 开始每次删除第 3 个数字，则删除的前 4 个数字依次是 2、0、4、1，因此最后剩下的数字是 3。

示例 1：

```text
输入: n = 5, m = 3
输出: 3
```

示例 2：

```text
输入: n = 10, m = 17
输出: 2
```

限制：

- `1 <= n <= 10^5`
- `1 <= m <= 10^6`

## 解题方案

### 思路

- 标签：动态规划
- 整体思路：
  - 如果依靠暴力枚举的话，每次要遍历 m 个元素，遍历 n 次留下最后一个，时间复杂度达到了$O(mn)$
  - 这道题是著名的约瑟夫环问题，可以将其使用倒推的方式推出来动态规划方程
- 复杂度：
  - 时间复杂度：$O(n)$。需要进行 n 次递归遍历
  - 空间复杂度：$O(1)$。动态规划可以优化存储空间为常量

### 算法流程

1. 状态定义：F(n) 表示还有 n 个人时最后剩下的数字索引号，一定要注意！是索引，而不是数字本身！
2. 初始状态：F[1] = 0，因为只剩 1 个数字的时候，索引号从 0 开始，所以一定为 0
3. 转移方程：

- F(1) = 0
- F(2) = (F(1) + m) % 2
- F(3) = (F(2) + m) % 3
    ...

  从下往上推可以得出方程为

$$F(n) = (F(n-1) + m) % n$$

4. 因为每个状态的下一步推导只需要上一个状态，所以用一个变量存储即可，不需要使用数组，将时间复杂度降低到$O(1)$

### 代码

```Java []
class Solution {
    public int lastRemaining(int n, int m) {
        int f = 0;
        for (int i = 2; i <= n; i++) {
            f = (m + f) % i;
        }
        return f;
    }
}
```

```JavaScript []
/**
 * @param {number} n
 * @param {number} m
 * @return {number}
 */
var lastRemaining = function(n, m) {
    let f = 0;
    for (let i = 2; i <= n; i++) {
        f = (m + f) % i;
    }
    return f;
};
```

### 画解

<![offer62-1.png](https://pic.leetcode-cn.com/1599801585-fGPAMP-offer62-1.png),![offer62-2.png](https://pic.leetcode-cn.com/1599801585-AsscIY-offer62-2.png),![offer62-3.png](https://pic.leetcode-cn.com/1599801585-trSIsd-offer62-3.png),![offer62-4.png](https://pic.leetcode-cn.com/1599801585-VESoOJ-offer62-4.png),![offer62-5.png](https://pic.leetcode-cn.com/1599801585-nMRCDw-offer62-5.png),![offer62-6.png](https://pic.leetcode-cn.com/1599801585-Cekqsv-offer62-6.png)>

### 花絮

![offer62.mp4](3ea76aff-98dd-46ec-aaee-8d47ec842168)


## 剑指 Offer 63. 股票的最大利润

>https://leetcode.cn/problems/gu-piao-de-zui-da-li-run-lcof/
<p>假设把某股票的价格按照时间先后顺序存储在数组中，请问买卖该股票一次可能获得的最大利润是多少？</p>

<p>&nbsp;</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入:</strong> [7,1,5,3,6,4]
<strong>输出:</strong> 5
<strong>解释: </strong>在第 2 天（股票价格 = 1）的时候买入，在第 5 天（股票价格 = 6）的时候卖出，最大利润 = 6-1 = 5 。
     注意利润不能是 7-1 = 6, 因为卖出价格需要大于买入价格。
</pre>

<p><strong>示例 2:</strong></p>

<pre><strong>输入:</strong> [7,6,4,3,1]
<strong>输出:</strong> 0
<strong>解释: </strong>在这种情况下, 没有交易完成, 所以最大利润为 0。</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<p><code>0 &lt;= 数组长度 &lt;= 10^5</code></p>

<p>&nbsp;</p>

<p><strong>注意：</strong>本题与主站 121 题相同：<a href="https://leetcode-cn.com/problems/best-time-to-buy-and-sell-stock/">https://leetcode-cn.com/problems/best-time-to-buy-and-sell-stock/</a></p>


### 剑指 Offer 63. 股票的最大利润 - 解决方案
## 题目描述

假设把某股票的价格按照时间先后顺序存储在数组中，请问买卖该股票一次可能获得的最大利润是多少？

示例 1:

```
输入: [7,1,5,3,6,4]
输出: 5
解释: 在第 2 天（股票价格 = 1）的时候买入，在第 5 天（股票价格 = 6）的时候卖出，最大利润 = 6-1 = 5 。
     注意利润不能是 7-1 = 6, 因为卖出价格需要大于买入价格。
```

示例 2:

```text
输入: [7,6,4,3,1]
输出: 0
解释: 在这种情况下, 没有交易完成, 所以最大利润为 0。
```

限制：

`0 <= 数组长度 <= 10^5`


## 解题方案

### 思路

- 标签：动态规划
- 整体思路：
  - 根据题意如果将第x天买，第y天卖进行穷举的话，需要$O(n^2)$的时间复杂度，所以考虑使用动态规划来降低
- 复杂度：
  - 时间复杂度：$O(n)$。动态规划需要遍历数组一次
  - 空间复杂度：$O(1)$。只需要记录最小花费和最大收益

### 算法流程

1. 状态定义： F[n] 表示 prices 中 0-n 下标的子数组的最大利润
2. 转移方程： 

- 前 n 天的最大利润 = max(前 n-1 天的最大利润，第 n 天的价格 - 前 n 天的最低价格)
- $F[n] = max(F(n-1), min(prices[n], minCost))$

3. 初始状态： F[0] = 0
4. 其中只需要记录 minCost 和 F(n-1) 这两个内容即可，不需要留存之前的动态规划记录，进而将空间复杂度从$O(n)$降低到了$O(1)$

### 代码

```Java []
class Solution {
    public int maxProfit(int[] prices) {
        int minCost = Integer.MAX_VALUE;
        int maxBenefit = 0;
        for(int price : prices) {
            minCost = Math.min(minCost, price);
            maxBenefit = Math.max(maxBenefit, price - minCost);
        }
        return maxBenefit;
    }
}
```

```JavaScript []
/**
 * @param {number[]} prices
 * @return {number}
 */
var maxProfit = function(prices) {
    let minCost = Number.MAX_SAFE_INTEGER;
    let maxBenefit = 0;
    for(const price of prices) {
        minCost = Math.min(minCost, price);
        maxBenefit = Math.max(maxBenefit, price - minCost);
    }
    return maxBenefit;
};
```

### 画解

<![offer63-1.png](https://pic.leetcode-cn.com/1599052405-KDMust-offer63-1.png),![offer63-2.png](https://pic.leetcode-cn.com/1599052405-YeiVpp-offer63-2.png),![offer63-3.png](https://pic.leetcode-cn.com/1599052405-JzeMGr-offer63-3.png),![offer63-4.png](https://pic.leetcode-cn.com/1599052405-PYSIBD-offer63-4.png),![offer63-5.png](https://pic.leetcode-cn.com/1599052405-gNkmYR-offer63-5.png),![offer63-6.png](https://pic.leetcode-cn.com/1599052405-GWAYRR-offer63-6.png),![offer63-7.png](https://pic.leetcode-cn.com/1599052405-yEOebS-offer63-7.png),![offer63-8.png](https://pic.leetcode-cn.com/1599052405-TRhjCH-offer63-8.png),![offer63-9.png](https://pic.leetcode-cn.com/1599052405-itkXgZ-offer63-9.png),![offer63-10.png](https://pic.leetcode-cn.com/1599052405-wiyhwb-offer63-10.png),![offer63-11.png](https://pic.leetcode-cn.com/1599052405-CuVVet-offer63-11.png),![offer63-12.png](https://pic.leetcode-cn.com/1599052405-MQiZiM-offer63-12.png),![offer63-13.png](https://pic.leetcode-cn.com/1599052405-AHMhMz-offer63-13.png),![offer63-14.png](https://pic.leetcode-cn.com/1599052405-ApnBGI-offer63-14.png)>


### 花絮

![offer63.mp4](8cad500e-58b2-488d-b17c-e717af701f0a)



# 树


## 剑指 Offer 68 - I. 二叉搜索树的最近公共祖先

>https://leetcode.cn/problems/er-cha-sou-suo-shu-de-zui-jin-gong-gong-zu-xian-lcof/
<p>给定一个二叉搜索树, 找到该树中两个指定节点的最近公共祖先。</p>

<p><a href="https://baike.baidu.com/item/%E6%9C%80%E8%BF%91%E5%85%AC%E5%85%B1%E7%A5%96%E5%85%88/8918834?fr=aladdin" target="_blank">百度百科</a>中最近公共祖先的定义为：&ldquo;对于有根树 T 的两个结点 p、q，最近公共祖先表示为一个结点 x，满足 x 是 p、q 的祖先且 x 的深度尽可能大（<strong>一个节点也可以是它自己的祖先</strong>）。&rdquo;</p>

<p>例如，给定如下二叉搜索树:&nbsp; root =&nbsp;[6,2,8,0,4,7,9,null,null,3,5]</p>

<p><img alt="" src="https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/12/14/binarysearchtree_improved.png"></p>

<p>&nbsp;</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入:</strong> root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 8
<strong>输出:</strong> 6 
<strong>解释: </strong>节点 <code>2 </code>和节点 <code>8 </code>的最近公共祖先是 <code>6。</code>
</pre>

<p><strong>示例 2:</strong></p>

<pre><strong>输入:</strong> root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 4
<strong>输出:</strong> 2
<strong>解释: </strong>节点 <code>2</code> 和节点 <code>4</code> 的最近公共祖先是 <code>2</code>, 因为根据定义最近公共祖先节点可以为节点本身。</pre>

<p>&nbsp;</p>

<p><strong>说明:</strong></p>

<ul>
	<li>所有节点的值都是唯一的。</li>
	<li>p、q 为不同节点且均存在于给定的二叉搜索树中。</li>
</ul>

<p>注意：本题与主站 235 题相同：<a href="https://leetcode-cn.com/problems/lowest-common-ancestor-of-a-binary-search-tree/">https://leetcode-cn.com/problems/lowest-common-ancestor-of-a-binary-search-tree/</a></p>


### 剑指 Offer 68 - I. 二叉搜索树的最近公共祖先  - 解决方案
## 题目描述

给定一个二叉搜索树, 找到该树中两个指定节点的最近公共祖先。

百度百科中最近公共祖先的定义为：“对于有根树 T 的两个结点 p、q，最近公共祖先表示为一个结点 x，满足 x 是 p、q 的祖先且 x 的深度尽可能大（一个节点也可以是它自己的祖先）。”

例如，给定如下二叉搜索树:  root = [6,2,8,0,4,7,9,null,null,3,5]

![](https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/12/14/binarysearchtree_improved.png)

**示例 1:**

```text
输入: root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 8
输出: 6
解释: 节点 2 和节点 8 的最近公共祖先是 6。
```

**示例 2:**

```text
输入: root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 4
输出: 2
解释: 节点 2 和节点 4 的最近公共祖先是 2, 因为根据定义最近公共祖先节点可以为节点本身。
```

**说明:**

- 所有节点的值都是唯一的。
- p、q 为不同节点且均存在于给定的二叉搜索树中。

## 解题方案

### 思路

- 标签：二叉搜索树
- 整体思路：
  - 祖先节点定义：当前节点的父节点，其父节点的父节点，只要当前节点在某一个节点的子树下，则可以称其为当前节点的祖先节点
  - 公共祖先定义：`p`、`q` 节点都在某一个节点的子树下或者其自身，则可以称其为 `p`、`q` 节点的公共祖先节点
  - 最近公共祖先定义：从祖先节点的定义可以知道，如果 `x` 节点是 `p`、`q` 节点的公共祖先，那么 `x` 节点的祖先节点也一定是 `p`、`q` 节点的公共祖先，则距离 `p`、`q` 个节点深度最小的为最近公共祖先，通常表现为 `p`、`q` 节点不在最近公共祖先的同一个子树上
  - 根据题意可知，树是二叉搜索树，所有的节点值唯一，则可以根据 `p`、`q` 节点不在最近公共祖先的同一个子树上的特征，进行循环遍历，找到结果
- 时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程

1. 首先在同一个二叉树上的 `p`、`q` 节点一定存在最近公共祖先，所以定义一个循环直到找到该节点为止
2. 如果 `root.val > p.val && root.val > q.val`，说明 `p`、`q` 节点都在 `root` 节点的左子树上，令 `root = root.left`，继续查询
3. 如果 `root.val < p.val && root.val < q.val`，说明 `p`、`q` 节点都在 `root` 节点的右子树上，令 `root = root.right`，继续查询
4. 如果 `root.val == p.val`，说明 `p` 节点就是最近公共祖先
5. 如果 `root.val == q.val`，说明 `q` 节点就是最近公共祖先
6. 如果 `root.val > p.val && root.val < q.val` 或者 `root.val < p.val && root.val > q.val`，说明 `root` 节点就是最近公共祖先
7. 4、5、6 三部分可以合并为其他情况，直接返回 `root` 即可

### 代码

```Java []
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
class Solution {
    public TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        while (true) {
            if (root.val > p.val && root.val > q.val) {
                root = root.left;
            } else if (root.val < p.val && root.val < q.val) {
                root = root.right;
            } else {
                return root;
            }
        }
    }
}
```

### 画解

<![offer68-1-1.png](https://pic.leetcode-cn.com/57e71e1a6d0e4227e7a31ad44c03b685382002a42e41b4de8fa759e6cdc43f26-offer68-1-1.png),![offer68-1-2.png](https://pic.leetcode-cn.com/2662c7520ed64cc962477d86dde5584c6f967c3a32da35be53795a4041480292-offer68-1-2.png),![offer68-1-3.png](https://pic.leetcode-cn.com/cf330e832fe44a7a5a94e706469185c5a6f567bba8e53fadca80081db7411c50-offer68-1-3.png),![offer68-1-4.png](https://pic.leetcode-cn.com/43d706753f712e5085948a7a589c258f4c2ce40eb1740aed76a2970e6c361d5c-offer68-1-4.png)>

### 花絮

![offer68-1.mp4](8950fdde-9033-474d-9675-a74118c24918)


## 剑指 Offer 68 - II. 二叉树的最近公共祖先

>https://leetcode.cn/problems/er-cha-shu-de-zui-jin-gong-gong-zu-xian-lcof/
<p>给定一个二叉树, 找到该树中两个指定节点的最近公共祖先。</p>

<p><a href="https://baike.baidu.com/item/%E6%9C%80%E8%BF%91%E5%85%AC%E5%85%B1%E7%A5%96%E5%85%88/8918834?fr=aladdin" target="_blank">百度百科</a>中最近公共祖先的定义为：&ldquo;对于有根树 T 的两个结点 p、q，最近公共祖先表示为一个结点 x，满足 x 是 p、q 的祖先且 x 的深度尽可能大（<strong>一个节点也可以是它自己的祖先</strong>）。&rdquo;</p>

<p>例如，给定如下二叉树:&nbsp; root =&nbsp;[3,5,1,6,2,0,8,null,null,7,4]</p>

<p><img alt="" src="https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/12/15/binarytree.png"></p>

<p>&nbsp;</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入:</strong> root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 1
<strong>输出:</strong> 3
<strong>解释: </strong>节点 <code>5 </code>和节点 <code>1 </code>的最近公共祖先是节点 <code>3。</code>
</pre>

<p><strong>示例&nbsp;2:</strong></p>

<pre><strong>输入:</strong> root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 4
<strong>输出:</strong> 5
<strong>解释: </strong>节点 <code>5 </code>和节点 <code>4 </code>的最近公共祖先是节点 <code>5。</code>因为根据定义最近公共祖先节点可以为节点本身。
</pre>

<p>&nbsp;</p>

<p><strong>说明:</strong></p>

<ul>
	<li>所有节点的值都是唯一的。</li>
	<li>p、q 为不同节点且均存在于给定的二叉树中。</li>
</ul>

<p>注意：本题与主站 236 题相同：<a href="https://leetcode-cn.com/problems/lowest-common-ancestor-of-a-binary-tree/">https://leetcode-cn.com/problems/lowest-common-ancestor-of-a-binary-tree/</a></p>


### 剑指 Offer 68 - II. 二叉树的最近公共祖先 - 解决方案
## 题目描述

给定一个二叉树, 找到该树中两个指定节点的最近公共祖先。

百度百科中最近公共祖先的定义为：“对于有根树 T 的两个结点 p、q，最近公共祖先表示为一个结点 x，满足 x 是 p、q 的祖先且 x 的深度尽可能大（一个节点也可以是它自己的祖先）。”

例如，给定如下二叉树:  root = [3,5,1,6,2,0,8,null,null,7,4]

![](https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/12/15/binarytree.png)

**示例 1:**

```text
输入: root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 1
输出: 3
解释: 节点 5 和节点 1 的最近公共祖先是节点 3。
```

**示例  2:**

```text
输入: root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 4
输出: 5
解释: 节点 5 和节点 4 的最近公共祖先是节点 5。因为根据定义最近公共祖先节点可以为节点本身。
```

**说明:**

- 所有节点的值都是唯一的。
- p、q 为不同节点且均存在于给定的二叉树中。

## 解题方案

### 思路

- 标签：二叉树、DFS
- 整体思路：
  - 祖先节点定义：当前节点的父节点，其父节点的父节点，只要当前节点在某一个节点的子树下，则可以称其为当前节点的祖先节点
  - 公共祖先定义：`p`、`q` 节点都在某一个节点的子树下或者其自身，则可以称其为 `p`、`q` 节点的公共祖先节点
  - 最近公共祖先定义：从祖先节点的定义可以知道，如果 `x` 节点是 `p`、`q` 节点的公共祖先，那么 `x` 节点的祖先节点也一定是 `p`、`q` 节点的公共祖先，则距离 `p`、`q` 个节点深度最小的为最近公共祖先，通常表现为 `p`、`q` 节点不在最近公共祖先的同一个子树上
  - 根据题意可知，所有的节点值唯一，则可以根据 `p`、`q` 节点不在最近公共祖先的同一个子树上的特征，进行深度优先遍历，找到结果
- 时间复杂度：$O(n)$，空间复杂度：$O(n)$

### 算法流程

1. 终止条件：

- 当 `root` 节点为 `null` 时，说明到达叶子节点的下一层，直接返回 `null` 即可
- 当 `root` 节点为 `p` 或 `q` 时，说明找到了对应的节点，返回 `root` 即可

2. 递归内容：

- 递归左子树 `root.left`，得到左子树返回值 `left`
- 递归右子树 `root.right`，得到右子树返回值 `right`

3. 返回值：

- 当 `left` 和 `right` 都为 `null` 时，说明当前层 `root` 的左右子树不包含 `p`、`q` 节点，返回 `null` 即可
- 当 `left` 为 `null` 且 `right` 不为 `null` 时，说明当前层 `root` 的左子树不包含 `p`、`q` 节点，右子树包含 `p`、`q` 节点，则返回右子树 `right`
- 当 `left` 不为 `null` 且 `right` 为 `null` 时，说明当前层 `root` 的左子树包含 `p`、`q` 节点，右子树不包含 `p`、`q` 节点，则返回左子树 `left`
- 当 `left` 和 `right` 都不为 `null` 时，说明当前层 `root` 的左右子树均包含 `p`、`q` 节点，返回 `root` 即可


### 代码

```Java []
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
class Solution {
    public TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        if(root == null || root == p || root == q) {
            return root;
        }
        TreeNode left = lowestCommonAncestor(root.left, p, q);
        TreeNode right = lowestCommonAncestor(root.right, p, q);
        if(left == null && right == null) {
            return null;
        } else if(left == null && right != null) {
            return right;
        } else if(left != null && right == null) {
            return left;
        } else {
            return root;
        }
    }
}
```

### 画解

<![offer68-2-1.png](https://pic.leetcode-cn.com/f40dcbc42c5a5eb9087f08e0ac2f4602fa6349d55db3810631ffb467b14ce83f-offer68-2-1.png),![offer68-2-2.png](https://pic.leetcode-cn.com/fb95d0464aff5f68c83537c6d738e16ca323978138c4340c63400b1b9e816742-offer68-2-2.png),![offer68-2-3.png](https://pic.leetcode-cn.com/7895cde267e94d8205536f8d8dde553d73d825347c4ed52fe9a76100a5a8b1c8-offer68-2-3.png),![offer68-2-4.png](https://pic.leetcode-cn.com/aeecdd4896473261d7ddba898c106cadb93541c02063ecaec270fa0b11718227-offer68-2-4.png),![offer68-2-5.png](https://pic.leetcode-cn.com/486d0a12995c1a46e105070b31e1698671fbce40ed0ca2ab2643c977115e3e4d-offer68-2-5.png),![offer68-2-6.png](https://pic.leetcode-cn.com/37a1f22464c39e9928b7085b44a6c7cb28f0b10447ab0a50fd31dff33aaa2ce5-offer68-2-6.png),![offer68-2-7.png](https://pic.leetcode-cn.com/830d072aa78ae27b81b91bf303504f7b87c873a4a999be9a75552dd6ab718d55-offer68-2-7.png),![offer68-2-8.png](https://pic.leetcode-cn.com/82202685ac6294099a264958de6aa33be217c2eb2eefe4ca295d3e891aac0141-offer68-2-8.png),![offer68-2-9.png](https://pic.leetcode-cn.com/f806477c965783a48e85dd59977d4e73bd5d826dbafbfe68ad6e318a85ffbedd-offer68-2-9.png),![offer68-2-10.png](https://pic.leetcode-cn.com/58ed033154805ee73547dbefd09a3394779dc71cc6074a4f5c5ea47f5bed7bb7-offer68-2-10.png),![offer68-2-11.png](https://pic.leetcode-cn.com/f7e9a4c0b1f6ba917181cf6867794a489b9458adf2a450aa9fa4d34bf57c3e6d-offer68-2-11.png)>

### 花絮

![offer68-2.mp4](ded451ac-d289-4cf3-a8f6-b01935f9e9fb)



# 位运算


## 剑指 Offer 15. 二进制中 1 的个数

>https://leetcode.cn/problems/er-jin-zhi-zhong-1de-ge-shu-lcof/
<p>编写一个函数，输入是一个无符号整数（以二进制串的形式），返回其二进制表达式中数字位数为 '1' 的个数（也被称为 <a href="http://en.wikipedia.org/wiki/Hamming_weight" target="_blank">汉明重量</a>).）。</p>

<p> </p>

<p><strong>提示：</strong></p>

<ul>
	<li>请注意，在某些语言（如 Java）中，没有无符号整数类型。在这种情况下，输入和输出都将被指定为有符号整数类型，并且不应影响您的实现，因为无论整数是有符号的还是无符号的，其内部的二进制表示形式都是相同的。</li>
	<li>在 Java 中，编译器使用 <a href="https://baike.baidu.com/item/二进制补码/5295284">二进制补码</a> 记法来表示有符号整数。因此，在上面的 <strong>示例 3 </strong>中，输入表示有符号整数 <code>-3</code>。</li>
</ul>

<p> </p>

<p><strong>示例 1：</strong></p>

<pre>
<strong>输入：</strong>n = 11 (控制台输入 00000000000000000000000000001011)
<strong>输出：</strong>3
<strong>解释：</strong>输入的二进制串 <code><strong>00000000000000000000000000001011</strong> 中，共有三位为 '1'。</code>
</pre>

<p><strong>示例 2：</strong></p>

<pre>
<strong>输入：</strong>n = 128 (控制台输入 00000000000000000000000010000000)
<strong>输出：</strong>1
<strong>解释：</strong>输入的二进制串 <strong>00000000000000000000000010000000</strong> 中，共有一位为 '1'。
</pre>

<p><strong>示例 3：</strong></p>

<pre>
<strong>输入：</strong>n = 4294967293 (控制台输入 11111111111111111111111111111101，部分语言中 n = -3）
<strong>输出：</strong>31
<strong>解释：</strong>输入的二进制串 <strong>11111111111111111111111111111101</strong> 中，共有 31 位为 '1'。</pre>

<p> </p>

<p><strong>提示：</strong></p>

<ul>
	<li>输入必须是长度为 <code>32</code> 的 <strong>二进制串</strong> 。</li>
</ul>

<p> </p>

<p>注意：本题与主站 191 题相同：<a href="https://leetcode-cn.com/problems/number-of-1-bits/">https://leetcode-cn.com/problems/number-of-1-bits/</a></p>


### 剑指 Offer 15. 二进制中 1 的个数 - 解决方案
## 题目描述

请实现一个函数，输入一个整数，输出该数二进制表示中 1 的个数。例如，把 9  表示成二进制是 1001，有 2 位是 1。因此，如果输入 9，则该函数输出 2。

示例 1：

```text
输入：00000000000000000000000000001011
输出：3
解释：输入的二进制串 00000000000000000000000000001011 中，共有三位为 '1'。
```

示例 2：

```text
输入：00000000000000000000000010000000
输出：1
解释：输入的二进制串 00000000000000000000000010000000 中，共有一位为 '1'。
```

示例 3：

```text
输入：11111111111111111111111111111101
输出：31
解释：输入的二进制串 11111111111111111111111111111101 中，共有 31 位为 '1'。
```

注意：本题与主站 [191 题](https://leetcode-cn.com/problems/number-of-1-bits/) 相同

## 解题方案

### 思路 1

- 标签：位运算
- 整体思路：通过与 1 进行与运算，可以判断末位是不是 1，然后将数字进行无符号右移，最终当数字变成 0 时结束判断
- n 表示数字的位数，时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程 1

1. 首先注意力扣在代码模板中标注了 `n` 是一个无符号数，如果 `n` 可能是负数还需要另行讨论
2. 初始化计数器 `count` 为 0
3. 无符号数 `n` 与 `1` 进行与运算，如果 `n & 1 == 1​`，说明 n 的末位为 1，则 `count` 加一，如果 ​`n & 1 == 0`，说明 `n` 的末位为 `0`，则 `count` 不变
4. 判断完末位之后，将 `n = n >>> 1​` 进行无符号右移，更新末位
5. 当 `n == 0​` 时，结束判断

### 代码 1

```Java []
public class Solution {
    // you need to treat n as an unsigned value
    public int hammingWeight(int n) {
        int count = 0;
        while(n != 0) {
            count += n & 1;
            n = n >>> 1;
        }
        return count;
    }
}
```

### 画解 1

<![offer15-1-1.png](https://pic.leetcode-cn.com/69e98660f3c7a0e21b8ea5a0f27b919b4ed88c85b1e421dc87b20bbc35583029-offer15-1-1.png),![offer15-1-2.png](https://pic.leetcode-cn.com/b88b08a7078f881a0bde998f126b9de2fe48407354a4b4a3592693c7ebf97946-offer15-1-2.png),![offer15-1-3.png](https://pic.leetcode-cn.com/908f2ba2b7ca5dfd9d97bc5b857e0b120bdec6a25396108dc000028a8f44602f-offer15-1-3.png),![offer15-1-4.png](https://pic.leetcode-cn.com/d5b231d5f9fa74076d6c052e5eae76ea9c13d964709d873aa8b89bcfd6e1d4e6-offer15-1-4.png),![offer15-1-5.png](https://pic.leetcode-cn.com/9ba7e4dcba29befd5b659854f62c4f848b92db2505386c3b524fb20df352ea8a-offer15-1-5.png),![offer15-1-6.png](https://pic.leetcode-cn.com/c410cb65782b720d06b6c62e9c257a6a47f0c021036593e35c8b47ec18923b42-offer15-1-6.png),![offer15-1-7.png](https://pic.leetcode-cn.com/7ce6bc65f963e904dca0eac3323c0a13eb164fd7aee222c63dd9e54d98ef30e1-offer15-1-7.png),![offer15-1-8.png](https://pic.leetcode-cn.com/e5596a262fd3720b10756ecc7c50a07df454508175d78fb2f0c31654f2d1de3c-offer15-1-8.png),![offer15-1-9.png](https://pic.leetcode-cn.com/7e0d4268565032fd1e4cc86243af39c4b5d80b4e649791eb5b09c8bb84db74cb-offer15-1-9.png),![offer15-1-10.png](https://pic.leetcode-cn.com/8b751f54f6068e12315196773c1da136647fb3e056abca332712367a9e8feb63-offer15-1-10.png),![offer15-1-11.png](https://pic.leetcode-cn.com/62d1420c0b335fbb3e6074cfa4180c6d4a82a76c3346391ca0a7b08ecf43db4b-offer15-1-11.png),![offer15-1-12.png](https://pic.leetcode-cn.com/29b299ebdd959e15da120339b0c8cc107bb0b63e2b7cad4205a0f7ec8ec7c535-offer15-1-12.png),![offer15-1-13.png](https://pic.leetcode-cn.com/225574ffb0a52dcfe80018f3ffadbc3e1defdd96e9e19289f0adf5a7f2778765-offer15-1-13.png),![offer15-1-14.png](https://pic.leetcode-cn.com/07a7a3340cb3f504a05d2c7bff412e7cae36933009971e2c36f00b605662d0d5-offer15-1-14.png),![offer15-1-15.png](https://pic.leetcode-cn.com/0335bdde8f0497a9b236752f3ed2b87da703b5ba8c5fc146e4582e1964ecb79d-offer15-1-15.png),![offer15-1-16.png](https://pic.leetcode-cn.com/f50a594666b5254f386494d95701556ac126bedac1f404428719aea1cc9cda25-offer15-1-16.png)>


### 思路 2

- 标签：位运算
- 整体思路：通过与 `n = n & (n - 1)​` 的运算直接获取最后一位为 1 的位置，减少时间复杂度
- n 表示数字中包含 1 的位数，时间复杂度：$O(n)$，空间复杂度：$O(1)$

### 算法流程 2

1. 首先注意力扣在代码模板中标注了 `n` 是一个无符号数，如果 `n` 可能是负数还需要另行讨论
2. 初始化计数器 `count` 为 0
3. `n = n & (n - 1)` 的运算可以直接获取到当前数字最后一位为 1 的位置，同时更新 `n`
4. 当 `n == 0​` 时，结束判断

### 代码 2

```Java []
public class Solution {
    // you need to treat n as an unsigned value
    public int hammingWeight(int n) {
        int count = 0;
        while(n != 0) {
            count++;
            n = n & (n - 1);
        }
        return count;
    }
}
```

### 画解 2

<![offer15-2-1.png](https://pic.leetcode-cn.com/267e7831b29f172bd246e38feb5541a001935c62f2b2363454b3f5247750afb7-offer15-2-1.png),![offer15-2-2.png](https://pic.leetcode-cn.com/d124e287e882428055a3e05c9b9029a2810cf3fb5a0e35fba9d8c87a70362f28-offer15-2-2.png),![offer15-2-3.png](https://pic.leetcode-cn.com/631eaddfd6df4f3aca273cc63b3829ec5d17dd9b203c3f2f5647b828e88a36b3-offer15-2-3.png),![offer15-2-4.png](https://pic.leetcode-cn.com/a083c5819669ae118341f10d6117c9256c58aa21dfea2305ece01b0d0f506ea7-offer15-2-4.png),![offer15-2-5.png](https://pic.leetcode-cn.com/e49da9f8bc263a79671cedc09e7e00447a7541131af45e24e277d493c95c5591-offer15-2-5.png),![offer15-2-6.png](https://pic.leetcode-cn.com/0fad0920fd4bbd780a5b6736ec01213a15b2c2ecf2c1e18bf4872861f8d8e91b-offer15-2-6.png),![offer15-2-7.png](https://pic.leetcode-cn.com/822c6913c61744e1c3bf57a2ff1794501f95774535b106e9ce815b44f58318b8-offer15-2-7.png),![offer15-2-8.png](https://pic.leetcode-cn.com/58b672c995503f78ebb6dbdfd1713d77d564ecf4382e7d6e234c45b835c99bc6-offer15-2-8.png)>

### 花絮

![offer15-2.mp4](d25afac6-78ec-4c5c-a547-a17c1e49795f)


## 剑指 Offer 16. 数值的整数次方

>https://leetcode.cn/problems/shu-zhi-de-zheng-shu-ci-fang-lcof/
<p>实现 <a href="https://www.cplusplus.com/reference/valarray/pow/">pow(<em>x</em>, <em>n</em>)</a> ，即计算 x 的 n 次幂函数（即，x<sup>n</sup>）。不得使用库函数，同时不需要考虑大数问题。</p>

<p> </p>

<p><strong>示例 1：</strong></p>

<pre>
<strong>输入：</strong>x = 2.00000, n = 10
<strong>输出：</strong>1024.00000
</pre>

<p><strong>示例 2：</strong></p>

<pre>
<strong>输入：</strong>x = 2.10000, n = 3
<strong>输出：</strong>9.26100</pre>

<p><strong>示例 3：</strong></p>

<pre>
<strong>输入：</strong>x = 2.00000, n = -2
<strong>输出：</strong>0.25000
<strong>解释：</strong>2<sup>-2</sup> = 1/2<sup>2</sup> = 1/4 = 0.25</pre>

<p> </p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>-100.0 < x < 100.0</code></li>
	<li><code>-2<sup>31</sup> <= n <= 2<sup>31</sup>-1</code></li>
	<li><code>-10<sup>4</sup> <= x<sup>n</sup> <= 10<sup>4</sup></code></li>
</ul>

<p> </p>

<p>注意：本题与主站 50 题相同：<a href="https://leetcode-cn.com/problems/powx-n/">https://leetcode-cn.com/problems/powx-n/</a></p>


### 剑指 Offer 16. 数值的整数次方 - 解题思路
## 题目描述

实现函数 double Power(double base, int exponent)，求 base 的 exponent 次方。不得使用库函数，同时不需要考虑大数问题。

**示例 1:**

```text
输入: 2.00000, 10
输出: 1024.00000
```

**示例 2:**

```text
输入: 2.10000, 3
输出: 9.26100
```

**示例 3:**

```text
输入: 2.00000, -2
输出: 0.25000
解释: $ 2-2 = 1/x^2 = 1/4 = 0.25 $
```

## 解题方案

### 思路

- 标签：快速幂
- 整体思路：
  - 直接求 x 的 n 次方是通过循环将 n 个 x 做乘积，时间复杂度为 $O(n)$，快速幂法 可将时间复杂度降低至 $O(log_n)$
  - 利用十进制数字 n 的二进制表示，可对快速幂进行数学化解释。
- 复杂度：
  - 时间复杂度：$O(log_n)$。
  - 空间复杂度：

### 算法流程

1. 对于任何十进制正整数 n ，设其二进制为 $b_k...b_3b_2b_1$ ($b_i$ 为二进制某位值，$i / n i∈[1,k]$)，则有：
    - 二进制转十进制：$n = b_1+2b_2+4b_3+...+2^{k-1}b_k$ 
    - 幂的二进制展开：$x^n = x^{b_1+2b_2+4b_3+...+2^{k-1}b_k} = x^{b_1}x^{2b_2}x^{4b_3}x^{2^{k-1}b_k}$
2. 根据以上推导，可把计算 $x^n$ 转化为解决以下两个问题：
    - 计算 $x^1,x^2,...,x^{2k-1}$ 的值：循环赋值操作 $x = x^2$
    - 获取二进制各位的值：循环
        - 1. 判断二进制最右一位是否为 1；
        - 2. n 右移一位；

### 代码

```Java []
class Solution {
    public double myPow(double x, int n) {
        if(x == 0.0f) return 0.0d;
        long b = n;
        double result = 1.0;
        if(b < 0) {
            x = 1 / x;
            b = -b;
        }
        while(b > 0) {
            if((b & 1) == 1) result *= x;
            x *= x;
            b >>= 1;
        }
        return result;
    }
}
```

### 画解

<![offer16-1.png](https://pic.leetcode-cn.com/1607943954-BSyXuC-offer16-1.png),![offer16-2.png](https://pic.leetcode-cn.com/1607943954-XRMBSJ-offer16-2.png),![offer16-3.png](https://pic.leetcode-cn.com/1607943954-oASPjr-offer16-3.png),![offer16-4.png](https://pic.leetcode-cn.com/1607943954-YfxhOk-offer16-4.png),![offer16-5.png](https://pic.leetcode-cn.com/1607943954-aEgTAl-offer16-5.png),![offer16-6.png](https://pic.leetcode-cn.com/1607943954-vsgPsu-offer16-6.png),![offer16-7.png](https://pic.leetcode-cn.com/1607943954-RaSGVr-offer16-7.png),![offer16-8.png](https://pic.leetcode-cn.com/1607943954-pmJGpx-offer16-8.png),![offer16-9.png](https://pic.leetcode-cn.com/1607943954-jhSJsv-offer16-9.png),![offer16-10.png](https://pic.leetcode-cn.com/1607943954-PtoVgF-offer16-10.png),![offer16-11.png](https://pic.leetcode-cn.com/1607943954-rLxNMd-offer16-11.png),![offer16-12.png](https://pic.leetcode-cn.com/1607943954-BhtFFH-offer16-12.png),![offer16-13.png](https://pic.leetcode-cn.com/1607943954-Vvcgov-offer16-13.png),![offer16-14.png](https://pic.leetcode-cn.com/1607943954-cMrqBE-offer16-14.png)>

### 花絮

![offer16.mp4](c5f76e8a-c103-4735-bfad-8ece0180cd42)


## 剑指 Offer 56 - I. 数组中数字出现的次数

>https://leetcode.cn/problems/shu-zu-zhong-shu-zi-chu-xian-de-ci-shu-lcof/
<p>一个整型数组 <code>nums</code> 里除两个数字之外，其他数字都出现了两次。请写程序找出这两个只出现一次的数字。要求时间复杂度是O(n)，空间复杂度是O(1)。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>nums = [4,1,4,6]
<strong>输出：</strong>[1,6] 或 [6,1]
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>nums = [1,2,10,4,1,4,3,3]
<strong>输出：</strong>[2,10] 或 [10,2]</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<ul>
	<li><code>2 &lt;= nums.length &lt;= 10000</code></li>
</ul>

<p>&nbsp;</p>


### 剑指 Offer 56 - I. 数组中数字出现的次数 - 解决方案
## 题目描述

一个整型数组 `nums` 里除两个数字之外，其他数字都出现了两次。请写程序找出这两个只出现一次的数字。要求时间复杂度是 O(n)，空间复杂度是 O(1)。

示例 1：

```text
输入：nums = [4,1,4,6]
输出：[1,6] 或 [6,1]
```

示例 2：

```text
输入：nums = [1,2,10,4,1,4,3,3]
输出：[2,10] 或 [10,2]
```

限制：

- `2 <= nums.length <= 10000`

## 解题方案

### 思路

- 标签：位运算
- 整体思路：
  - 求解一个只出现一次的数字是非常容易的，只需要将所有数字进行一次异或运算即可，这个是求解这道题的前置知识，如果不了解可以查看 [136. 只出现一次的数字](https://leetcode-cn.com/problems/single-number/)
  - 如果程序中存在两个只出现一次的数字，那么进行所有数字的异或运算之后，就会剩下这两个数字的异或结果
  - 异或运算上某一位如果为 1，则说明这两个值在这一位上是不同的，那么可以根据这个特性，将数组中的数字分成 2 组，分别进行异或运算就可以得到最终的两个数字
- 复杂度：
  - 时间复杂度：$O(n)$。第一次异或需要遍历一次数组，第二次分组需要遍历一次数组
  - 空间复杂度：$O(1)$。只需要保存第一次的数组和还有异或位即可

### 算法流程

1. 首先初始化异或结果 tmp，进行数组遍历，完成所有数字的异或运算
2. 初始化异或位 div，从最低位开始，找到第一位为1的结果
3. 再次遍历数组，根据 `div & num` 运算进行数字分组，组内进行异或运算，最终得到两组的结果 a、b 即为最终的结果

### 代码

```Java []
class Solution {
    public int[] singleNumbers(int[] nums) {
        int tmp = 0;
        for (int num: nums) {
            tmp ^= num;
        }
        int div = 1;
        while ((div & tmp) == 0) {
            div <<= 1;
        }
        int a = 0;
        int b = 0;
        for (int num: nums) {
            if ((div & num) == 0) {
                a ^= num;
            }
            else {
                b ^= num;
            }
        }

        return new int[]{a, b};
    }
}
```

### 画解

<![offer56-1-1.png](https://pic.leetcode-cn.com/1599801502-iNIuzL-offer56-1-1.png),![offer56-1-2.png](https://pic.leetcode-cn.com/1599801502-tgVPqW-offer56-1-2.png),![offer56-1-3.png](https://pic.leetcode-cn.com/1599801502-xVqwmE-offer56-1-3.png),![offer56-1-4.png](https://pic.leetcode-cn.com/1599801502-AffWOz-offer56-1-4.png),![offer56-1-5.png](https://pic.leetcode-cn.com/1599801502-mmwKga-offer56-1-5.png),![offer56-1-6.png](https://pic.leetcode-cn.com/1599801502-PfiSMX-offer56-1-6.png),![offer56-1-7.png](https://pic.leetcode-cn.com/1599801502-QIkQmP-offer56-1-7.png),![offer56-1-8.png](https://pic.leetcode-cn.com/1599801502-hAShfQ-offer56-1-8.png),![offer56-1-9.png](https://pic.leetcode-cn.com/1599801502-KQOisY-offer56-1-9.png),![offer56-1-10.png](https://pic.leetcode-cn.com/1599801502-yfbvdK-offer56-1-10.png),![offer56-1-11.png](https://pic.leetcode-cn.com/1599801502-uXDYon-offer56-1-11.png),![offer56-1-12.png](https://pic.leetcode-cn.com/1599801502-jiwSBr-offer56-1-12.png),![offer56-1-13.png](https://pic.leetcode-cn.com/1599801502-yvxhUL-offer56-1-13.png)>

### 花絮

![offer56-1.mp4](cb35639e-bd31-4deb-b437-ffc7872979ad)


## 剑指 Offer 65. 不用加减乘除做加法

>https://leetcode.cn/problems/bu-yong-jia-jian-cheng-chu-zuo-jia-fa-lcof/
<p>写一个函数，求两个整数之和，要求在函数体内不得使用 &ldquo;+&rdquo;、&ldquo;-&rdquo;、&ldquo;*&rdquo;、&ldquo;/&rdquo; 四则运算符号。</p>

<p>&nbsp;</p>

<p><strong>示例:</strong></p>

<pre><strong>输入:</strong> a = 1, b = 1
<strong>输出:</strong> 2</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>a</code>,&nbsp;<code>b</code>&nbsp;均可能是负数或 0</li>
	<li>结果不会溢出 32 位整数</li>
</ul>


### 剑指 Offer 65. 不用加减乘除做加法 - 解决方案
## 题目描述

写一个函数，求两个整数之和，要求在函数体内不得使用 “+”、“-”、“\*”、“/” 四则运算符号。

示例:

```text
输入: a = 1, b = 1
输出: 2
```

提示：

- `a`, `b`  均可能是负数或 0
- 结果不会溢出 32 位整数

## 解题方案

### 思路

- 标签：位运算
- 整体思路：
  - 这道题在不让用四则基础运算的基础上把结果算出来，说明只能利用二进制的位运算来求解
  - 其中无进位和用 `n` 表示，进位用 `c` 表示，$sum = a + b = n + c$，位运算可以分别计算出来这两个
  - 以 2 个 1 位的二进制数字求和为例，共有 4 种情况，观察下规律，进行位运算求和公式推导
  - 从表中可以看出来，无进位和 $n = a\bigoplus b$，进位 $c = a & b << 1$
  - 在 $sum = n + c$ 的计算中，还是使用了加法，进而这种加法运算可以再次使用位运算来解决，这里就是一个循环的思路
  - 循环结束的条件是$c = 0$，因为当$c = 0$时，$sum = n + c = n + 0 = n$的，所以`n`就是最终的结果

| a   | b   | 无进位和 n | 进位 c |
| --- | --- | ---------- | ------ |
| 0   | 0   | 0          | 0      |
| 0   | 1   | 1          | 0      |
| 1   | 0   | 1          | 0      |
| 1   | 1   | 0          | 10     |

- 复杂度：
  - 时间复杂度：$O(1)$。因为题目中提到结果不会溢出 32 位整数，所以最多进行 32 次循环
  - 空间复杂度：$O(1)$。只需要存储无进位和和进位即可

### 算法流程

1. 当进位不为 0 时进行循环
2. 使用公式 $c = a & b << 1$ 计算出进位值
3. 根据公式 $n = a \bigoplus b$ 求出无进位和
4. 无进位和和进位值依次放到 a、b 中，进行下一次循环

### 代码

```Java []
class Solution {
    public int add(int a, int b) {
        while(b != 0) {
            int carry = (a & b) << 1;
            int n = a ^ b;
            a = n;
            b = carry;
        }
        return a;

    }
}
```

### 画解

<![offer65-1.png](https://pic.leetcode-cn.com/1599052226-cuilTd-offer65-1.png),![offer65-2.png](https://pic.leetcode-cn.com/1599052226-mSFBbp-offer65-2.png),![offer65-3.png](https://pic.leetcode-cn.com/1599052226-VNIIYa-offer65-3.png),![offer65-4.png](https://pic.leetcode-cn.com/1599052226-SNxnqk-offer65-4.png),![offer65-5.png](https://pic.leetcode-cn.com/1599052226-wswDCw-offer65-5.png),![offer65-6.png](https://pic.leetcode-cn.com/1599052226-raTmLq-offer65-6.png),![offer65-7.png](https://pic.leetcode-cn.com/1599052226-LGGLpE-offer65-7.png),![offer65-8.png](https://pic.leetcode-cn.com/1599052226-jUvsZw-offer65-8.png),![offer65-9.png](https://pic.leetcode-cn.com/1599052226-bgpSER-offer65-9.png),![offer65-10.png](https://pic.leetcode-cn.com/1599052226-ulfCME-offer65-10.png),![offer65-11.png](https://pic.leetcode-cn.com/1599052226-KbYXVe-offer65-11.png),![offer65-12.png](https://pic.leetcode-cn.com/1599052226-hQhqZy-offer65-12.png),![offer65-13.png](https://pic.leetcode-cn.com/1599052226-gPOQol-offer65-13.png),![offer65-14.png](https://pic.leetcode-cn.com/1599052226-cMcaMy-offer65-14.png)>

### 花絮

![offer65.mp4](5ef3084e-e736-402e-83e1-0761154c04de)



# 递归


## 剑指 Offer 07. 重建二叉树

>https://leetcode.cn/problems/zhong-jian-er-cha-shu-lcof/
<p>输入某二叉树的前序遍历和中序遍历的结果，请构建该二叉树并返回其根节点。</p>

<p>假设输入的前序遍历和中序遍历的结果中都不含重复的数字。</p>

<p> </p>

<p><strong>示例 1:</strong></p>
<img alt="" src="https://assets.leetcode.com/uploads/2021/02/19/tree.jpg" />
<pre>
<strong>Input:</strong> preorder = [3,9,20,15,7], inorder = [9,3,15,20,7]
<strong>Output:</strong> [3,9,20,null,null,15,7]
</pre>

<p><strong>示例 2:</strong></p>

<pre>
<strong>Input:</strong> preorder = [-1], inorder = [-1]
<strong>Output:</strong> [-1]
</pre>

<p> </p>

<p><strong>限制：</strong></p>

<p><code>0 <= 节点个数 <= 5000</code></p>

<p> </p>

<p><strong>注意</strong>：本题与主站 105 题重复：<a href="https://leetcode-cn.com/problems/construct-binary-tree-from-preorder-and-inorder-traversal/">https://leetcode-cn.com/problems/construct-binary-tree-from-preorder-and-inorder-traversal/</a></p>


### 剑指 Offer 07. 重建二叉树 - 解决方案
## 题目描述

输入某二叉树的前序遍历和中序遍历的结果，请重建该二叉树。假设输入的前序遍历和中序遍历的结果中都不含重复的数字。

**示例 1:**

```text
例如，给出
前序遍历 preorder = [3,9,20,15,7]
中序遍历 inorder = [9,3,15,20,7]
返回如下的二叉树：

    3
   / \
  9  20
    /  \
   15   7
```

## 解题方案

### 思路

- 标签：递归
- 整体思路：
  - 根据二叉树的遍历特点可知：前序遍历首个元素为根节点；在中序遍历中可由根节点位置将其分为‘左子树’‘根节点’‘右子树’；在中序遍历中可知左右子树的节点数量。因此可以确定三个节点关系，根据树的特点，我们很自然的可以使用递归方法。
- 复杂度：
  - 时间复杂度：$O(n)$。 n 为树的节点数量。初始化 HashMap 需遍历 inOrder ，占用 $O(n)$ ；递归占用 $O(n)$ 。（最差情况为所有子树只有左节点，树转化为链表，此时递归深度 $O(n)$ ；平均情况下递归深度 $O(log_n)$。
  - 空间复杂度：$O(n)$。HashMap 使用 $O(n)$ 额外空间；递归操作需使用 $O(n)$ 额外空间。

### 算法流程

1. 递推参数： 前序遍历中根节点的索引 preRoot、中序遍历左边界 inLeft、中序遍历右边界 inRight。
2. 终止条件： 当 inLeft > inRight ，子树中序遍历为空，说明已经越过叶子节点，此时返回 null 。当 inLeft = inRight 时， 代表只有该节点本身。
3. - 由先序遍历中确定根节点 root
   - 左子树的根节点就是 左子树的（前序遍历）第一个，就是+1,左边边界就是 inLeft，右边边界是中间区分的根节点在中序中的索引 -1
   - 右子树的根，是右子树（前序遍历）的第一个，也就是当前根节点 加上左子树的数量
4. 返回 root

### 代码

```Java []
class Solution {
    HashMap<Integer, Integer> midMap = new HashMap<>();
    int[] preOrder;

    public TreeNode buildTree(int[] preOrder, int[] inOrder) {
        this.preOrder = preOrder;
        //为了提升搜索效率，使用哈希表存储中序遍历的值与索引的映射关系。
        for(int i = 0; i < preOrder.length; i++) {
            midMap.put(inOrder[i], i);
        }
        return build(0, 0, inOrder.length - 1);
    }

    public TreeNode build(int preRoot, int inLeft, int inRight) {
        //终止条件
        if(inLeft > inRight) {
            return null;
        }
        //构建根节点
        TreeNode root = new TreeNode(this.preOrder[preRoot]);

        //在中序map中获取根节点的索引
        int inRootIndex = midMap.get(this.preOrder[preRoot]);
        root.left = build(preRoot + 1, inLeft, inRootIndex - 1);
        root.right = build(preRoot + (inRootIndex - 1 - inLeft + 1) + 1, inRootIndex + 1, inRight);
        return root;
    }
}
```

### 画解

<![offer7-1.png](https://pic.leetcode-cn.com/1605489052-uXyjJd-offer7-1.png),![offer7-2.png](https://pic.leetcode-cn.com/1605489052-URWIXd-offer7-2.png),![offer7-3.png](https://pic.leetcode-cn.com/1605489052-FMWTAC-offer7-3.png),![offer7-4.png](https://pic.leetcode-cn.com/1605489052-eEyIVd-offer7-4.png),![offer7-5.png](https://pic.leetcode-cn.com/1605489052-dqDekn-offer7-5.png),![offer7-6.png](https://pic.leetcode-cn.com/1605489052-AXixjT-offer7-6.png),![offer7-7.png](https://pic.leetcode-cn.com/1605489052-bXAyWA-offer7-7.png),![offer7-8.png](https://pic.leetcode-cn.com/1605489052-WSknzB-offer7-8.png),![offer7-9.png](https://pic.leetcode-cn.com/1605489052-cfrzsb-offer7-9.png),![offer7-10.png](https://pic.leetcode-cn.com/1605489052-ahKODp-offer7-10.png),![offer7-11.png](https://pic.leetcode-cn.com/1605489052-UGTWZh-offer7-11.png)>

### 花絮

![offer7.mp4](e9244128-25f6-4687-913c-3bddc5c6bcbe)


## 剑指 Offer 26. 树的子结构

>https://leetcode.cn/problems/shu-de-zi-jie-gou-lcof/
<p>输入两棵二叉树A和B，判断B是不是A的子结构。(约定空树不是任意一个树的子结构)</p>

<p>B是A的子结构， 即 A中有出现和B相同的结构和节点值。</p>

<p>例如:<br>
给定的树 A:</p>

<p><code>&nbsp; &nbsp; &nbsp;3<br>
&nbsp; &nbsp; / \<br>
&nbsp; &nbsp;4 &nbsp; 5<br>
&nbsp; / \<br>
&nbsp;1 &nbsp; 2</code><br>
给定的树 B：</p>

<p><code>&nbsp; &nbsp;4&nbsp;<br>
&nbsp; /<br>
&nbsp;1</code><br>
返回 true，因为 B 与 A 的一个子树拥有相同的结构和节点值。</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>A = [1,2,3], B = [3,1]
<strong>输出：</strong>false
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>A = [3,4,5,1,2], B = [4,1]
<strong>输出：</strong>true</pre>

<p><strong>限制：</strong></p>

<p><code>0 &lt;= 节点个数 &lt;= 10000</code></p>


### 剑指 Offer 26. 树的子结构 - 解题思路
## 题目描述

输入两棵二叉树 A 和 B，判断 B 是不是 A 的子结构。(约定空树不是任意一个树的子结构)

B 是 A 的子结构， 即  A 中有出现和 B 相同的结构和节点值。

例如:
给定的树 A:

```

     3
    / \
   4   5
  / \
 1   2 
 
```

给定的树 B：

```
   4 
  /
 1

```
返回 true，因为 B 与 A 的一个子树拥有相同的结构和节点值。

  

示例 1：
```
输入：A = [1,2,3], B = [3,1]
输出：false 

```

示例 2：
``` 
输入：A = [3,4,5,1,2], B = [4,1]
输出：true 
```


限制：

```
0 <= 节点个数 <= 10000
```

## 解题方案

### 思路 

- 标签：递归
- 整体思路：
	- 子树：若 B 是 A 的子树，则 A 包含 B 的所有结点，**并且 B 的叶子节点一定是A的叶子节点**。 也就是 A 只要包含了 B 的一个结点，就得包含这个结点下的所有节点。 
	- 子结构：若 B 是 A 的子结构，则 A 包含 B 的所有结点，**但 B 的叶子节点不一定是 A 的叶子节点**。也就是子结构 B 是 A 树的任意一部分。
	- 此题目是 **子结构**相关。此题目约定空树，不为任何一棵树的子结构。如果 B 为 A 的子结构，则B的根节点一定是A的任意一个节点。
	- 双重递归。
- 复杂度：
	时间复杂度 $O(mn)$，$m$ 和 $n$ 为树 A 和 B 的节点数量。
    空间复杂度 $O(m)$，$m$ 是树 A 的递归深度。

### 算法流程  
1. 双重递归第一重，`isSubStructure`
 - 判断 `pRoot2` 是否为 `pRoot1` 的子结构 (约定空树,不为任何一棵树的子结构)
 - 约定空树不是任意一个树的子结构. 所以 A 不可为空树,且 B 不可为空树。
 - B 是以 "**A 为根节点**"  的子结构,或者 B 是 "**A 的左子树**" 的子结构,或者B是 "**A 的右子树**" 的子结构。注意三者为 **或** 的关系
 - 相当于对 A 进行了前序遍历: 根->左->右


2. 双重递归第二重，`isInclude`
 - 判断 `pRoot1` 是否包含 `pRoot2` (从集合关系分析,空集属于任何集合的子集)
 - `pRoot2` 为空,则 `pRoot1` 包含 `pRoot2`
 - `pRoot1` 为空,则 `pRoot1` 不包含 `pRoot2`
 - `pRoot1`，`pRoot2` 都不为空, 但节点值不同，则 `pRoot1` 不包含 `pRoot2`，即不具备包含关系
 - 如果值相同，则判断他们的左右节点是否也是包含关系（必须都是包含关系才行）
 - 递归判断 A 的左节点和 B 的左节点是否相等, 递归判断 A 的右节点和 B 的右节点是否相等


### 代码 

```Golang []
func isSubStructure(pRoot1 *TreeNode, pRoot2 *TreeNode) bool {
	if pRoot1 == nil {
		return false
	}
	if pRoot2 == nil {
		return false
	}
	return isInclude(pRoot1, pRoot2) || isSubStructure(pRoot1.Left, pRoot2) || isSubStructure(pRoot1.Right, pRoot2)
}


func isInclude(pRoot1 *TreeNode, pRoot2 *TreeNode) bool {
	if pRoot2 == nil {
		return true
	}
	if pRoot1 == nil {
		return false
	}
	if pRoot1.Val != pRoot2.Val {
		return false
	}
	return isInclude(pRoot1.Left, pRoot2.Left) && isInclude(pRoot1.Right, pRoot2.Right)
}
```

### 画解 

<![offer26-1.png](https://pic.leetcode-cn.com/1607957653-LeoKsK-offer26-1.png),![offer26-2.png](https://pic.leetcode-cn.com/1607957653-dwIuwT-offer26-2.png),![offer26-3.png](https://pic.leetcode-cn.com/1607957653-XIgZig-offer26-3.png),![offer26-4.png](https://pic.leetcode-cn.com/1607957653-HlzKHR-offer26-4.png),![offer26-5.png](https://pic.leetcode-cn.com/1607957653-GFIYJA-offer26-5.png)>

### 花絮

![offer26.mp4](ae537398-f6d0-49ef-b0ec-bd06c26f1ff5)


## 剑指 Offer 64. 求1+2+…+n

>https://leetcode.cn/problems/qiu-12n-lcof/
<p>求 <code>1+2+...+n</code> ，要求不能使用乘除法、for、while、if、else、switch、case等关键字及条件判断语句（A?B:C）。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入:</strong> n = 3
<strong>输出:&nbsp;</strong>6
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入:</strong> n = 9
<strong>输出:&nbsp;</strong>45
</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<ul>
	<li><code>1 &lt;= n&nbsp;&lt;= 10000</code></li>
</ul>


### 剑指 Offer 64. 求1+2+…+n - 解决方案
## 题目描述

求 `1+2+...+n` ，要求不能使用乘除法、for、while、if、else、switch、case 等关键字及条件判断语句（A?B:C）。

**示例 1：**

```text
输入: n = 3
输出: 6
```

**示例 2：**

```text
输入: n = 9
输出: 45
```

限制：

- `1 <= n <= 10000`

## 解题方案

### 思路

- 标签：递归、短路
- 整体思路：
  - 首先由于题目限制，排除了公式计算、循环迭代和普通递归的方式
  - 普通递归算法中的终止条件和条件判断可以用**与运算**的短路效应来替代
- 复杂度：
  - 时间复杂度：$O(n)$。需要递归计算 n 次
  - 空间复杂度：$O(n)$。递归产生的函数调用栈深度为 n

### 算法流程

1. 普通递归的方式求和代码如下：

```java
class Solution {
    public int sumNums(int n) {
        return n == 0 ? 0 : n + sumNums(n - 1);
    }
};
```

2. 与运算的短路效应指的是，当出现 `conditionA && conditonB` 场景时，如果 `conditionA` 不成立，那么`conditionB`也不会执行
3. 因为短路效应，所以其中的三元运算符条件判断可以用与运算来进行代替

### 代码

```Java []
class Solution {
    public int sumNums(int n) {
        // 其中 tmp 和 (n += sumNums(n - 1)) > 0 中的大于0条件都是为了做短路运算符合语法要求加的，并没有实际意义
        boolean tmp = n > 0 && (n += sumNums(n - 1)) > 0; 
        return n;
    }
}
```

```JavaScript []
/**
 * @param {number} n
 * @return {number}
 */
var sumNums = function(n) {
    n > 0 && (n += sumNums(n - 1)) > 0;
    return n;
};
```

### 画解

<![offer64-1.png](https://pic.leetcode-cn.com/1599052339-rLSxGF-offer64-1.png),![offer64-2.png](https://pic.leetcode-cn.com/1599052339-bkXXch-offer64-2.png),![offer64-3.png](https://pic.leetcode-cn.com/1599052339-lMpiIb-offer64-3.png),![offer64-4.png](https://pic.leetcode-cn.com/1599052339-rVQiAV-offer64-4.png),![offer64-5.png](https://pic.leetcode-cn.com/1599052339-fzFLPo-offer64-5.png),![offer64-6.png](https://pic.leetcode-cn.com/1599052339-xZLegH-offer64-6.png),![offer64-7.png](https://pic.leetcode-cn.com/1599052339-XiJEJB-offer64-7.png),![offer64-8.png](https://pic.leetcode-cn.com/1599052339-tdxTgt-offer64-8.png),![offer64-9.png](https://pic.leetcode-cn.com/1599052339-SFECtX-offer64-9.png)>


### 花絮

![offer64.mp4](6ce38c83-57ac-4d7a-8175-23d04eaa7bcb)



# 数学


## 剑指 Offer 44. 数字序列中某一位的数字

>https://leetcode.cn/problems/shu-zi-xu-lie-zhong-mou-yi-wei-de-shu-zi-lcof/
<p>数字以0123456789101112131415&hellip;的格式序列化到一个字符序列中。在这个序列中，第5位（从下标0开始计数）是5，第13位是1，第19位是4，等等。</p>

<p>请写一个函数，求任意第n位对应的数字。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>n = 3
<strong>输出：</strong>3
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>n = 11
<strong>输出：</strong>0</pre>

<p>&nbsp;</p>

<p><strong>限制：</strong></p>

<ul>
	<li><code>0 &lt;= n &lt;&nbsp;2^31</code></li>
</ul>

<p>注意：本题与主站 400 题相同：<a href="https://leetcode-cn.com/problems/nth-digit/">https://leetcode-cn.com/problems/nth-digit/</a></p>


### 剑指 Offer 44. 数字序列中某一位的数字 - 解决方案
## 题目描述

数字以 0123456789101112131415…的格式序列化到一个字符序列中。在这个序列中，第 5 位（从下标 0 开始计数）是 5，第 13 位是 1，第 19 位是 4，等等。

请写一个函数，求任意第 n 位对应的数字。

**示例 1:**

```text
输入：n = 3
输出：3
```

**示例 2:**

```text
输入：n = 11
输出：0
```

## 解题方案

### 思路

- 标签：迭代，取余
- 整体思路：

根据初始字符串很容易找到数学规律：

- 123456789:是 9 个 1 位数字
- 1011121314...9899:是 90 个 2 位数字
- 100...999:是 900 个 3 位数字

- 复杂度：

  - 时间复杂度：$O(log_n)$。 所求数位 n 对应数字 num 的位数 digit 最大为 $O(log_n)$ ；第一步最多循环 $O(log_n)$ 次；第三步中将 num 转化为字符串使用 $O(log_n)$ 时间；因此总体为 $O(log_n)$ 。

  - 空间复杂度：$O(log_n)$： 将数字转化为字符串时占用额外空间 $O(log_n)$

### 算法流程

1. 先找到输入的数字对应的是几位数 digit
2. 然后确定这个数的数值 num
3. 最后找到是该数值的第几位数
4. 返回结果

### 代码

```Java []
class Solution {
    public int findNthDigit(int n) {
        int digit = 1;
        long start = 1; //每个位数的起始数字
        long count = 9;
        while (n > count) { // 1.
            n -= count;
            digit += 1;
            start *= 10;
            count = digit * start * 9;
        }
        long num = start + (n - 1) / digit; // 2.
        return Long.toString(num).charAt((n - 1) % digit) - '0'; // 3.
    }
}
```

### 画解

<![offer44-1.png](https://pic.leetcode-cn.com/1609894200-wibsLH-offer44-1.png),![offer44-2.png](https://pic.leetcode-cn.com/1609894200-pbMbhR-offer44-2.png),![offer44-3.png](https://pic.leetcode-cn.com/1609894200-sVgkDZ-offer44-3.png)>

### 花絮

![offer44.mp4](e00c9e5c-dd39-4f07-97c2-63943ca12471)


