
# 感知智能
本章汇总了针对【感知智能】细分领域的简答题，涵盖 NLP、CV 两大方向。

## NLP
本节题目考察 NLP 相关知识点。

### 题组 I
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. Batch Normalization 缺点？（百度）</p>
 <label for="control1" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box"> 
batch 太小,会造成波动大；对于文本数据，不同有效长度问题；测试集上两个数据均值和方差差别很大就不合适了
附：LN 是对一个样本的一个时间步上的数据进行减均除标准差，然后再回放（参数学习）对应到普通线性回归就是一层节点求均除标准差。
   </p>
 </div>
 <br>
 <p>2. 分词如何做？（百度）</p>
 <label for="control2" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box"> 
基于规则（超大词表）；基于统计（两字同时出现越多，就越可能是词）；基于网络 LSTM + CRF 词性标注，也可以分词。
    </p>
 </div>
 <br>
 <p>3. word2vector 负采样时为什么要对频率做 3/4 次方?（百度）</p>
 <label for="control3" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box"> 
在保证高频词容易被抽到的大方向下，通过权重 3/4 次幂的方式，适当提升低频词、罕见词被抽到的概率。如果不这么做，低频词，罕见词很难被抽到，以至于不被更新到对应 Embedding。
    </p>
 </div>
 <br>
 <p>4. word2vec 的两种优化方式？（车企）</p>
 <label for="control4" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box"> 
第一种改进为基于层序 softmax 的模型。<br>
首先构建哈夫曼树，即以词频作为 n 个词的节点权重，不断将最小权重的节点进行合并，最终形成一棵树，权重越大的叶子结点越靠近根节点，权重越小的叶子结点离根节点越远。
然后进行哈夫曼编码，即对于除根节点外的节点，左子树编码为 1，右子树编码为 0。
最后采用二元逻辑回归方法，沿着左子树走就是负类，沿着右子树走就是正类，从训练样本中学习逻辑回归的模型参数。<br>
优点：计算量由 V（单词总数）减小为 log2V；高频词靠近根节点，所需步数小，低频词远离根节点。<br>
第二种改进为基于负采样的模型。<br>
通过采样得到少部分的负样本，对正样本和少部分的负样本，利用二元逻辑回归模型，通过梯度上升法，来得到每个词对应的模型参数。具体负采样的方法为：根据词频进行采样，也就是词频越大的词被采到的概率也越大。
    </p>
 </div>
 <br>
 <p>5. CNN 原理及优缺点？（车企）</p>
 <label for="control5" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control5" class="nav-con">
    <p class="nav-box"> 
CNN 是一种前馈神经网络，通常包含 5 层，输入层，卷积层，激活层，池化层，全连接 FC 层，其中核心部分是卷积层和池化层。<br>
优点：共享卷积核，对高维数据处理无压力；无需手动选取特征。<br>
缺点：需要调参；需要大量样本。
    </p>
 </div>
 <br>
 <p>6. 描述下 CRF 模型及应用（车企）</p>
 <label for="control6" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control6" class="nav-con">
    <p class="nav-box"> 
给定一组输入随机变量的条件下另一组输出随机变量的条件概率分布密度。条件随机场假设输出变量构成马尔科夫随机场，而我们平时看到的大多是线性链条随机场，也就是由输入对输出进行预测的判别模型。求解方法为极大似然估计或正则化的极大似然估计。CRF 模型通常应用于优化命名实体识别任务。
    </p>
 </div>
 <br>
 <p>7. transformer 结构？（车企）</p>
 <label for="control7" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control7" class="nav-con">
    <p class="nav-box"> 
Transformer 本身是一个典型的 encoder-decoder 模型，Encoder 端和 Decoder 端均有6个 Block，Encoder 端的 Block 包括两个模块，多头 self-attention 模块以及一个前馈神经网络模块；Decoder 端的 Block 包括三个模块，多头 self-attention 模块，多头 Encoder-Decoder attention 交互模块，以及一个前馈神经网络模块；需要注意：Encoder 端和 Decoder 端中的每个模块都有残差层和 Layer Normalization 层。
    </p>
 </div>
 <br>
 <p>8. elmo 和 Bert 的区别？（车企）</p>
 <label for="control8" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control8" class="nav-con">
    <p class="nav-box"> 
BERT 采用的是 Transformer 架构中的 Encoder 模块;
GPT 采用的是 Transformer 架构中的 Decoder 模块;
ELMo 采用的双层双向 LSTM 模块。
    </p>
 </div>
 <br>
 <p>9. elmo 和 word2vec 的区别？（车企）</p>
 <label for="control9" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control9" class="nav-con">
    <p class="nav-box"> 
elmo 词向量是包含上下文信息的，不是一成不变的，而是根据上下文而随时变化。
   </p>
 </div>
 <br>
 <p>10. lstm 与 GRU 区别？（车企）</p>
 <label for="control10" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control10" class="nav-con">
    <p class="nav-box"> 
（1）LSTM 和 GRU 的性能在很多任务上不分伯仲；<br>
（2）GRU 参数更少，因此更容易收敛，但是在大数据集的情况下，LSTM性能表现更好；<br>
（3）GRU 只有两个门（update和reset），LSTM 有三个门（forget，input，output），GRU 直接将hidden state 传给下一个单元，而 LSTM 用 memory cell 把 hidden state 包装起来。
    </p>
 </div>
 <br>
 </body>
 </html>


## CV
本节题目考察 CV 相关知识点。

### 题组 I
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. 图像处理的基本知识：直方图均衡化、维纳滤波、锐化的操作（字节跳动）</p>
 <label for="control1" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box"> 
直方图均衡化(Histogram Equalization)是一种增强图像对比度(Image Contrast)的方法，其主要思想是将一副图像的直方图分布通过累积分布函数变成近似均匀分布，从而增强图像的对比度。<br>
维纳滤波器一种以最小平方为最优准则的线性滤波器。在一定的约束条件下，其输出与一给定函数（通常称为期望输出）的差的平方达到最小。<br>
锐化滤波器则使用邻域的微分作为算子，增大邻域间像素的差值，使图像的突变部分变的更加明显。锐化的作用是加强图像的边沿和轮廓，通常也成为高通滤波器。
   </p>
 </div>
 <br>
 <p>2. BN 过程，为什么测试和训练不一样？（字节跳动）</p>
 <label for="control2" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box"> 
对于BN，在训练时，是对每一批的训练数据进行归一化，也即用每一批数据的均值和方差。<br>
而在测试时，比如进行一个样本的预测，就并没有batch的概念，因此，这个时候用的均值和方差是全量训练数据的均值和方差，这个可以通过移动平均法求得。<br>
对于BN，当一个模型训练完成之后，它的所有参数都确定了，包括均值和方差，gamma和bata。
    </p>
 </div>
 <br>
 <p>3. 简单介绍 gbdt 算法的原理（美团）</p>
 <label for="control3" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box"> 
GBDT是梯度提升决策树，是一种基于Boosting的算法，采用以决策树为基学习器的加法模型，通过不断拟合上一个弱学习器的残差，最终实现分类或回归的模型。关键在于利用损失函数的负梯度在当前模型的值作为残差的近似值，从而拟合一个回归树。对于分类问题：常使用指数损失函数；对于回归问题：常使用平方误差损失函数（此时，其负梯度就是通常意义的残差），对于一般损失函数来说就是残差的近似。
无论损失函数是什么形式，每个决策树拟合的都是负梯度。准确的说，不是用负梯度代替残差，而是当损失函数是均方损失时，负梯度刚好是残差，残差只是特例。
    </p>
 </div>
 <br>
 <p>4. pca 属于有监督还是无监督？（美团）</p>
 <label for="control4" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box"> 
PCA 按有监督和无监督划分应该属于无监督学习，所以数据集有无 y 并不重要，只是改变样本 X 的属性(特征)维度。
    </p>
 </div>
 <br>
 <p>5. 防止过拟合的方法？（阿里）</p>
 <label for="control5" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control5" class="nav-con">
    <p class="nav-box"> 
降低模型复杂度<br>
增加更多的训练数据：使用更大的数据集训练模型<br>
数据增强<br>
正则化：L1、L2、添加BN层<br>
添加Dropout策略<br>
Early Stopping
    </p>
 </div>
 <br>
 <p>6. Pytorch 和 Tensorflow 的区别？（科大讯飞）</p>
 <label for="control6" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control6" class="nav-con">
    <p class="nav-box"> 
图创建 <br>
创建和运行计算图可能是两个框架最不同的地方。 <br>
在pyTorch中，图结构是动态的，这意味着图在运行时构建。而在TensorFlow中，图结构是静态的，这意味着图先被“编译”然后再运行。 <br>
pyTorch中简单的图结构更容易理解，更重要的是，还更容易调试。调试pyTorch代码就像调试Python代码一样。你可以使用pdb并在任何地方设置断点。调试tensorFlow代码可不容易。要么得从会话请求要检查的变量，要么学会使用tensorFlow的调试器。 <br>
灵活性 <br>
pytorch：动态计算图，数据参数在CPU与GPU之间迁移十分灵活，调试简便； <br>
tensorflow：静态计算图，数据参数在CPU与GPU之间迁移麻烦，调试麻烦。 <br>
设备管理 <br>
pytorch：需要明确启用的设备 <br>
tensorflow：不需要手动调整，简单
    </p>
 </div>
 <br>
 <p>7. torch.eval() 的作用？（科大讯飞）</p>
 <label for="control7" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control7" class="nav-con">
    <p class="nav-box"> 
对BN的影响： <br>
对于BN，训练时通常采用mini-batch，所以每一批中的mean和std大致是相同的；而测试阶段往往是单个图像的输入，不存在mini-batch的概念。所以将model改为eval模式后，BN的参数固定，并采用之前训练好的全局的mean和std；总结就是使用全局固定的BN。 <br>
对dropout的影响： <br>
训练阶段，隐含层神经元先乘概率P，再进行激活；而测试阶段，神经元先激活，每个隐含层神经元的输出再乘概率P，总结来说就是顺序不同！
    </p>
 </div>
 <br>
 <p>8. PCA 是什么？实现过程是什么，意义是什么？（科大讯飞）</p>
 <label for="control8" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control8" class="nav-con">
    <p class="nav-box"> 
主成分分析 (PCA, principal component analysis)是一种数学降维方法, 利用正交变换 (orthogonal transformation)把一系列可能线性相关的变量转换为一组线性不相关的新变量，也称为主成分，从而利用新变量在更小的维度下展示数据的特征。 <br>
实现过程： <br>
一种是基于特征值分解协方差矩阵实现PCA算法，一种是基于SVD分解协方差矩阵实现PCA算法。 <br>
意义： <br>
使得数据集更易使用；降低算法的计算开销；去除噪声；使得结果容易理解。
    </p>
 </div>
 <br>
 <p>9. 简述 K-means。（科大讯飞）</p>
 <label for="control9" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control9" class="nav-con">
    <p class="nav-box"> 
K-means算法的基本思想是：以空间中k个点为中心进行聚类，对最靠近他们的对象归类。通过迭代的方法，逐次更新各聚类中心的值，直至得到最好的聚类结果。 <br>
假设要把样本集分为k个类别，算法描述如下： <br>
（1）适当选择k个类的初始中心，最初一般为随机选取； <br>
（2）在每次迭代中，对任意一个样本，分别求其到k个中心的欧式距离，将该样本归到距离最短的中心所在的类； <br>
（3）利用均值方法更新该k个类的中心的值； <br>
（4）对于所有的k个聚类中心，重复（2）（3），类的中心值的移动距离满足一定条件时，则迭代结束，完成分类。
Kmeans聚类算法原理简单，效果也依赖于k值和类中初始点的选择。
   </p>
 </div>
 <br>
 <p>10. 图像边缘检测的原理？（其他）</p>
 <label for="control10" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control10" class="nav-con">
    <p class="nav-box"> 
图像的边缘是指其周围像素灰度急剧变化的那些像素的集合，它是图像最基本的特征，⽽图像的边缘检测即先检测图像的边缘点，再按照某种策略将边缘点连接成轮廓，从而构成分割区域。
    </p>
 </div>
 <br>
 <p>11. 图像中的角点（Harris 角点）是什么？为什么用角点作为特征点？（其他）</p>
 <label for="control11" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control11" class="nav-con">
    <p class="nav-box"> 
Harris角点：在任意两个相互垂直的方向上，都有较大变化的点。角点在保留图像图形重要特征的同时，可以有效地减少信息的数据量，使其信息的含量很高，有效地提高了计算的速度，有利于图像的可靠匹配，使得实时处理成为可能。
    </p>
 </div>
 <br>
 <p>12. 什么是感受野？（其他）</p>
 <label for="control12" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control12" class="nav-con">
    <p class="nav-box"> 
某⼀层特征图中的⼀个cell，对应到原始输⼊的响应的大小区域。
    </p>
 </div>
 <br>
 <p>13. 工业界中遇到上亿的图像检索任务，如何提高图像对比效率?（其他）</p>
 <label for="control13" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control13" class="nav-con">
    <p class="nav-box"> 
假设原图像输出的特征维度为2048维，通过哈希的索引技术，将原图的2048维度映射到128维度的0/1值中，再进⾏特征维度对⽐。
    </p>
 </div>
 <br>
 <p>14. 物体检测方法列举（其他）</p>
 <label for="control14" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control14" class="nav-con">
    <p class="nav-box"> 
Deformable Parts Model <br>
RCNN <br>
Fast-RCNN <br>
Faster-RCNN <br>
RFCN <br>
Mask-RCNN
    </p>
 </div>
 <br>
 </body>
 </html>



# 数据挖掘
本章汇总了针对【数据挖掘】细分领域的简答题，涵盖机器学习、深度学习两大方向。

## 机器学习
本节题目考察机器学习相关知识点。

### 题组 I
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. KNN 中的 K 如何选取的？（BAT）</p>
 <label for="control1" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box"> 
如果选择较小的K值，就相当于用较小的领域中的训练实例进行预测，“学习”近似误差会减小，只有与输入实例较近或相似的训练实例才会对预测结果起作用，与此同时带来的问题是“学习”的估计误差会增大，换句话说，K值的减小就意味着整体模型变得复杂，容易发生过拟合； <br>
如果选择较大的K值，就相当于用较大领域中的训练实例进行预测，其优点是可以减少学习的估计误差，但缺点是学习的近似误差会增大。这时候，与输入实例较远（不相似的）训练实例也会对预测器作用，使预测发生错误，且K值的增大就意味着整体的模型变得简单。 <br>
K=N，则完全不足取，因为此时无论输入实例是什么，都只是简单的预测它属于在训练实例中最多的累，模型过于简单，忽略了训练实例中大量有用信息。 <br>
在实际应用中，K值一般取一个比较小的数值，例如采用交叉验证法（简单来说，就是一部分样本做训练集，一部分做测试集）来选择最优的K值。
   </p>
 </div>
 <br>
 <p>2. 防止过拟合的方法（BAT）</p>
 <label for="control2" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box"> 
过拟合的原因是算法的学习能力过强；一些假设条件（如样本独立同分布）可能是不成立的；训练样本过少不能对整个空间进行分布估计。 <br>
处理方法： <br>
1. 早停止：如在训练中多次迭代后发现模型性能没有显著提高就停止训练 <br>
2. 数据集扩增：原有数据增加、原有数据加随机噪声、重采样 <br>
3. 正则化，正则化可以限制模型的复杂度 <br>
4. 交叉验证 <br>
5. 特征选择/特征降维 <br>
6. 创建一个验证集是最基本的防止过拟合的方法。我们最终训练得到的模型目标是要在验证集上面有好的表现，而不训练集
    </p>
 </div>
 <br>
 <p>3. 什么最小二乘法？（BAT）</p>
 <label for="control3" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box"> 
最小二乘法（又称最小平方法）是一种数学优化技术。它通过最小化误差的平方和寻找数据的最佳函数匹配。利用最小二乘法可以简便地求得未知的数据，并使得这些求得的数据与实际数据之间误差的平方和为最小。 <br>
使误差「所谓误差，当然是观察值与实际真实值的差量」平方和达到最小以寻求估计值的方法，就叫做最小二乘法，用最小二乘法得到的估计，叫做最小二乘估计。当然，取平方和作为目标函数只是众多可取的方法之一。
    </p>
 </div>
 <br>
 <p>4. 请简要介绍下SVM（BAT）</p>
 <label for="control4" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box"> 
SVM，全称是support vector machine，中文名叫支持向量机。SVM是一个面向数据的分类算法，它的目标是为确定一个分类超平面，从而将不同的数据分隔开。
    </p>
 </div>
 <br>
 <p>5. 请简要介绍下 tensorflow 的计算图（BAT）</p>
 <label for="control5" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control5" class="nav-con">
    <p class="nav-box"> 
Tensorflow是一个通过计算图的形式来表述计算的编程系统，计算图也叫数据流图，可以把计算图看做是一种有向图，Tensorflow中的每一个计算都是计算图上的一个节点，而节点之间的边描述了计算之间的依赖关系。
    </p>
 </div>
 <br>
 <p>6. overfitting 怎么解决？（BAT）</p>
 <label for="control6" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control6" class="nav-con">
    <p class="nav-box"> 
dropout、regularization、batch normalizatin
    </p>
 </div>
 <br>
 <p>7. LR 和 SVM 的联系与区别（BAT）</p>
 <label for="control7" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control7" class="nav-con">
    <p class="nav-box"> 
联系： <br>
1. LR和SVM都可以处理分类问题，且一般都用于处理线性二分类问题（在改进的情况下可以处理多分类问题） <br>
2. 两个方法都可以增加不同的正则化项，如l1、l2等等。所以在很多实验中，两种算法的结果是很接近的。 <br>
区别：<br>
1. LR是参数模型，SVM是非参数模型。<br>
2. 从目标函数来看，区别在于逻辑回归采用的是logistical loss，SVM采用的是hinge loss.这两个损失函数的目的都是增加对分类影响较大的数据点的权重，减少与分类关系较小的数据点的权重。 <br>
3. SVM的处理方法是只考虑support vectors，也就是和分类最相关的少数点，去学习分类器。而逻辑回归通过非线性映射，大大减小了离分类平面较远的点的权重，相对提升了与分类最相关的数据点的权重。 <br>
4. 逻辑回归相对来说模型更简单，好理解，特别是大规模线性分类时比较方便。而SVM的理解和优化相对来说复杂一些，SVM转化为对偶问题后,分类只需要计算与少数几个支持向量的距离,这个在进行复杂核函数计算时优势很明显,能够大大简化模型和计算。 <br>
5. logic 能做的 svm能做，但可能在准确率上有问题，svm能做的logic有的做不了。
    </p>
 </div>
 <br>
 <p>8. LR 与线性回归的区别与联系（BAT）</p>
 <label for="control8" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control8" class="nav-con">
    <p class="nav-box"> 
个人感觉逻辑回归和线性回归首先都是广义的线性回归，其次经典线性模型的优化目标函数是最小二乘，而逻辑回归则是似然函数，另外线性回归在整个实数域范围内进行预测，敏感度一致，而分类范围，需要在[0,1]。逻辑回归就是一种减小预测范围，将预测值限定为[0,1]间的一种回归模型，因而对于这类问题来说，逻辑回归的鲁棒性比线性回归的要好。
逻辑回归的模型本质上是一个线性回归模型，逻辑回归都是以线性回归为理论支持的。但线性回归模型无法做到sigmoid的非线性形式，sigmoid可以轻松处理0/1分类问题。
    </p>
 </div>
 <br>
 <p>9. 请问（决策树、Random Forest、Booting、Adaboot）GBDT 和 XGBoost 的区别是什么？（BAT）</p>
 <label for="control9" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control9" class="nav-con">
    <p class="nav-box"> 
xgboost类似于gbdt的优化版，不论是精度还是效率上都有了提升。与gbdt相比，具体的优点有： <br>
1. 损失函数是用泰勒展式二项逼近，而不是像gbdt里的就是一阶导数 <br>
2. 对树的结构进行了正则化约束，防止模型过度复杂，降低了过拟合的可能性 <br>
3. 节点分裂的方式不同，gbdt是用的gini系数，xgboost是经过优化推导后的
   </p>
 </div>
 <br>
 <p>10. 为什么 XGBoost 要用泰勒展开，优势在哪里？（BAT）</p>
 <label for="control10" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control10" class="nav-con">
    <p class="nav-box"> 
XGBoost使用了一阶和二阶偏导，二阶导数有利于梯度下降的更快更准。使用泰勒展开取得二阶倒数形式，可以在不选定损失函数具体形式的情况下用于算法优化分析。本质上也就把损失函数的选取和模型算法优化/参数选择分开了。这种去耦合增加了XGBoost的适用性。
    </p>
 </div>
 <br>
 <p>11. XGBoost 如何寻找最优特征？是又放回还是无放回的呢？（BAT）</p>
 <label for="control11" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control11" class="nav-con">
    <p class="nav-box"> 
XGBoost在训练的过程中给出各个特征的评分，从而表明每个特征对模型训练的重要性。XGBoost利用梯度优化模型算法，样本是不放回的(想象一个样本连续重复抽出,梯度来回踏步会不会高兴)。但XGBoost支持子采样，也就是每轮计算可以不使用全部样本。
    </p>
 </div>
 <br>
 <p>12. 谈谈判别式模型和生成式模型？（BAT）</p>
 <label for="control12" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control12" class="nav-con">
    <p class="nav-box"> 
判别方法：由数据直接学习决策函数 Y = f（X），或者由条件分布概率 P（Y|X）作为预测模型，即判别模型。 <br>
生成方法：由数据学习联合概率密度分布函数 P（X,Y）,然后求出条件概率分布P(Y|X)作为预测的模型，即生成模型。 <br>
由生成模型可以得到判别模型，但由判别模型得不到生成模型。 <br>
常见的判别模型有：K近邻、SVM、决策树、感知机、线性判别分析（LDA）、线性回归、传统的神经网络、逻辑斯蒂回归、boosting、条件随机场 <br>
常见的生成模型有：朴素贝叶斯、隐马尔可夫模型、高斯混合模型、文档主题生成模型（LDA）、限制玻尔兹曼机
    </p>
 </div>
 <br>
 <p>13. L1 和 L2 的区别。（BAT）</p>
 <label for="control13" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control13" class="nav-con">
    <p class="nav-box"> 
L1范数（L1 norm）是指向量中各个元素绝对值之和，也有个美称叫“稀疏规则算子”（Lasso regularization）。 <br>
比如 向量A=[1，-1，3]， 那么A的L1范数为 |1|+|-1|+|3|<br>
简单总结一下就是： <br>
L1范数: 为x向量各个元素绝对值之和 <br>
L2范数: 为x向量各个元素平方和的1/2次方，L2范数又称Euclidean范数或Frobenius范数 <br>
Lp范数: 为x向量各个元素绝对值p次方和的1/p次方 <br>
在支持向量机学习过程中，L1范数实际是一种对于成本函数求解最优的过程，因此，L1范数正则化通过向成本函数中添加L1范数，使得学习得到的结果满足稀疏化，从而方便人类提取特征。 <br>
L1范数可以使权值稀疏，方便特征提取。 <br>
L2范数可以防止过拟合，提升模型的泛化能力。
    </p>
 </div>
 <br>
 <p>14. L1 和 L2 正则先验分别服从什么分布 ？（BAT）</p>
 <label for="control14" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control14" class="nav-con">
    <p class="nav-box"> 
L1是拉普拉斯分布，L2是高斯分布。
    </p>
 </div>
 <br>
 </body>
 </html>

### 题组 II
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. LSTM 结构推导，为什么比 RNN 好？（BAT）</p>
 <label for="control15" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control15" class="nav-con">
    <p class="nav-box"> 
推导forget gate，input gate，cell state， hidden information等的变化；因为LSTM有进有出且当前的cell informaton是通过input gate控制之后叠加的，RNN是叠乘，因此LSTM可以防止梯度消失或者爆炸。
    </p>
 </div>
 <br>
 <p>2. 为什么朴素贝叶斯如此“朴素”？（BAT）</p>
 <label for="control16" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control16" class="nav-con">
    <p class="nav-box"> 
因为它假定所有的特征在数据集中的作用是同样重要和独立的。正如我们所知，这个假设在现实世界中是很不真实的，因此，说朴素贝叶斯真的很“朴素”。
    </p>
 </div>
 <br>
 <p>3. 如何解决梯度消失和梯度膨胀？（BAT）</p>
 <label for="control17" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control17" class="nav-con">
    <p class="nav-box"> 
（1）梯度消失： <br>
根据链式法则，如果每一层神经元对上一层的输出的偏导乘上权重结果都小于1的话，那么即使这个结果是0.99，在经过足够多层传播之后，误差对输入层的偏导会趋于0。 <br>
可以采用ReLU激活函数有效的解决梯度消失的情况。 <br>
（2）梯度膨胀： <br>
根据链式法则，如果每一层神经元对上一层的输出的偏导乘上权重结果都大于1的话，在经过足够多层传播之后，误差对输入层的偏导会趋于无穷大。 <br>
可以通过激活函数来解决。
    </p>
 </div>
 <br>
 <p>4. 了解正则化么？（BAT）</p>
 <label for="control18" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control18" class="nav-con">
    <p class="nav-box"> 
正则化是针对过拟合而提出的，以为在求解模型最优的是一般优化最小的经验风险，现在在该经验风险上加入模型复杂度这一项（正则化项是模型参数向量的范数），并使用一个rate比率来权衡模型复杂度与以往经验风险的权重，如果模型复杂度越高，结构化的经验风险会越大，现在的目标就变为了结构经验风险的最优化，可以防止模型训练过度复杂，有效的降低过拟合的风险。
奥卡姆剃刀原理，能够很好的解释已知数据并且十分简单才是最好的模型。
    </p>
 </div>
 <br>
 <p>5. 线性分类器与非线性分类器的区别以及优劣？（BAT）</p>
 <label for="control19" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control19" class="nav-con">
    <p class="nav-box"> 
如果模型是参数的线性函数，并且存在线性分类面，那么就是线性分类器，否则不是。 <br>
常见的线性分类器有：LR、贝叶斯分类、单层感知机、线性回归。 <br>
常见的非线性分类器：决策树、RF、GBDT、多层感知机。 <br>
SVM两种都有(看线性核还是高斯核)。 <br>
线性分类器速度快、编程方便，但是可能拟合效果不会很好。 <br>
非线性分类器编程复杂，但是效果拟合能力强。
    </p>
 </div>
 <br>
 <p>6. BN 和 LN 区别？（字节）</p>
 <label for="control20" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control20" class="nav-con">
    <p class="nav-box"> 
Batch Normalization 是对这批样本的同一维度特征做归一化， Layer Normalization 是对这单个样本的所有维度特征做归一化。 <br>
区别：LN中同层神经元输入拥有相同的均值和方差，不同的输入样本有不同的均值和方差；BN中则针对不同神经元输入计算均值和方差，同一个batch中的输入拥有相同的均值和方差。所以，LN不依赖于batch的大小和输入sequence的长度，因此可以用于batchsize为1和RNN中sequence的normalize操作。
    </p>
 </div>
 <br>
 <p>7. 讲讲 self attention。（字节）</p>
 <label for="control21" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control21" class="nav-con">
    <p class="nav-box"> 
Self Attention与传统的Attention机制非常的不同：传统的Attention是基于source端和target端的隐变量（hidden state）计算Attention的，得到的结果是源端的每个词与目标端每个词之间的依赖关系。但Self Attention不同，它分别在source端和target端进行，仅与source input或者target input自身相关的Self Attention，捕捉source端或target端自身的词与词之间的依赖关系；然后再把source端的得到的self Attention加入到target端得到的Attention中，捕捉source端和target端词与词之间的依赖关系。因此，self Attention Attention比传统的Attention mechanism效果要好，主要原因之一是，传统的Attention机制忽略了源端或目标端句子中词与词之间的依赖关系，相对比，self Attention可以不仅可以得到源端与目标端词与词之间的依赖关系，同时还可以有效获取源端或目标端自身词与词之间的依赖关系。
    </p>
 </div>
 <br>
 <p>8. Bert 的预训练过程？（字节）</p>
 <label for="control22" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control22" class="nav-con">
    <p class="nav-box"> 
Bert的预训练主要包含两个任务，MLM和NSP，Masked Language Model任务可以理解为完形填空，随机mask每一个句子中15%的词，用其上下文来做预测；Next Sentence Prediction任务选择一些句子对A与B，其中50%的数据B是A的下一条句子，剩余50%的数据B是语料库中随机选择的，学习其中的相关性。BERT 预训练阶段实际上是将上述两个任务结合起来，同时进行，然后将所有的 Loss 相加。
    </p>
 </div>
 <br>
 <p>9. Pre Norm 与 Post Norm 的区别？（字节）</p>
 <label for="control23" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control23" class="nav-con">
    <p class="nav-box"> 
在同一设置下，Pre Norm（也就是Norm and add）的效果是要优于Post Norm（Add and Norm）的，但是单独调整的话，Post Norm的效果是更好的，Pre Norm结构无形地增加了模型的宽度而降低了模型的深度，Post Norm每Norm一次就削弱一次恒等分支的权重，所以Post Norm反而是更突出残差分支的。
    </p>
 </div>
 <br>
 <p>10. GPT 与 Bert 的区别？（字节）</p>
 <label for="control24" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control24" class="nav-con">
    <p class="nav-box"> 
1） GPT是单向模型，无法利用上下文信息，只能利用上文；而BERT是双向模型。 <br>
2） GPT是基于自回归模型，可以应用在NLU和NLG两大任务，而原生的BERT采用的基于自编码模型，只能完成NLU任务，无法直接应用在文本生成上面。
    </p>
 </div>
 <br>
 <p>11. 如何加速 Bert 模型的训练？（字节）</p>
 <label for="control25" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control25" class="nav-con">
    <p class="nav-box"> 
BERT 基线模型的训练使用 Adam with weight decay（Adam优化器的变体）作为优化器，LAMB 是一款通用优化器，它适用于小批量和大批量，且除了学习率以外其他超参数均无需调整。LAMB 优化器支持自适应元素级更新（adaptive element-wise updating）和准确的逐层修正（layer-wise correction）。LAMB 可将 BERT 预训练的批量大小扩展到 64K，且不会造成准确率损失，76分钟就可以完成BERT的训练。
    </p>
 </div>
 <br>
 <p>12. 比较 Boosting 和 Bagging 的异同（其他）</p>
 <label for="control26" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control26" class="nav-con">
    <p class="nav-box"> 
二者都是集成学习算法，都是将多个弱学习器组合成强学习器的方法。 <br>
Bagging：从原始数据集中每一轮有放回地抽取训练集，训练得到k个弱学习器，将这k个弱学习器以投票的方式得到最终的分类结果。 <br>
Boosting：每一轮根据上一轮的分类结果动态调整每个样本在分类器中的权重，训练得到k个弱分类器，他们都有各自的权重，通过加权组合的方式得到最终的分类结果。
    </p>
 </div>
 <br>
 <p>13. 无监督学习中存在过拟合吗？（其他）</p>
 <label for="control27" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control27" class="nav-con">
    <p class="nav-box"> 
存在。我们可以使用无监督学习的某些指标或人为地去评估模型性能，以此来判断是否过拟合。
    </p>
 </div>
 <br>
 </body>
 </html>


## 深度学习
本节题目考察深度学习相关知识点。

### 题组 I
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. 什么是 RNN？（其他）</p>
 <label for="control1" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box"> 
RNNs的目的使用来处理序列数据。在传统的神经网络模型中，是从输入层到隐含层再到输出层，层与层之间是全连接的，每层之间的节点是无连接的。但是这种普通的神经网络对于很多问题却无能无力。例如，你要预测句子的下一个单词是什么，一般需要用到前面的单词，因为一个句子中前后单词并不是独立的。 <br>
RNNs之所以称为循环神经网路，即一个序列当前的输出与前面的输出也有关。具体的表现形式为网络会对前面的信息进行记忆并应用于当前输出的计算中，即隐藏层之间的节点不再无连接而是有连接的，并且隐藏层的输入不仅包括输入层的输出还包括上一时刻隐藏层的输出。
   </p>
 </div>
 <br>
 <p>2. CNN 关键的层有哪些？（其他）</p>
 <label for="control2" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box"> 
其关键层有： <br>
① 输入层，对数据去均值，做data augmentation等工作 <br>
② 卷积层，局部关联抽取feature <br>
③ 激活层，非线性变化 <br>
④ 池化层，下采样 <br>
⑤ 全连接层，增加模型非线性 <br>
⑥ 高速通道，快速连接 <br>
⑦ BN层，缓解梯度弥散"
    </p>
 </div>
 <br>
 <p>3. GRU 是什么？GRU 对 LSTM 做了哪些改动？（其他）</p>
 <label for="control3" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box"> 
GRU是 Gated Recurrent Units，是循环神经网络的一种。 <br>
GRU只有两个门（update和reset），LSTM有三个门（forget，input，output），GRU直接将 hidden state 传给下一个单元，而LSTM用 memory cell 把 hidden state 包装起来。
    </p>
 </div>
 <br>
 <p>4. 何解决深度学习中模型训练效果不佳的情况？（其他）</p>
 <label for="control4" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box"> 
如果模型的训练效果不好，可先考察以下几个方面是否有可以优化的地方。 <br>
(1) 选择合适的损失函数（choosing proper loss ） <br>
神经网络的损失函数是非凸的，有多个局部最低点，目标是找到一个可用的最低点。非凸函数是凹凸不平的，但是不同的损失函数凹凸起伏的程度不同，例如下述的平方损失和交叉熵损失，后者起伏更大，且后者更容易找到一个可用的最低点，从而达到优化的目的。 <br>
- Square Error（平方损失） <br>
- Cross Entropy（交叉熵损失） <br>
(2) 选择合适的Mini-batch size <br>
采用合适的Mini-batch进行学习，使用Mini-batch的方法进行学习，一方面可以减少计算量，一方面有助于跳出局部最优点。因此要使用Mini-batch。更进一步，batch的选择非常重要，batch取太大会陷入局部最小值，batch取太小会抖动厉害，因此要选择一个合适的batch size。
    </p>
 </div>
 <br>
 <p>5. 卷积神经网络 CNN 中池化层有什么作用？（其他）</p>
 <label for="control5" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control5" class="nav-con">
    <p class="nav-box"> 
 减小图像尺寸即数据降维，缓解过拟合，保持一定程度的旋转和平移不变性。
    </p>
 </div>
 <br>
 <p>6. 神经网络中 Dropout 的作用？具体是怎么实现的？（其他）</p>
 <label for="control6" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control6" class="nav-con">
    <p class="nav-box"> 
防止过拟合。每次训练，都对每个神经网络单元，按一定概率临时丢弃。
    </p>
 </div>
 <br>
 <p>7. 利用梯度下降法训练神经网络，发现模型loss不变，可能有哪些问题？怎么解决？（其他）</p>
 <label for="control7" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control7" class="nav-con">
    <p class="nav-box"> 
很有可能是梯度消失了，它表示神经网络迭代更新时，有些权值不更新的现象。 <br>
改变激活函数，改变权值的初始化等。
    </p>
 </div>
 <br>
 <p>8. 残差网络为什么能做到很深层？（其他）</p>
 <label for="control8" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control8" class="nav-con">
    <p class="nav-box"> 
神经网络在反向传播过程中要不断地传播梯度，而当网络层数加深时，梯度在逐层传播过程中会逐渐衰减，导致无法对前面网络层的权重进行有效的调整。 残差网络中， 加入了short connections 为梯度带来了一个直接向前面层的传播通道，缓解了梯度的减小问题。
    </p>
 </div>
 <br>
 <p>9. 卷积神经网络中空洞卷积的作用是什么？（其他）</p>
 <label for="control9" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control9" class="nav-con">
    <p class="nav-box"> 
空洞卷积也叫扩张卷积，在保持参数个数不变的情况下增大了卷积核的感受野，同时它可以保证输出的特征映射（feature map）的大小保持不变。一个扩张率为 2 的 3×3 卷积核，感受野与 5×5 的卷积核相同，但参数数量仅为 9 个。
   </p>
 </div>
 <br>
 <p>10. 解释下卷积神经网络中感受野的概念？（其他）</p>
 <label for="control10" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control10" class="nav-con">
    <p class="nav-box"> 
在卷积神经网络中，感受野 (receptive field) 的定义是卷积神经网络每一层输出的特征图（feature map）上的像素点在原始图像上映射的区域大小。
    </p>
 </div>
 <br>
 <p>11. 卷积神经网络中 im2col 是如何实现的？（其他）</p>
 <label for="control11" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control11" class="nav-con">
    <p class="nav-box"> 
使用im2col的方法将划窗卷积转为两个大的矩阵相乘。
    </p>
 </div>
 <br>
 <p>12. 梯度爆炸的解决方法？（其他）</p>
 <label for="control12" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control12" class="nav-con">
    <p class="nav-box"> 
针对梯度爆炸问题，解决方案是引入Gradient Clipping(梯度裁剪)。通过Gradient Clipping，将梯度约束在一个范围内，这样不会使得梯度过大。
    </p>
 </div>
 <br>
 <p>13. 多任务学习中标签缺失如何处理？（其他）</p>
 <label for="control13" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control13" class="nav-con">
    <p class="nav-box"> 
一般做法是将缺失的标签设置特殊标志，在计算梯度的时候忽略。
    </p>
 </div>
 <br>
 </body>
 </html>



# 决策智能
本章汇总了针对【决策智能】细分领域的简答题，涵盖自动驾驶、强化学习两大方向。

## 自动驾驶
本节题目考察自动驾驶相关知识点。

### 题组 I
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. IMU 的噪声模型是什么？</p>
 <label for="control1" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box"> 
目前市面中常见的IMU一般都是六轴，即三轴加速度计和三轴陀螺仪，IMU的随机误差一般包括以下几类，各类误差项及其原理如下： <br>
量化噪声 。量化噪声是传感器的固有误差，在数字传感器通过AD采集把连续时间信号采集成离散信号时产生的误差。量化噪声属于高频噪声，在工程中使用低通滤波或者姿态更新消除掉； <br>
零偏。加速度计/陀螺仪角速度输入为零时的输出量，描述陀螺仪的输出信号围绕其均值的起伏或波动； <br>
零偏稳定性。当输入角速率为零时，陀螺仪输出量围绕其均值的离散程度，即零偏稳定性表达零偏随时间的波动趋势；<br>
角度随机游走 。角度随机游走属于高斯白噪声，一般在卡尔曼滤波中作为误差参数进行处理；
角速率随机游走从理解上和角度随机游走一样，角速率里面并不全是白噪声，它也有马尔可夫性质的误差成分，而这个误差是由宽带角加速率白噪声累积的结果； <br>
速率斜坡。速率斜坡是一种确定性误差，一般由周边环境变化引起。
   </p>
 </div>
 <br>
 <p>2. GPS 双天线安装偏角是怎么标定的？</p>
 <label for="control2" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box"> 
通过车辆前行得到航迹角，同时双天线自己可以计算出一个航向角，两者之差为安装偏角，具体拟合方法可以通过最小二乘或滤波算出。
    </p>
 </div>
 <br>
 <p>3. 多传感器之间是怎么对时的？</p>
 <label for="control3" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box"> 
激光雷达：大多数雷达如VLP-16等都提供基于pps脉冲和GPRMC信号的输入接口，PPS和GPRMC信号可以由GNSS或IMU提供，或者由外部时钟源提供。少数激光雷达还支持NTP/PTP同步，PTP的精度一般来说比NTP要高，这两个信号都需要由外部时钟源设备提供。 <br>
相机：需要支持外部触发曝光的型号，因为相机帧周期包括曝光时间和readout时间（整帧像素点读出），一般来说readout时间是固定的，可以补偿这个时间，相机的时间戳选择为曝光的中间时间。 <br>
GNSS：GNSS可以从卫星获得高精度的时钟信号，而且通常的GNSS都支持PPS脉冲以及GPRMC信号。 <br>
（1）使用GNSS作为时钟源，将GNSS的PPS信号提供给LiDAR和一个开发板，开发板将给相机同时提供一个曝光的脉冲信号。CAMVOX采用这种方案。 <br>
（2）使用外部时钟源，这种时钟源通常支持PPS信号输入，将GNSS的PPS传给外部时钟源，同时外部时钟源可以使用PTP/NTP/PPS给LiDAR做时间同步，同时触发相机开始曝光。外部时钟源同时也可以使用PTP/NTP对主机进行时间同步。
    </p>
 </div>
 <br>
 <p>4. GPS 到来时是有延时的，而 IMU 给出的加速度和角速度是实时的，这种情况下怎么处理延时？怎么做的融合？</p>
 <label for="control4" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box"> 
先通过imu积分计算实时的轨迹，同时把imu数据缓存下来，当GPS到来时，再根据GPS的时间戳去修正历史时刻的数据，然后重新积分该时刻后的imu。
    </p>
 </div>
 <br>
 <p>5. DR 递推的原理是什么？大概怎么去做？</p>
 <label for="control5" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control5" class="nav-con">
    <p class="nav-box"> 
DR，也叫航位推算，是在知道当前时刻位置的条件下，通过测量移动的距离和方位，推算下一时刻位置的方法。可以根据上一时刻位置速度角度，通过imu加速度二次积分得到平移量，角速度积分得到旋转量来进行DR，也可以通过轮速计和车辆运动模型来进行DR。
    </p>
 </div>
 <br>
 <p>6. 组合导航卡尔曼滤波过程噪声是如何调参的？</p>
 <label for="control6" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control6" class="nav-con">
    <p class="nav-box"> 
先通过GPS和imu的性能参数和频率确定一个米级单位下的噪声。之后在该噪声参数下得到融合的轨迹，然后分别对两个噪声增大缩小分成几组进行调节，观察轨迹。最终选最平滑的一组轨迹的噪声参数，或者选跟真值比精度最高的一组的噪声参数。
    </p>
 </div>
 <br>
 <p>7. 常见的高精度地图格式有哪些？</p>
 <label for="control7" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control7" class="nav-con">
    <p class="nav-box"> 
目前最主流的通用格式规范分NDS和OpenDRIVE两种。此外还有日本OMP公司的格式规范。
    </p>
 </div>
 <br>
 <p>8. 常用的高精度定位方式有哪些？</p>
 <label for="control8" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control8" class="nav-con">
    <p class="nav-box"> 
包括RTK算法、Lidar匹配、视觉匹配、SINS模块、Mapping match等等。
    </p>
 </div>
 <br>
 <p>9. 高精度地图的全局路径规划算法有哪些？</p>
 <label for="control9" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control9" class="nav-con">
    <p class="nav-box"> 
常用的全局路径规划算法有： <br>
Dijkstra <br>
BFS（Best-First-Search） <br>
A* <br>
hybrid A* <br>
D * <br>
RRT <br>
RRT* <br>
蚁群算法 <br>
Rectangular Symmetry Reduction (RSR) <br>
BUG <br>
Beam search <br>
Iterative Deepeningc <br>
Dynamic weighting <br>
Bidirectional search <br>
Dynamic A* and Lifelong Planning A * <br>
Jump Point Search <br>
Theta * <br>
不过目前主流的还是深度优先搜索、广度优先搜索、A*和Dijkstra。
   </p>
 </div>
 <br>
 <p>10. 高精度地图曲线拟合算法算有哪些？</p>
 <label for="control10" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control10" class="nav-con">
    <p class="nav-box"> 
高精度地图曲线拟合和局部车道线规划如出一辙，一般有：多项式曲线拟合、三次样条插值曲线、贝塞尔曲线拟合、微分平坦、B样条曲线、RANSAC等等。
    </p>
 </div>
 <br>
 <p>11. 如何使用 ceres 库？</p>
 <label for="control11" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control11" class="nav-con">
    <p class="nav-box"> 
Ceres是一个C++库，可以求解通用的最小二乘问题，使用方法大体上分为如下三步： <br>
定义代价函数； <br>
构建最小二乘问题，向问题中添加误差项，此时会用到第一步的代价函数； <br>
配置求解器，开始求解。
    </p>
 </div>
 <br>
 </body>
 </html>

### 题组 II
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. 路径规划的主要内容有哪些？</p>
 <label for="control12" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control12" class="nav-con">
    <p class="nav-box"> 
路径规划只要分为：寻路（Routing）、决策（Behavioral Decision）、运动规划（Motion Planning）。寻路主要为全局路径规划，现阶段主要为传统导航地图（SD地图）和高精度地图结合进行路径规划；决策主要为在遇到交通灯和行人时的避让、高速路分流合流的选择、以及路口时转向判断等等；运动规划是指局部路径规划，判断前方几百米内的期望行驶路径，需结合汽车运动学、动力学、舒适性和无碰撞等要求。
    </p>
 </div>
 <br>
 <p>2. 是否了解基于人工势场的规划算法？</p>
 <label for="control13" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control13" class="nav-con">
    <p class="nav-box"> 
人工势场的规划算法主要假设车辆行驶在虚拟力场下，车辆的初始点在高势场下，要达到低势场。这种算法使得车辆在势的影响下，避开障碍物达到目标点，常见的相关算法也有很多，重点需要解决的问题就是如何避免车辆先入局部最优解。
    </p>
 </div>
 <br>
 <p>3. 是否了解 RRT 算法？</p>
 <label for="control14" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control14" class="nav-con">
    <p class="nav-box"> 
RRT算法主要原理是基于采样的算法，把起点作为一颗种子，向下生长枝桠。像树一样的路径以探索空间的大部分区域，快速的进行扩张，伺机找到目标点，但找到的路径质量不高，通常不是最优路径。
    </p>
 </div>
 <br>
 <p>4. linux 内核主要分为哪几个系统？</p>
 <label for="control15" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control15" class="nav-con">
    <p class="nav-box"> 
进程管理系统、内存管理系统、I/O管理系统和文件管理系统
    </p>
 </div>
 <br>
 <p>5. vi 有哪两种模式？</p>
 <label for="control16" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control16" class="nav-con">
    <p class="nav-box"> 
命令模式和输入模式
    </p>
 </div>
 <br>
 <p>6. 进程的查看和调度命令？</p>
 <label for="control17" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control17" class="nav-con">
    <p class="nav-box"> 
进程查看：ps和top <br>
进程调度：kill、at、batch
    </p>
 </div>
 <br>
 <p>7. Linux 属于哪种类型的操作系统？</p>
 <label for="control18" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control18" class="nav-con">
    <p class="nav-box"> 
多用户、多任务、多进程
    </p>
 </div>
 <br>
 <p>8. 如何查看当前进程？如何退出？</p>
 <label for="control19" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control19" class="nav-con">
    <p class="nav-box"> 
ps；exit
    </p>
 </div>
 <br>
 <p>9. ROS 中 rosrun 与 roslaunch 的区别？</p>
 <label for="control20" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control20" class="nav-con">
    <p class="nav-box"> 
rosrun 允许您在任意软件包中运行可执行文件，而无需先在其中进行cd（或roscd）。 <br>
roslaunch 是一种工具，可通过SSH在本地和远程轻松启动多个ROS节点，以及在参数服务器上设置参数。 它包括自动重生已经死掉的进程的选项。 roslaunch接收一个或多个XML配置文件（带有.launch扩展名），这些文件指定要设置的参数和要启动的节点以及应在其上运行的计算机。 <br>
可以看出：rosrun只能运行一个node， roslaunch可以同时运行多个nodes。 <br>
roslaunch可以用来启动定义在launch文件中的多个节点，通常的命名方案是以.launch作为启动文件的后缀，启动文件是xml文件，一般把启动文件存储在取名为launch的目录中，用法：$ roslaunch [package] [filename.launch]
    </p>
 </div>
 <br>
 <p>10. ROS 中常用的开发工具？</p>
 <label for="control21" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control21" class="nav-con">
    <p class="nav-box"> 
launch文件，可以同时启动多个ros节点，可自动启动rosmaster。 <br>
TF坐标变换，用来描述机器人系统中繁杂的坐标系。 <br>
QT工具箱，用来可视化各个ros节点之间的订阅或者请求关系或者可视化各种话题的数据。常用命令，rqt_graph、rqt_plot，而且还可以动态修改部分参数。 <br>
rviz可视化平台，机器人可视化平台，几乎是最常用的工具。使用rviz命令启动 <br>
Gazebo物理仿真环境，可对机器人进行三维物理仿真。需要仿真的同学常用。
    </p>
 </div>
 <br>
 </body>
 </html>


## 强化学习
本节题目考察强化学习相关知识点。

### 题组 I
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. L 的马尔科夫性质</p>
 <label for="control1" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box"> 
t+1 时的状态仅与 t 时的状态有关，而与更早之前的历史状态无关。
   </p>
 </div>
 <br>
 <p>2. RL 与监督学习和无监督学习的区别？</p>
 <label for="control2" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box"> 
RL： <br>
通过反复试错学习最优策略 <br>
不需要由外部提供带标签的训练数据，仅需要在交互中对代理的动作选择做出反馈 <br>
监督学习： <br>
学会推断样本的标签 <br>
需要带正确标签的样本指导训练 <br>
无监督学习： <br>
学习底层数据的结构 <br>
不需要标签值也不需要反馈
    </p>
 </div>
 <br>
 <p>3. RL 不同于其它学习算法的原因？</p>
 <label for="control3" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box"> 
没有监督者，只有一个奖励信号 <br>
反馈是延迟的，不是即时的 <br>
数据间有时序关系，是序列数据，而不是独立同分布数据 <br>
代理的动作影响后续接受到的数据
    </p>
 </div>
 <br>
 <p>4. 重要性采样的作用？</p>
 <label for="control4" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box"> 
重要性采样一般用于off-policy学习中。off-policy一般有两个策略：行为策略 b 和目标策略Π，且 b≠Π。当我们要评估基于 Π 的值函数 VΠ 和 QΠ 时，需要使用到历史交互样本，但是这些样本都是用策略 b 得到的，所以得到的结果必然存在偏差。重要性采样则把基于行为策略 b 估计得到的值矫正到基于目标策略 Π 所估计得到的值，得到基于目标策略的无偏估计，并使得行为策略向目标策略靠拢。
    </p>
 </div>
 <br>
 <p>5. DQN 和 Sarsa 的区别？</p>
 <label for="control5" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control5" class="nav-con">
    <p class="nav-box"> 
DQN是Q-learning的改进算法，属于off-policy算法，而SARSA属于on-policy的算法。 <br>
所以可以回答off-policy和on-policy的区别；再有就是回答使用神经网络近似值函数的优点：可以处理连续状态空间，无需存Q-表，节省内存。
    </p>
 </div>
 <br>
 </body>
 </html>



# 搜推广
本章汇总了针对【搜推广】细分领域的简答题，涵盖推荐系统、计算广告两大方向。

## 推荐系统
本节题目考察推荐系统相关知识点。

### 题组 I
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. 为什么分类问题损失不使用 MSE 而使用交叉熵？（美团）</p>
 <label for="control1" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box"> 
1. 均方误差作为损失函数，这时所构造出来的损失函数是非凸的，不容易求解，容易得到其局部最优解；而交叉熵的损失函数是凸函数； <br>
2. 均方误差作为损失函数，求导后，梯度与sigmoid的导数有关，会导致训练慢；而交叉熵的损失函数求导后，梯度就是一个差值，误差大的话更新的就快，误差小的话就更新的慢点。
   </p>
 </div>
 <br>
 <p>2. 训练时出现不收敛的情况怎么办，为什么会出现不收敛？ （美团）</p>
 <label for="control2" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box"> 
从数据角度： <br>
是否对数据进行了预处理，包括分类标注是否正确，数据是否干净 <br>
是否对数据进行了归一化 <br>
考虑样本的信息量是否太大，而网络结构是否太简单 <br>
考虑标签是否设置正确 <br>

从模型角度： <br>
尝试加深网络结构 <br>
Learning rate是否合适（太大，会造成不收敛，太小，会造成收敛速度非常慢） <br>
错误初始化网络参数 <br>
train loss 不断下降，test loss不断下降，说明网络仍在学习; <br>
train loss 不断下降，test loss趋于不变，说明网络过拟合; <br>
train loss 趋于不变，test loss不断下降，说明数据集100%有问题; <br>
train loss 趋于不变，test loss趋于不变，说明学习遇到瓶颈，需要减小学习率或批量数目; <br>
train loss 不断上升，test loss不断上升，说明网络结构设计不当，训练超参数设置不当，数据集经过清洗等问题。
 </p>
 </div>
 <br>
 <p>3. LR 与决策树的区别？（美团）</p>
 <label for="control3" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box"> 
1、逻辑回归通常用于分类问题，决策树可回归、可分类。 <br>
2、逻辑回归是线性函数，决策树是非线性函数。 <br>
3、逻辑回归的表达式很简单，回归系数就确定了模型。决策树的形式就复杂了，叶子节点的范围+取值。两个模型在使用中都有很强的解释性，银行较喜欢。 <br>
4、逻辑回归可用于高维稀疏数据场景，比如ctr预估；决策树变量连续最好，类别变量的话，稀疏性不能太高。 <br>
5、逻辑回归的核心是sigmoid函数，具有无限可导的优点，常作为神经网络的激活函数。 <br>
6、在集成模型中，随机森林、GBDT以决策树为基模型，Boosting算法也可以用逻辑回归作为基模型。
    </p>
 </div>
 <br>
 <p>4. 有哪些决策树算法？（美团）</p>
 <label for="control4" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box"> 
ID3、C4.5、CART树的算法思想 <br>
ID3算法的核心是在决策树的每个节点上应用信息增益准则选择特征，递归地构架决策树。 <br>
C4.5算法的核心是在生成过程中用信息增益比来选择特征。 <br>
CART树算法的核心是在生成过程用基尼指数来选择特征。 <br>
基于决策树的算法有随机森林、GBDT、Xgboost等。
    </p>
 </div>
 <br>
 <p>5. 召回和排序的差异？（美团）</p>
 <label for="control5" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control5" class="nav-con">
    <p class="nav-box"> 
召回的目的在于减少候选的数量（尽量控制在1000以内），方便后续排序环节使用复杂模型精准排序；因为在短时间内评估海量候选，所以召回的关键点是个快字，受限与此与排序相比，召回的算法模型相对简单，使用的特征比较少。而排序模型相对更加复杂，更追求准确性，使用的特征也会较多。
    </p>
 </div>
 <br>
 <p>6. 结果 f1 提升的 1% 怎么保证有效性，如何保证置信呢？（美团）</p>
 <label for="control6" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control6" class="nav-con">
    <p class="nav-box"> 
实验过程中固定随机种子、多次实验取平均。
    </p>
 </div>
 <br>
 <p>7. 固定随机种子后，多次实验结果相同吗？（美团）</p>
 <label for="control7" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control7" class="nav-con">
    <p class="nav-box"> 
还是会有细微差别，因为在梯度传播过程，梯度（浮点数）精度有差异，随着神经网络层数的增加，梯度差异会从小数后面的位置往前跑。只能设置浮点数精度增加来缓解这个问题。
    </p>
 </div>
 <br>
 <p>8. 召回主流的做法？（美团）</p>
 <label for="control8" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control8" class="nav-con">
    <p class="nav-box"> 
主流的召回做法包括：规则召回，协同召回，基于内容语义的 I2I 召回，向量召回（基于embedding），树召回和图召回。
    </p>
 </div>
 <br>
 <p>9. 介绍下 embedding 召回？（美团）</p>
 <label for="control9" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control9" class="nav-con">
    <p class="nav-box"> 
举一个文本类embedding的例子。 <br>
文本类的Embedding可以分为两种，一种是比较传统的word2vector、fasttext、glove这些算法的方案，叫做词向量固定表征类算法，这些算法主要是通过分析词的出现频率来进行Embedding生成，不考虑文本上下文。 <br>
而另一种文本Embedding方法，也是目前最流行的方案是动态词表征算法，比如Bert、ELMo、GPT，这类算法会考虑文本上下文。
   </p>
 </div>
 <br>
 <p>10. 推荐系统冷启动问题，怎么解决？（美团）</p>
 <label for="control10" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control10" class="nav-con">
    <p class="nav-box"> 
1. 提供非个性化的推荐 <br>
最简单的例子就是热门排行榜，我们可以给用户推荐热门排行榜，然后等到用户数据收集到一定的时候，再切换为个性化推荐。 <br>
2. 利用用户注册信息 <br>
用户注册时提供包括用户的年龄、性别、职业、民族、学历和居住地等数据，做粗粒度的个性化。有一些网站还会让用户用文字描述他们的兴趣。 <br>
3. 利用社交网络信息 <br>
引导用户通过社交网络账号登录（需要用户授权），导入用户在社交网站上的好友信息，然后给用户推荐其好友喜欢的物品。
    </p>
 </div>
 <br>
 </body>
 </html>

### 题组 II
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. 你所理解的推荐系统是什么样的？大致流程？所用模型？（携程）</p>
 <label for="control11" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control11" class="nav-con">
    <p class="nav-box"> 
推荐系统一方面是为了帮助消费者发现对自己有价值的商品，另一方面是帮助生产者把用户可能感兴趣的商品展现给用户，实现生产者和消费者的双赢。 <br>
大致流程主要包括：获取用户特征，召回过程，排序过程（粗排、精排）。 <br>

召回模型： <br>
规则召回（兴趣标签top，热门top，新品top等） <br>

协同召回（基于用户的协同过滤，基于商品的协同过滤） <br>

向量召回（FM召回，Item2vec,Youtube DNN向量召回，Graph Embedding召回，DSSM双塔召回） <br>

排序模型：GBDT + LR、Xgboost、FM/FFM、Wide&Deep、DeepFM、Deep & Cross、DIN、BST等 
    </p>
 </div>
 <br>
 <p>2. 双塔模型优势，缺点，如何改进？（携程）</p>
 <label for="control12" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control12" class="nav-con">
    <p class="nav-box"> 
双塔模型的优势是速度快，但模型精度还有待提升。 <br>
速度快是因为将所有Item转化成Embedding，并存储进ANN检索系统，比如FAISS，以供查询。类似FAISS这种ANN检索系统对海量数据的查询效率高。 <br>
而双塔模型为了速度快，必须对用户和Item进行特征分离，而特征分离，又必然导致上述两个原因产生的效果损失。 <br>
改进：SENet双塔模型，把SENet放在Embedding层之上，目的是通过SENet网络，动态地学习这些特征的重要性：对于每个特征学会一个特征权重，然后再把学习到的权重乘到对应特征的Embedding里，这样就可以动态学习特征权重，通过小权重抑制噪音或者无效低频特征，通过大权重放大重要特征影响的目的。
    </p>
 </div>
 <br>
 <p>3. 粗排的目的是什么？（携程）</p>
 <label for="control13" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control13" class="nav-con">
    <p class="nav-box"> 
粗排是用来帮精排模型找到那些它本来就要打高分的item，只不过范围更广一些。按照上面的例子，如果没有粗排，精排模型自己找出来的某top10的item。而粗排的任务就是要找到包含这10个item的一个更小的候选集，既保证了效果，又减少线上预测的负担。
    </p>
 </div>
 <br>
 <p>4. wide & deep 模型 为什么要有 wide 层结构，优缺点，如何改进？（携程）</p>
 <label for="control14" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control14" class="nav-con">
    <p class="nav-box"> 
wide&deep模型中的wide部分可以通过利用交叉特征引入非线性高效的实现记忆能力，但需要依赖人工特征工程。 <br>
改进：DeepFM在Wide&Deep的基础上进行改进，不需要预训练FM得到隐向量，不需要人工特征工程，能同时学习低阶和高阶的组合特征；FM模块和Deep模块共享Feature Embedding部分，可以更快的训练，以及更精确的训练学习。
    </p>
 </div>
 <br>
 <p>5. 推荐领域 GBDT + LR 的做法了解吗？（携程）</p>
 <label for="control15" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control15" class="nav-con">
    <p class="nav-box"> 
GBDT+LR 由两部分组成，其中GBDT用来对训练集提取特征作为新的训练输入数据，LR作为新训练输入数据的分类器。GBDT+LR的提出意味着特征工程可以完全交由一个独立的模型来完成，模型的输入可以是原始的特征向量，不必在特征工程上投入过多的人工筛选和模型设计的精力，真正实现了端到端的训练。
    </p>
 </div>
 <br>
 <p>6. ROC，PR 曲线含义，坐标轴代表什么？（携程）</p>
 <label for="control16" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control16" class="nav-con">
    <p class="nav-box"> 
ROC曲线以真正例率TPR为纵轴，以假正例率FPR为横轴，在不同的阈值下获得坐标点，并连接各个坐标点，得到ROC曲线。 <br>
PR曲线中的P代表的是Precision（精准率），R代表的是Recall（召回率），其代表的是精准率与召回率的关系，一般情况下，Precision设置为纵坐标，将Recall设置为横坐标。
    </p>
 </div>
 <br>
 <p>7. AUC 怎么求，实际意义？（携程）</p>
 <label for="control17" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control17" class="nav-con">
    <p class="nav-box"> 
AUC：随机取一个正样本和一个负样本，正样本的预测值大于负样本预测值的概率。 <br>
AUC计算的关键是找到所有正样本预测值大于负样本预测值的正负样本对。 <br>
首先，需要将样本按照预测值进行从小到大排序（最小score对应的sample的rank为1，第二小score对应sample的rank为2，以此类推）； <br>
其次，把所有的正类样本的rank相加，再减去两个正样本组合的情况。
    </p>
 </div>
 <br>
 <p>8. 召回阶段的负采样是怎么做的？（字节跳动）</p>
 <label for="control18" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control18" class="nav-con">
    <p class="nav-box"> 
第一版i2i在batch内随机负采样，并加了bias进行修正；第二版u2i借鉴w2v，以uv曝光为权重，全局负采样，但是由于全局负彩成本太大，做了二次哈希，根据样本uv进行了分桶； <br>
加bias有什么用？ <br>
答：负采样的本质是想打压高曝光item，但是由于高曝光的item本身就频繁出现在样本中，随机采可能会打压过头，因此加一个bias tower进行修正（其实就是学一个值取平衡正负样本）。 <br>
带权负采样的逻辑？ <br>
答：如果按照uv曝光进行带权负采样，就是先按照uv曝光排序，之后累加，最后生成一个随机数，看着随机数落到哪两个item的uv累加和（前缀和）区间，就采样哪个item。
    </p>
 </div>
 <br>
 <p>9. FM，DeepFM 跟 FFM 的对比（字节跳动）</p>
 <label for="control19" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control19" class="nav-con">
    <p class="nav-box"> 
FM主要解决了LR不能主动学习特征交叉组合问题；解决特征稀疏，特征交叉，权重矩阵稀疏学习困难问题；解决特征交叉组合，模型参数量过大，复杂度高问题。 <br>
FFM相比FM基础上，引入了Field-aware，每个特征在每个field上有对应不同的隐向量。 <br>
DeepFM是一个端到端的学习模型，DeepFM将FM的隐向量同时作为Deep的词向量参数，两者共享，让模型自动去学习低阶与高阶的特征交互。
    </p>
 </div>
 <br>
 </body>
 </html>


## 计算广告
本节题目考察计算广告相关知识点。

### 题组 I
<!DOCTYPE html>
 <html>
 <head>
 <style>
 label:hover  {color: #3172cc;}
 .nav-con{display: none;}
 .nav-box{display: none;}
 .nav-con:checked ~ .nav-box{display: block;}
 .nav-btn{font-size:16px; font-weight: bold;}
 </style>
 </head>
 <body>
 <p>1. 为什么用交叉熵不用均方误差?（快手）</p>
 <label for="control1" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box"> 
1、均方误差作为损失函数，这时所构造出来的损失函数是非凸的，不容易求解，容易得到其局部最优解；而交叉熵的损失函数是凸函数； <br>
2、均方误差作为损失函数，求导后，梯度与sigmoid的导数有关，会导致训练慢；而交叉熵的损失函数求导后，梯度就是一个差值，误差大的话更新的就快，误差小的话就更新的慢点。
   </p>
 </div>
 <br>
 <p>2. 说一下 Adam 优化的优化方式？（快手）</p>
 <label for="control2" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box"> 
Adam算法即自适应时刻估计方法（Adaptive Moment Estimation），能计算每个参数的自适应学习率。这个方法不仅存储了AdaDelta先前平方梯度的指数衰减平均值，而且保持了先前梯度M(t)的指数衰减平均值，这一点与动量类似。 <br>
Adam实际上就是将Momentum和RMSprop集合在一起，把一阶动量和二阶动量都使用起来了。
    </p>
 </div>
 <br>
 <p>3. DQN 是 On-policy 还是 off-policy？有什么区别？（快手）</p>
 <label for="control3" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box"> 
off-policy的方法将收集数据作为RL算法中单独的一个任务，它准备两个策略：行为策略 (behavior policy) 与目标策略 (target policy)。<br>
行为策略是专门负责学习数据的获取，具有一定的随机性，总是有一定的概率选出潜在的最优动作。而目标策略借助行为策略收集到的样本以及策略提升方法提升自身性能，并最终成为最优策略。<br>
Off-policy是一种灵活的方式，如果能找到一个“聪明的”行为策略，总是能为算法提供最合适的样本，那么算法的效率将会得到提升。on-policy 里面只有一种策略，它既为目标策略又为行为策略。
    </p>
 </div>
 <br>
 <p>4. 归一化  [-1,1]  和归一化到 [0,1] 对后面的网络计算有什么影响吗？（快手）</p>
 <label for="control4" class="nav-btn">👉查看答案👈</label>
 <div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box"> 
一般会归一化到 [-1,1]，因为大部分网络是偏好零对称输入的，神经网路中使用激活函数一般都是ReLU，如果ReLU的输入都是正数，那么它其实就是一个恒等函数，有没有它都一个样，ReLU就失去了意义。 <br>
如果ReLU的输入都是负数的话，会出现“死区”，即神经元输出都是0，为了避免这个问题，需要令ReLU的输入尽量正负平衡，比如在ReLU前加一个BN。
    </p>
 </div>
 <br>
 </body>
 </html>



# 算法岗推荐学习书目
- [数据库知识手册](https://leetcode.cn/leetbook/detail/database-handbook/?from=from_parent_mindnote)
- [概率题面试突击](https://leetcode.cn/leetbook/detail/probability-problems/?from=from_parent_mindnote)
- [春招热门岗位攻略](https://leetcode.cn/leetbook/detail/chun-zhao-re-men-gang-wei-gong-lue/)
- [图解算法数据结构](https://leetcode.cn/leetbook/detail/illustration-of-algorithm/)
- [岗位面试模拟题集](https://leetcode.cn/leetbook/detail/gang-wei-mian-shi-mo-ni-ti-ji/)
