
# C++ 编译与内存相关
本章将重点涉及以下高频知识点：

## C++ 内存管理
1. `ELF` 文件:
   可执行与可链接格式 `(Executable and Linkable Format)` 是一种用于可执行文件、目标代码、共享库和核心转储 `（core dump）` 的标准文件格式，每个 $\texttt{ELF}$ 文件都由一个 `ELF header` 和紧跟其后的文件数据部分组成，可以参考 $\texttt{ELF}$ 文件的构成如下:
![1_2_1.png](https://pic.leetcode-cn.com/1661172875-aSnoQn-1_2_1.png)
   我们可以看到可执行程序内部都是分段进行存储的。

+ `.text section`：代码段。通常存放已编译程序的机器代码，一般操作系统加载后，这部分是只读的。

+ `.rodatasection`：只读数据段。此段的数据不可修改，存放程序中会使用的常量。比如程序中的常量字符串 $\texttt{"aasdasdaaasdasd"}$。

+ `.datasection`：数据段。主要用于存放已初始化的全局变量、常量。

+ .`bsssection`: `bss` 段。该段主要存储未初始化全局变量，仅是占位符，不占据任何实际磁盘空间。目标文件格式区分初始化和非初始化是为了空间效率。

操作系统在加载 `ELF` 文件时会将按照标准依次读取每个段中的内容，并将其加载到内存中，同时为该进程分配栈空间，并将 `pc` 寄存器指向代码段的起始位置，然后启动进程。


2. 内存分区：
   `C++` 程序在运行时也会按照不同的功能划分不同的段，`C++` 程序使用的内存分区一般包括：栈、堆、全局/静态存储区、常量存储区、代码区。

+ **栈**：目前绝大部分 $\texttt{CPU}$ 体系都是基于栈来运行程序，栈中主要存放函数的局部变量、函数参数、返回地址等，栈空间一般由操作系统进行默认分配或者程序指定分配，栈空间在进程生存周期一直都存在，当进程退出时，操作系统才会对栈空间进行回收。

+ **堆**：动态申请的内存空间，就是由 `malloc` 函数或者 `new` 函数分配的内存块，由程序控制它的分配和释放，可以在程序运行周期内随时进行申请和释放，如果进程结束后还没有释放，操作系统会自动回收。我们可以利用 

+ **全局区/静态存储区**：主要为 `.bss` 段和 `.data` 段，存放全局变量和静态变量，程序运行结束操作系统自动释放，在 `C` 中，未初始化的放在 `.bss` 段中，初始化的放在 `.data` 段中，`C++` 中不再区分了。

+ **常量存储区**：`.rodata 段`，存放的是常量，不允许修改，程序运行结束自动释放。

+ **代码区**：`.text 段`，存放代码，不允许修改，但可以执行。编译后的二进制文件存放在这里。

我们参考常见的 $\texttt{Linux}$ 操作系统下的内存分布图如下:

从操作系统的本身来讲，以上存储区在该程序内存中的虚拟地址分布是如下形式（虚拟地址从低地址到高地址，实际的物理地址可能是随机的）：$\texttt{.text} \rightarrow \texttt{.data}  \rightarrow \texttt{.bss} \rightarrow \texttt{heap} \rightarrow  \texttt{unused} \rightarrow  \texttt{stack} \rightarrow \cdots$。

![1_2_2.png](https://pic.leetcode-cn.com/1661172955-UkYaoa-1_2_2.png)


+ **程序实例**：
  以下为详细的程序实例，当然可以通过 $\texttt{GDB}$ 工具来查看具体的每个变量的存放地址。

    ```C++ []
    #include <iostream>
    using namespace std;
    /*
    说明：C++ 中不再区分初始化和未初始化的全局变量、静态变量的存储区，如果非要区分下述程序标注在了括号中
    */
    int g_var = 0; // g_var 在全局区（.data 段）
    char *gp_var;  // gp_var 在全局区（.bss 段）
  
    int main()
    {
        int var;                    // var 在栈区
        char *p_var;                // p_var 在栈区
        char arr[] = "abc";         // arr 为数组变量，存储在栈区；"abc"为字符串常量，存储在常量区
        char *p_var1 = "123456";    // p_var1 在栈区；"123456"为字符串常量，存储在常量区
        static int s_var = 0;       // s_var 为静态变量，存在静态存储区（.data 段）
        p_var = (char *)malloc(10); // 分配得来的 10 个字节的区域在堆区
        free(p_var);
        return 0;
    }
    ```

  参考资料：

+ [How programs get run: ELF binaries](https://lwn.net/Articles/631631/)

+ [Memory Layout of C Programs](https://www.***.org/memory-layout-of-c-program/?ref=lbp)

## 堆与栈
1. 栈：
   首先需要详细了解计算机系统中的 「[Stack machine](https://www.cp.eng.chula.ac.th/~prabhas//teaching/ca/stack.htm)」的基本概念，了解程序中函数的调用过程。每次在调用函数时，会按照从右向左的顺序依次将函数调用参数压入到栈中，并在栈中压入返回地址与当前的栈帧，然后跳转到调用函数内部，`pc` 跳转函数内部执行该函数的指令，在此不再展开叙述，可以详细参考许多关于栈模型的资料。
![1_3_1.png](https://pic.leetcode-cn.com/1661173060-pmaNGZ-1_3_1.png)

+ **程序示例**：我们可以在 `gdb` 下查看分配的栈的空间以及当前栈上分配的元素。

  + 我们编写如下程序：

  ```Cpp
  #include <iostream>
  using namespace std;
  /*
  说明：C++ 中不再区分初始化和未初始化的全局变量、静态变量的存储区，如果非要区分下述程序标注在了括号中
  */
  int g_var = 0; // g_var 在全局区（.data 段）
  char *gp_var;  // gp_var 在全局区（.bss 段）
  
  int main()
  {
      int var;                    // var 在栈区
      char *p_var;                // p_var 在栈区
      char arr[] = "abc";         // arr 为数组变量，存储在栈区；"abc"为字符串常量，存储在常量区
      char *p_var1 = "123456";    // p_var1 在栈区；"123456"为字符串常量，存储在常量区
      static int s_var = 0;       // s_var 为静态变量，存在静态存储区（.data 段）
      p_var = (char *)malloc(10); // 分配得来的 10 个字节的区域在堆区
      free(p_var);
      return 0;
  }
  ```

  + 我们使用调试工具「[$\texttt{GDB}$](https://sourceware.org/gdb/download/onlinedocs/gdb.pdf)」查看程序的堆栈信息，以及当前堆中的变量信息如下：

  ```shell
  $ gdb d
  (gdb) b main
  Breakpoint 1 at 0x81d: file d.cpp, line 10.
  (gdb) r
  Starting program: /mnt/c/work/leetcode/d
  
  Breakpoint 1, main () at d.cpp:10
  10      {
  (gdb) bt full
  #0  main () at d.cpp:10
          var = <optimized out>
          p_var = 0x8000730 <_start> "1\355I\211\321^H\211\342H\203\344\360PTL\215\005\n\002"
          arr = "\377\177\000"
          p_var1 = 0x80008e0 <__libc_csu_init> "AWAVI\211\327AUATL\215%\206\004 "
          s_var = 0
  (gdb) info reg
  rax            0x8000815        134219797
  rbx            0x0      0
  rcx            0x100    256
  rdx            0x7ffffffedd28   140737488280872
  rsi            0x7ffffffedd18   140737488280856
  rdi            0x1      1
  rbp            0x7ffffffedc30   0x7ffffffedc30
  rsp            0x7ffffffedc10   0x7ffffffedc10
  r8             0x7ffffefdcd80   140737471434112
  r9             0x0      0
  r10            0x6      6
  r11            0x7fffff1316d0   140737472829136
  r12            0x8000730        134219568
  r13            0x7ffffffedd10   140737488280848
  r14            0x0      0
  r15            0x0      0
  rip            0x800081d        0x800081d <main()+8>
  eflags         0x202    [ IF ]
  cs             0x33     51
  ss             0x2b     43
  ds             0x0      0
  es             0x0      0
  fs             0x0      0
  gs             0x0      0
  (gdb)
  ```

  + 我们知道 $\texttt{rsp}$ 寄存器存放的地址即为当前的栈顶，$\texttt{rbp}$ 寄存器存放的地址即为当前的栈帧，与 $\texttt{rbp}$ 寄存器相邻的位置存放的数据即为函数的返回地址与调用函数的栈帧，通过以上信息我们即可获取函数的调用关系。

+ **栈溢出**: 
  一般情况操作系统为每个进程会固定栈空间的大小：

  ```shell
  $ ulimit -s 
  8192
  ```

  当然实际情况，我们可以根据自己的需要来分配每个进程的栈空间。在实际编写程序时，如果出现两个函数互相调用或者递归无退出条件时，此时栈空间的就会无限增长。
  当然实际的栈的分配与应用较为复杂，需要详细阅读操作系统的相关材料，栈一般还分为内核栈与用户栈，在栈顶会有一个特殊的内存页 `guard`，当栈一旦越界访问该特殊的 `guard` 页时，则会出现栈溢出的错误。

2. 堆：
   当程序在运行时，需要动态申请额外的内存来存放相应的数据和变量，此时就需要用到堆。堆的内存空间一般由操作系统或者专门内存程序来管理的。在 `C/C++` 一般用 `malloc` 或者 `new` 来从堆中申请内存，使用 `free` 或者 `delete` 来释放空间，空间释放后会有操作系统进行回收。当然在实际的程序运行中动态内存管理非常复杂，会有许多非常复杂的技巧来处理。

3. 堆与栈的优缺点：

+ **申请方式**：栈中存放的变量在编译时由编译器为其在栈上分配了空间，即程序编译后该变量在栈中使用的内存即确定，释放时也由于函数调用的返回，栈的空间会自动进行回收。堆中存放的变量由程序运行时决定的，会有操作系统或者内存管理模块来进行分配的。

+ **申请后系统响应**：
  + 分配栈空间时如果剩余空间大于申请空间则分配成功，否则分配失败栈溢出，绝大多数情况下，栈的空间较小，一般栈上分配的变量不会占用太大的空间，且当函数返回时，当前栈帧中的变量生存周期会结束；申请堆空间，堆在内存中呈现的方式类似于链表（记录空闲地址空间的链表），在链表上寻找第一个大于申请空间的节点分配给程序，将该节点从链表中删除，大多数系统中该块空间的首地址存放的是本次分配空间的大小，便于释放，将该块空间上的剩余空间再次连接在空闲链表上，堆上可以分配较大的空间，如果不对申请的内存进行释放，则堆上存储的变量生存周期一直存在，直到当前进程退出。
  + 栈在内存中是连续的一块空间（向低地址扩展）最大容量是系统预定好的，且只能被当前的线程访问；堆在内存中的空间（向高地址扩展）是不连续的，中间允许有间隔，堆中的内存并不是线程安全的，同一进程的线程都都可访问。

+ **申请效率**：栈是有系统自动分配，申请效率高，但程序员无法控制；堆是由程序员主动申请，效率低，使用起来方便但是容易产生碎片。
  存放的内容：栈中存放的是局部变量，函数的参数；堆中存放的内容由程序员控制。

4. 实际的内存管理
   实际的内存管理可能更为复杂，一般分为两级内存管理。

+ 操作系统按照段页式来管理内存，当需要创建新的进程或者线程时，操作系统会为新创建的进程分配物理页，当运行的进程需要更多的内存时，操作系统也会为其分配新的物理页并将其映射到该进程的虚拟地址空间中。
+ 程序运行时，每个程序都含有一个内存管理的子程序，专门负责程序中的内存申请和释放，其中的技巧可能非常复杂，并且涉及许多内存分配的算法。

参考资料：

+ [Stack machine](https://www.cp.eng.chula.ac.th/~prabhas//teaching/ca/stack.htm)
+ [Memory Management: Stack And Heap](https://icarus.cs.weber.edu/~dab/cs1410/textbook/4.Pointers/memory.html)
+ [Stack vs Heap Memory Allocation](https://www.***.org/stack-vs-heap-memory-allocation/?ref=gcse)
+ [$\texttt{GDB}$](https://sourceware.org/gdb/download/onlinedocs/gdb.pdf)
+ [Dynamic Memory Allocation and Fragmentation in C and C++](https://www.design-reuse.com/articles/25090/dynamic-memory-allocation-fragmentation-c.html)
+ [从操作系统内存管理来说，malloc申请一块内存的背后原理是什么？](https://www.zhihu.com/question/33979489)

## 变量定义与生存周期
`C/C++` 变量有两个非常重要的属性：作用域与生命周期，这两个属性代表从时间和空间两个不同的维度来描述一个变量。

1. 作用域：
   作用域即一个变量可以被引用的范围，常见的作用域可分为 6 种：全局作用域，局部作用域，语句作用域，类作用域，命名空间作用域和文件作用域。从作用域来来看：

+ **全局变量**：具有全局作用域。全局变量只需在一个源文件中定义，就可以作用于所有的源文件。其他不包含全局变量定义的源文件需要用 `extern` 关键字再次声明这个全局变量。

+ **静态全局变量**：具有文件作用域。它与全局变量的区别在于如果程序包含多个文件的话，它作用于定义它的文件里，不能作用到其它文件里，即被 `static` 关键字修饰过的变量具有文件作用域。这样即使两个不同的源文件都定义了相同名字的静态全局变量，它们也是不同的变量。

+ **局部变量**：具有局部作用域。它是自动对象（`auto`），在程序运行期间不是一直存在，而是只在函数执行期间存在，函数的一次调用执行结束后，变量被撤销，其所占用的内存也被收回，局部变量对于函数外部的程序来说是不可见的。当然内部实际更复杂，实际是以 `{}` 为作用域的。

+ **静态局部变量**：具有局部作用域。它只被初始化一次，自从第一次被初始化直到程序运行结束都一直存在，它和全局变量的区别在于全局变量对所有的函数都是可见的，而静态局部变量只对定义自己的函数体始终可见, 只有定义该变量的函数内部可以使用访问和修改该变量。
  比如以下文件定义

+ **程序实例**：
  以下为详细的程序实例 `a.cpp, b.cpp`，分别对应的变量定义。

    + `a.cpp`:

    ```C++ [sol1-C++]
    #include <iostream>
    using namespace std;
    int g_var = 0; // 全局变量
    static char *gs_var;  // 静态全局变量
  
    int main()
    {
        int var;                    // 局部变量
        static int s_var = 0;       // 静态局部变量
        return 0;
    }
    ```

    + `b.cpp`

    ```C++ [sol1-C++]
    #include <iostream>
    using namespace std;
    extern int g_var = 0; // 访问全局变量
    // extern static char *gs_var;  无法访问静态全局变量
  
    int test()
    {
        g_var = 1;
    }
    ```

2. 生命周期：
   生命周期即该变量可以被引用的时间段（生存期表示变量存在的时间）。

+ **全局变量**: 全局变量在整个程序运行期间都会一直存在，都可以随时访问，当程序结束时，对应的变量则会自动销毁，内存会被系统回收。
+ **局部变量**: 局部变量的生命周期仅限于函数被调用期间，当函数调用结束时，该变量会自动销毁。
+ **静态局部变量**：实际上静态局部变量的作用域仅限于函数内部，它的作用域与局部变量相同，但实际上该变量在程序运行期间是一直存在的，生命周期贯穿于整个程序运行期间。局部静态变量只能被初始化一次。

3. 从分配内存空间看：
   不同生命周期的变量，在程序内存中的分布位置是不一样的。。我们知道程序的内存分为代码区（`.text`）、全局数据区（`.data`，`.bss`，`.rodata`）、堆区（`heap`）、栈区（`stack`），不同的内存区域，对应不同的生命周期。
![1_2_2.png](https://pic.leetcode-cn.com/1661412780-mtAvuQ-1_2_2.png)

+ 静态变量一般存储在数据段，包括 `data` 段、`bss` 段、`rodata` 段，其中 `data` 存储已经已经初始化的静态变量和全局变量，`bss` 存储未初始化的静态变量与全局变量。这里静态变量包括全局变量，静态全局变量，静态局部变量。
+ 局部变量一般存储在栈区或者堆区。

4. 注意：

+ 静态变量和栈变量（存储在栈中的变量）、堆变量（存储在堆中的变量）的区别：静态变量会被放在程序的静态数据存储区（`.data` 段，`bss` 段，`rodata` 段）中（静态变量会自动初始化），这样可以在下一次调用的时候还可以保持原来的赋值。而栈变量或堆变量不能保证在下一次调用的时候依然保持原来的值。
+ 静态变量和全局变量的区别：静态变量仅在变量的作用范围内可见，实际是依靠编译器来控制作用域。全局变量在整个程序范围内都可可见，只需声明该全局变量，即可使用。
+ 全局变量定义在不要在头文件中定义：如果在头文件中定义全局变量，当该头文件被多个文件 `include` 时，该头文件中的全局变量就会被定义多次，编译时会因为重复定义而报错，因此不能再头文件中定义全局变量。一般情况下我们将变量的定义放在 `.cpp` 文件中，一般在 `.h` 文件使用`extern` 对变量进行声明。


参考资料：

+ [Static Keyword in C++](https://www.***.org/static-keyword-cpp/?ref=gcse)
+ [Static data members in C++](https://www.***.org/static-data-members-c/?ref=gcse)
+ [Static Variables in C](https://www.***.org/static-variables-in-c/?ref=gcse)
+ [Storage Classes in C](https://www.***.org/storage-classes-in-c/?ref=lbp)
+ [Memory Layout of C Programs](https://www.***.org/memory-layout-of-c-program/?ref=lbp)
+ [.bss](https://en.wikipedia.org/wiki/.bss)
+ [Data segment](https://en.wikipedia.org/wiki/Data_segment)
+ [6.9 — Sharing global constants across multiple files (using inline variables)](https://www.learncpp.com/cpp-tutorial/sharing-global-constants-across-multiple-files-using-inline-variables/)

## 内存对齐
1. 什么是内存对齐：
   计算机中内存的地址空间是按照 `byte` 来划分的，从理论上讲对任何类型变量的访问可以从内存中的任意地址开始，但实际情况是：在访问特定类型变量的时候通常在特定的内存地址访问，这就需要对这些数据在内存中存放的位置进行限制，各种类型数据按照一定的规则在空间上排列，而不是顺序的一个接一个的排放，这就是对齐。编译器将程序中的每个 `数据单元` 的地址安排在机器字的整数倍的地址指向的内存之中。

2. 为什么要内存对齐：
   主要是由于 `CPU` 的访问内存的特性决定，`CPU` 访问内存时并不是以字节为单位来读取内存，而是以机器字长为单位，实际机器字长由 `CPU` 数据总线宽度决定的。实际 `CPU` 运行时，每一次控制内存读写信号发生时，`CPU` 可以从内存中读取数据总线宽度的数据，并将其写入到 `CPU` 的通用寄存器中。比如 `32` 位 `CPU`，机器字长为 `4` 字节，数据总线宽度为 `32` 位，如果该 `CPU` 的地址总线宽度也是为 $32$ 位，则其可以访问的地址空间为 $[0,\text{0xffffffff}]$。内存对齐的主要目的是为了减少 `CPU` 访问内存的次数，加大 `CPU` 访问内存的吞吐量。假设读取 `8` 个字节的数据，按照每次读取 `4` 个字节的速度，则 `8` 个字节需要 `CPU` 耗费 `2` 次读取操作。`CPU` 始终以字长访问内存，如果不进行内存对齐，很可能增加 `CPU` 访问内存的次数。
![1_5_1.png](https://pic.leetcode-cn.com/1661173255-dXASLi-1_5_1.png)
   比如以上在读取变量 `b` 时，如果不进行内存对齐的话，会导致 `CPU` 读取次数为 `2`，在内存对齐的情况下，只需读取一次即可，当然实际的读取非对齐的内存处理更为复杂，我们参考下图中读取非对齐内存时的数据处理过程：
![1_5_2.png](https://pic.leetcode-cn.com/1661173267-sLDgeV-1_5_2.png)

除了能够减少内存访问次数，增加内存读取的吞吐量以外，还有其他原因：

+ 比如某些特定的硬件设备只能存取对齐数据，存取非对齐的数据可能会引发异常，比如对于 `CPU` 中 `SIMD` 指令，则必须要求内存严格对齐；
+ 每次内存访问是原子的，如果变量的大小不超过字长，那么内存对齐后，对该变量的访问就是原子的。某些硬件设备不能保证在存取非对齐数据的时候的操作是原子操作，因此此时 `CPU` 需要可能需要读取多次内存，这样就破坏了变量的原子性；
+ 相比于存取对齐的数据，存取非对齐的数据需要花费更多的时间，提高内存的访问效率，因为 `CPU` 在读取内存时，是一块一块的读取；
+ 某些处理器虽然支持非对齐数据的访问，但会引发对齐陷阱（`alignment trap`）；
+ 某些硬件设备只支持简单数据指令非对齐存取，不支持复杂数据指令的非对齐存取。

3. 内存对齐的原则：
程序中的内存对齐大部分都是由编译器来处理，编译器会自动在内存之间填充字节。结构体中的变量对齐的基本规则如下：

- 结构体变量的首地址能够被其最宽的基本类型成员的长度和对齐基数二者中的较小者所整除；

+ 结构体中的 `static` 成员变量不占用结构体的空间，由于静态成员变量在程序初始化时已经在静态存储区分配完成，所有该结构体实例中的静态成员都指向同一个内存区域；

  ```C++ []
  struct st {
      char a;
      int b;
      static double c; //静态成员
  } T;
  cout<<sizeof(st)<<endl;
  // 8
  ```

+ 结构体每个成员相对于结构体首地址的偏移量 （`offset`） 都是该成员大小与对齐基数中的较小者的整数倍，如有需要编译器会在成员之间加上填充字节 （`internal padding`）；

+ 结构体的总大小为结构体中最宽基本类型成员的长度与对齐基数二者中的较小者的整数倍，如有需要编译器会在最末尾的成员之后加上填充字节 （`trailing padding`）；

+ **实例**：
  我们可以利用 `offset` 宏定义来计算出结构体中每个变量的偏移地址。

  ```C++ []
  /*
   说明：程序是在 64 位编译器下测试的
   */
   #include <iostream>
   using namespace std;
   #define offset(TYPE,MEMBER) ((long)&((TYPE *)0)->MEMBER)
  
   struct A
   {
       short var; // 偏移 0 字节 （内存对齐原则 : short 2 字节 + 填充 2 个字节）
       int var1;  // 偏移 4 字节 （内存对齐原则：int 占用 4 个字节）
       long var2; // 偏移 8 字节 （内存对齐原则：long 占用 8 个字节）
       char var3; // 偏移 16 字节 （内存对齐原则：char 占用 1 个字节 + 填充 7 个字节）
       string s;  // 偏移 24 字节 （string 占用 32 个字节）
   };
  
   int main()
   {
       string s;
       A ex1;
       cout << offset(A, var) <<endl;
       cout << offset(A, var1) <<endl;
       cout << offset(A, var2) <<endl;
       cout << offset(A, var3) <<endl;
       cout << offset(A, s) <<endl;
       cout << sizeof(ex1) << endl;  // 56 struct
       return 0;
   }
  ```

   我们可以看到运行结果如下:

   ```C++ []
  0
  4
  8
  16
  24
  56
   ```

+ 指定程序对齐规则：
  我们可以指定结构体的对齐规则，在某些特定场景下我们需要指定结构体内存进行对齐，比如在发送特定网络协议报文、硬件协议控制、消息传递、硬件寄存器访问时，这时就就需要避免内存对齐，因为双方均按照预先定义的消息格式来进行交互，从而避免不同的硬件平台造成的差异，同时能够将双方传递的数据进行空间压缩，避免不必要的空间浪费。
  **programpack**: 我们可以用 `#progma pack(x)` 指定结构体以 $x$ 为单位进行对齐。一般情况下我们可以使用如下：

    ```C++ []
  #pragma pack（push）
  #pragma pack（x）
   // 存放需要 x 对齐方式的数据块
  #pragma pack（pop）
    ```

    我们同样指定上述程序以 $1$ 字节对齐，则可以看到结果如下:

    ```C++ []
    /*
    说明：程序是在 64 位编译器下测试的
    */
    #include <iostream>
    using namespace std;
    #define offset(TYPE,MEMBER) ((long)&((TYPE *)0)->MEMBER)
    #pragma pack(push)
    #pragma pack(1)
    struct A
    {
        short var; // 偏移 0 字节 （内存对齐原则 : short 2 字节 + 填充 2 个字节）
        int var1;  // 偏移 4 字节 （内存对齐原则：int 占用 4 个字节）
        long var2; // 偏移 8 字节 （内存对齐原则：long 占用 8 个字节）
        char var3; // 偏移 16 字节 （内存对齐原则：char 占用 1 个字节 + 填充 7 个字节）
        string s;  // 偏移 24 字节 （string 占用 32 个字节）
    };
    #pragma pack(pop)
  
    int main()
    {
        string s;
        A ex1;
        cout << offset(A, var) <<endl;
        cout << offset(A, var1) <<endl;
        cout << offset(A, var2) <<endl;
        cout << offset(A, var3) <<endl;
        cout << offset(A, s) <<endl;
        cout << sizeof(ex1) << endl;  // 56 struct
        return 0;
    }
    ```

    运行结果如下:

    ```C++ []
  0
  2
  6
  14
  15
  47
    ```

  **__attribute__((aligned (n)))**: `__attribute__((aligned (n)))` 让所作用的结构成员对齐在 `n` 字节自然边界上。如果结构中有成员的长度大于`n`，则按照最大成员的长度来对齐。需要注意的是：内存对齐的对齐数取决于对齐系数和成员的字节数两者之中的较小值。对齐属性的有效性会受到链接器(linker)固有限制的限制，即如果你的链接器仅仅支持 `8` 字节对齐，即使你指定`16`字节对齐，那么它也仅仅提供 `8` 字节对齐。`__attribute__((packed))` 表示取消结构在编译过程中的优化对齐，按照实际占用字节数进行对齐，这部分属于 `gcc` 中的用法，详细了解详情可以参考 `gcc` 的手册。

**alignof**: `C++ 11` 以后新增 `alignof` 的特性，通过调用 `alignof` 返回当前变量的字节对齐方式。比如以下程序：

    ```C++ []
    /*
    说明：程序是在 64 位编译器下测试的
    */
    #include <iostream>
    using namespace std;
    #define offset(TYPE,MEMBER) ((long)&((TYPE *)0)->MEMBER)
    #pragma pack(push)
    #pragma pack(1)
    struct A
    {
        short var; // 偏移 0 字节 （内存对齐原则 : short 2 字节 + 填充 2 个字节）
        int var1;  // 偏移 4 字节 （内存对齐原则：int 占用 4 个字节）
        long var2; // 偏移 8 字节 （内存对齐原则：long 占用 8 个字节）
        char var3; // 偏移 16 字节 （内存对齐原则：char 占用 1 个字节 + 填充 7 个字节）
        string s;  // 偏移 24 字节 （string 占用 32 个字节）
    };
    #pragma pack(pop)
    
    int main()
    {
        string s;
        A ex1;
        cout << alignof(A) <<endl;
        return 0;
    }
    ```
    此时返回结果为 $1$。

4. 小结：
   内存对齐使得程序便于在不同的平台之间进行移植，因为有些硬件平台不能够支持任意地址的数据访问，只能在某些地址处取某些特定的数据，否则会抛出异常；另一方面提高内存的访问效率，因为 `CPU` 在读取内存时，是以块为单位进行读取。


参考资料:

+ [Purpose of memory alignment](https://stackoverflow.com/questions/381244/purpose-of-memory-alignment)
+ [Memory alignment… run, you fools!](http://blog.virtualmethodstudio.com/2017/03/memory-alignment-run-fools/)
+ [Data alignment: Straighten up and fly right](https://web.archive.org/web/20080607055623/http://www.ibm.com/developerworks/library/pa-dalign/)
+ [Alignment](https://docs.microsoft.com/en-us/cpp/cpp/alignment-cpp-declarations?view=msvc-170&viewFallbackFrom=vs-2019)
+ [内存对齐](http://light3moon.com/2015/01/19/%5B%E8%BD%AC%5D%20%E5%86%85%E5%AD%98%E5%AF%B9%E9%BD%90/)
+ [Data structure alignment](https://en.wikipedia.org/wiki/Data_structure_alignment)
+ [一文轻松理解内存对齐](https://cloud.tencent.com/developer/article/1727794)
+ [What is alignment?](https://www.cs.umd.edu/~meesh/cms***11/website/projects/outer/memory/align.htm)

## 智能指针简介与使用
1. 智能指针:
   智能指针是为了解决动态内存分配时带来的内存泄漏以及多次释放同一块内存空间而提出的。`C++ 11` 中提供了智能指针的定义，所有关于智能指针的定义可以参考 `<memory>` 头文件。传统的指针在申请完成后，必须要调用 `free` 或者 `delete` 来释放指针，否则容易产生内存泄漏的问题；`smart pointer` 遵循 `RAII` 原则，当 `smart pointer` 对象创建时，即为该指针分配了相应的内存，当对象销毁时，析构函数会自动释放内存。需要注意的是，智能指针不能像普通指针那样支持加减运算。

    ```C++ []
    #include <iostream>
    using namespace std;
   
    class SmartPtr {
        int* ptr; 
    public:
        explicit SmartPtr(int* p = NULL) { ptr = p; }
        ~SmartPtr() { delete (ptr); }
        int& operator*() { return *ptr; }
    };
   
    int main()
    {
        SmartPtr ptr(new int());
        *ptr = 20;
        cout << *ptr;
        return 0;
    }
    ```

   同时 `smart pointer` 重载了 `*` 和 `->` 等操作，使用该对象就像 `C` 语言中的普通指针一样，但是区别于普通指针的它会自动释放所申请的内存资源。以下为智能指针的简单实现：

```C++ []
#include <iostream>
using namespace std;

template <class T>
class SmartPtr {
	T* ptr; // Actual pointer
public:
	explicit SmartPtr(T* p = NULL) { ptr = p; }
	~SmartPtr() { delete (ptr); }
	T& operator*() { return *ptr; }
	T* operator->() { return ptr; }
};

int main()
{
	SmartPtr<int> ptr(new int());
	*ptr = 20;
	cout << *ptr;
	return 0;
}
```

按照常用的使用用途，智能指针有三类:

+ **unique_ptr**：独享所有权的智能指针，资源只能被一个指针占有，该指针不能拷贝构造和赋值。但可以进行移动构造和移动赋值构造（调用 `move()` 函数），即一个 `unique_ptr` 对象赋值给另一个 `unique_ptr` 对象，可以通过该方法进行赋值。
![1_9_1.png](https://pic.leetcode-cn.com/1661173525-UZwbot-1_9_1.png)
  如图所示，`object` 资源只能被 `P1` 占有，`P2` 无法对 `object` 有所有权，只能通过移动赋值给 `P2`。如下代码示例:

  ```C++ []
  #include <iostream>
  using namespace std;
  #include <memory>
  
  class Rectangle {
  	int length;
  	int breadth;
  
  public:
  	Rectangle(int l, int b){
  		length = l;
  		breadth = b;
  	}
  
  	int area(){
  		return length * breadth;
  	}
  };
  
  int main(){
  	unique_ptr<Rectangle> P1(new Rectangle(10, 5));
  	cout << P1->area() << endl; // This'll print 50
  
  	unique_ptr<Rectangle> P2;
  	// unique_ptr<Rectangle> P2(P1); // 无法拷贝构造
  	// P2 = P1;   // 无法赋值构造
  	P2 = move(P1);
  
  	cout << P2->area() << endl;
  	
  	// cout<<P1->area()<<endl; // 已经传递，P1 无所有权
  	return 0;
  }
  ```

  我们可以通过查看源代码看到该函数的拷贝构造函数和赋值构造函数均被禁止，只允许使用移动拷贝构造函数和移动赋值构造函数：

```C++ []
// Disable copy from lvalue.不允许复制，体现专属所有权语义
unique_ptr(const unique_ptr&) = delete;
unique_ptr& operator=(const unique_ptr&) = delete;

// Move constructor.体现专属所有权语义和只移型别
// 只允许使用移动拷贝构造函数
// 如果复制一个unique_ptr对象，会将源unique_ptr对象管理的资源release掉
unique_ptr(unique_ptr&& __u) noexcept
: _M_t(__u.release(), std::forward<deleter_type>(__u.get_deleter())) { }

// 这个也是移动拷贝构造函数
// 只是使用的类型是可以隐式转换的其他unique_ptr对象
template<typename _Up, typename _Ep, typename = _Require<
		__safe_conversion_up<_Up, _Ep>,
typename conditional<is_reference<_Dp>::value,
	is_same<_Ep, _Dp>,
	is_convertible<_Ep, _Dp>>::type>>
unique_ptr(unique_ptr<_Up, _Ep>&& __u) noexcept
: _M_t(__u.release(), std::forward<_Ep>(__u.get_deleter()))
{ }

// Assignment，也可以说明是专属所有权语义和只移型别
unique_ptr& operator=(unique_ptr&& __u) noexcept
{
	// __u.release()释放并返回源unique_ptr对象管理的资源
	// reset是将__u.release()返回的资源赋给目标（当前）unique_ptr对象
	reset(__u.release());
	get_deleter() = std::forward<deleter_type>(__u.get_deleter());
	return *this;
}

// 析构函数，调用析构器析构掉管理的资源，并将__ptr指向nullptr
~unique_ptr()
{
	auto& __ptr = _M_t._M_ptr();
	if (__ptr != nullptr)
		get_deleter()(__ptr);
	__ptr = pointer();
}
```

同时我们可以看到 `reset` 重新给其赋值，在获取资源的同时会释放原有的资源。

```C++ []
void reset(pointer __p = pointer()) noexcept
{
    using std::swap;
    swap(_M_t._M_ptr(), __p);
    if (__p != pointer() get_deleter()(__p);
}
```

+ **shared_ptr**：与 `unique_ptr` 不同的是，`shared_ptr` 中资源可以被多个指针共享，但是多个指针指向同一个资源不能被释放多次，因此使用计数机制表明资源被几个指针共享。
![1_9_2.png](https://pic.leetcode-cn.com/1661173547-qRsDoz-1_9_2.png)
  通过 `use_count()` 查看资源的所有者的个数，可以通过 `unique_ptr`、`weak_ptr` 来构造，调用 `release()` 释放资源的所有权，同时将计数减一，当计数减为 `0` 时会自动释放内存空间，从而避免了内存泄漏。特别需要注意的是 `shared_ptr` 并不是线程安全的，但 `shared_ptr` 的计数是原子操作实现的，利用 `atmoic CAS` 指令实现。我们可以看到 `share_ptr` 的内存模型，当引用计数和 `weak count` 同时为 `0` 时，`share_ptr` 对象才会被最终释放掉。
![1_9_3.png](https://pic.leetcode-cn.com/1661173560-wRKfuA-1_9_3.png)

  代码示例如下:

  ```C++ []
  #include <iostream>
  using namespace std;
  #include <memory>
  
  class Rectangle {
  	int length;
  	int breadth;
  
  public:
  	Rectangle(int l, int b)
  	{
  		length = l;
  		breadth = b;
  	}
  
  	int area()
  	{
  		return length * breadth;
  	}
  };
  int main()
  {
  
  	shared_ptr<Rectangle> P1(new Rectangle(10, 5));
  	cout << P1->area() << endl;
  	shared_ptr<Rectangle> P2;
  	P2 = P1;
  
  	cout << P2->area() << endl; // 50
  	cout << P1->area() << endl; // 50
  	cout << P1.use_count() << endl; // 2
  	return 0;
  }
  ```

  我们通过查看 `shared_ptr` 的源代码可以看到如下，`shared_ptr` 实际成员包含两个指针，一个指向对象资源的指针 `ptr`，另一个指向管理区域的指针 `__cntrl_`，具体 `__cntrl_` 指向的区域包括 `deleter`、`allocator`、`shared_ptr` 对象的引用计数、`weak_ptrs` 的对象的引用计数。

  ```C++ []
  template<class _Tp>
  class shared_ptr {
  	typedef _Tp element_type;
  
  private:
  	element_type*      __ptr_;
  	__shared_weak_count* __cntrl_;
  
  	...
  }
  ```

+ **weak_ptr**：指向 `share_ptr` 指向的对象，能够解决由 `shared_ptr` 带来的循环引用问题。与 `shared_ptr` 配合使用，将 `weak_ptr` 转换为 `share_ptr` 时，虽然它能访问 `share_ptr` 所指向的资源但却不享有资源的所有权，不影响该资源的引用计数。有可能资源已被释放，但 `weak_ptr` 仍然存在，`share_ptr` 必须等待所有引用的 `weak_ptr` 全部被释放才会进行释放。因此每次访问资源时都需要判断资源是否有效。
![1_9_4.png](https://pic.leetcode-cn.com/1661173574-icuaQj-1_9_4.png)

  `shared_ptr` 通过引用计数的方式来管理对象，当进行拷贝或赋值操作时，每个 `shared_ptr` 都会记录当前对象的引用计数，当引用计数为0时，内存将被自动释放。当对 `shared_ptr` 赋予新值或者被对象被销毁时，引用计数会递减。但特殊情况出现循环引用时，`shared_ptr` 无法正常释放资源。循环引用，即 `A` 指向 `B`，`B` 指向 `A`，在表示双向关系时，是很可能出现这种情况的。下面的示例代码即为出现了循环引用导致内存无法正常被释放。

  ```C++ []
  #include <iostream>
  #include <memory>
  using namespace std;
  
  class B;
  
  class A {
  public:
  	shared_ptr<B> b_;
  	A() {
  		cout << "A constructed!" << endl;
  	}
  	~A() {
  		cout << "A destructed!" << endl;
  	}
  };
  
  class B {
  public:
  	shared_ptr<A> a_;
  	B() {
  		cout << "B constructed!" << endl;
  	}
  	~B() {
  		cout << "B destructed!" << endl;
  	}
  };
  
  int main()
  {
  	auto classA = make_shared<A>();
  	auto classB = make_shared<B>();
  	classA->b_ = classB;
  	classB->a_ = classA;
  	cout << "A: " << classA.use_count() << endl;
  	cout << "B: " << classB.use_count() << endl;
  	return 0;
  }
  ```

  程序结果运行如下:

  ```C++ []
  A constructed!
  B constructed!
  A: 2
  B: 2
  ```

  为了解决上述的循环引用问题，才出现了 `weak_ptr`，我们知道 `shared_ptr A` 被赋值给 `shared_ptr B` 时，`A` 的引用计数加 `1`；但是 `shared_ptr A` 被赋值给 `weak_ptr C` 时，`A` 的引用计数不变。`weak_ptr` 在使用时是与 `shared_ptr` 绑定的，`weak_ptr` 不影响对象 `shared_ptr` 的引用计数，`weak_ptr` 可以用来跟踪 `shared_ptr` 对象，当 `shared_ptr` 的对象引用计数为 `0` 时，此时 `shared_ptr` 会释放所占用的对象资源，但 `shared_ptr` 对象本身不会释放，它会等待 `weak_ptrs` 引用计数为 `0` 时，此时才会释放管理区域的内存，而释放 `shared_ptr` 对象本身。上述的循环引用，我们可以将一个对象改为 `weak_ptr` 即可避免循环引用导致的异常。例如下列代码：

  ```C++ []
  #include <iostream>
  #include <memory>
  using namespace std;
  
  class B;
  
  class A {
  public:
  	shared_ptr<B> b_;
  	A() {
  		cout << "A constructed!" << endl;
  	}
  	~A() {
  		cout << "A destructed!" << endl;
  	}
  };
  
  class B {
  public:
  	weak_ptr<A> a_;
  	B() {
  		cout << "B constructed!" << endl;
  	}
  	~B() {
  		cout << "B destructed!" << endl;
  	}
  };
  
  int main()
  {
  	auto classA = make_shared<A>();
  	auto classB = make_shared<B>();
  	classA->b_ = classB;
  	classB->a_ = classA;
  	cout << "A: " << classA.use_count() << endl;
  	cout << "B: " << classB.use_count() << endl;
  	return 0;
  }
  ```

  代码执行结果如下：

  ```C++ []
  A constructed!
  B constructed!
  A: 1
  B: 2
  A destructed!
  B destructed!
  ```


参考资料:

+ [Smart Pointers in C++ and How to Use Them](https://www.***.org/smart-pointers-cpp/)
+ [std::weak_ptr](https://en.cppreference.com/w/cpp/memory/weak_ptr)
+ [std::shared_ptr](https://en.cppreference.com/w/cpp/memory/shared_ptr#Implementation_notes)
+ [what-is-a-smart-pointer-and-when-should-i-use-one](https://stackoverflow.com/questions/106508/what-is-a-smart-pointer-and-when-should-i-use-one)
+ [当我们谈论shared_ptr的线程安全性时，我们在谈论什么](https://zhuanlan.zhihu.com/p/416289479)
+ [循环引用中的shared_ptr和weak_ptr](https://zhuanlan.zhihu.com/p/355812360)

## 智能指针的创建
1. `make_unique` 与 `make_share`:
   `make_unique` 在 `C++ 14` 以后才被加入到标准的 `C++` 中，`make_shared` 则是 `C++ 11` 中加入的。在 「​`《Effective Modern C++》`」 学习笔记之条款二十一：优先选用 `std::make_unique` 和 `std::make_shared`,而非直接 `new`。

+ `make_unique`：减少代码量，能够加快编译速度，定义两遍类型时，编译器需要进行类型推导会降低编译速度，某些意外意外情况下可能会导致内存泄漏。但是 `make_unique` 不允许自定析构器，不接受 `std::initializer_list` 对象。

  ```C++ []
  auto upw1(std::make_unique<Widget>());
  //重复写了两次Widget型别
  std::unique_ptr<Widget> upw2(new Widget);
  ```

+ `make_shared`：这个主要是可以减少对堆中申请内存的次数，只需要申请一次即可。我们知道 `share_ptr` 的内存模型如下:
![1_9_3.png](https://pic.leetcode-cn.com/1661412915-YtfoXu-1_9_3.png)

当我们使用 `new` 时，我们将 `new` 出的资源指针赋给 `share_ptr` 的 `ptr`, 然后 `share_ptr` 本身还需要再次在堆上申请一块单独的内存作为它的管理区，存放引用计数、用户自定的函数等，因此创建 `shared_ptr` 时需要在堆上申请两次。
    ```C++ []
    std::shared_ptr<Widget>(new Widget);
    ```
当我们使用 `make_share` 时，我们只需要申请一块大的内存，一半用来存储资源，另一半作为管理区, 存放引用计数、用户自定的函数等，此时需要在堆上申请一次即可。
    ```C++
    auto upw1(std::make_unique<Widget>());
    ```
以下为两种方式的对比:
![1_10_1.png](https://pic.leetcode-cn.com/1661515496-tSvOZF-1_10_1.png)
`make_share` 虽然效率高，但是同样不能自定义析构器，同时 `share_ptr` 的对象资源可能会延迟释放，因为此时对象资源与管理区域在同一块内存中，必须要同时释放。

参考资料：

+ [why using make_unique rather than unique_ptr](https://zhuanlan.zhihu.com/p/528139040)
+ [Differences between std::make_unique and std::unique_ptr with new](https://stackoverflow.com/questions/22571202/differences-between-stdmake-unique-and-stdunique-ptr-with-new)
+ [which one is better between make_unique and new](https://www.sololearn.com/Discuss/2595135/which-one-is-better-between-make_unique-and-new)

## 编译与链接
1. 为什么需要编译：

+ 我们常见的 $\texttt{C/C++}$ 语言，$\texttt{CPU}$ 是无法理解的，这就需要将我们编写好的代码最终翻译为机器可执行的二进制指令，编译的过程本质上也即是翻译的过程，当然中间涉及的细节非常复杂。

2. 编译的处理过程：
   编译器读取源文件 `cpp`，并将其翻译为可执行文件「[$\texttt{ELF}$](https://baike.baidu.com/item/ELF/7120560?fr=aladdin)」，$\texttt{ELF}$ 文件可以经过操作系统进行加载执行。常见的编译过程分为四个过程：编译预处理、编译、汇编、链接。
![1_1_1.png](https://pic.leetcode-cn.com/1661172766-jkudLd-1_1_1.png)

+ **编译预处理**：在预编译过程中主要处理源代码中的预处理指令，比如引入头文件（`#include`），去除注释，处理所有的条件编译指令（`#ifdef, #ifndef, #else, #elif, #endif`），宏的替换（`#define`），添加行号，保留所有的编译器指令；

+ **编译**：针对预处理后的文件进行词法分析、语法分析、语义分析、符号汇总、汇编代码生成，并针对程序的结构或者特定的 $\texttt{CPU}$ 平台进行优化，其中涉及的过程较为复杂。简单来说编译的过程即为将 `.cpp` 源文件翻译成 `.s` 的汇编代码；

+ **汇编**：将汇编代码 `.s` 翻译成机器指令 `.o` 文件，一个 `.cpp` 文件只会生成一个 `.o` 文件；

+ **链接**：汇编程序生成的目标文件即为 `.o` 文件，单独的 `.o` 文件可能无法执行。因为一个程序可能由多个源文件组成，此时就存在多个 `.o` 文件。文件 `A` 中的函数引用了另一个文件 `B` 中定义的符号或者调用了某个库文件中的函数，这就需要链接处理。那链接的目的就是将这些文件对应的目标文件连接成一个整体，从而生成一个可被操作系统加载执行的 $\texttt{ELF}$ 程序文件。链接的过程较为复杂，如有兴趣可以参考：「[Computer Systems: A Programmer's Perspective](http://csapp.cs.cmu.edu/3e/pieces/preface3e.pdf)」。

3. 静态链接与动态链接:

+ **静态链接**：代码在生成可执行文件时，将该程序所需要的全部外部调用函数全部拷贝到最终的可执行程序文件中，在该程序被执行时，该程序运行时所需要的全部代码都会被装入到该进程的虚拟地址空间中。在 $\texttt{Linux}$ 系统下，静态链接库一般以 `.a` 文件，我们可以将多个 `.o` 文件链接成一个静态链接库。静态链接演示如下：

定义 `a.cpp` 与 `c.cpp` 如下:

```C++
// a.cpp
#include <iostream>
#include <vector>

extern int test_dynamic();

int main() {
    test_dynamic();
}

// c.cpp
#include <iostream>
#include <vector>

using namespace std;

int test_dynamic() {
    cout<<"this is test dynamic program!"<<endl;
    return 0;
}
```

  + 采用静态链接方式进行编译，并查看编译后的函数:

  ```shell []
  $ g++ a.cpp b.cpp -o test
  $ objdump -d test
  ```

  + 可以看到里面包含 `main` 函数的调用过程以及 `test_static` 函数的详细定义：

  ```asm []
  00000000000008b5 <main>:
  8b5:   55                      push   %rbp
  8b6:   48 89 e5                mov    %rsp,%rbp
  8b9:   e8 65 00 00 00          callq  923 <_Z11test_staticv>
  8be:   b8 00 00 00 00          mov    $0x0,%eax
  8c3:   5d                      pop    %rbp
  8***:   c3                      retq
  
  0000000000000923 <_Z11test_staticv>:
  923:   55                      push   %rbp
  924:   48 89 e5                mov    %rsp,%rbp
  927:   48 8d 35 18 01 00 00    lea    0x118(%rip),%rsi        # a46 <_ZStL19piecewise_construct+0x1>
  92e:   48 8d 3d 0b 07 20 00    lea    0x20070b(%rip),%rdi        # 201040 <_ZSt4cout@@GLIBCXX_3.4>
  935:   e8 56 fe ff ff          callq  790 <_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@plt>
  93a:   48 89 c2                mov    %rax,%rdx
  93d:   48 8b 05 8c 06 20 00    mov    0x20068c(%rip),%rax        # 200fd0 <_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GLIBCXX_3.4>
  944:   48 89 c6                mov    %rax,%rsi
  947:   48 89 d7                mov    %rdx,%rdi
  94a:   e8 51 fe ff ff          callq  7a0 <_ZNSolsEPFRSoS_E@plt>
  94f:   b8 00 00 00 00          mov    $0x0,%eax
  954:   5d                      pop    %rbp
  955:   c3                      retq
  ```

+ **动态链接**：代码在生成可执行文件时，该程序所调用的部分程序被放到动态链接库或共享对象的某个目标文件中，链接程序只是在最终的可执行程序中记录了共享对象的名字等一些信息，最终生成的 $\texttt{ELF}$ 文件中并不包含这些调用程序二进制指令。在程序执行时，当需要调用这部分程序时，操作系统会从将这些动态链或者共享对象进行加载，并将全部内容会被映射到该进行运行的虚拟地址的空间。在 `Linux` 系统下，动态链接库一般以 `.so` 文件，我们可以将多个 `.o` 文件链接成一个动态链接库。动态链接演示如下： 

  + 定义 `a.cpp` 与 `c.cpp` 如下: 

    ```C++ []
    // a.cpp
    #include <iostream>
    #include <vector>
    
    extern int test_dynamic();
    
    int main() {
        test_dynamic();
    }
     
    // c.cpp
    #include <iostream>
    #include <vector>
    
    using namespace std;
    
    int test_dynamic() {
        cout<<"this is test dynamic program!"<<endl;
        return 0;
    }
    ```

  + 采用动态态链接方式进行编译，并查看编译后的函数:

  ```shell []
  $ g++ -fPIC -shared -o lib.so c.cpp
  $ g++ -o test a.cpp ./lib.so
  $ objdump -d test
  ```

  + 通过 `-fPIC` 和 `-shared` 可以生成一个动态链接库，再链接到可执行程序就可以正常运行。生成的 `elf` 文件中可以查看 `main` 函数的详细定义，但并未找到 `test_dynamic` 函数的定义：

  ```asm []
  0000000000000835 <main>:
  835:   55                      push   %rbp
  836:   48 89 e5                mov    %rsp,%rbp
  839:   e8 e2 fe ff ff          callq  720 <_Z12test_dynamicv@plt>
  83e:   b8 00 00 00 00          mov    $0x0,%eax
  843:   5d                      pop    %rbp
  844:   c3                      retq
  ```

  + 我们查看生成的动态链接库中可以查看到 `test_dynamic` 的详细定义：

  ```asm []
  0000000000000865 <_Z12test_dynamicv>:
  865:   55                      push   %rbp
  866:   48 89 e5                mov    %rsp,%rbp
  869:   48 8d 35 96 00 00 00    lea    0x96(%rip),%rsi        # 906 <_ZStL19piecewise_construct+0x1>
  870:   48 8b 05 61 07 20 00    mov    0x200761(%rip),%rax        # 200fd8 <_ZSt4cout@GLIBCXX_3.4>
  877:   48 89 c7                mov    %rax,%rdi
  87a:   e8 f1 fe ff ff          callq  770 <_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc@plt>
  87f:   48 89 c2                mov    %rax,%rdx
  882:   48 8b 05 47 07 20 00    mov    0x200747(%rip),%rax        # 200fd0 <_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_@GLIBCXX_3.4>
  889:   48 89 c6                mov    %rax,%rsi
  88c:   48 89 d7                mov    %rdx,%rdi
  88f:   e8 ec fe ff ff          callq  780 <_ZNSolsEPFRSoS_E@plt>
  894:   b8 00 00 00 00          mov    $0x0,%eax
  899:   5d                      pop    %rbp
  89a:   c3                      retq
  ```

  实际上使用 `PLT` 延迟绑定技术，当然动态链接中使用的技巧和技术较为复杂，参考资料中会讲述的更加详细和深入。

+ **二者的优缺点**：静态链接浪费空间，每个可执行程序都会有目标文件的一个副本，这样如果目标文件进行了更新操作，就需要重新进行编译链接生成可执行程序（更新困难），优点就是执行的时候运行速度快，因为可执行程序具备了程序运行的所有内容；动态链接节省内存、更新方便，但是动态链接是在程序运行时，每次执行都需要链接，相比静态链接会有一定的性能损失。静态链接是由连接器完成的，动态链接最终是由操作系统来完成链接的功能，动态链接在不同的操作系统下可能由不同的实现原理，比如在 $\texttt{Linux}$ 系统下，动态链接库通常以 `.so` 文件存在，在 $\texttt{windows}$ 下同下，动态链接库一般以 `.dll` 文件存在。

参考资料：

+ [Computer Systems: A Programmer's Perspective](http://csapp.cs.cmu.edu/3e/pieces/preface3e.pdf)
+ [Static and Dynamic Linking in Operating System](https://www.geeksforgeeks.org/static-and-dynamic-linking-in-operating-systems/)

## 大端与小端
1. 字节序
   字节顺序又称端序或尾序（`Endianness`），在计算机科学领域中，指电脑内存中或在数字通信链路中，组成多字节的字的字节的排列顺序。在几乎所有的机器上，多字节对象都被存储为连续的字节序列。例如在 `C` 语言中，一个类型为 `int` 的变量 `x` 地址为 `0x100`，那么其对应地址表达式 `&x` 的值为 `0x100`，`x` 的四个字节将被存储在电脑内存的 `0x100`，`0x101`，`0x102`，`0x103` 位置。字节的排列方式常见的方式有两种：将一个多位数的低位放在较小的地址处，高位放在较大的地址处，则称小端序（`Little-Endian`）；反之则称大端序（`Big-Endian`）。为什么需要字节序这个规定，主要是因为在网络应用中字节序是一个必须被考虑的因素，对于不同 `CPU` 可能采用不同标准的字节序，所以均按照网络标准转化成相应的字节序。

+ **Little-Endian**：将低序字节存储在起始地址（低位编址），在变量指针转换的时候地址保持不变，比如 `int64*` 转到 `int32*`，对于机器计算来说更友好和自然。
![1_6_1.png](https://pic.leetcode-cn.com/1661173350-WbnRmC-1_6_1.png)


+ **Big-Endian**：将高序字节存储在起始地址（高位编址），内存顺序和数字的书写顺序是一致的，对于人的直观思维比较容易理解，网络字节序统一规定采用 `Big-Endian`。
![1_6_2.png](https://pic.leetcode-cn.com/1661173365-PPzbSl-1_6_2.png)

+ 检测字节序:
  一般情况下我们直接调用宏定义 `__BYTE_ORDER` 即可，可以通过引用 `<bits/endian.h>` 即可。或者我们也可以编写程序来判断当前的字节序。

  ```C++ []
  bool byteorder_check() {
      int a = 1;
      return (*(char *)&a); /* 1 为小端机，0 为大端机 */
  }
  ```

+ 字节序转换:
  在程序中字节序转换时，我们将高位与低位依次进行交换即可完成，以下为整数的字节序转换。

```C++ []
#define ORDER_TRANS(i) ((i & 0xff000000) >> 24 ) |  ( (i & 0x00ff0000) >> 8 ) | ( (i & 0x0000ff00) << 8 )  | ( (i & 0x000000ff) << 24 )
```

常用的网络字节序转换函数:

```C++ []
ntohl(uint32 x)       // uint32 类型 网络序转主机序
htonl(uint32 x)       // uint32 类型 主机序转网络序
ntohs(uint16 x)       // uint16 类型 网络序转主机序
htons(uint16 x)       // uint16 类型 主机序转网络序
```

参考资料:

+ [Endianness](https://en.wikipedia.org/wiki/Endianness#Middle-endian)
+ [Understanding Big and Little Endian Byte Order](https://betterexplained.com/articles/understanding-big-and-little-endian-byte-order/)
+ [What Is Little-Endian And Big-Endian Byte Ordering?](https://www.section.io/engineering-education/what-is-little-endian-and-big-endian/)
+ [Big Endian and Little Endian](https://chortle.ccsu.edu/assemblytutorial/Chapter-15/ass15_3.html)

## 内存泄漏
1. 内存泄漏
   程序在堆中申请的动态内存，在程序使用完成时没有得到及时的释放。当这些变量的生命周期已结束时，该变量在堆中所占用的内存未能得到释放，从而就导致了堆中可使用的内存越来越少，最终可能产生系统运行较慢或者系统因内存不足而崩溃的问题。

+ 内存泄漏并非指内存从物理上消失，而是指程序在运行过程中，由于疏忽或错误而失去了对该内存的控制，从而造成了内存的浪费。
+ 内存泄漏主要指堆上分配的变量，因为栈中分配的变量，随着函数退出时会自动回收。而堆是动态分配的，一旦用户申请了内存分配而为及时释放，那么该部分内存在整个程序运行周期内都是被占用的，其他程序无法再使用这部分内存。
+ 对于实际的程序来说，我们在调用过程中使用 `malloc`、`calloc`、`realloc`、`new` 等分配内存时，使用完后要调用相应的 `free` 或 `delete` 释放内存，否则这块内存就会造成内存泄漏。当然在实际应用中，我们可能在使用系统资源或者在堆中创建对象时，没有及时将这些资源或者对象进行释放时，也会造成内存泄漏，这些资源或者对象的创建实际也占用了堆中的内存，在使用完成时应及时将其进行释放。

代码示例:

```C++ []
// Program with memory leak
#include <bits/stdc++.h>
using namespace std;

void func_to_show_mem_leak()
{
	int* ptr = new int(5);
    // 返回时未释放内存
	return;
}
int main()
{
	func_to_show_mem_leak();
	return 0;
}
```

2. 内存泄漏导致的问题：
   由于内存未得到及时释放，从而可能导致可使用的动态内存空间会越来越少，一旦内存空间全部使用完，则程序可能会导致因为内存不够中止运行。由于内存泄漏导致的问题比较严重，现在许多语言都带有 `GC` 程序会自动对不使用的内存进行回收，从而避免内存泄漏。

+ [Memory leak in C++ and How to avoid it?](https://www.***.org/memory-leak-in-c-and-how-to-avoid-it/?ref=lbp)
+ [Memory leak](https://en.wikipedia.org/wiki/Memory_leak)
+ [Memory leak detection - How to find, eliminate, and avoid](https://raygun.com/blog/memory-leak-detection/)

## 内存泄漏检测与预防
1. 内存泄漏检测与预防
   对于 `C/C++` 没有 `GC` 程序的语言来说因为内存造成的问题较多，当然一般情况下如果存在严重的内存泄漏，我们通过查看内存使用统计即可检测到内存泄漏，但是细小的内存泄漏很难通过统计观察到，目前一般都是利用各种内存检测工具来检测内存泄漏，当然关键还是在于统计和分析申请和释放的相关日志。内存检测工具有很多，这里重点介绍下 `valgrind` 。
![1_8_1.png](https://pic.leetcode-cn.com/1661173460-cqRhcI-1_8_1.png)
   `valgrind` 是一套 `Linux` 下，开放源代码（`GPL V2`）的仿真调试工具的集合，包括以下工具：

+ `Memcheck`：内存检查器（`valgrind` 应用最广泛的工具），能够发现开发中绝大多数内存错误的使用情况，比如：使用未初始化的内存，使用已经释放了的内存，内存访问越界等。

+ `Callgrind`：检查程序中函数调用过程中出现的问题。

+ `Cachegrind`：检查程序中缓存使用出现的问题。

+ `Helgrind`：检查多线程程序中出现的竞争问题。

+ `Massif`：检查程序中堆栈使用中出现的问题。

+ `Extension`：可以利用 `core` 提供的功能，自己编写特定的内存调试工具。

+ `Memcheck` 能够检测出内存问题，关键在于其建立了两个全局表：

+ `Valid-Value` 表：对于进程的整个地址空间中的每一个字节（`byte`），都有与之对应的 `8` 个 `bits` ；对于 `CPU` 的每个寄存器，也有一个与之对应的 `bit` 向量。这些 `bits` 负责记录该字节或者寄存器值是否具有有效的、已初始化的值。

+ `Valid-Address` 表：对于进程整个地址空间中的每一个字节（`byte`），还有与之对应的 `1` 个 `bit`，负责记录该地址是否能够被读写。

+ 检测原理：
  当要读写内存中某个字节时，首先检查这个字节对应的 `Valid-Address` 表中对应的 `bit`。如果该 `bit` 显示该位置是无效位置，`Memcheck` 则报告读写错误。
  内核（`core`）类似于一个虚拟的 `CPU` 环境，这样当内存中的某个字节被加载到真实的 `CPU` 中时，该字节在 `Valid-Value` 表对应的 `bits` 也被加载到虚拟的 `CPU` 环境中。一旦寄存器中的值，被用来产生内存地址，或者该值能够影响程序输出，则 `Memcheck` 会检查 `Valid-Value` 表对应的 `bits`，如果该值尚未初始化，则会报告使用未初始化内存错误。

+ 程序实例:

  ```C []
  #include <stdio.h>
  #include <stdlib.h> 
  
  int main(void)
  {
      char *p = (char *)malloc(1);
      *p = 'a'; 
  
      char c = *p; 
  
      printf("\n [%c]\n",c); 
  
      return 0;
  }
  ```

  我们运行`memcheck`工具时即可检测出未释放的内存:

  ```shell []
  $ valgrind --tool=memcheck --leak-check=full ./2
  ==437== Memcheck, a memory error detector
  ==437== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
  ==437== Using Valgrind-3.13.0 and LibVEX; rerun with -h for copyright info
  ==437== Command: ./2
  ==437==
  ==437== error calling PR_SET_PTRACER, vgdb might block
  
  [a]
  ==437==
  ==437== HEAP SUMMARY:
  ==437==     in use at exit: 1 bytes in 1 blocks
  ==437==   total heap usage: 2 allocs, 1 frees, 513 bytes allocated
  ==437==
  ==437== 1 bytes in 1 blocks are definitely lost in loss record 1 of 1
  ==437==    at 0x4C2FB0F: malloc (in /usr/lib/valgrind/vgpreload_memcheck-amd64-linux.so)
  ==437==    by 0x108676: main (in /mnt/c/work/leetcode/2)
  ==437==
  ==437== LEAK SUMMARY:
  ==437==    definitely lost: 1 bytes in 1 blocks
  ==437==    indirectly lost: 0 bytes in 0 blocks
  ==437==      possibly lost: 0 bytes in 0 blocks
  ==437==    still reachable: 0 bytes in 0 blocks
  ==437==         suppressed: 0 bytes in 0 blocks
  ==437==
  ==437== For counts of detected and suppressed errors, rerun with: -v
  ==437== ERROR SUMMARY: 1 errors from 1 contexts (suppressed: 0 from 0)
  ```

2. 如何防止内存泄漏:

+ 内部封装：将内存的分配和释放封装到类中，在构造的时候申请内存，析构的时候释放内存。

  ```C++ []
  #include <iostream>
  #include <cstring>
  
  using namespace std;
  
  class A
  {
  private:
      char *p;
      unsigned int p_size;
  
  public:
      A(unsigned int n = 1) // 构造函数中分配内存空间
      {
          p = new char[n];
          p_size = n;
      };
      ~A() // 析构函数中释放内存空间
      {
          if (p != NULL)
          {
              delete[] p; // 删除字符数组
              p = NULL;   // 防止出现野指针
          }
      };
      char *GetPointer()
      {
          return p;
      };
  };
  void fun()
  {
      A ex(100);
      char *p = ex.GetPointer();
      strcpy(p, "Test");
      cout << p << endl;
  }
  int main()
  {
      fun();
      return 0;
  }
  ```

  说明：但这样做并不是最佳的做法，在类的对象复制时，程序会出现同一块内存空间释放两次的情况，请看如下程序：

  ```C++ []
  void fun1()
  {
      A ex(100);
      A ex1 = ex; 
      char *p = ex.GetPointer();
      strcpy(p, "Test");
      cout << p << endl;
  }
  ```

  简单解释：对于 `fun1` 这个函数中定义的两个类的对象而言，在离开该函数的作用域时，会两次调用析构函数来释放空间。但是这两个对象指向的是同一块内存空间，所以导致同一块内存空间被释放两次，可以通过增加计数机制来避免这种情况。示例程序：

  ```C++ []
  #include <iostream>
  #include <cstring>
  using namespace std;
  class A
  {
  private:
      char *p;
      unsigned int p_size;
      int *p_count; // 计数变量
  public:
      A(unsigned int n = 1) // 在构造函数中申请内存
      {
          p = new char[n];
          p_size = n;
          p_count = new int;
          *p_count = 1;
          cout << "count is : " << *p_count << endl;
      };
      // reference count
      A(const A &temp)
      {
          p = temp.p;
          p_size = temp.p_size;
          p_count = temp.p_count;
          (*p_count)++; // 复制时，计数变量 +1
          cout << "count is : " << *p_count << endl;
      }
  
      // deep copy
      A(const A &temp)
      {
          p = new char[temp.p_size];
          p_size = p_size;    
      }
  
      ~A()
      {
          (*p_count)--; // 析构时，计数变量 -1
          cout << "count is : " << *p_count << endl; 
  
          if (*p_count == 0) // 只有当计数变量为 0 的时候才会释放该块内存空间
          {
              cout << "buf is deleted" << endl;
              if (p != NULL) 
              {
                  delete[] p; // 删除字符数组
                  p = NULL;   // 防止出现野指针
                  if (p_count != NULL)
                  {
                      delete p_count;
                      p_count = NULL;
                  }
              }
          }
      };
      char *GetPointer()
      {
          return p;
      };
  };
  void fun()
  {
      A ex(100);
      char *p = ex.GetPointer();
      strcpy(p, "Test");
      cout << p << endl;
  
      A ex1 = ex; // 此时计数变量会 +1
      cout << "ex1.p = " << ex1.GetPointer() << endl;
  }
  int main()
  {
      fun();
      return 0;
  }
  ```

  程序运行结果：

  ```C++ []
  count is : 1
  Test
  count is : 2
  ex1.p = Test
  count is : 1
  count is : 0
  buf is deleted
  ```

  解释下：程序运行结果的倒数 `2、3` 行是调用两次析构函数时进行的操作，在第二次调用析构函数时，进行内存空间的释放，从而会有倒数第 `1` 行的输出结果。当然上述程序我们在定义类的拷贝构造函数时，直接定义为深拷贝也可以解决多次释放的问题。

+ 使用智能指针：智能指针是 `C++` 中已经对内存泄漏封装好了一个工具，智能指针对象会自动释放所申请的内存，将在下一个问题中对智能指针进行详细的解释。

+ 良好的编码习惯：良好的编码习惯可以有效的避免内存泄漏的问题，内存申请和释放要一一对应。

  + 在 `C++` 中需要将基类的析构函数定义为虚函数；
  + 遵循 `RAII`（`Resource acquisition is initialization`）原则：在对象构造时获取资源，在对象生命期控制对资源的访问使之始终保持有效，最后在对象析构的时候释放资源；
  + 尽量使用智能指针；
  + 有效引入内存检测工具；

参考资料：

+ [General guidelines to avoid memory leaks in C++](https://stackoverflow.com/questions/76796/general-guidelines-to-avoid-memory-leaks-in-c)
+ [Find memory leaks with the CRT library](https://docs.microsoft.com/en-us/visualstudio/debugger/finding-memory-leaks-using-the-crt-library?view=vs-2022)
+ [Linux 性能分析valgrind（一）之memcheck使用](https://zhuanlan.zhihu.com/p/92074597)
+ [The Valgrind Quick Start Guide](https://valgrind.org/docs/manual/quick-start.html#quick-start.mcrun)
+ [Using Valgrind to Find Memory Leaks and Invalid Memory Use](https://www.cprogramming.com/debugging/valgrind.html)
+ [How do I use valgrind to find memory leaks?](https://stackoverflow.com/questions/5134891/how-do-i-use-valgrind-to-find-memory-leaks)
+ [Resource acquisition is initialization](https://en.wikipedia.org/wiki/Resource_acquisition_is_initialization)

## include " " 和 <> 的区别
1. `#include`:
   `include` 关键字主要用来标识 `C/C++` 程序源代码编译时需要引用的头文件，编译器会自动去查找这些头文件中的变量、函数声明、结构体定义等相关信息，常见的有 `include <filename>` 和 `#include "filename"`，二者之间的区别:
   查找文件的位置：`#include<filename>` 通常在编译器或者 `IDE` 中预先指定的搜索目录中进行搜索，通常会搜索 `/usr/include` 目录，此方法通常用于包括标准库头文件；`#include "filename"` 在当前源文件所在目录中进行查找，如果没有；再到当前已经添加的系统目录（编译时以 `-I` 指定的目录）中查找，最后会在 `/usr/include` 目录下查找 。
   日常编写程序时，对于标准库中的头文件常用 `#include<filename>`，对于自己定义的头文件常用 `#include "filename"`。

2. `__has_include`：
   `C++ 17` 支持该特性，用来检查是否已经包含某个文件:

```C++ []
#include <iostream>

int main()
{
#if __has_include(<cstdio>)
    printf("c program");
#endif

#if __has_include("iostream")
    std::cout << "c++ program" << std::endl;
#endif

    return 0;
}
```

参考资料:

+ [Source file inclusion](https://en.cppreference.com/w/cpp/preprocessor/include)
+ [C/C++ #include directive with Examples](https://www.***.org/c-c-include-directive-with-examples/)


# C++ 语言对比
本章将重点涉及以下高频知识点：

## C++ 11 新特性
`C++ 11` 与 `C++ 98` 相比，引入新特性有很多，从面试的角度来讲，如果面试官问到该问题，常以该问题作为引子，对面试者提到的知识点进行深入展开提问。面试者尽可能的列举常用的并且熟悉的特性，尽可能的掌握相关原理，下文只是对相关知识点进行了简单的阐述，有关细节还需要结合相关知识点的相关问题。下面主要介绍 `C++ 11` 中的一些面试中经常遇到的特性。

1. `auto` 类型推导:
   `auto` 关键字：自动类型推导，编译器会在 **编译期间** 通过初始值或者函数返回值推导出变量的类型，通过 `auto` 定义的变量必须有初始值。
   `auto` 关键字基本的使用语法如下：

```C++ []
auto var = val1 + val2; // 根据 val1 和 val2 相加的结果推断出 var 的类型
auto ret = [](double x){return x*x;}; // 根据函数返回值推导出 ret 的类型
auto al = { 10, 11, 12 }; //类型是std::initializer_list<int>
```

使用 `auto` 关键字做类型自动推导时，依次施加以下规则:
首先，如果初始化表达式是引用，首先去除引用；
上一步后，如果剩下的初始化表达式有顶层的 `const` 或 `volatile` 限定符，去除掉。使用 `auto` 关键字声明变量的类型，不能自动推导出顶层的 `const` 或者 `volatile`，也不能自动推导出引用类型，需要程序中显式声明，比如以下程序：

```C++ []
const int v1 = 101;
auto v2 = v1;       // v2 类型是int，脱去初始化表达式的顶层const
v2 = 102；            // 可赋值
int a = 100;
int &b = a; 
auto c = b;          // c 类型为int，脱去初始化表达式的 &
```

初始化表达式为数组，`auto` 关键字推导的类型为指针。数组名在初始化表达式中自动隐式转换为首元素地址的右值。

```C++ []
int a[9]; 
auto j = a; // 此时j 为指针为 int* 类型，而不是 int(*)[9] 类型
std::cout << typeid(j).name() << " "<<sizeof(j)<<" "<<sizeof(a)<< std::endl;
```

注意：编译器推导出来的类型和初始值的类型并不完全一样，编译器会适当地改变结果类型使其更符合初始化规则。

2. `decltype` 类型推导:
   `decltype` 关键字：`decltype` 是 `“declare type”` 的缩写，译为“声明类型”。和 `auto` 的功能一样，都用来在编译时期进行自动类型推导。如果希望从表达式中推断出要定义的变量的类型，但是不想用该表达式的值初始化变量，这时就不能再用 `auto`。`decltype` 作用是选择并返回操作数的数据类型。
   区别：

```C++ []
auto var = val1 + val2; 
decltype(val1 + val2) var1 = 0; 
```

`auto` 根据 = 右边的初始值 `val1 + val2` 推导出变量的类型，并将该初始值赋值给变量 `var`；`decltype` 根据 `val1 + val2` 表达式推导出变量的类型，变量的初始值和与表达式的值无关。`auto` 要求变量必须初始化，因为它是根据初始化的值推导出变量的类型，而 `decltype` 不要求，定义变量的时候可初始化也可以不初始化。
类似于 `sizeof` 操作符，`decltype` 不对其操作数求值。`decltype(e)` 返回类型前，进行了如下推导:

+ 若表达式 `e` 为一个无括号的变量、函数参数、类成员访问，那么返回类型即为该变量或参数或类成员在源程序中的“声明类型”；
+ 否则的话，根据表达式的值分类（`value categories`），设 `T` 为 `e` 的类型：
  - 若 `e` 是一个左值（`lvalue`，即“可寻址值”），则 `decltype(e)` 将返回`T&`；
  - 若 `e` 是一个临终值（`xvalue`），则返回值为 `T&&` ；
  - 若 `e` 是一个纯右值（`prvalue`），则返回值为 `T`。

```C++ []
const int&& foo();
const int bar();
int i;
struct A { double x; };
const A* a = new A();
decltype(foo()) x1; // 类型为const int&&
decltype(bar()) x2; // 类型为int
decltype(i) x3; // 类型为int
decltype(a->x) x4; // 类型为double
decltype((a->x)) x5; // 类型为const double&
```

3. `lambda` 表达式
   `lambda` 表达式，又被称为 `lambda` 函数或者 `lambda` 匿名函数。
   `lambda` 匿名函数的定义:

```C++ []
[capture list] (parameter list) -> return type
{
function body;
};
```

其中：

+ `capture list`：捕获列表，指 `lambda` 所在函数中定义的局部变量的列表。定义在与 `lambda` 函数相同作用域的参数引用也可以被使用，一般被称作 `closure`（闭包），以下为闭包的常见用法。

```C++ []
[]      // 没有定义任何变量。使用未定义变量会引发错误。
[x, &y] // x以传值方式传入（默认），y以引用方式传入。
[&]     // 任何被使用到的外部变量都隐式地以引用方式加以引用。
[=]     // 任何被使用到的外部变量都隐式地以传值方式加以引用。
[&, x]  // x显式地以传值方式加以引用。其余变量以引用方式加以引用。
[=, &z] // z显式地以引用方式加以引用。其余变量以传值方式加以引用。
```

比如下面以引用的方式调用 `a`：

```C++ []
int main()
{
    int a = 10;
    auto f = [&a](int x)-> int {
        a = 20;
        return a + x;
    };
    cout<<a<<endl; // 10
    cout<<f(10)<<endl; // 30
    cout<<a<<endl; // 20
    return 0;
}
```

+ `return type`、`parameter list`、`function body`：分别表示返回值类型、参数列表、函数体，和普通函数一样。
  举例：

```C++ []
#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int arr[4] = {4, 2, 3, 1};
    //对 a 数组中的元素进行升序排序
    sort(arr, arr + 4, [=](int x, int y) -> bool{ return x < y; } );
    auto f = [&](int x)-> int {
        return arr[0] + x;
    }

    for(int n : arr){
        cout << n << " ";
    }
    return 0;
}
```

需要注意的是 `lambda` 函数按照值方式捕获的环境中的变量，在 `lambda` 函数内部是不能修改的。否则，编译器会报错。其值是 `lambda` 函数定义时捕获的值，不再改变。如果在 `lambda` 函数定义时加上 `mutable` 关键字，则该捕获的传值变量在 `lambda` 函数内部是可以修改的，对同一个 `lambda` 函数的随后调用也会累加影响该捕获的传值变量，但对外部被捕获的那个变量本身无影响。

```C++ []
#include <iostream> 
using namespace std;
int main()
{
	size_t t = 9;
	auto f = [t]() mutable{
		t++;
		return t; 
	};
	cout << f() << endl; // 10
	t = 100;
	cout << f() << endl; // 11
	cout << "t:" << t << endl; // t: 100
	return 0;
}
```

4. 范围 `for` 语句：
   语法格式：

```C++ []
for (declaration : expression){
    statement
}
```

参数的含义：
`expression`：必须是一个序列，例如用花括号括起来的初始值列表、数组、`vector`，`string` 等，这些类型的共同特点是拥有能返回迭代器的 `beign`、`end` 成员。
`declaration`：此处定义一个变量，序列中的每一个元素都能转化成该变量的类型，常用 `auto` 类型说明符。
实例：

```C++ []
#include <iostream>
#include <vector>
using namespace std;
int main() {
    char arr[] = "hello world!";
    for (char c : arr) {
        cout << c;
    }  
    return 0;
}
/*
程序执行结果为：
hello world!
*/
```

5. 右值引用：
   `C++` 表达式中的 “值分类”（`value categories`）属性为左值或右值。其中左值是对应（`refer to`）内存中有确定存储地址的对象的表达式的值，而右值是所有不是左值的表达式的值。因而，右值可以是字面量、临时对象等表达式。能否被赋值不是区分 `C++` 左值与右值的依据，`C++` 的 `const` 左值是不可赋值的；而作为临时对象的右值可能允许被赋值。左值与右值的根本区别在于是否允许取地址 `&` 运算符获得对应的内存地址。`C++` 标准定义了在表达式中左值到右值的三类隐式自动转换：

+ 左值转化为右值；如整数变量 `i` 在表达式 （`i+3`）；
+ 数组名是常量左值，在表达式中转化为数组首元素的地址值；
+ 函数名是常量左值，在表达式中转化为函数的地址值；
  `C++ 03` 在用临时对象或函数返回值给左值对象赋值时的深度拷贝（`deep copy`），因此造成性能低下。考虑到临时对象的生命期仅在表达式中持续，如果把临时对象的内容直接移动（`move`）给被赋值的左值对象（右值参数所绑定的内部指针复制给新的对象，然后把该指针置为空），效率改善将是显著的。右值引用就是为了实现 `move` 与 `forward` 所需要而设计出来的新的数据类型。右值引用的实例对应于临时对象；右值引用并区别于左值引用，用作形参时能通过函数重载来区别对象是调用拷贝构造函数还是移动拷贝构造函数。实际上无论是左值引用还是右值引用，从编译后的反汇编层面上，都是对象的存储地址的引用。右值引用与左值引用的变量都不能悬空，也即定义时必须初始化从而绑定到一个对象上。
  `C++` 右值引用即绑定到右值的引用，用 `&&` 来获得右值引用，右值引用只能绑定到要销毁的对象。为了和右值引用区分开，常规的引用称为左值引用。左值引用是绑定到左值对象上；右值引用是绑定到临时对象上。左值对象是指可以通过取地址 `&` 运算符得到该对象的内存地址；而临时对象是不能用取地址 `&` 运算符获取到对象的内存地址，具体的引用绑定规则如下:
+ 非常量左值引用（`X &`）：只能绑定到 `X` 类型的左值对象；
+ 常量左值引用（`const X &`）：可以绑定到 `X`、`const X` 类型的左值对象，或 `X`、`const X` 类型的右值；
+ 非常量右值引用（`X &&`）：只能绑定到 `X` 类型的右值；
+ 常量右值引用（`const X &&`）：可以绑定规定到 `X`、`const X` 类型的右值。

举例：

```C++ []
#include <iostream>
#include <vector>
using namespace std;
int main()
{
    int var = 42;
    int &l_var = var;
    int &&r_var = var; // error: cannot bind rvalue reference of type 'int&&' to lvalue of type 'int' 错误：不能将右值引用绑定到左值上
    int &&r_var2 = var + 40; // 正确：将 r_var2 绑定到求和结果上
    int &&r_var3 = std::move(var) // 正确
    return 0;
}
```


6. 标准库 `move()` 函数
   `move()` 函数：通过该函数可获得绑定到左值上的右值引用。通过 `move` 获取变量的右值引用，从而可以调用对象的移动拷贝构造函数和移动赋值构造函数。

7. 智能指针:
   `auto_ptr` 在 `C++ 11` 中被，取而代之的是 `unique_ptr`。智能指针在第一章中已经详细，可以参考第一章第 `9` 节。

8. 使用或禁用对象的默认函数:
   在旧版本的 `C++` 中，若用户没有提供，则编译器会自动为对象生成默认构造函数（`default constructor`)、复制构造函数（`copy constructor`），赋值运算符（`copy assignment operator operator=`）以及析构函数（`destructor`）。另外，`C++` 也为所有的类定义了数个全局运算符（如`operator delete` 及 `operator new`）。当用户有需要时，也可以提供自定义的版本改写上述的函数。由于无法精确地控制这些默认函数的生成，要让类不能被拷贝，必须将复制构造函数与赋值运算符声明为 `private`，并不去定义它们，尝试使用这些未定义的函数会导致编译期或链接期的错误。此外，编译器产生的默认构造函数与用户定义的构造函数无法同时存在。若用户定义了任何构造函数，编译器便不会生成默认构造函数； 但有时同时部分场景下需要同时具有两者提供的构造函数。`C++ 11` 中允许显式地表明采用或拒用编译器提供的内置函数。

+ 允许编译器生成默认的构造函数: 
  `default` 函数：`= default` 表示编译器生成默认的函数，例如：生成默认的构造函数。
+ 禁止编译器使用类或者结构体中的某个函数:
  `delete` 函数：`= delete` 修改某个函数则表示该函数不能被调用。与 `default` 不同的是，`= delete` 也能适用于非编译器内置函数，所有的成员函数都可以用 `=delete` 来进行修饰。

程序示例:

```C++ []
#include <iostream>
using namespace std;

class A
{
public:
	A() = default; // 表示使用默认的构造函数
	~A() = default;	// 表示使用默认的析构函数
	A(const A &) = delete; // 表示类的对象禁止拷贝构造
	A &operator=(const A &) = delete; // 表示类的对象禁止拷贝赋值
};
int main()
{
	A ex1;
	A ex2 = ex1; // error: use of deleted function 'A::A(const A&)'
	A ex3;
	ex3 = ex1; // error: use of deleted function 'A& A::operator=(const A&)'
	return 0;
}
```

9. `constexpr`：
   常量表示式对编译器来说是优化的机会，编译器时常在编译期执行它们并且将值存入程序中。同样地，在许多场合下，`C++` 标准要求使用常量表示式。例如在数组大小的定义上，以及枚举值（`enumerator values`）都要求必须是常量表示式。常量表示式不能含有函数调用或是对象构造函数。所以像是以下的例子是不合法的：

```C++ []
int g() {return 5;}
int f[g() + 10]; // 不合法的C++ 写法
```

由于编译器无从得知函数 `g()` 的返回值为常量，因此表达式 `g() + 10` 就不能确定是常量。`C++ 11` 引进关键字 `constexpr` 允许用户保证函数或是对象构造函数是编译期常量，编译器在编译时将去验证函数返回常量。

```C++
constexpr int g() {return 5;}
int f[g() + 10]; // 合法
```

用 `constexpr` 修饰函数将限制函数的行为。

+ 函数的回返值类型不能为void；
+ 函数体不能声明变量或定义新的类型；
+ 函数体只能包含声明、null语句或者一段return语句；
+ 函数的内容必须依照 `"return expr"` 的形式，在参数替换后，`expr` 必须是个常量表达式；
+ 这些常量表达式只能够调用其他被定义为 `constexpr` 的函数，或是其他常量形式的参数。
  `constexpr` 修饰符的函数直到在该编译单元内被定义之前是不能够被调用的。声明为 `constexpr` 的函数也可以像其他函数一样用于常量表达式以外的调用。
  `C++ 11` 中的常量表达式中的变量都必须是常量，可以使用 `constexpr` 关键字来定义表达式中的变量：

```C++ []
constexpr double PI = 3.14;
constexpr double Degree = PI * 2.0;
```

如果创建用户定义类型的常量表达式，则自定义类型的构造函数必须用 `constexpr` 声明，函数体仅包含声明或 `null` 语句，不能声明变量或定义类型。构造函数的实参值应该是常量表达式，直接初始化类的数据成员。同时该类型对象的拷贝构造函数应该也定义为 `constexpr`，以允许 `constexpr` 函数返回一个该类型的对象。`C++ 14` 以后的规则有所改动。

10.  初始化列表 `initializer list`：
     `C++ 11` 把初始化列表的定义为标准类型，称作 `std::initializer_list`。允许构造函数或其他函数像参数般地使用初始化列表，在对象中可以定义初始化列表构造函数。初始化列表是常量；一旦被创建，其成员均不能被改变，成员中的资料也不能够被变动。在 `C++ 11` 中初始化列表是标准类型，除了对象的构造函数之外还能够被用在其他地方，一般的函数能够使用初始化列表作为形参。

```C++ []
void f(std::initializer_list<int> list);
f({1, 2, 3, 4, 5}); // 初始化列表作为形参
vector<int> arr1 = {1, 2, 3, 4, 5}; // 初始化列表构造函数
vector<int> arr2({1, 2, 3, 4, 5});
```

11. `nullptr`:
    在 `C` 语言中，常量 `0` 带有常量及空指针的双重身份。`C` 使用宏定义 `NULL` 表示空指针，让 `NULL` 及 `0` 分别代表空指针及常量 `0`。 `NULL` 可被定义为 `((void*)0)` 或是 `0`。这样容易引起语义歧义，比如 `char* c = NULL`，`NULL` 只能定义为 `0`，这样可能使得函数重调用错误，比如调用 `f(NULL)`，`NULL` 隐式被转换为 `0`，这样实际编译器可能会调用 `f(int)`，但实际上可能希望调用 `f(char *)`。

```C++ []
void f(char *);
void f(int);
```

`C++ 11` 引入了新的关键字来代表空指针常量：`nullptr`，将空指针和整数 `0` 的概念拆开。`nullptr` 的类型为 `nullptr_t`，能隐式转换为任何指针或是成员指针的类型，也能和它们进行相等或不等的比较。

```C++ []
typedef decltype(nullptr) nullptr_t;
```

`nullptr` 不能隐式转换为整数，也不能和整数做比较，因此就避免上述的语义歧义。值得注意的是的 `f(nullptr_t)` 被隐式转换为 `foo(char *)` 只会发生在该函数不存在其它的指针类型重载（比如 `f(int *), f(double *)` 等）时候，否则就会产生歧义错误（可以通过显示声明一个 `foo(nullptr_t)` 来消除该歧义），如果存在多个指针类型重载，此时需要 `f(nullptr)` 时，则需要显示声明一个函数来消除歧义。

```C++ []
void f(char *);
void f(int *);
void f(int);
void f(nullptr_t);
```

12. 可扩展的随机数功能：
    `C++ 11` 将会提供产生伪随机数的新方法。`C++ 11` 的随机数功能分为两部分：

+ 随机数生成引擎，其中包含该生成引擎的状态，用来产生随机数。
+ 随机数分布，这可以用来决定产生随机数的范围，也可以决定以何种分布方式产生随机数。
  随机数生成对象即是由随机数生成引擎和分布所构成。
  针对产生随机数的机制，`C++ 11` 将会提供三种算法，每一种算法都有其强项和弱项：
+ `linear_congruential`：可以产生整数，速度较慢，随机数质量较差；
+ `subtract_with_carry`: 可以产生整数和随机数，速度较快，随机数质量中等；
+ `mersenne_twister`：可以产生整数，速度较快，随机数质量较好；

`C++ 11` 将会提供一些标准分布：`uniform_int_distribution`（离散型均匀分布），`bernoulli_distribution`（伯努利分布），`geometric_distribution`（几何分布），`poisson_distribution`（卜瓦松分布），`binomial_distribution`（二项分布），`uniform_real_distribution`（离散型均匀分布)，`exponential_distribution`（指数分布），`normal_distribution`（正态分布）和 `gamma_distribution`（伽玛分布）。

```C++ []
std::uniform_int_distribution<int> distribution(0, 99); // 离散型均匀分布
std::mt19937 engine; // 随机数生成引擎
auto generator = std::bind(distribution, engine); // 将随机数生成引擎和分布绑定生成函数
int random = generator();  // 产生随机数
```

参考资料：

+ [auto (C++)](https://zh.m.wikipedia.org/zh-sg/Auto_(C%2B%2B))
+ [decltype](https://zh.m.wikipedia.org/wiki/Decltype)
+ [右值引用](https://zh.m.wikipedia.org/zh-sg/%E5%8F%B3%E5%80%BC%E5%BC%95%E7%94%A8)
+ [C++的左值和右值](https://www.cnblogs.com/relaxease/p/16027916.html)
+ [C++11](https://zh.m.wikipedia.org/wiki/C%2B%2B11)
+ [如何评价 C++11 的右值引用（Rvalue reference）特性？](https://www.zhihu.com/question/22111546/answer/30801982)
+ [Deleted functions (C++11)](https://www.ibm.com/docs/en/zos/2.4.0?topic=definitions-deleted-functions-c11)
+ [What is std::move(), and when should it be used?](https://stackoverflow.com/questions/3413470/what-is-stdmove-and-when-should-it-be-used)
+ [constexpr](https://zh.wikipedia.org/wiki/Constexpr)

## C++ 14, C++ 17 新特性
1. 函数返回值类型推导:
   函数返回类性也可以用 `auto` 类型，编译时会有编译器进行类型推导。

```C++
auto func(int i) {
    return i;
}
```

需要注意：		

+ 函数内如果有多个 `return` 语句，它们必须返回相同的类型，否则编译失败。
+ 如果 `return` 语句返回初始化列表，返回值类型推导也会失败。
+ 如果函数是虚函数，不能使用返回值类型推导。
+ 返回类型推导可以用在递归函数中，但是递归调用必须以至少一个返回语句作为先导，以便编译器推导出返回类型。


+ 在 `C++ 14` 中，`lambda` 函数的形式参数允许泛型。

```C++ []
auto lambda = [](auto x, auto y) {return x + y;}
lambda(1, 2);
lambda(1.0, 2.0);
```

+ `Lambda` 初始化捕获:
  允许在 `lambda` 捕获列表中对变量进行表达式赋值，并且支持定义新的变量并进行初始化。

```C++ []
auto lambda = [value = 1] {return value;}
```

+ `constexpr` 函数限制变动:
  `C++ 11` 中 `constexpr` 函数只含有一个将被返回的表达式，`C++ 14` 放松了这些限制：
  + 除了 `static` 或 `thread_local` 变量 以外，可以声明新的变量，且声明的变量必须初始化。
  + 可以包含条件分支语句 `if` 和 `switch`。
  + 可以包含所有的循环语句，包括基于范围的for循环。
  + 表达式可以改变一个对象的值，只需该对象的生命期在声明为 `constexpr` 的函数内部开始。

+ `变量模板`：

```C++ []
template<class T>
constexpr T pi = T(3.1415926535897932385L);

int main() {
    cout << pi<int> << endl; // 3
    cout << pi<double> << endl; // 3.14159
    return 0;
}
```

+ `deprecated` 属性
  `deprecated` 属性允许标记不推荐使用的实体，该实体仍然能合法使用，但会让用户注意到使用它是不受欢迎的，并且可能会导致在编译期间输出警告消息。`deprecated` 可以使用字符串文字作为参数，以解释弃用的原因和/或建议替代者。

```C++ []
[[deprecated]] int f();

[[deprecated("g() is thread-unsafe. Use h() instead")]]
void g( int& x );

void h( int& x );

void test() {
  int a = f(); // 警告：'f'已弃用
  g(a); // 警告：'g'已弃用：g() is thread-unsafe. Use h() instead
}
```

+ `std::make_unique`:
  `C++ 11` 中有 `std::make_shared`，却没有`std::make_unique`，在 `C++ 14` 增加 `std::make_unique`。

```C++ []
struct A {};
std::unique_ptr<A> ptr = std::make_unique<A>();
```

+ 共享的互斥体和锁
  `C++ 14` 增加了一类共享的互斥体和相应的共享锁，通过使用 `std::shared_timed_mutex` 和 `std::shared_lock` 来进行线程同步。

### C++ 17 新特性

+ 结构化绑定
  利用该特性可以把以 `C++` 中的 `pair`，`tuple`，`array`，`struct` 的成员赋值给多个变量。

```C++ []
#include <iostream>
#include <tuple>

struct Point {
    int x;
    int y;
    Point(int x, int y) {
        this->x = x;
        this->y = y;
    }
};

int main() {
    auto [x, y, z] = std::make_tuple(1, 2.3, "456");
    auto [a, b] = std::make_pair(1, 2);
    int arr[3] = {1, 2, 3};
    auto [c, d, e] = arr;
    auto [f, g] = Point(5, 6);
    return 0;
}
```

+ `if-switch` 语句初始化:
  `if` 语句可以支持 `if (init; condition)` 写法，即在判断条件中对变量进行初始化。

```C++ []
if (int a = 10; a < 101) {
    cout << a;
}
```

+ `constexpr lambda` 表达式:
  `C++ 17` 前 `lambda` 表达式只能在运行时使用，`C++ 17` 引入了 `constexpr lambda` 表达式，可以用于在编译期进行计算。

```C++ []
int main() {
    constexpr auto lamb = [] (int n) { return n * n; };
    static_assert(lamb(3) == 9, "a");
}
```

+ `namespace` 嵌套:
  `C++ 17` 支持命名空间嵌套，比如如下写法:

```C++ []
#include <iostream>
namespace A {
    void func(){
        std::cout<<"A func"<<std::endl;
    }
    namespace B {
        namespace C {
            void func(){
                std::cout<<"C func"<<std::endl;
            }
        }
    }
}

int main(int argc, char * argv[])
{
    A::func(); // A func 
    A::B::C::func(); // C func
    return 0;
}
```

+ `std::any`：
  增加了 `any` 可以存储任何类型，可以将其转化为任意类型。

```C++ []
std::any t = 100;
cout << std::any_cast<int>(t) << endl;
t.reset();
t = std::string("1111111");
cout << std::any_cast<string>(t) << endl;
```

+ `std::basic_string_view`:
  字符串视图实际为对外部字符串或字符串片断（`string-slice`）的引用。通过 `string view` 可以访问字符串，但不允许修改字符串。它并不真正持有这个字符串的拷贝，而是与相对应的字符串共享同一段空间。`string view` 的创建与修改不影响原始字符串。`string_view` 支持迭代器，也同样支持 `for` 语句获取元素等操作，标准库也为它编写了相关的 `istream` 和 `ostream` 的运算符重载形式，同时也支持字符串查找操作。

```C++ []
string s = "123456789";
std::string_view sv(s.c_str());
cout<<sv<<endl;
for (auto & ch : sv) {
    cout << ch << ' ';
}
for (auto it = sv.crbegin(); it != sv.crend(); ++it) {
    cout << *it << ' ';
}
cout<<sv.find("345")<<endl; // 2
```

`string_view` 并不真正的持有字符串，所以若视图所引用的字符串区域已经被销毁，那么对应的，视图也会相应的失效。

```C++ []
std::string_view test() {
    char str[] = "1111111";
    return {str};
}

int main() {
    cout<< test() << endl; // error
    return 0;
}
```

+ `std::filesystem`：
  `C++ 17` 正式将 `filesystem` 纳入标准中，提供了关于文件的大多数功能。


参考资料：

+ [C++14](https://zh.m.wikipedia.org/zh-sg/C%2B%2B14)
+ [C++ 11 vs C++ 14 vs C++ 17](https://www.***.org/c-11-vs-c-14-vs-c-17/)
+ [“Difference between C++11 and C++14 and C++17 ”](https://medium.com/@ramprasad.s1973/difference-between-c-11-c-14-c-17-c73288193e17)
+ [C++17 new feature : If Else and Switch Statements with initializers](https://www.***.org/c17-new-feature-else-switch-statements-initializers/)
+ [Changes between C++11 and C++14](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2018/p1319r0.html)
+ [What’s New in C++11 and C++14?](https://www.opensourceforu.com/2018/11/whats-new-in-c11-and-c14/)
+ [C++11\14\17\20 特性介绍](https://blog.csdn.net/bodybo/article/details/124901297)
+ [C++11、C++14、C++17、C++20新特性总结](https://blog.csdn.net/qq_41854911/article/details/119657617)
+ [3.1 Lambda 表达式](https://changkun.de/modern-cpp/zh-cn/03-runtime/#3-1-Lambda-%E8%A1%A8%E8%BE%BE%E5%BC%8F)
+ [【C++】C++ 17简单上手（2）——string_view](https://blog.csdn.net/hepangda/article/details/80821567)
+ [10分钟速览 C++20 新增特性](https://zhuanlan.zhihu.com/p/137646370)
+ [C++14的新特性简介](https://cloud.tencent.com/developer/article/1670712)

## C 和 C++ 的对比
`C` 语言是典型面向过程（`Procedure Oriented`）的编程语言，`C++` 则是典型面向对象（`Object Oriented`）的编程语言，当然 `C++` 也支持面向过程编程。

+ 面向过程（`Procedure Oriented`）：一种以过程为中心的编程思想，侧重于分析解决问题所需的步骤，使用函数把这些步骤依次实现。
+ 面向对象（`Object Oriented`）：侧重于把构成问题的事务分解为各个对象。建立对象的目的不是完成其中的一个步骤，而是描述某个事务在解决整个具体问题步骤中的行为。面向对象语言的显著特征就是支持封装、继承、类的抽象。

1. `C` 语言:
   `C` 语言诞生于 `1969` 年在贝尔实验室诞生，`C` 语言是面向过程的编程，它最重要的特点是函数，通过 `main` 函数来调用各个子函数。程序运行的顺序都是程序员事先决定好的。截至本书完书时，当前 `C` 语言的最新稳定版本为 `C18`，目前力扣已经支持 `C11`。

2. `C++` 语言:
   `C++` 诞生于 `1979` 年，设计者为 `Bjarne Stroustrup`.
   `C++` 是面向对象的编程，类是它的主要特点，在程序执行过程中，先由主 `main` 函数进入，定义一些类，根据需要执行类的成员函数，过程的概念被淡化了（实际上过程还是有的，就是主函数的那些语句）。以类驱动程序运行，类就是对象，所以我们称之为面向对象程序设计。面向对象在分析和解决问题的时候，将涉及到的数据和数据的操作封装在类中，通过类可以创建对象，以事件或消息来驱动对象执行处理。最新的 `C++` 语言标准为 `C++ 20`，目前力扣已经支持 `C++ 17`。

3. 两者之间的比较:
   `C++` 既继承了 `C` 强大的底层操作特性，又被赋予了面向对象机制。它特性繁多，支持面向对象语言的多继承、对值传递与引用传递的区分以及 `const` 关键字，现代 `C++` 编译器完全兼容 `C` 语言语法。 

+ **二者的相同之处**:
  `C++` 能够大部分兼容 `C` 的语法，且二者之间相同的关键字和运算符功能和作用也几乎相同；二者之间的内存模型与硬件比较接近，几乎都可以直接操纵硬件。栈、堆、静态变量这些概念在两种语言都存在。
+ **二者的不同之处**：
  - `C` 为面向过程的编程语言，不支持面向对象，不支持继承、多态、封装。
  - 类型检查更为严格，`C` 语言中的类型转换几乎是任意的，但是 `C++` 编译器对于类型转换进行非常严格检查，部分强制类型转换在 `C` 语言编译器下可以通过，但在 `C++` 编译器下无法通过。
  - `C` 和 `C++` 中都有结构的概念，但是在 `C` 语言中结构只有成员变量，而没成员方法，`C` 的成员变量没有权限控制，该结构体的变量对所有调用全部可见；而在 `C++` 中结构中，它可以有自己的成员变量和成员函数，`C++` 对类的成员变量具有访问权限控制。
  - 增加了面向对象的机制、泛型编程的机制（`Template`）、异常处理、引用、运算符重载、标准模板库（`STL`）、命名空间（避免全局命名冲突）。
  - 应用领域：对于 `C` 语言程序员来说，程序的底层实现和内存分布基本上都可见，所以一般常用于直接控制硬件，特别是 `C` 语言在嵌入式领域应用很广，比如常见的驱动开发等与硬件直接打交道的领域，`C++` 可以用于应用层开发，用户界面开发等与操作系统打交道的领域，特别是图形图像编程领域，几乎所有的高性能图形图像库都是用 `C++` 实现的。

参考资料：

+ [C11 (C语言标准)](https://zh.m.wikipedia.org/zh-sg/C11_(C%E8%AF%AD%E8%A8%80%E6%A0%87%E5%87%86))
+ [Difference between C and C++](https://www.***.org/difference-between-c-and-c/)
+ [Difference between C and C++.](https://www.tutorialspoint.com/difference-between-c-and-cplusplus)

## Java 和 C++ 的对比
`Java` 和 `C++` 都是典型的面向对象（`Object Oriented`）的编程语言。

1. `Java` 语言:<br>
   `Java` 是一种广泛使用的计算机编程语言，拥有跨平台、面向对象、泛型编程的特性，广泛应用于企业级 `Web` 应用开发和移动应用开发。`Java` 语言由 `Sun` 微系统（`Sun MicroSystems`）公司在 `1995` 年正式发布。`Java` 伴随着互联网的迅猛发展而发展，逐渐成为重要的网络编程语言。<br>
   `Java` 编程语言的风格十分接近 `C++` 语言。继承了 `C++` 语言面向对象技术的核心，舍弃了容易引起错误的指针，以引用取代；移除了 `C++` 中的运算符重载和多重继承特性，用接口取代；增加垃圾回收器功能。引入了泛型编程、类型安全的枚举、不定长参数和自动装/拆箱特性。`Java` 不同于一般的编译语言或解释型语言。它首先将原始码编译成字节码，再依赖各种不同平台上的虚拟机 （`JVM`）来解释执行字节码，从而具有 “一次编写，到处运行”的跨平台特性。
<br>
2. 两者之间的比较:
+ **二者的相同之处**:
  `C++` 与 `Java` 均支持面对对象（`Object Oriented`），支持类、继承、封装等常见的概念。
<br>
+ **二者的不同之处**：
  - `Java` 被编译成字节码，并运行在虚拟机 `JVM` 上，和开发平台无关，具有跨平台的特性；`C++` 直接编译成可执行文件，是否跨平台在于用到的编译器的特性是否有多平台的支持。
<br>
  - `Java` 是完全面向对象的语言，所有函数和变量部必须是类的一部分。除了基本数据类型之外，其余的都作为类对象，包括数组。对象将数据和方法结合起来，把它们封装在类中，这样每个对象都可实现自己的特点和行为。而 `C++` 允许将函数和变量定义为全局的。
<br>
  - 由于`Java` 被编译为字节码，只要安装能够运行 `Java` 的虚拟机即可运行 `Java` 程序，因此 `Java` 程序具有很强的可移植性，具有 “一次编写，到处运行” 的跨平台特性；而 `C++` 跨平台后，必须需要重新编译；
<br>
  - `Java` 语言具有垃圾回收机制，由系统进行分配和回收内存，编程人员无需考虑内存管理的问题，可以有效的防止内存泄漏，有效的使用空闲的内存。`Java` 所有的对象都是用 `new` 操作符建立在内存堆栈上，类似于 `C++` 中的 `new` 操作符，但是当要释放该申请的内存空间时，`Java` 自动进行内存回收操作，`Java` 中的内存回收是以线程的方式在后台运行的，利用空闲时间。`C++` 则需要程序员进行内存管理，当资源释放时需要程序员进行手动释放内存空间。
<br>
  - `C++` 支持多重继承，允许多个父类派生一个类，虽然功能很强大，但是如果使用的不当会造成很多问题，例如：菱形继承；`Java` 不支持多重继承，但允许一个类可以继承多个接口，可以实现 `C++` 多重继承的功能，但又避免了多重继承带来的许多不便。
<br>
  - `C++` 支持方法与操作符的重载；但 `Java` 只支持方法重载，不支持操作符重载。
<br>
  - `C++` 用 `virtual` 关键字标记的方法可以被覆盖；`Java` 中非 `static` 方法均可被覆盖，`Java` 中的方法默认均可以被覆盖。
<br>
  - `C++` 可以直接操作指针，容易产生内存泄漏以及非法指针引用的问题；`Java` 并不是没有指针，虚拟机（`JVM`）内部还是使用了指针，只是编程人员不能直接使用指针，不能通过指针来直接访问内存，并且 `Java` 增加了内存管理机制。
<br>
  - `C++` 标准库不提供 `thread` 相关接口；`Java` 的标准 `SDK` 提供 `thread` 类。
<br>
  - `C++` 支持结构体（`structure`）与联合体（`union`），`Java` 不支持结构体（`structure`）与联合体（`union`）。
<br>
  - 从应用场景来说， `C++` 可以直接编译成可执行文件，运行效率比 `Java` 高。`Java` 目前主要用来开发 Web 应用。`C++` 主要用在嵌入式开发、网络、并发编程、图形图像处理、系统编程的方面。
<br>

参考资料：

+ [C++ Vs Java: Top 30 Differences Between C++ And Java With Examples](https://www.softwaretestinghelp.com/cpp-vs-java/)
+ [C++ vs Java](https://www.javatpoint.com/cpp-vs-java)
+ [Difference between C and C++.](https://www.tutorialspoint.com/difference-between-c-and-cplusplus)

## Python 和 C++ 的对比
1. `Python` 语言:

   `Python` 是一种广泛使用的解释型、高级和通用的编程语言。`Python` 支持多种编程范型，包括函数式、指令式、反射式、结构化和面向对象编程。它拥有动态类型系统和垃圾回收功能，能够自动管理内存使用，并且其本身拥有一个巨大而广泛的标准库。它的语言结构以及面向对象的方法旨在帮助程序员为小型的和大型的项目编写清晰的、合乎逻辑的代码。吉多·范罗苏姆于 `1991` 年首次发布 `Python 0.9.0`。`Python 2.0` 于 `2000` 年发布并引入了新功能。`Python 3.0` 于 `2008` 年发布，是该语言的主要修订版，并非完全向后兼容。`Python 2` 于 `2020` 年随 `2.7.18` 版停止支持。`Python` 的设计哲学强调代码的可读性和简洁的语法，尤其是使用空格缩进划分代码块。相比于 `C` 或 `Java`，`Python` 让开发者能够用更少的代码表达想法。`Python` 解释器本身几乎可以在所有的操作系统中运行。`Python` 的官方解释器 `CPython` 是用 `C` 语言编写的，它是一个由社群驱动的自由软件，目前由 `Python` 软件基金会管理。`Python` 是最受欢迎的编程语言之一。<br>
   `Python` 是多泛型编程语言。它完全支持结构化编程和面向对象编程，还有很多特征支持函数式编程和元编程比如元对象协议（元类和魔术方法）。通过扩展还可以支持很多范型，包括面向切面编程、契约式设计和逻辑编程。<br>
   `Python` 使用动态类型，在内存管理上采用引用计数和环检测相结合的垃圾收集器。它的特征还有动态名字解析（后期绑定（英语：`late binding`）），即在程序执行期间绑定方法和变量的名字。<br>
   `Python` 对遵循 `LISP` 传统的函数式编程提供了有限的支持，它提供了 `map`、`filter` 和 `reduce` 函数；列表推导式、字典、集合（英语：`Set (abstract data type)`）和生成器表达式。标准库中的模块 `functools` 和 `itertools`，实现了从 `Haskell` 和 `Standard ML` 借鉴来的函数式工具。<br>
   `Python` 的设计哲学是“优雅”、“明确”、“简单”。它的重要准则被称为 “`Python` 之禅”。在 `Python` 解释器内运行 `import this` 可以获得完整的列表。`Python` 遵循的设计理念:

+ 优美优于丑陋。明了优于隐晦。
+ 简单优于复杂。复杂优于凌乱。
+ 扁平优于嵌套。稀疏优于稠密。
+ 可读性很重要。

2. 两者之间的比较:

+ **二者的相同之处**:
  `C++` 与 `Python` 均支持面向对象，二者均可用来编写大型应用程序。
<br>
+ **二者的不同之处**：
  + 从语言自身来说，`Python` 为脚本语言，解释执行，不需要经过编译，所有的 `python` 源代码都是经过 `Python` 解释器；`C++` 是一种需要编译后才能运行的语言，在特定的机器上编译后运行。
<br>
  + `Python` 变量的作用域不仅局限于（`while，for`）循环内，在循环外还可以继续访问在循环内定义的变量；`C++` 则不允许循环外访问循环内定义的变量。
<br>
  + `Python` 没有严格限定函数的参数类型和返回值类型；`C++` 则严格限定函数参数和返回值的类型。
<br>
  + 从运行效率来说，`C++` 运行效率高，安全稳定。`Python` 代码和 `C++` 最终都会变成 `CPU` 指令来跑，但一般情况下，比如反转和合并两个字符串，`Python` 最终转换出来的 `CPU` 指令会比 C++ 多很多。首先，`Python` 中涉及的内容比 `C++` 多，经过了更多层，`Python` 中甚至连数字都是 `object`；其次，`Python` 是边解释边执行，和物理机 `CPU` 之间多了解释器这层，而 `C++` 是编译执行的，直接就是机器码，编译的时候编译器又可以进行一些优化。
<br>
  + 从开发效率来说，`Python` 开发效率高。`Python` 一两句代码就能实现的功能，`C++` 往往需要更多的代码才能实现。
<br>
  + 书写格式和语法不同，`Python` 的语法格式不同于其 `C++` 定义声明才能使用，而且极其灵活，完全面向更上层的开发者，`C++` 是严格静态类型声明语言，编译器在进行编译时必须经过严格的静态类型检查，如果发现类型检查错误，则中止编译；`Python` 为动态类型语言，我们在编写代码时不用指定变量的类型，只在执行时才会进行变量类型推导，确定变量类型。
<br>
  + `C++` 可以直接用来操纵硬件，适合用来作为系统编程；`Python` 作为一门脚本语言，功能小巧而精湛，非常适合做工具开发和运维开发。
<br>

参考资料：

+ [Python vs. C++ Differences: Difficulty, Popularity, and Career Options](https://hackr.io/blog/python-vs-cpp)
+ [Python Vs C++ | Top 16 Differences Between C++ And Python](https://www.softwaretestinghelp.com/python-vs-cpp/)
+ [Differences Between Python vs C++](https://www.educba.com/python-vs-c-plus-plus/)
+ [Python vs C++: What’s the Difference?](https://www.guru99.com/python-vs-c-plus-plus.html)
+ [Python vs C++: Know what are the differences](https://www.edureka.co/blog/python-vs-cpp/)
+ [Difference between Python and C++](https://www.***.org/difference-between-python-and-c/)

## Go 和 C++ 的对比
1. `Go` 语言:<br>
   `Go`（又称 `Golang`）是 `Google` 开发的一种静态强类型、编译型、并发型，并具有垃圾回收功能的编程语言。`Google` 的罗伯特·格瑞史莫（英语：`Robert Griesemer`）、罗勃·派克及肯·汤普逊于 `2007` 年 `9` 月开始设计 `Go`，稍后伊恩·兰斯·泰勒（`Ian Lance Taylor`）、拉斯·考克斯（`Russ Cox`）加入项目。`Go` 的语法接近 `C` 语言，但对于变量的声明（`type declaration`）有所不同。`Go` 支持垃圾回收功能。`Go` 的并行计算模型是以东尼·霍尔的通信顺序进程（`CSP`）为基础，采取类似模型的其他语言包括 `Occam` 和 `Limbo`，`Go` 也具有这个模型的特征，比如通道传输。通过 `goroutine` 和通道等并行构造可以建造线程池和管道等。在 `1.8` 版本中开放插件（`Plugin`）的支持，这意味着现在能从 `Go` 中动态加载部分函数。与 `C++` 相比，`Go` 并不包括如枚举、异常处理、继承、泛型、断言、虚函数等功能，但增加了切片（`Slice`）型、并发、管道、垃圾回收功能、接口等特性的语言级支持。`Go 2.0` 版本将支持泛型。不同于 `Java`，`Go` 原生提供了关联数组（也称为哈希表（`Hashes`）或字典（`Dictionaries`））。
<br>
2. 两者之间的比较:

+ **二者的相同之处**:
  二者都为静态类型编程语言，二者都为编译性语言，都具有高性能的特点。
 <br>
+ **二者的不同之处**：
  + `Go` 的许多越语法和逻辑跟 `C` 非常类似，`Go` 的运行效率很高，`Go` 主要是面向过程，对于面向对象支持较弱，不支持继承、多态这些概念，`Go` 通过结构体中含有方法来支持面向对象，但不支持多重继续，`Go` 没有类的概念，同时也不支持构造函数与析构函数；`C++` 则是面向对象（`Object Oriented`），支持继承、多重继承、多态、重载这些特性。
<br>
  + `Go` 语言自带垃圾回收（`garbage collection`）；`C++` 不支持内存垃圾自动回收，需要程序手动管理动态申请的内存。
<br>
  + `Go` 语言也支持指针，但是 `Go` 语言不支持指针的运算；`C++` 支持指针，同时也支持指针运算。
<br>
  + `C++` 编译器提供 `SIMD` 指令生成，但是 `Go` 编译器不支持 `SIMD` 指令的生成。
<br>
  + `C++` 遵循的许可为 `open source project 2.0`，而 `Go` 遵循的许可为 `BSD`。
<br>
  + `C++` 与 `Go` 都属于静态类型编程语言，但是 `Go` 语言需要遵循强类型语言规则，`Go` 不支持隐式类型转换。
<br>
  + `Go` 编译时如果需要引用外部函数则使用 `import` 关键字，引入 `packages`，而 `C++` 则使用 `#include` 关键字，引入头文件。
<br>
  + `Go` 不支持函数重载和操作符重载，而 `C++` 支持函数重载与操作符重载。
<br>
  + `Go` 中的空指针用 `nil` 表示，而 `C++` 中空指针可以用 `nullptr` 或者 `0` 表示。
<br>
  + `C++` 支持异常处理，可以捕获异常，`Go` 使用 `panic` 并保存所有的错误信息。
<br>
  + `Go` 可以利用 `goroutines` 与 `channel` 来进行并发与多线程，`C++` 只能使用线程。
<br>

参考资料：

+ [Go vs C++ Compared and Contrasted](https://careerkarma.com/blog/go-vs-c-plus-plus/)
+ [Go 语言教程](https://www.runoob.com/go/go-tutorial.html)
+ [C++ vs Go](https://www.educba.com/c-plus-plus-vs-go/)
+ [Go vs C++](https://www.***.org/go-vs-c-plus-plus/)
+ [Go](https://zh.m.wikipedia.org/wiki/Go)

## Rust 和 C++ 的对比
1. `Rust` 语言:<br>
   `Rust` 是由 `Mozilla` 主导开发的通用、编译型编程语言。设计准则为“安全、并发、实用”，支持函数式、并发式、过程式以及面向对象的程序设计风格。`Rust` 语言原本是 `Mozilla` 员工 `Graydon Hoare` 的私人计划，而 `Mozilla` 于 `2009` 年开始赞助这个计划，并且在 `2010` 年首次公开。也在同一年，其编译器源代码开始由原本的 `OCaml` 语言转移到用 `Rust` 语言，进行 `bootstrapping` 工作，编译器在架构上采用了 `LLVM` 做为它的后端。第一个有版本号的 `Rust` 编译器于2012年1月发布。`Rust 1.0` 是第一个稳定版本，于 `2015` 年 `5` 月 `15` 日发布。`Rust` 的设计目标之一，是要使设计大型的互联网客户端和服务器的任务变得更容易，因此更加强调安全性、存储器配置、以及并发处理等方面的特性。在性能上，具有额外安全保证的代码会比 `C++` 慢一些，例如对 `Rust` 的数组进行操作时默认会检查索引是否越界，而 `C++` 则不会，但是如果以 `C++` 也手工提供保证的情况下，则两者性能上是相似的。为了提供存储器安全，它的设计不允许空指针和悬空指针。 指针只能透过固定的初始化形态来建构，而所有这些形态都要求它们的输入已经分析过了。`Rust` 有一个检查指针生命期间和指针冻结的系统，可以用来预防在 `C++` 中许多的类型错误，甚至是用了智能指针功能之后会发生的类型错误。
<br>
2. 两者之间的比较:

+ **二者的相同之处**:
  二者都支持指针操作，都可以用来作为系统编程语言，二者都可以用来操作底层硬件，二者都都具有与 `C` 语言程序相当的性能。
<br>
+ **二者的不同之处**：
  + `Rust` 不允许控制指针和悬空指针，`C++` 则允许空指针；
<br>
  + `Rust` 只支持函数式编程，`C++` 支持的语言特性较多；
<br>
  + `Rust` 没有头文件，`C++` 有头文件；
<br>
  + `Rust` 语言自带有内存管理，保证内存使用安全，`Rust` 利用编译时的静态分析很大程度上保证了代码使用内存的安全性；而 `C++` 需要进行手动申请和释放内存；
<br>
  + `Rust` 利用静态分析，在编译时会分析代码由于并发引起的数据竞争，较好的做好的并发处理；`C++` 的使用多线程并发容易引起各种数据竞争的问题。
<br>

参考资料：

+ [Rust vs. C++—the main differences between these popular programming languages](https://codilime.com/blog/rust-vs-cpp-the-main-differences-between-these-popular-programming-languages/)
+ [Rust vs C++: an in-depth language comparison](https://www.educative.io/blog/rust-vs-cpp)
+ [Rust vs C++ Comparison](https://www.apriorit.com/dev-blog/520-rust-vs-c-comparison)
+ [Rust vs C++: Which Technology Should You Choose?](https://www.ideamotive.co/blog/rust-vs-cpp-which-technology-should-you-choose)


# C++ 关键字与关键库函数
本章将重点涉及以下高频知识点：

## sizeof 和 strlen 的区别
+ `strlen` 是头文件 `<cstring>` 中的函数，`sizeof` 是 `C++` 中的运算符。`strlen` 测量的是字符串的实际长度（其源代码如下），以 `\0` 结束，而 `sizeof` 测量的是对象或者表达式类型占用的字节大小。`strlen` 源代码如下:

```C++ []
size_t strlen(const char *str) {
    size_t length = 0;
    while (*str++)
        ++length;
    return length;
}
```

举例：

```C++ []
#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char arr[10] = "hello";
    cout << strlen(arr) << endl; // 5
    cout << sizeof(arr) << endl; // 10
    return 0;
}
```

若字符数组 `arr` 作为函数的形参，`sizeof(arr)` 中 `arr` 被当作字符指针来处理，`strlen(arr)` 中 `arr` 依然是字符数组，从下述程序的运行结果中就可以看出。

```C++ []
#include <iostream>
#include <cstring>

using namespace std;

void size_of(char arr[])
{
    cout << sizeof(arr) << endl; // warning: 'sizeof' on array function parameter 'arr' will return size of 'char*' .
    cout << strlen(arr) << endl; 
}

int main()
{
    char arr[20] = "hello";
    size_of(arr); 
    return 0;
}
/*
输出结果：
8
5
*/
```

+ 二者的不同之处:

  + `strlen` 本身是库函数，因此在程序运行过程中，计算长度；而 `sizeof` 是在编译时计算长度；`sizeof` 的参数可以是类型，也可以是变量，且必须是完整类型；`strlen` 的参数必须是 `char *` 类型的变量。
  + `sizeof` 接受的参数可以是对象也可以是表达式，但是 `sizeof(expression)` 在运行时不会对接受的表达式进行计算，编译器只会推导表达式的类型从而计算占用的字节大小；而 `strlen` 是一个函数，如果接受表达式则会对表达式进行运算。 

  ```C++ []
    #include <iostream>
    using namespace std;
    int main(int argc, char * argv[])
    {
        int x = 4;
        char *s = "12345678";
        char *p = s;
        sizeof(x++);
        printf("%d\n", x);
        strlen(p++);
        return 0;
    }
  ```

  + 对于 `C99` 中结构体允许最后一个变量为不定长数组，`sizeof` 则不计算空间。

  ```C++ []
    #include <iostream>
    #include <cstring>
  
    using namespace std;
  
    struct flexarray {
        int val;
        int array[];  /* Flexible array member; must be last element of struct */
    };
  
    int main()
    {
        printf("%ld\n", sizeof(struct flexarray)); // 4
    }
  ```


参考资料：

+ [sizeof](https://en.wikipedia.org/wiki/Sizeof)
+ [sizeof operator in C](https://www.geeksforgeeks.org/sizeof-operator-c/)
+ [sizeof operator](https://en.cppreference.com/w/cpp/language/sizeof)

## C 和 C++ static 中的作用
+ 在 `C` 语言中，使用 `static` 可以定义局部静态变量、外部静态变量、静态函数。
+ 在 `C++` 中，使用 `static` 可以定义局部静态变量、外部静态变量、静态函数、静态成员变量和静态成员函数。因为 `C++` 中有类的概念，静态成员变量、静态成员函数都是与类有关的概念。

1. `static` 全局静态变量:

+ 普通全局变量和 `static` 全局静态变量都为静态存储方式。普通全局变量的作用域是整个源程序，当一个源程序由多个源文件组成时，普通全局变量在各个源文件中都是有效的；
+ 静态全局变量则限制了其作用域，即只在定义该变量的源文件内有效，在同一源程序的其它源文件中不能使用它。由于静态全局变量的作用域限于一个源文件内，只能为该源文件内的函数公用，因此可以避免在其他源文件中引起错误。静态全局变量只初始化一次，防止在其他文件中使用。实际上全局静态变量存储在内存的静态存储区，生命周期贯穿于整个程序运行期间。静态变量会被放在程序的静态数据存储区，这样可以在下一次调用的时候还可以保持原来的赋值，静态变量用 `static` 告知编译器，自己仅仅在变量的作用范围内可见，实际是依靠编译器来控制作用域。

2. `static` 局部静态变量:
   局部静态变量只能被初始化一次。与全局静态变量不同的是静态局部变量的作用域仅限于函数内部，它的作用域与函数内部的局部变量相同。实际上局部静态变量同样也存储在静态存储区，因此它的生命周期贯穿于整个程序运行期间。

+ `a.cpp`:

```C++ []
#include <iostream>
using namespace std;
int g_var = 0; // 全局变量
static char *gs_var;  // 静态全局变量

int main()
{
    int var;                    // 局部变量
    static int s_var = 0;       // 静态局部变量
    return 0;
}
```

 + `b.cpp`

```C++ []
#include <iostream>
using namespace std;
extern int g_var = 0; // 访问全局变量
// extern static char *gs_var;  无法访问静态全局变量

int test()
{
    g_var = 1;
}
```

3. `static` 静态函数:
   `static` 函数限制函数的作用域，仅可在定义该函数的文件内部调用，如下所示程序示例编译会报错，找不到 `test` 函数定义。

+ `a.cpp`:

```C++ []
#include <iostream>
using namespace std;
int g_var = 0; // 全局变量
static char *gs_var;  // 静态全局变量
extern int test();
int main()
{
    int var;                    // 局部变量
    static int s_var = 0;       // 静态局部变量
    test();  
    return 0;
}
```

+ `b.cpp`

```C++ []
#include <iostream>
using namespace std;

static int test()
{
    return 0；
}
```

4. `static` 静态成员变量:

+ 静态成员变量是在类内进行声明，在类外进行定义和初始化，在类外进行定义和初始化的时候不要出现 `static` 关键字和 `private`、`public`、`protected` 访问规则。
+ 静态成员变量相当于类域中的全局变量，被类的所有对象所共享，包括派生类的对象，且只能该变量只能被初始化一次，不能在类的构造函数中对静态成员变量进行初始化。

```C++ []
// C++ program to demonstrate static
// variables inside a class
#include<iostream>
using namespace std;

class GfG
{
public:
	static int i;
	GfG() {
		
	};
};

int GfG::i = 1; // initial

int main()
{
    GfG obj1;
    GfG obj2;
    obj1.i =2; // error
    obj2.i = 3; // error
    GfG::i = 10; // assignment
    // prints value of i
    cout << obj1.i<<" "<<obj2.i; // 10 
}
```

+ 静态成员变量可以作为成员函数的参数，而普通成员变量不可以。

```C++ []
#include <iostream>
using namespace std;

class A
{
public:
    static int s_var;
    int var;
    void fun1(int i = s_var); // 正确，静态成员变量可以作为成员函数的参数
    void fun2(int i = var);   //  error: invalid use of non-static data member 'A::var'
};
int main()
{
    return 0;
}
```

+ 静态数据成员的类型可以是所属类的类型，而普通数据成员的类型只能是该类类型的指针或引用。

```C++ []
#include <iostream>
using namespace std;

class A
{
public:
    static A s_var; // 正确，静态数据成员
    A var;          // error: field 'var' has incomplete type 'A'
    A *p;           // 正确，指针
    A &var1;        // 正确，引用
};

int main()
{
    return 0;
}
```

5. `static` 静态成员函数:
   静态成员函数不能调用非静态成员变量或者非静态成员函数，因为静态成员函数没有 `this` 指针。静态成员函数做为类作用域的全局函数。
   静态成员函数不能声明成虚函数（`virtual`）、`const` 函数和 `volatile` 函数。

```C++ []
#include<iostream>
using namespace std;
class GfG
{
public:
	static void printMsg()
	{
		cout<<"Welcome to GfG!";
	}
};
int main()
{
	GfG::printMsg();
}

```

6. `static` 对象:
   静态对象的生存周期为整个程序的生命周期，而非静态对象的生命周期只存在于某个循环中，我们可以通过以下程序做对比:

```C++ []
#include<iostream>
using namespace std;

class GfG1
{
	int i;
	public:
		GfG1()
		{
			i = 0;
			cout << "GFG1 Inside Constructor\n";
		}
		~GfG1()
		{
			cout << "GFG1 Inside Destructor\n";
		}
};

class GfG2
{
	int i;
	public:
		GfG2()
		{
			i = 0;
			cout << "GfG2 Inside Constructor\n";
		}
		~GfG2()
		{
			cout << "GfG2 Inside Destructor\n";
		}
};

int main()
{
	int x = 0;
	if (x==0)
	{
		GfG1 obj1;
        static GfG2 obj2;
	}
	cout << "End of main\n";
}
```

程序的输出为:

```C++ []
GFG1 Inside Constructor
GfG2 Inside Constructor
GFG1 Inside Destructor
End of main
GfG2 Inside Destructor
```

我们可以观察到当 `main` 函数执行完成，静态对象 `obj2` 对象的生命周期仍然存在。

参考资料：

+ [Static Keyword in C++](https://www.***.org/static-keyword-cpp/)
+ [static members](https://en.cppreference.com/w/cpp/language/static)
+ [C/C++ 中 static 的用法全局变量与局部变量](https://www.runoob.com/w3cnote/cpp-static-usage.html)
+ [The static keyword and its various uses in C++](https://stackoverflow.com/questions/15235526/the-static-keyword-and-its-various-uses-in-c)
+ [Static Members of a C++ Class](https://www.tutorialspoint.com/cplusplus/cpp_static_members.htm)

## const 作用及用法
+ `const` 修饰普通变量或者成员变量，定义成 `const` 常量，相较于宏常量可进行类型检查，节省内存空间，提高了效率。
+ `const` 修饰函数参数，使得传递过来的函数参数的值不能改变。
+ `const` 修饰成员函数，使得成员函数不能修改任何类型的成员变量（`mutable` 修饰的变量除外），也不能调用非 `const` 成员函数，因为非 `const` 成员函数可能会修改成员变量。

1. `const` 变量:
   定义成 `const` 常量，相较于宏常量，可进行类型检查，节省内存空间，提高了效率。被定义为 `const` 的变量是不可修改的。

```C++
#include <iostream>
using namespace std;

int main()
{
    const int y = 10;
    cout << y;
    y = 9; // error
    return 0;
}

```

2. `const` 指针:

+ `const` 修饰指针指向的内容，则指针指向的内容不可变，但是指针本身的内容可以改变。

```C++
int x = 0;
int *q = &x;
const int *p = &x;
*p = 10; // error
p = q; // OK
```

+ `const` 修饰指针，则指针为不可变量，指针指向的内容可以变，但指针本身不能变。

```C++
int a = 8;
int* const p = &a; // 指针为常量
*p = 9;  // OK
int  b = 7;
p = &b; // error
```

+ `const` 修饰指针和指针指向的内容，则指针和指针指向的内容都为不可变量。

```C++
int a = 8;
const int * const  p = &a;
```

3. `const` 引用:
   `const` 引用是指向 `const` 对象的引用，可以读取变量，但不能通过引用修改指向的对象。我们可以将 `const` 引用指向非 `const` 变量，但不能使用非 `const` 引用指向 `const` 变量。`const` 引用可以初始化为不同类型的对象或者右值（如字面值常量），但非 `const` 引用不可以。

```C++
int i = 10;
const int &ref = i;
double d = 3.14;
const int &ref2 = d;
```

4. `const` 成员变量：
   `const` 成员变量只能在类内声明、定义，在构造函数初始化列表中初始化。
   `const` 成员变量只在某个对象的生存周期内是常量，对于整个类而言却是可变的，因为类可以创建多个对象，不同类的 `const` 成员变量的值是不同的。因此不能在类的声明中初始化 `const` 成员变量。

5. `const` 函数参数与返回值:
   用 `const` 修饰函数参数，表明函数参数为常量，在函数内部不可以修改参数的内容，一般我们使用 `const` 指针或者 `const` 引用。函数返回值如果为指针或者引用，我们可以用 `const` 指针或者引用接受返回值，此时指向的内容则不可以修改。

6. `const` 成员函数：
   不能修改成员变量的值，除非有 `mutable` 修饰；只能访问成员变量。
   不能调用非常量成员函数，以防修改成员变量的值。

+ `const` 对象只能访问 `const` 成员函数,而非 `const` 对象可以访问任意的成员函数，包括 `const` 成员函数。
+ 加上 `mutable` 修饰符的数据成员,对于任何情况下通过任何手段都可修改,自然此时的 `const` 成员函数是可以修改它的。

```C++
#include <iostream>
using namespace std;
class A
{
public:
	int var;
	A(int tmp) : var(tmp) {}
	void c_fun(int tmp) const // const 成员函数
	{
		var = tmp; // error: assignment of member 'A::var' in read-only object. 在 const 成员函数中，不能修改任何类成员变量。		
		fun(tmp); // error: passing 'const A' as 'this' argument discards qualifiers. const 成员函数不能调用非 const 成员函数，因为非 const 成员函数可能会修改成员变量。
	}

	void fun(int tmp)
	{
		var = tmp;
	}
};
int main()
{
    return 0;
}
```

参考资料：

+ [C++ const 关键字小结](https://www.runoob.com/w3cnote/cpp-const-keyword.html)
+ [const (C++)](https://docs.microsoft.com/en-us/cpp/cpp/const-cpp?view=msvc-170)
+ [Const keyword in C++](https://www.geeksforgeeks.org/const-keyword-in-cpp/)

## define 和 const 的区别
二者之间的区别:

+ 编译阶段：`define` 是在编译预处理阶段进行替换，`const` 是在编译阶段确定其值。
+ 安全性：`define` 定义的宏常量没有数据类型，只是进行简单的代码替换，不会进行类型安全的检查；`const` 定义的常量是有类型的，是要进行判断的，可以避免一些低级的错误。
+ 存储空间：`define` 定义的宏定义只是作为代码替换的表达式而已，宏定义本身不占用内存空间，`define` 定义的宏常量，在程序中使用多少次就会进行多少次替换，内存中有多个备份，实际使用宏定义替换代码时占用的是代码段的空间；`const` 定义的常量占用静态存储区的只读空间，程序运行过程中常量只有一份。
+ 调试：`define` 定义的宏常量不能调试，因为在预编译阶段就已经进行替换了；`const` 定义的常量可以进行调试。
+ `define` 可以接受参数构造非常复杂的表达式，`const` 不能接受参数。

参考资料：

+ [Difference between #define and const in C?](https://www.***.org/diffference-define-const-c/)
+ [What is the difference between #define and const?](https://stackoverflow.com/questions/6442328/what-is-the-difference-between-define-and-const)
+ [Difference between const and #define in C, C++ programming language](https://www.includehelp.com/cpp-tutorial/difference-between-const-and-define.aspx)

## inline 作用及使用方法
`inline` 是一个关键字，可以用于定义内联函数。内联函数，像普通函数一样被调用，但是在调用时并不通过函数调用的机制而是直接在调用点处展开，这样可以大大减少由函数调用带来的开销，从而提高程序的运行效率。在内联函数出现之前，在 `C/C++` 的大型工程中常见用 `#define` 定义一些“函数”来消除调用这些函数的开销。内联函数设计的目的之一，就是取代 `#define` 的这项功能。由于使用 `#define` 定义的“函数”，编译器不会检查其参数的正确性等，而使用 `inline` 定义的函数，可以指定参数类型，则会被编译器校验）。内联函数可以在头文件中被定义，并被多个 `.cpp` 文件 `include`，而不会有重定义错误。这也是设计内联函数的主要目的之一。

+ 使用方法：类内定义成员函数默认是内联函数，除了虚函数以外，因为虚函数是在运行时决定的，在编译时还无法确定虚函数的实际调用。
  在类内定义成员函数，可以不用在函数头部加 `inline` 关键字，因为编译器会自动将类内定义的函数（构造函数、析构函数、普通成员函数等）声明为内联函数，代码如下:

```C++ []
#include <iostream>
using namespace std;

class A{
public:
    int var;
    A(int tmp){ 
      var = tmp;
    }
    void fun(){ 
        cout << var << endl;
    }
};

int main()
{    
    return 0;
}
```

+ 类外定义成员函数，若想定义为内联函数，需用关键字声明
  当在类内声明函数，在类外定义函数时，如果想将该函数定义为内联函数，则可以在类内声明时不加 `inline` 关键字，而在类外定义函数时加上 `inline` 关键字。关键字 `inline` 必须与函数定义体放在一起才能使函数成为内联，如果只是 `inline` 放在函数声明前面不起任何作用。

```C++ []
#include <iostream>
using namespace std;

class A{
public:
    int var;
    A(int tmp){ 
      var = tmp;
    }
    void fun();
};

inline void A::fun(){
    cout << var << endl;
}

int main()
{    
    return 0;
}
```


参考资料：

+ [Inline Functions in C++](https://www.***.org/inline-functions-cpp/?ref=gcse)

## new 和 malloc 的区别
1. `malloc` 的实现原理：
<br>

   `malloc` 为 `C` 语言的库函数，主要用来从堆中申请指定大小且连续的内存空间。实际的底层实现可能较为复杂，每个程序都带有自己的动态内存管理子模块，常见的动态内存分配算法有 `best fit` 和 `first fit` 等。由于现代操作系统用户程序都是采用虚拟地址空间，理论上对于一个程序来说，在 `64` 位地址空间下，它可见的地址空间为 `0x0000000000000000-0xFFFFFFFFFFFFFFF`，而程序中的 `heap` 段是虚拟地址中的一段连续的空间。程序运行时，操作系统会预先为程序分配 `heap` 段，虽然程序的运行，使用的 `heap` 空间不断增大，当操作系统已分配的空间不够使用时，这时会通过 `mmap` 映射新的物理内存页加入到 `heap` 空间中，并将新加入的物理页映射到 `heap` 的末尾，从而形成连续的虚拟内存空间。
<br>
2. `new` 与 `malloc` 的区别：

+ `new` 在申请内存的同时，会调用对象的构造函数，对象会进行初始化，`malloc` 仅仅在堆中申请一块指定大小的内存空间，并不会对内存和对象进行初始化。
<br>
+ `new` 可以指定内存空间初始化对象，而 `malloc` 只能从堆中申请内存。
<br>
+ `new` 是 `c++` 中的一个操作符，而 `malloc` 是 `C` 中的一个函数。
<br>
+ `new` 的返回值为一个对象的指针类型，而 `malloc` 统一返回 `void *` 指针。
<br>
+ `new` 内存分配成功，返回该对象类型的指针，分配失败，抛出 `bad_alloc` 异常；而 `malloc` 成功申请到内存，返回指向该内存的指针；分配失败，返回 `NULL` 指针。
<br>
+ `new` 的空间大小由编译器会自动计算，而 `malloc` 则需要指定空间大小。
<br>
+ `new` 作为一个运算符可以进行重载，而 `malloc` 作为一个函数不支持重载。
<br>
+ `malloc` 可以更改申请过的空间大小，我们可以 `realloc` 指定空间大小，而 `new` 一旦申请则无法更改。
<br>


参考资料：

+ [malloc](https://en.cppreference.com/w/c/memory/malloc)
+ [C library function - malloc()](https://www.tutorialspoint.com/c_standard_library/c_function_malloc.htm)
+ [Dynamic Memory Allocation in C using malloc(), calloc(), free() and realloc()](https://www.***.org/dynamic-memory-allocation-in-c-using-malloc-calloc-free-and-realloc/)
+ [Difference Between malloc() and calloc() with Examples](https://www.***.org/difference-between-malloc-and-calloc-with-examples/)

## delete 与 free 的区别
1. `free` 的简介：
<br>

   `free` 释放 `heap` 中申请的动态内存空间，只能释放 `malloc`，`calloc`，`realloc` 申请的内存。需要注意的是，`free` 函数只是将参数指针指向的内存归还给操作系统，并不会把参数指针置 `NULL`，为了以后访问到被操作系统重新分配后的错误数据，所以在调用 `free` 之后，通常需要手动将指针置 `NULL`。内存资源都是由操作系统来管理的，而不是编译器，编译器只是向操作系统提出申请，所以 `free` 函数是没有能力去真正的 `free` 内存的，只是向内存管理模块归还了内存，其他模块还可以继续申请使用这些内存。`free` 后指针仍然指向原来的堆地址，实际还可以使用，但操作系统可能将这块内存已经分配给其他模块使用，一般建议在 `free` 以后将指针置为空。一个指针经过两次 `free`，也是比较危险的操作，因为可能该段内存已被别的内存使用申请使用了，`free` 之后会造成严重后果。
<br>
2. `delete` 的简介：
<br>

   `delete` 是 `C++` 中的一个操作符，如果对象存在析构函数，它首先执行该对象所属类的析构函数，进而通过调用 `operator delete` 的标准库函数来释放所占的内存空间。`delete` 用来释放单个对象所占的空间，只会调用一次析构函数；`delete []` 用来释放数组空间，会对数组中的每个元素都调用一次析构函数。`delete` 只能用来释放 `new` 操作返回的指针，否则会产生不可预知的后果。在单个对象上的删除 使用 `delete []` 的数组形式，以及对数组使用非数组形式的删除都会产生不可预知的后果。如果 `new` 的对象是指定地址，则不能直接调用 `delete`。
<br>
3. `delete` 与 `free` 的区别：
<br>

+ `delete` 是 `C++` 中的一个操作符，可以进行重载；而 `free` 是 `C` 中的一个函数，不能进行重载；
<br>
+ `free` 只会释放指向的内存，不会执行对象的析构函数；`delete` 则可以执行对象的析构函数；
<br>

参考资料：

+ [Difference between delete and free() in C++](https://www.includehelp.com/cpp-tutorial/difference-between-delete-and-free.aspx)

## volatile 的作用与使用场景
1. `volatile` 的简介：
   `volatile` 的作用：当对象的值可能在程序的控制或检测之外被改变时，应该将该对象声明为 `volatile`，告知编译器不应对这样的对象进行优化。`volatile` 关键字修饰变量后，提醒编译器它后面所定义的变量随时都有可能改变，因此编译后的程序每次需要存储或读取这个变量的时候，都会直接从变量地址中读取数据。如果没有 `volatile` 关键字，则编译器可能优化读取和存储，可能暂时使用寄存器中的值，如果这个变量由别的程序更新了的话，将出现不一致的现象。
   使用 `volatile` 关键字试图阻止编译器过度优化，`volatile` 主要作用如下：

+ 阻止编译器为了提高速度将一个变量缓存到寄存器内而不写回；（缓存一致性协议、轻量级同步）
+ 阻止编译器调整操作 `volatile` 变量的指令排序。

2. `volatile` 的作用：

+ 读取变量时，阻止编译器对缓存的优化: `volatile` 关键字是一种类型修饰符，用它声明的类型变量表示可以被某些编译器未知的因素更改，比如：操作系统、硬件或者其它线程等。遇到这个关键字声明的变量，编译器对访问该变量的代码就不再进行优化，从而可以提供对特殊地址的稳定访问。比如声明时 `volatile` 变量，`int volatile vInt`; 当要求使用 `volatile` 声明的变量的值的时候，系统总是重新从它所在的内存读取数据，即使它前面的指令刚刚从该处读取过数据，而且读取的数据立刻被保存。

```C++ []
volatile int i=10;
int a = i;
...
// 其他代码，并未明确告诉编译器，对 i 进行过操作
int b = i;
```

`volatile` 修饰 `i` 后，表明每次使用 `i` 时必须从 `i` 的地址中读取，因而编译器生成的汇编代码会重新从 `i` 的地址读取数据放在 `b` 中。如果不加 `volatile`，编译器会进行优化，编译器发现两次从 `i` 读数据的代码之间的代码没有对 `i` 进行过操作，它会自动把上次读的数据放在 `b` 中，而不是重新从 `i` 里面读，如果 `i` 是一个寄存器变量，则 `i` 可能已经被外部程序进行改写，因此 `volatile`可以保证对特殊地址的稳定访问。 

+ 写入变量时，阻止编译器对指令顺序的优化: 在某些特定的场景下，比如读写寄存器或者操作某些硬件，需要按照某些特定的指令序列读写寄存器，而不能忽略其中的某些步骤，比如如下程序:

```C++ []
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int ra = 0;
    int rb = 0;
    ra = 0x1111;
    ra = 0x2222;
    ra = 0x3333;
    rb = ra;
    printf("%d\n", ra);
    return 0;
}
```

我们使用编译器优化：

```shell []
g++ -S -O3 test.cpp -o test
```

查看编译后的代码为:

```C []
0000000000000560 <main>:
 560:   48 83 ec 08             sub    $0x8,%rsp
 564:   ba 33 33 00 00          mov    $0x3333,%edx
 569:   bf 01 00 00 00          mov    $0x1,%edi
 56e:   31 c0                   xor    %eax,%eax
 570:   48 8d 35 8d 01 00 00    lea    0x18d(%rip),%rsi        # 704 <_IO_stdin_used+0x4>
 577:   e8 c4 ff ff ff          callq  540 <__printf_chk@plt>
 57c:   31 c0                   xor    %eax,%eax
 57e:   48 83 c4 08             add    $0x8,%rsp
 582:   c3                      retq
 583:   66 2e 0f 1f 84 00 00    nopw   %cs:0x0(%rax,%rax,1)
 58a:   00 00 00
 58d:   0f 1f 00                nopl   (%rax)
```

我们可以看到编译的汇编代码，变量 `ra` 直接赋值为 `0x3333`，从而省略了中间赋值过程：

```C++ []
ra = 0x1111;
ra = 0x2222;
ra = 0x3333;
```

在初始化某些硬件平台时，我们需要按照芯片手册对寄存器依次连续写入一系列的指令，上述程序中假如 `ra` 为一个寄存器变量，则依次为寄存器按照顺序写入特定的值来操作硬件。如果不添加 `volatile` 关键字，某些编译器会对上述代码进行优化，直接会省略中间的写入指令。实际在硬件在初始化中不能省略中间的指令，此时编译器的优化反而造成错误，此时我们用 `volatile` 修饰变量 `ra`，可以阻止编译器对指令顺序进行优化。

```C []
0000000000000560 <main>:
 560:   48 83 ec 18             sub    $0x18,%rsp
 564:   48 8d 35 b9 01 00 00    lea    0x1b9(%rip),%rsi        # 724 <_IO_stdin_used+0x4>
 56b:   bf 01 00 00 00          mov    $0x1,%edi
 570:   c7 44 24 0c 00 00 00    movl   $0x0,0xc(%rsp)
 577:   00
 578:   c7 44 24 0c 11 11 00    movl   $0x1111,0xc(%rsp)
 57f:   00
 580:   c7 44 24 0c 22 22 00    movl   $0x2222,0xc(%rsp)
 587:   00
 588:   c7 44 24 0c 33 33 00    movl   $0x3333,0xc(%rsp)
 58f:   00
 590:   8b 44 24 0c             mov    0xc(%rsp),%eax
 594:   31 c0                   xor    %eax,%eax
 596:   8b 54 24 0c             mov    0xc(%rsp),%edx
 59a:   e8 a1 ff ff ff          callq  540 <__printf_chk@plt>
 59f:   31 c0                   xor    %eax,%eax
 5a1:   48 83 c4 18             add    $0x18,%rsp
 5a5:   c3                      retq
 5a6:   66 2e 0f 1f 84 00 00    nopw   %cs:0x0(%rax,%rax,1)
 5ad:   00 00 00
```

3. `volatile` 的应用场景：
   在实际场景中除了操纵硬件需要用到 `volatile` 以外，更多的可能是多线程并发访问共享变量时，一个线程改变了变量的值，怎样让改变后的值对其它线程可见，此时我们就需要使用 `volatile` 进行修饰。一般说来，`volatile` 用在如下的几个地方：

+ 中断服务程序中修改的供其它程序检测的变量需要加 `volatile`；
+ 多任务环境下各任务间共享的标志应该加 `volatile`；
+ 存储器映射的硬件寄存器通常也要加 `volatile` 说明，因为每次对它的读写都可能有不同意义；

参考资料：

+ [volatile (C++)](https://docs.microsoft.com/en-us/cpp/cpp/volatile-cpp?view=msvc-170)
+ [What is volatile keyword in C++?](https://www.tutorialspoint.com/what-is-volatile-keyword-in-cplusplus)
+ [Why do we use volatile keyword?](https://stackoverflow.com/questions/4437527/why-do-we-use-volatile-keyword)

## 用宏实现比较大小，以及两个数中的最小值
实现比较简单，需要注意括号和作用域的问题，由于 `#define` 只是做简单的替换，而 `#define` 中替代时可能含有表达式，因此我们需要用括号进行作用域限制。

```C++ []
#include <iostream>
#define MAX(X, Y) ((X) > (Y) ? (X) : (Y))
#define MIN(X, Y) ((X) < (Y) ? (X) : (Y))
using namespace std;

int main ()
{
    int var1 = 10, var2 = 100;
    cout << MAX(var1, var2) << endl;
    cout << MIN(var1, var2) << endl;
    return 0;
}
/*
程序运行结果：
100
10
*/
```

上述可能存在重复计算的问题，比如表达式 `X,Y` 均计算了两次，多次计算在某些场景下性能较低或者会产生影响，我们可以进行简化如下:

```C++ []
#define MIN(x, y) ({				\
	typeof(x) _min1 = (x);			\
	typeof(y) _min2 = (y);			\
	(void) (&_min1 == &_min2);		\
	_min1 < _min2 ? _min1 : _min2; })

#define MAX(x, y) ({				\
	typeof(x) _max1 = (x);			\
	typeof(y) _max2 = (y);			\
	(void) (&_max1 == &_max2);		\
	_max1 > _max2 ? _max1 : _max2; })
```

参考资料：

+ [【宏定义系列】 两个数中的最小](https://blog.csdn.net/u012028275/article/details/118052249)

## 宏定义（define）和内联函数（inline）的区别
1. 二者的区别

+ 内联函数是在编译时展开，而宏在编译预处理时展开；在编译的时候，内联函数直接被嵌入到目标代码中去，而宏只是一个简单的文本替换。
+ 内联函数是真正的函数，和普通函数调用的方法一样，在调用点处直接展开，避免了函数的参数压栈操作，减少了调用的开销，在编译后的代码段中可以看到内联函数的定义。宏定义编写较为复杂，常需要增加一些括号来避免歧义。宏定义只进行文本替换，不会对参数的类型、语句能否正常编译等进行检查，因此在实际使用宏时非常容易出错。而内联函数是真正的函数，会对参数的类型、函数体内的语句编写是否正确等进行检查。
+ 内联函数可以进行调试，宏定义的“函数”无法调试。
+ 由于类的成员函数全部为内联函数，通过内联函数，可以访问类的数据成员，而宏不能访问类的数据成员。
+ 在 `inline` 函数传递参数只计算一次，而在使用宏定义的情况下，每次在程序中使用宏时都会计算表达式参数，因此宏会对表达式参数计算多次。


参考资料：

+ [Inline Functions in C++](https://www.***.org/inline-functions-cpp/?ref=gcse)
+ [Inline function](https://en.wikipedia.org/wiki/Inline_function)
+ [inline 作用及使用方法](https://www.***.org/difference-between-inline-and-macro-in-c/?ref=gcse)

## C 和 C++ struct 的区别
+ 在 `C `语言中 struct 是用户自定义数据类型；在 `C++` 中 `struct` 是抽象数据类型，支持成员函数的定义。`C++` 中的 `class` 可以实现 `struct` 的所有功能，`C++` 为了兼容 `C` 语言保留了 `struct` 关键字。
+ `C` 语言中 `struct` 没有访问权限的设置，是一些变量的集合体，不能定义成员函数；`C++` 中 `struct` 可以和类一样，有访问权限，并可以定义成员函数。
+ `C` 语言中 `struct` 定义的自定义数据类型，在定义该类型的变量时，需要加上 `struct` 关键字，例如：`struct A var;`，定义 `A` 类型的变量；而 `C++` 中，不用加该关键字，例如：`A var`。
+ `C++` 中 `struct` 可以继承，也可以实现多态，而 `C` 语言中不支持继承和多态。

参考资料：

+ [【C++】struct和class的区别](https://zhuanlan.zhihu.com/p/47808468)

## struct 和 union 的区别
+ `union` 是联合体，`struct` 是结构体。`union` 中的所有成员变量共享同一段内存空间，`struct` 中的每个成员变量独占内存空间。
+ 联合体和结构体都是由若干个数据类型不同的数据成员组成。使用时，联合体只有一个有效的成员；而结构体所有的成员都有效。
+ 对联合体的不同成员赋值，将会对覆盖其他成员的值，而对于结构体的对不同成员赋值时，相互不影响。
+ 联合体的大小为其内部所有变量的最大值，按照最大类型的倍数进行分配大小；结构体分配内存的大小遵循内存对齐原则。
+ `struct` 可以定义变长数组成员变量 `int a[]`，`union` 中不能包含有这种不确定长度的变量。
  以下为示例程序:

```C++ []
#include <iostream>
using namespace std;

typedef union
{
    char c[10];
    char cc1; // char 1 字节，按该类型的倍数分配大小
} u11;

typedef union
{
    char c[10];
    int i; // int 4 字节，按该类型的倍数分配大小
} u22;

typedef union
{
    char c[10];
    double d; // double 8 字节，按该类型的倍数分配大小
} u33;

typedef struct s1
{
    char c;   // 1 字节
    double d; // 1（char）+ 7（内存对齐）+ 8（double）= 16 字节
} s11;

typedef struct s2
{
    char c;   // 1 字节
    char cc;  // 1（char）+ 1（char）= 2 字节
    double d; // 2 + 6（内存对齐）+ 8（double）= 16 字节
} s22;

typedef struct s3
{
    char c;   // 1 字节
    double d; // 1（char）+ 7（内存对齐）+ 8（double）= 16 字节
    char cc;  // 16 + 1（char）+ 7（内存对齐）= 24 字节
} s33;

int main()
{
    cout << sizeof(u11) << endl; // 10
    cout << sizeof(u22) << endl; // 12
    cout << sizeof(u33) << endl; // 16
    cout << sizeof(s11) << endl; // 16
    cout << sizeof(s22) << endl; // 16
    cout << sizeof(s33) << endl; // 24

    cout << sizeof(int) << endl;    // 4
    cout << sizeof(double) << endl; // 8
    return 0;
}
```

参考资料：

+ [Difference between Structure and Union in C](https://www.***.org/difference-structure-union-c/)
+ [Difference Between Structure and Union in C](https://www.guru99.com/difference-structure-union-c.html)
+ [Understanding the Difference Between Structure and Union in C](https://www.naukri.com/learning/articles/difference-between-structure-and-union-in-c/)

## extern C 的作用
`C` 和 `C++` 对同一个函数经过编译后生成的函数名是不同的，由于 `C++` 支持函数重载，因此编译器编译函数的过程中会将函数的参数类型也加到编译后的函数名中，而不仅仅是原始的函数名。比如以下函数，同一个函数 `test` 在 `C++` 编译后符号表中生成的函数名可能为 `_Z4testv`，而 `C` 编译后符号表中生成的函数名可能为 `test`。
比如同一个函数:

```C++ []
int test() {
    return 0;
}
```

+ 由于 `C` 语言并不支持函数重载，在 `C` 语言中函数不能重名，因此编译 `C` 语言代码的函数时不会带上函数的参数类型，一般只包括函数名。如果在 `C++` 中调用一个使用 `C` 语言编写的模块中的某个函数 `test`，`C++` 是根据 `C++` 的函数名称修饰方式来查找并链接这个函数，去在生成的符号表查找 `_Z4testv` 这个函数的代码，此时就会发生链接错误。而此时我们用 `extern C` 声明，那么在链接时，`C++` 编译器则按照 `C` 语言的函数命名规则 `test` 去符号表中查找对应的函数。因此当 `C++` 程序需要调用 `C` 语言编写的函数，`C++` 使用链接指示，即 `extern "C"` 指出任意非 `C++` 函数所用的语言。

```C++ []
// 可能出现在 C++ 头文件<cstring>中的链接指示
extern "C"{
    int strcmp(const char*, const char*);
}
```

参考资料：

+ [extern (C++)](https://docs.microsoft.com/en-us/cpp/cpp/extern-cpp?view=msvc-170)

## strcpy 函数的缺陷
1. `strcpy` 函数的实现:
   `strcpy` 是 `C++` 语言的一个标准函数 ，`strcpy` 把含有 `'\0'` 结束符的字符串复制到另一个地址空间，返回值的类型为 `char*`，返回值为拷贝后的字符串的首地址。

```C++ []
char * strcpy(char * strDest,const char * strSrc) {
    if ((NULL==strDest) || (NULL==strSrc)) 
    throw "Invalid argument(s)"; 
    char * strDestCopy = strDest; 
    while ((*strDest++=*strSrc++)!='\0'); 
    return strDestCopy;
}
```

2. `strcpy` 函数的缺陷：`strcpy` 函数不检查目的缓冲区的大小边界，而是将源字符串逐一的全部赋值给目的字符串地址起始的一块连续的内存空间，同时加上字符串终止符，会导致其他变量被覆盖。

```C++ []
#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    int var = 0x11112222;
    char arr[10];
    cout << "Address : var " << &var << endl;
    cout << "Address : arr " << &arr << endl;
    strcpy(arr, "hello world!");
    cout << "var:" << hex << var << endl; // 将变量 var 以 16 进制输出
    cout << "arr:" << arr << endl;
    return 0;
}

/*
Address : var 0x23fe4c
Address : arr 0x23fe42
var:11002164
arr:hello world!
*/
```

说明：从上述代码中可以看出，变量 `var` 的后六位被字符串 `"hello world!"` 的 `"d!\0"` 这三个字符改变，这三个字符对应的 `ascii` 码的十六进制为：`\0(0x00)，!(0x21)，d(0x64)`。
原因：变量 `arr` 只分配的 `10` 个内存空间，通过上述程序中的地址可以看出 `arr` 和 `var` 在内存中是连续存放的，但是在调用 `strcpy` 函数进行拷贝时，源字符串 `"hello world!"` 所占的内存空间为 `13`，因此在拷贝的过程中会占用 `var` 的内存空间，导致 `var` 的后六位被覆盖。由于 `strcpy` 函数存在一定的安全风险，如果使用不当容易出现安全问题，利用 `strcpy` 的特性可以编写 `shellcode` 来进行缓冲区溢出攻击。在大多数工程代码中，为了保证代码的健壮性和安全性，一般会使用 `strncpy` 代替 `strcpy`。

参考资料：

+ [strcpy in C/C++](https://www.***.org/strcpy-in-c-cpp/)
+ [strcpy](https://cplusplus.com/reference/cstring/strcpy/)

## lambda 表达式的应用
`lambda` 表达式，又被称为 `lambda` 函数或者 `lambda` 匿名函数。
`lambda` 匿名函数的定义:

```C++ []
[capture list] (parameter list) -> return type
{
function body;
};
```

其中：

+ `capture list`：捕获列表，指 `lambda` 所在函数中定义的局部变量的列表。定义在与 `lambda` 函数相同作用域的参数引用也可以被使用，一般被称作 `closure`（闭包），以下为闭包的常见用法。

```C++ []
[]      // 没有定义任何变量。使用未定义变量会引发错误。
[x, &y] // x以传值方式传入（默认），y以引用方式传入。
[&]     // 任何被使用到的外部变量都隐式地以引用方式加以引用。
[=]     // 任何被使用到的外部变量都隐式地以传值方式加以引用。
[&, x]  // x显式地以传值方式加以引用。其余变量以引用方式加以引用。
[=, &z] // z显式地以引用方式加以引用。其余变量以传值方式加以引用。
```

比如下面以引用的方式调用 `a`：

```C++ []
int main()
{
    int a = 10;
    auto f = [&a](int x)-> int {
        a = 20;
        return a + x;
    };
    cout<<a<<endl; // 10
    cout<<f(10)<<endl; // 30
    cout<<a<<endl; // 20
    return 0;
}
```

+ `return type`、`parameter list`、`function body`：分别表示返回值类型、参数列表、函数体，和普通函数一样。
  举例：

```C++ []
#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int arr[4] = {4, 2, 3, 1};
    //对 a 数组中的元素进行升序排序
    sort(arr, arr + 4, [=](int x, int y) -> bool{ return x < y; } );
    auto f = [&](int x)-> int {
        return arr[0] + x;
    }

    for(int n : arr){
        cout << n << " ";
    }
    return 0;
}
```

+ 需要注意的是 `lambda` 函数按照值方式捕获的环境中的变量，在 `lambda` 函数内部是不能修改的，否则编译器会报错。其值是 `lambda` 函数定义时捕获的值，不再改变。如果在 `lambda` 函数定义时加上 `mutable` 关键字，则该捕获的传值变量在 `lambda` 函数内部是可以修改的，对同一个 `lambda` 函数的随后调用也会累加影响该捕获的传值变量，但对外部被捕获的那个变量本身无影响。

```C++ []
#include <iostream> 
using namespace std;
int main()
{
	size_t t = 9;
	auto f = [t]() mutable{
		t++;
		return t; 
	};
	cout << f() << endl; // 10
	t = 100;
	cout << f() << endl; // 11
	cout << "t:" << t << endl; // t: 100
	return 0;
}
```

+ 引用捕获可能带来悬挂引用常见于使用 `lambda` 表达式使用引用捕获某个局部变量，而调用 `lambda` 表达式时，局部变量已经被清理导致捕获的引用指向被清理的内存空间，从而产生悬挂引用。比如下面程序实例中，当 `GetFunc` 返回时，`s` 的对象已经被销毁，此时 `s` 的引用则会出现问题，应将其修改为值传递。

```C++ []
#include <iostream>
#include <cstring>
#include <functional>

auto GetFunc(){
    std::string s = "112234234234";
    return [&](){ std::cout << s << std::endl; };
}

int main(int, char*[]){
    auto func = GetFunc();
    func();
    return 0;
}
```

+ 在 `C++ 14` 以后，`lambda` 函数的形式参数允许泛型和初始化捕获。
  返回值和参数均使用泛型，编译器会根据实际进行类型推导。

```C++ []
auto lambda = [](auto x, auto y) {return x + y;}
lambda(1, 2);
lambda(1.0, 2.0);
```

允许在 `lambda` 捕获列表中对变量进行表达式赋值，并且支持定义新的变量并进行初始化。

```C++ []
auto lambda = [value = 1] {return value;}
```

+ `C++ 17` 以后，`lambda` 函数也支持使用用 `constexpr` 修饰，此时 `lambda` 函数内部应当满足 `constexpr` 的要求。

```C++ []
int y = 32;
auto answer = [y]() constexpr
{
    int x = 10;
    return y + x;
};

constexpr int Increment(int n)
{
    return [n] { return n + 1; }();
}
```


参考资料：

+ [C++11](https://zh.wikipedia.org/wiki/C%2B%2B11)
+ [Lambda expressions (since C++11)](https://en.cppreference.com/w/cpp/language/lambda)
+ [Lambda expressions in C++](https://docs.microsoft.com/en-us/cpp/cpp/lambda-expressions-in-cpp?view=msvc-170)
+ [What is a lambda expression in C++11?](https://stackoverflow.com/questions/7627098/what-is-a-lambda-expression-in-c11)

## explicit 的作用
用来声明类构造函数是显式调用的，而非隐式调用，可以阻止调用构造函数时进行隐式转换和赋值初始化。只可用于修饰单参构造函数，因为无参构造函数和多参构造函数本身就是显示调用的，再加上 `explicit` 关键字也没有什么意义。

隐式转换：

```C++
#include <iostream>
#include <cstring>
using namespace std;

class A
{
public:
    int var;
    A(int tmp)
    {
        var = tmp;
    }
};
int main()
{
    A ex = 10; // 发生了隐式转换
    return 0;
}
```

上述代码中，`A ex = 10`; 在编译时，进行了隐式转换，将 `10` 转换成 `A` 类型的对象，然后将该对象赋值给 `ex`，等同于如下操作：

```C++ []
A ex1(10);
A ex = ex1;
```

为了避免隐式转换，可用 `explicit` 关键字进行声明：

```C++ []
#include <iostream>
#include <cstring>
using namespace std;

class A
{
public:
    int var;
    explicit A(int tmp)
    {
        var = tmp;
        cout << var << endl;
    }
};
int main()
{
    A ex(100);
    A ex1 = 10; // error: conversion from 'int' to non-scalar type 'A' requested
    return 0;
}
```

+ 在日常使用时一般情况下建议声明 `explicit` 的构造函数，从而可以阻止编译器执行非预期 (往往也不被期望) 的类型转换，因为某些非预期的类型转换可能会引起意向不到的错误。


参考资料：

+ [C++ explicit 关键字](https://zhuanlan.zhihu.com/p/52152355)
+ [What does the explicit keyword mean?](https://stackoverflow.com/questions/121162/what-does-the-explicit-keyword-mean)
+ [explicit specifier](https://en.cppreference.com/w/cpp/language/explicit)

## define 和 typedef 的区别
二者之间的区别:

+ `#define` 作为预处理指令，在编译预处理时进行替换操作，不作正确性检查，只有在编译已被展开的源程序时才会发现可能的错误并报错。`typedef` 是关键字，在编译时处理，有类型检查功能，用来给一个已经存在的类型一个别名，但不能在一个函数定义里面使用 `typedef` 。
+ `typedef` 用来定义类型的别名，方便使用。`#define` 不仅可以为类型取别名，还可以定义常量、变量、编译开关等。
+ `#define` 没有作用域的限制，只要是之前预定义过的宏，在以后的程序中都可以使用，如果在 `.cpp` 文件中定义了宏，则在整个文件中都可以使用该宏，如果在 `.h` 文件中定义了宏，则只要包含该头文件都可以使用；而 `typedef` 有自己的作用域，如果在函数之外定义了类型，则在整个文件中都可以使用该类型定义，如果在函数内部定义了该类型，则只能在函数内部使用该类型。
+ 指针的操作：`typedef` 和 `#define` 在处理指针时不完全一样。比如以下程序：

```C++ []
#include <stdio.h>
typedef char* ptr;
#define PTR char*
int main()
{
	ptr a, b, c;
	PTR x, y, z;
	printf("sizeof a:%zu\n" ,sizeof(a) );
	printf("sizeof b:%zu\n" ,sizeof(b) );
	printf("sizeof c:%zu\n" ,sizeof(c) );
	printf("sizeof x:%zu\n" ,sizeof(x) );
	printf("sizeof y:%zu\n" ,sizeof(y) );
	printf("sizeof z:%zu\n" ,sizeof(z) );
	return 0;
}
```

输出为:

```C++ []
sizeof a:8
sizeof b:8
sizeof c:8
sizeof x:8
sizeof y:1
sizeof z:1
```

由于在处理，`typedef` 定义了新的类型，因此变量 `a, b, c` 都属于指针类型，而 `#define` 只是做了简单的替换，被替换为语句 `char *x, y, z` 实际 `x,y` 为 `char` 类型。

参考资料：

+ [typedef versus #define in C](https://www.***.org/typedef-versus-define-c/)
+ [Difference between typedef and define in C](https://www.javatpoint.com/typedef-vs-define-in-c)

## inline 函数工作原理
1. 内联函数的工作原理：

+ 内联函数不是在调用时发生控制转移关系，而是在编译阶段将函数体嵌入到每一个调用该函数的语句块中，编译器会将程序中出现内联函数的调用表达式用内联函数的函数体来替换。函数调用时，需要切换栈帧寄存器，同时栈中压入参数、返回值，然后进行跳转，这些都需要开销，而内联函数则可以不要这些开销，直接将内联函数中函数体直接插入或者替换到该函数调用点。
+ 普通函数是将程序执行转移到被调用函数所存放的内存地址，当函数执行完后，返回到执行此函数前的地方。转移操作需要保护现场，被调函数执行完后，再恢复现场，该过程需要较大的资源开销。
+ 虽然内联函数在调用时直接进行展开，但实际在编译后代码中存在内联函数的定义，可以供编译器进行调用。普通函数可以有指向它的函数指针，内敛函数也可以有指向它的函数指针。

2. 内联函数的优缺点:

+ 内联函数具有以下优点：
  + 不会产生函数调用开销。节省了调用函数时在堆栈上推送/弹出变量的开销。节省了函数返回调用的开销。当你内联一个函数时，你可以让编译器对函数体执行上下文特定的优化，其他优化可以通过考虑调用上下文和被调用上下文的流程来获得，而对于普通函数不会有这种优化。
+ 内联函数的缺点：
  + 从内联函数中添加的变量会消耗额外的寄存器，在内联函数之后，如果要使用寄存器的变量数量增加，则可能会在寄存器变量资源利用方面产生开销。在函数调用点替换内联函数体时，函数使用的变量总数也会增加，用于存储变量的寄存器数量也会增加。因此，如果在函数内联变量数量急剧增加之后，它肯定会导致寄存器利用率的开销。
  + 如果你使用太多的内联函数，那么二进制可执行文件的大小会很大，因为相同的代码重复。
  + 过多的内联也会降低指令缓存命中率，从而降低从缓存内存到主内存的指令获取速度。
  + 如果有人更改内联函数内的代码，内联函数可能会增加编译时间开销，那么所有调用位置都必须重新编译，因为编译器需要再次替换所有代码，否则它将继续使用旧功能.
  + 内联函数可能会导致抖动，因为内联可能会增加二进制可执行文件的大小。内存抖动会导致计算机性能下降。

3. `inline` 函数的使用场景：
   内联函数一般只适用于比较短小，处理较为简单的函数。内联只是对编译器的请求，而不是命令。编译器可以忽略内联请求。编译器可能不会在以下情况下执行内联：

+ 如果函数包含循环（`for, while, do-while`）；
+ 如果一个函数包含静态变量；
+ 如果一个函数是递归的；
+ 如果函数返回类型不是 `void`，并且函数体中不存在 `return` 语句；
+ 如果函数包含 `switch` 或 `goto` 语句；

4. 内联可以去除函数只能定义一次的限制：
   内联函数可以在程序中定义不止一次， 但是 `inline` 函数的定义在某个源文件中只能出现一次，而且在所有源文件中，其定义必须是完全相同的。一般情况下，我们可以在头文件中定义 `inline` 函数，所有 `include` 该头文件，如果修改了头文件中的 `inline` 函数时，使用了该头文件的所有源文件都必须重新编译。比如我们可以在定义以下两个文件包含相同的函数。

```C++ []
// b.cpp
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

inline int min(int a, int b) {
    return a + b;
}

// a.cpp
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

inline int min(int a, int b) {
    return a + b;
}

int main() {
    int a = 10, b = 9;
    min(a, b);
    return 0;
}
```

参考资料：

+ [Inline Functions in C++](https://www.***.org/inline-functions-cpp/?ref=gcse)
+ [Inline function](https://en.wikipedia.org/wiki/Inline_function)

## class 和 struct 的异同
`C++` 中为了兼容 `C` 语言而保留了 `C` 语言的 `struct` 关键字，并且加以扩充。在 `C` 语言中，`struct` 只能包含成员变量，不能包含成员函数。而在 `C++` 中，`struct` 类似于 `class`，既可以包含成员变量，又可以包含成员函数。
`C++` 中的 `struct` 和 `class` 基本是通用的，唯有几个细节不同：

+ `class` 中类中的成员默认都是 `private` 属性的；而在 `struct` 中结构体中的成员默认都是 `public` 属性的。
+ `class` 继承默认是 `private` 继承，而 `struct` 继承默认是 `public` 继承。
+ `class` 可以用于定义模板参数，`struct` 不能用于定义模板参数。

```C++ []
struct A{}；
class B : A{}; // private 继承 
struct C : B{}； // public 继承
```

举例：

```C++ []
#include<iostream>

using namespace std;

class A{
public:
    void funA(){
        cout << "class A" << endl;
    }
};

struct B: A{ // 由于 B 是 struct，A 的默认继承级别为 public
public:
    void funB(){
        cout << "class B" << endl;
    }
};

class C: B{ // 由于 C 是 class，B 的默认继承级别为 private，所以无法访问基类 B 中的 printB 函数

};

int main(){
    A ex1;
    ex1.funA(); // class A

    B ex2;
    ex2.funA(); // class A
    ex2.funB(); // class B

    C ex3;
    ex3.funB(); // error: 'B' is not an accessible base of 'C'.
    return 0;
}
```

参考资料：

+ [Inline Functions in C++](https://www.ibm.com/docs/en/zos/2.3.0?topic=only-classes-structures-c)
+ [Difference between Structure and Class in C++](https://www.javatpoint.com/structure-vs-class-in-cpp)

## 返回函数中静态变量的地址会发生什么
```C++ []
#include <iostream>
using namespace std;

int * fun(int tmp){
    static int var = 10;
    var *= tmp;
    return &var;
}

int main() {
    cout << *fun(5) << endl;
    return 0;
}

/*
运行结果：
50
*/
```

+ 前面的章节中讲过，静态局部变量存在静态区，程序初始化时则已经创建了改变量，变量的生存周期为整个程序的生命周期。上述代码中在函数 `fun` 中定义了静态局部变量 `var`，使得离开该函数的作用域后，该变量不会销毁，返回到主函数中，该变量依然存在，从而使程序得到正确的运行结果，该静态局部变量直到程序运行结束后才销毁。
+ 需要注意的是，全局静态对象在程序初始化时，则进行了初始化。局部静态对象的初始化在第一次进入函数内部时，才会调用对象的构造函数进行初始化。程序退出时，先释放静态局部变量，再释放全局静态变量。


参考资料：

+ [线程安全：局部静态变量的初始化](https://baijiahao.baidu.com/s?id=1686962192046161801&wfr=spider&for=pc)
+ [static初始化](https://zhuanlan.zhihu.com/p/406301228)

## sizeof(1==1) 在 C 和 C++ 中的结果
前面的章节中讲述过 `sizeof` 接受的参数可以是对象也可以是表达式，但是 `sizeof(expression)` 在运行时不会对接受的表达式进行计算，编译器只会推导表达式的类型从而计算占用的字节大小； 

```C++ []
#include <iostream>
using namespace std;
int main(int argc, char * argv[])
{
    int x = 4;
    sizeof(x++);
    printf("%d\n", x);
    return 0;
}
```

+ 由于 `C` 语言没有 `bool` 类型，用整形表示布尔型，因此下面的程序返回 `4`;

```C []
#include<stdio.h>

void main(){
    printf("%d\n", sizeof(1==1));
}

/*
运行结果：
4
*/
```

+ 由于 `C++` 语言有 `bool` 类型，布尔型占 `1` 个字节，因此下面的程序返回 `1`;

```C++ []
#include <iostream>
using namespace std;

int main() {
    cout << sizeof(1==1) << endl;
    return 0;
}

/*
1
*/
```

参考资料：

+ [sizeof operator in C](https://www.***.org/sizeof-operator-c/)

## memmove 函数的底层原理
+ `memmove` 用于拷贝字节，如果目标区域和源区域有重叠的话，`memmove` 能够保证源串在被覆盖之前将重叠区域的字节拷贝到目标区域中，但复制后源内容会被更改。但是当目标区域与源区域没有重叠则和 `memcpy` 函数功能相同。面试时会经常要求实现 `memmove` 函数，在实现的时候需要特殊处理地址重叠的情况。

```C++ []
void *memmove(void *dst, const void *src, size_t size)
{
    char *psrc;
    char *pdst;

    if (NULL == dst || NULL == src)
    {
        return NULL;
    }

    if ((src < dst) && (char *)src + size > (char *)dst) // 出现地址重叠的情况，自后向前拷贝
    {
        psrc = (char *)src + size - 1;
        pdst = (char *)dst + size - 1;
        while (size--)
        {
            *pdst-- = *psrc--;
        }
    }
    else
    {
        psrc = (char *)src;
        pdst = (char *)dst;
        while (size--)
        {
            *pdst++ = *psrc++;
        }
    }

    return dst;
}
```

参考资料：

+ [memmove() in C/C++](https://www.***.org/memmove-in-cc/?ref=gcse)

## auto 类型推导的原理
`auto` 是 `C++` 语言的关键字。`C++11` 规定，`auto` 关键字用于两种情况：

+ 声明变量时根据初始化表达式自动推断该变量的类型；
+ 声明函数时函数返回值的占位符；
  `auto` 声明变量时，根据初始化的表达式来推导该变量的类型，此时变量必须进行初始化。使用 `auto` 类型可以使变量定义变得更为简单，程序结构更为清晰一些，比如以下程序示例：

```C++ []
std::vector<int> vect; 
for(auto it = vect.begin(); it != vect.end(); ++it)
{  //it的类型是std::vector<int>::iterator
    std::cin >> *it;
}
auto ptr = [](double x){return x*x;};//类型为std::function<double(double)>函数对象
```

使用 `auto` 关键字做类型自动推导时，依次施加以下规则：

+ 首先，如果初始化表达式是引用，首先去除引用，如果 `auto` 类型关键字带上 `&` 则不进行去除；
  以下程序程序示例中可以看到 `myAuto` 是一个 `int`，而不是引用 `int`。

```C++ []
#include <iostream>

using namespace std;

int main( )
{
    int count = 10;
    int& countRef = count;
    auto myAuto = countRef;

    countRef = 11;
    cout << count << " ";

    myAuto = 12;
    cout << count << endl;
}
// 11
// 11
```

+ 其次，去掉剩下的初始化表达式顶层的 `const` 或 `volatile` 限定符。
+ `C++ 14` 以后如果用 `{}` 来进行赋值，此时 `auto` 类型推导出的类型为 `std::initializer_list`；而模板函数的形参推导时不认为这种值列表是一个类型，此时则不能推导出 `std::initializer_list` 类型。

```C++ []
#include <initializer_list>
int main()
{
    // A 的类型: std::initializer_list<int>
    auto A = { 1, 2 };
    // B 的类型: std::initializer_list<int>
    auto B = { 3 };
    // C 的类型: int
    auto C{ 4 };
    return 0;
}
```

+ `auto` 关键字的类型完美转发：
  `C++11` 使用 `auto` 声明变量时，如：`auto&& var=initValue;`，则此时 `“auto&&”` 并不意味着这一定是右值引用类型的变量，而是类似于模板函数参数的类型推导，既可能是左值引用，也可能是右值引用。其目的是把初始化表达式的值分类情况，完美转发给由 `auto` 声明的变量。也即：
  + 如果初始化值是类型 `A` 的左值，则声明的变量类型为左值引用 `A&`；
  + 如果初始化值是类型 `A` 的右值，则声明的变量类型为右值引用 `A&&`。

```C++ []
#include<iostream>  
#include <vector>
#include <typeinfo>
using namespace std;
 
struct Widget{};
Widget makeWidget(){ return Widget(); } // 类工厂函数

int main()
{
	Widget&& var1 = Widget(); // var1的类型是右值引用，但是作为左值
	auto&& var2 = var1;       //var2的类型是左值引用
	std::vector<int> v = { 1, 2, 3 };
	auto&& val = v[0]; // std::vector::operator[]的返回值是元素左值，所以val的类型是左值引用
	Widget&& var3 = makeWidget(); // var3是左值，但它的类型是右值引用 
	Widget var4 = static_cast<Widget&&>(var1); // var4是左值，但它的类型是右值引用

	std::cout << typeid(var1).name() << std::endl;
	std::cout << typeid(var2).name() << std::endl;
	std::cout << typeid(val).name() << std::endl;
	std::cout << typeid(var3).name()  << std::endl;
	std::cout << typeid(var4).name() << std::endl;
}
```

参考资料：

+ [auto (C++)](https://zh.m.wikipedia.org/zh-hans/Auto_(C%2B%2B))
+ [auto (C++)](https://docs.microsoft.com/zh-cn/cpp/cpp/auto-cpp?view=msvc-170)

## new 的作用
1. `new` 的简介：
   `new` 是 `C++` 中的关键字，尝试分配和初始化指定或占位符类型的对象或对象数组，并返回指向对象 (或数组的初始对象) 的指针。

+ 用 `new` 创建对象时，首先从堆中申请相应的内存空间，然后调用对象的构造函数，最后返回指向对象的指针。`new` 操作符从自由存储区（`free store`）上为对象动态分配内存空间，而 `malloc` 函数从堆上动态分配内存。自由存储区是 `C++` 基于 `new` 操作符的一个抽象概念，凡是通过 `new` 操作符进行内存申请，该内存即为自由存储区。而堆是操作系统中的术语，是操作系统所维护的一块特殊内存，用于程序的内存动态分配，`C` 语言使用 `malloc` 从堆上分配内存，使用 `free` 释放已分配的对应内存。`new` 可以指定在内存地址空间创建对象，用法如下:

```C++ []
new (place_address) type
```

`place_address` 为一个指针，代表一块内存的地址。当使用上面这种仅以一个地址调用 `new` 操作符时，`new` 操作符调用特殊的 `operator new`：

```C++ []
void * operator new (size_t, void *) 
```

对于指定的地址的 `new` 对象，在释放时，不能直接调用 `delete`, 应该先调用对象的析构函数，然后再对内存进行释放。比如以下程序:

```C++ []
include <iostream>
using namespace std;

int main(int argc, char* argv[])
{
    char buf[100];
    int *p=new (buf) int(101);
    cout<<*(int*)buf<<endl;
    return 0;
}
```

+ `new` 可以用来动态生成对象数组，但此时 `new` 生成的数组，只能用 `delete` 来释放。

```C++ []
int *arr = new int [100];
```

+ 在 `cpp` 中由于 `new` 作为操作符可以进行重载，所以可以对 `new` 进行重载，比如可以指定构造函数对对象进行初始化。对 `new` 操作符可以进行全局重载和局部重载，全局重载后，所有调用 `new` 的操作都会被重写；局部重载就是在类中重写 `operator new` 函数，但只会对该类生效，即该类执行 `new` 操作时会生效。

```C++ []
#include <iostream>

class Test {
private:
    int value;

public:
    Test() {
        printf("[Test] Constructor\n");
    }

    void* operator new(size_t size) {
        printf("[Test] operator new\n");
        return NULL;
    }
};

int main() 
{ 
    Test* t = new Test();
    return 0;
}

// [Test] operator new
// [Test] Constructor
```


参考资料：

+ [new (C++)](https://zh.m.wikipedia.org/zh/New_(C%2B%2B))
+ [C++ new的三种面貌](https://cloud.tencent.com/developer/article/1177460)
+ [new 运算符 (C++)](https://docs.microsoft.com/zh-cn/cpp/cpp/new-operator-cpp?view=msvc-170)


# C++ 面向对象
本章将重点涉及以下高频知识点：

## 面向对象及其三大特性
+ 面向对象：对象是指具体的某一个事物，这些事物的抽象就是类，类中包含数据（成员变量）和动作（成员方法）。
+ 面向对象的三大特性：
  - 封装：将具体的实现过程和数据封装成一个函数，只能通过接口进行访问，降低耦合性。
  - 继承：子类继承父类的特征和行为，子类有父类的非 `private` 方法或成员变量，子类可以对父类的方法进行重写，增强了类之间的耦合性，但是当父类中的成员变量、成员函数或者类本身被 `final` 关键字修饰时，修饰的类不能继承，修饰的成员不能重写或修改。
  - 多态：多态就是不同继承类的对象，对同一消息做出不同的响应，基类的指针指向或绑定到派生类的对象，使得基类指针呈现不同的表现方式。在 `C++` 中多态一般是使用虚函数来实现的，使用基类指针调用函数方法时，如果该指针指向的是一个基类的对象，则调用的是基类的虚函数；如果该指针指向的是一个派生类的对象，则调用的是派生类的虚函数。


参考资料：

+ [C++多态的实现原理](https://zhuanlan.zhihu.com/p/65410057)
+ [C++ What is OOP?](https://www.w3schools.com/cpp/cpp_oop.asp)
+ [Object Oriented Programming in C++](https://www.***.org/object-oriented-programming-in-cpp/)

## 重载、重写、隐藏的区别
1. 函数重载:
   重载是指同一可访问区内被声明几个具有不同参数列（参数的类型、个数、顺序）的同名函数，根据参数列表确定调用哪个函数，重载不关心函数返回类型。

```C++ []
class A
{
public:
    void fun(int tmp);
    void fun(float tmp);        // 重载 参数类型不同（相对于上一个函数）
    void fun(int tmp, float tmp1); // 重载 参数个数不同（相对于上一个函数）
    void fun(float tmp, int tmp1); // 重载 参数顺序不同（相对于上一个函数）
    int fun(int tmp);            // error: 'int A::fun(int)' cannot be overloaded 错误：注意重载不关心函数返回类型
};
```

2. 函数隐藏：
   函数隐藏是指派生类的函数屏蔽了与其同名的基类函数，只要是与基类同名的成员函数，不管参数列表是否相同，基类函数都会被隐藏。

```C++ []
#include <iostream>
using namespace std;

class Base
{
public:
    void fun(int tmp, float tmp1) { cout << "Base::fun(int tmp, float tmp1)" << endl; }
};

class Derive : public Base
{
public:
    void fun(int tmp) { cout << "Derive::fun(int tmp)" << endl; } // 隐藏基类中的同名函数
};

int main()
{
    Derive ex;
    ex.fun(1);       // Derive::fun(int tmp)
    ex.fun(1, 0.01); // error: candidate expects 1 argument, 2 provided
    return 0;
}
```

说明: 上述代码中 `ex.fun(1, 0.01);` 出现错误，说明派生类中将基类的同名函数隐藏了。若是想调用基类中的同名函数，可以加上类型名指明 `ex.Base::fun(1, 0.01);`，这样就可以调用基类中的同名函数。

3. 函数重写（覆盖）：
   函数覆盖是指派生类中存在重新定义的函数。函数名、参数列表、返回值类型都必须同基类中被重写的函数一致，只有函数体不同。派生类调用时会调用派生类的重写函数，不会调用被重写函数。重写的基类中被重写的函数必须有 `virtual` 修饰。

```C++ []
#include <iostream>
using namespace std;

class Base
{
public:
    virtual void fun(int tmp) { cout << "Base::fun(int tmp) : " << tmp << endl; }
};

class Derived : public Base
{
public:
    virtual void fun(int tmp) { cout << "Derived::fun(int tmp) : " << tmp << endl; } // 重写基类中的 fun 函数
};
int main()
{
    Base *p = new Derived();
    p->fun(3); // Derived::fun(int) : 3
    return 0;
}
```

4. 重写和重载的区别：

+ 范围区别：对于类中函数的重载或者重写而言，重载发生在同一个类的内部，重写发生在不同的类之间（子类和父类之间）。
+ 参数区别：重载的函数需要与原函数有相同的函数名、不同的参数列表，不关注函数的返回值类型；重写的函数的函数名、参数列表和返回值类型都需要和原函数相同，父类中被重写的函数需要有 `virtual` 修饰。
+ `virtual` 关键字：重写的函数基类中必须有 `virtual` 关键字的修饰，重载的函数可以有 `virtual` 关键字的修饰也可以没有。


5. 隐藏和重写，重载的区别：

+ 范围区别：隐藏与重载范围不同，隐藏发生在不同类中。
+ 参数区别：隐藏函数和被隐藏函数参数列表可以相同，也可以不同，但函数名一定相同；当参数不同时，无论基类中的函数是否被 `virtual` 修饰，基类函数都是被隐藏，而不是重写。
+ 利用重写可以实现多态，而隐藏不可以。如果使用基类指针 `p` 指向派生类对象，利用这个指针调用函数时，对于隐藏的函数，会根据指针的类型去调用函数；对于重写的函数，会根据指针所指对象的类型去调用函数。重写必须使用 `virtual` 关键字，此时会更改派生类虚函数表的表项。
+ 隐藏是发生在编译时，即在编译时由编译器实现隐藏，而重写一般发生运行时，即运行时会查找类的虚函数表，决定调用函数接口。

参考资料：

+ [C++ Programming: Method Overriding Vs. Method Hiding](http://ixodoi.expertscolumn.com/article/c-programming-method-overriding-vs-method-hiding)
+ [C++中的函数隐藏机制](https://blog.csdn.net/niu91/article/details/109485455)
+ [Object Oriented Programming in C++](https://www.***.org/object-oriented-programming-in-cpp/)

## 多态及其实现方法
1. 多态的概念：
   多态就是不同继承类的对象，对同一消息做出不同的响应，基类的指针指向或绑定到派生类的对象，使得基类指针呈现不同的表现方式。在基类的函数前加上 `virtual` 关键字，在派生类中重写该函数，运行时将会根据对象的实际类型来调用相应的函数。如果对象类型是派生类，就调用派生类的函数；如果对象类型是基类，就调用基类的函数。
   程序示例如下:

```C++
#include <iostream>
using namespace std;

class Base
{
public:
	virtual void fun() { cout << "Base::fun()" << endl; }

	virtual void fun1() { cout << "Base::fun1()" << endl; }

	virtual void fun2() { cout << "Base::fun2()" << endl; }
};
class Derive : public Base
{
public:
	void fun() { cout << "Derive::fun()" << endl; }

	virtual void D_fun1() { cout << "Derive::D_fun1()" << endl; }

	virtual void D_fun2() { cout << "Derive::D_fun2()" << endl; }
};
int main()
{
	Base *p = new Derive();
	p->fun(); // Derive::fun() 调用派生类中的虚函数
	return 0;
}
```

2. 多态的实现原理:
   多态是通过虚函数实现的，虚函数的地址保存在虚函数表中，虚函数表的地址保存在含有虚函数的类的实例对象的内存空间中。

+ 在类中用 `virtual` 关键字声明的函数叫做虚函数；
+ 存在虚函数的类都有一个虚函数表，当创建一个该类的对象时，该对象有一个指向虚函数表的虚表指针（虚函数表和类对应的，虚表指针是和对象对应）；
+ 当基类指针指向派生类对象，基类指针调用虚函数时，该基类指针指的虚表指针实际指向派生类虚函数表，通过遍历虚表，寻找相应的虚函数然后调用执行。
  基类的虚函数表如下图所示：
![4_3_1.png](https://pic.leetcode-cn.com/1661223701-LHxbLq-4_3_1.png)
  派生类的对象虚函数表如下：
![4_3_2.png](https://pic.leetcode-cn.com/1661223754-KTbnHb-4_3_2.png)
  简单解释：当基类的指针指向派生类的对象时，通过派生类的对象的虚表指针找到虚函数表（派生类的对象虚函数表），进而找到相应的虚函数 `Derive::f()` 进行调用。

3. 多态的总结:
   根据上述的结论，我们可以知道虚函数的调用是在运行时决定，是由本身所指向的对象所决定的。

+ 如果使用虚函数，基类指针指向派生类对象并调用对象方法时，使用的是子类的方法;
+ 如果未使用虚函数，则是普通的隐藏，则基类指针指向派生类对象时，使用的是基类的方法（与指针类型看齐）
+ 基类指针能指向派生类对象，但是派生类指针不能指向基类对象


参考资料：

+ [C++ Programming: Method Overriding Vs. Method Hiding](http://ixodoi.expertscolumn.com/article/c-programming-method-overriding-vs-method-hiding)
+ [C++中的函数隐藏机制](https://blog.csdn.net/niu91/article/details/109485455)
+ [Object Oriented Programming in C++](https://www.***.org/object-oriented-programming-in-cpp/)

## 虚函数和纯虚函数详解
1. 虚函数：
   被 `virtual` 关键字修饰的成员函数，`C++` 的虚函数在运行时动态绑定，从而实现多态。

```C++ []
#include <iostream>
using namespace std;

class A
{
public:
    virtual void v_fun() // 虚函数
    {
        cout << "A::v_fun()" << endl;
    }
};
class B : public A
{
public:
    void v_fun()
    {
        cout << "B::v_fun()" << endl;
    }
};
int main()
{
    A *p = new B();
    p->v_fun(); // B::v_fun()
    return 0;
}
```


2. 纯虚函数：

+ 纯虚函数在类中声明时，用 `virtual` 关键字修饰且加上 `=0`，且没有函数的具体实现；
+ 含有纯虚函数的类称为抽象类（只要含有纯虚函数这个类就是抽象类），类中只有接口定义，没有具体的实现方法；
+ 继承纯虚函数的派生类，如果没有完全实现基类纯虚函数，依然是抽象类，不能实例化对象。
  对于抽象类需要说明的是:
+ 抽象类对象不能作为函数的参数，不能创建对象，不能作为函数返回类型；
+ 可以声明抽象类指针，可以声明抽象类的引用；
+ 抽象类只能作为基类来使用，其纯虚函数的实现由派生类给出。如果派生类中没有重新定义纯虚函数，而只是继承基类的纯虚函数，则这个派生类仍然还是一个抽象类。如果派生类中给出了基类纯虚函数的实现，则该派生类就不再是抽象类了，它是一个可以建立对象的具体的类。

纯虚函数的作用：含有纯虚函数的基类要求任何派生类都要定义自己的实现方法，以实现多态性。实现了纯虚函数的子类，该纯虚函数在子类中就变成了虚函数。定义纯虚函数是为了实现统一的接口属性，用来规范派生类的接口属性，也即强制要求继承这个类的程序员必须实现这个函数。纯虚函数的意义在于，让所有的类对象（主要是派生类对象）都可以要求实现纯虚函数的属性，在面对对象设计中非常有用的一个特性。


参考资料：

+ [C++ 虚函数、纯虚函数](https://zhuanlan.zhihu.com/p/37331092)
+ [C++胎教：虚函数，虚析构函数，纯虚函数](https://zhuanlan.zhihu.com/p/202551705)
+ [Pure Virtual Destructor in C++](https://www.***.org/pure-virtual-destructor-c/?ref=gcse)

## 虚函数和纯虚函数的区别
+ 虚函数和纯虚函数可以出现在同一个类中，该类称为抽象基类（含有纯虚函数的类称为抽象基类）。
+ 使用方式不同：虚函数可以直接使用，纯虚函数必须在派生类中实现后才能使用；
+ 定义形式不同：虚函数在定义时在普通函数的基础上加上 `virtual` 关键字，纯虚函数定义时除了加上 `virtual` 关键字还需要加上 `=0`;
+ 虚函数必须实现，否则编译器会报错；
+ 对于实现纯虚函数的派生类，该纯虚函数在派生类中被称为虚函数，虚函数和纯虚函数都可以在派生类中重写；
+ 析构函数最好定义为虚函数，特别是对于含有继承关系的类；析构函数可以定义为纯虚函数，此时，其所在的类为抽象基类，不能创建实例化对象。


参考资料：

+ [C++ 虚函数和纯虚函数的区别](https://www.runoob.com/w3cnote/cpp-virtual-functions.html)
+ [Pure Virtual Destructor in C++](https://www.***.org/pure-virtual-destructor-c/?ref=gcse)

## 虚函数的实现机制
1. 虚函数的实现原理:
   实现机制：虚函数通过虚函数表来实现。虚函数的地址保存在虚函数表中，在类的对象所在的内存空间中，保存了指向虚函数表的指针（称为“虚表指针”），通过虚表指针可以找到类对应的虚函数表。虚函数表解决了基类和派生类的继承问题和类中成员函数的覆盖问题，当用基类的指针来操作一个派生类的时候，这张虚函数表就指明了实际应该调用的函数。

+ 每个使用虚函数的类（或者从使用虚函数的类派生）都有自己的虚函数表。该表是编译器在编译时设置的静态数组，一般我们称为 `vtable`。虚函数表包含可由该类调用的虚函数，此表中的每个条目是一个函数指针，指向该类可访问的虚函数。
+ 每个对象在创建时，编译器会为对象生成一个指向该类的虚函数表的指针，我们称之为 `vptr`。`vptr` 在创建类实例时自动设置，以便指向该类的虚拟表。如果对象（或者父类）中含有虚函数，则编译器一定会为其分配一个 `vptr`；如果对象不包含（父类也不含有），此时编译器则不会为其分配 `vptr`。与 `this` 指针不同，`this` 指针实际上是编译器用来解析自引用的函数参数，`vptr` 是一个真正的指针。

虚函数表相关知识点：

+ 虚函数表存放的内容：类的虚函数的地址。
+ 虚函数表建立的时间：编译阶段，即程序的编译过程中会将虚函数的地址放在虚函数表中。
+ 虚表指针保存的位置：虚表指针存放在对象的内存空间中最前面的位置，这是为了保证正确取到虚函数的偏移量。
+ 虚函数表和类绑定，虚表指针和对象绑定。即类的不同的对象的虚函数表是一样的，但是每个对象在创建时都有自己的虚表指针 `vptr`，来指向类的虚函数表 `vtable`。

实例：
无虚函数覆盖的情况：

```C++ []
#include <iostream>
using namespace std;

class Base
{
public:
    virtual void B_fun1() { cout << "Base::B_fun1()" << endl; }
    virtual void B_fun2() { cout << "Base::B_fun2()" << endl; }
    virtual void B_fun3() { cout << "Base::B_fun3()" << endl; }
};

class Derive : public Base
{
public:
    virtual void D_fun1() { cout << "Derive::D_fun1()" << endl; }
    virtual void D_fun2() { cout << "Derive::D_fun2()" << endl; }
    virtual void D_fun3() { cout << "Derive::D_fun3()" << endl; }
};
int main()
{
    Base *p = new Derive();
    p->B_fun1(); // Base::B_fun1()
    return 0;
}
```

+ 基类和派生类的继承关系：
![4_8_1.png](https://pic.leetcode-cn.com/1661223939-pVNuOM-4_8_1.png)
+ 基类的虚函数表：
![4_3_1.png](https://pic.leetcode-cn.com/1661223950-bjKjYx-4_3_1.png)
+ 派生类的虚函数表：
![4_3_2.png](https://pic.leetcode-cn.com/1661223960-YGKHNe-4_3_2.png)
  主函数中基类的指针 `p` 指向了派生类的对象，当调用函数 `B_fun1()` 时，通过派生类的虚函数表找到该函数的地址，从而完成调用。

2. 虚拟函数表指针 `vptr`:
   带有虚函数的类，通过该类所隐含的虚函数表来实现多态机制，该类的每个对象均具有一个指向本类虚函数表的指针，这一点并非 `C++` 标准所要求的，而是编译器所采用的内部处理方式。实际应用场景下，不同平台、不同编译器厂商所生成的虚表指针在内存中的布局是不同的，有些将虚表指针置于对象内存中的开头处，有些则置于结尾处。如果涉及多重继承和虚继承，情况还将更加复杂。因此永远不要使用 `C` 语言的方式调用 `memcpy()` 之类的函数复制对象，而应该使用初始化（构造和拷构）或赋值的方式来复制对象。
   程序示例，我们通过对象内存的开头处取出 `vptr`，并遍历对象虚函数表。

```C++ []
#include <iostream>
#include <memory>
using namespace std;
 
 
typedef void (*func)(void);

class A {
public:
	void f() { cout << "A::f" << endl; }
	void g() { cout << "A::g" << endl; }
	void h() { cout << "A::h" << endl; }
};

class Base {
public:
	virtual void f() { cout << "Base::f" << endl; }
	virtual void g() { cout << "Base::g" << endl; }
	virtual void h() { cout << "Base::h" << endl; }
};

class Derive: public Base {
public:
	void f() { cout << "Derive::f" << endl; }
    void g() { cout << "Derive::g" << endl; }
	void h() { cout << "Derive::h" << endl; }
};
 
int main() 
{
	Base base;
    Derive derive;
	//获取vptr的地址，运行在gcc  x64环境下，所以将指针按unsigned long *大小处理
    //另外基于C++的编译器应该是保证虚函数表的指针存在于对象实例中最前面的位置
	unsigned long* vPtr = (unsigned long*)(&base);
	//获取vTable 首个函数的地址
	func vTable_f = (func)*(unsigned long*)(*vPtr);
	//获取vTable 第二个函数的地址
	func vTable_g = (func)*((unsigned long*)(*vPtr) + 1);//加1 ，按步进计算
	func vTable_h = (func)*((unsigned long*)(*vPtr) + 2);//同上
	vTable_f();
	vTable_g();
	vTable_h();
    vPtr = (unsigned long*)(&derive);
	//获取vTable 首个函数的地址
	vTable_f = (func)*(unsigned long*)(*vPtr);
	//获取vTable 第二个函数的地址
	vTable_g = (func)*((unsigned long*)(*vPtr) + 1);//加1 ，按步进计算
	vTable_h = (func)*((unsigned long*)(*vPtr) + 2);//同上
	vTable_f();
	vTable_g();
	vTable_h();
    cout<<sizeof(A)<<endl;
    cout<<sizeof(base)<<endl;
    cout<<sizeof(derive)<<endl;
	return 0;
}
/*
Base::f
Base::g
Base::h
Derive::f
Derive::g
Derive::h
1
8
8
*/
```

我们可以看到同样的函数实现，对象在分配空间时，编译器会为对象多分配一个 `vptr` 指针的空间。

3. 虚函数的使用场景:

+ 构造函数不能为虚函数：构造函数不能定义为虚函数。构造函数是在实例化对象的时候进行调用，如果此时将构造函数定义成虚函数，需要通过访问该对象所在的内存空间才能进行虚函数的调用（因为需要通过指向虚函数表的指针调用虚函数表，虽然虚函数表在编译时就有了，但是没有虚函数的指针，虚函数的指针只有在创建了对象才有），但是此时该对象还未创建，便无法进行虚函数的调用。所以构造函数不能定义成虚函数。
+ 析构函数为虚函数：一般建议析构函数定义成虚函数，这样做可以有效是防止内存泄漏，实际应用时当基类的指针或者引用指向或绑定到派生类的对象时，如果未将基类的析构函数定义成虚函数，当我们对基类指针执行 `delete` 操作时，此时只会调用基类的析构函数，将基类的成员所占的空间释放掉，而派生类中特有的资源就会无法释放而导致内存泄漏。
+ `static` 函数不能定义为虚函数。


参考资料：

+ [c++ vptr和vptr_table](https://www.jianshu.com/p/3cccced44b58?u_atoken=e8ede029-5293-407a-9985-526c394f9b8a&u_asession=01bIPvXx9SY5_xBkApG0jxuFquU3CNI8UDsgCDSdHq2i2mjap72ElAso_66tm-TDNZX0KNBwm7Lovlpxjd_P_q4JsKWYrT3W_NKPr8w6oU7K-SQrcSpU2wKWEMjf4_ystnslvTX-jMTLEIhdGFg3rxgWBkFo3NEHBv0PZUm6pbxQU&u_asig=0571xFqT6ytNlYS2FmxKjAUdsqIiXpCEpA3oVT5M8VvEmArNbD__2GdaNqCpJhE6sKEWSbWvLurnKkQM8UDw9dpq1QaT-QMloEqiRNkDTkodMUEoCRvcqQemB454***DsuJ2oQa7hZhyN55PkQ5xaBoj0AhcSH1wl0eqC5j_MoEi39JS7q8ZD7Xtz2Ly-b0kmuyAKRFSVJkkdwVUnyHAIJzYB6zf84piLcxhHyLSCEfChSMikju3ElgVHUh31mnWFE6FPw117USKdEPc8n7HkzU-3h9VXwMyh6PgyDIVSG1W_16QxpFtJKKMbx9Ow-IaNKL6GwjCufiNkuwxPu3TW8Jdu-bki0QJggyafeAwVHEi-9BZd-asvIzjeFlQSnb_AWmWspDxyAEEo4kbsryBKb9Q&u_aref=D9qKzka2hg16cYfkVO8qiMiPKeU%3D)
+ [C++基础——虚指针（vptr）与虚基表（vtable）](https://blog.csdn.net/qq_25065595/article/details/107372446)
+ [C++对象模型3——vptr的位置、手动调用虚函数、从汇编代码看普通调用和多态调用](https://blog.csdn.net/Master_Cui/article/details/114983811)
+ [C++:对象模型：关于vptr（虚指针）和vtbl](https://blog.csdn.net/weixin_43589450/article/details/107393198)
+ [Virtual Function in C++](https://www.***.org/virtual-function-cpp/?ref=gcse)
+ [Polymorphism in C++](https://www.***.org/polymorphism-in-c/)
+ [C++ 虚函数和纯虚函数的区别](https://www.runoob.com/w3cnote/cpp-virtual-functions.html)

## 构造函数、析构函数是否可以定义成虚函数
1. 构造函数一般不定义为虚函数:

+ 从存储空间的角度考虑：构造函数是在实例化对象的时候进行调用，如果此时将构造函数定义成虚函数，需要通过访问该对象所在的内存空间才能进行虚函数的调用（因为需要通过指向虚函数表的指针调用虚函数表，虽然虚函数表在编译时就有了，但是没有虚函数的指针，虚函数的指针只有在创建了对象才有），但是此时该对象还未创建，便无法进行虚函数的调用。所以构造函数不能定义成虚函数。
+ 从使用的角度考虑：虚函数是基类的指针指向派生类的对象时，通过该指针实现对派生类的虚函数的调用，构造函数是在创建对象时自动调用的。
+ 从实现上考虑：虚函数表指针是在创建对象之后才有的，因此不能定义成虚函数。
+ 从类型上考虑：在创建对象时需要明确其类型。

2. 析构函数一般定义成虚函数：
   析构函数定义成虚函数是为了防止内存泄漏，因为当基类的指针或者引用指向或绑定到派生类的对象时，如果未将基类的析构函数定义成虚函数，会调用基类的析构函数，那么只能将基类的成员所占的空间释放掉，派生类中特有的就会无法释放内存空间导致内存泄漏。
   比如以下程序示例:

```C++ []
#include <iostream>

using namespace std;

class A {
private:
    int val;
public:
    ~A() {
        cout<<"A destroy!"<<endl;
    }
};

class B: public  A {
private:
    int *arr;
public:
    B() {
        arr = new int[10];
    }
    ~B() {
        cout<<"B destroy!"<<endl;
        delete arr;
    }
};

int main() {
    A *base = new B();
    delete base;
    return 0;
}
// A destroy!
```

我们可以看到如果析构函数不定义为虚函数，此时执行析构的只有基类，而派生类没有完成析构。我们将析构函数定义为虚函数，在执行析构时，则根据对象的类型来执行析构函数，此时派生类的资源得到释放。

```C++ []
#include <iostream>

using namespace std;

class A {
private:
    int val;
public:
    virtual ~A() {
        cout<<"A destroy!"<<endl;
    }
};

class B: public  A {
private:
    int *arr;
public:
    B() {
        arr = new int[10];
    }
    virtual ~B() {
        cout<<"B destroy!"<<endl;
        delete arr;
    }
};

int main() {
    A *base = new B();
    delete base;
    return 0;
}
// B destroy!
// A destroy!
```

参考资料：

+ [默认构造函数](https://baike.baidu.com/item/%E9%BB%98%E8%AE%A4%E6%9E%84%E9%80%A0%E5%87%BD%E6%95%B0/10132851)
+ [Default Constructors in C++](https://www.***.org/default-constructors-in-cpp/)
+ [Default constructors (C++ only)](https://www.ibm.com/docs/en/zos/2.2.0?topic=only-default-constructors-c)
+ [Default constructors](https://en.cppreference.com/w/cpp/language/default_constructor)

## 多重继承的常见问题及避免方法
多重继承（多继承）：是指从多个直接基类中产生派生类。多重继承容易出现命名冲突和数据冗余问题。
程序示例如下:

```C++ []
#include <iostream>
using namespace std;

// 间接基类
class Base1
{
public:
    int var1;
};

// 直接基类
class Base2 : public Base1
{
public:
    int var2;
};

// 直接基类
class Base3 : public Base1
{
public:
    int var3;
};

// 派生类
class Derive : public Base2, public Base3
{
public:
    void set_var1(int tmp) { var1 = tmp; } // error: reference to 'var1' is ambiguous. 命名冲突
    void set_var2(int tmp) { var2 = tmp; }
    void set_var3(int tmp) { var3 = tmp; }
    void set_var4(int tmp) { var4 = tmp; }

private:
    int var4;
};

int main()
{
    Derive d;
    return 0;
}
```

上述程序的继承关系如下：（菱形继承）
![4_15_1.png](https://pic.leetcode-cn.com/1661310999-nOjItm-4_15_1.png)
上述代码中存的问题：
对于派生类 `Derive` 上述代码中存在直接继承关系和间接继承关系。

+ 直接继承：`Base2` 、`Base3`
+ 间接继承：`Base1`
  对于派生类中继承的的成员变量 `var1` ，从继承关系来看，实际上保存了两份，一份是来自基类 `Base2`，一份来自基类 `Base3`。因此，出现了命名冲突。

1. 解决方法：显式声明出现冲突的成员变量来源于哪个类。

```C++
#include <iostream>
using namespace std;

// 间接基类
class Base1
{
public:
    int var1;
};

// 直接基类
class Base2 : public Base1
{
public:
    int var2;
};

// 直接基类
class Base3 : public Base1
{
public:
    int var3;
};

// 派生类 
class Derive : public Base2, public Base3
{
public:
    void set_var1(int tmp) { Base2::var1 = tmp; } // 这里声明成员变量来源于类 Base2，当然也可以声明来源于类 Base3
    void set_var2(int tmp) { var2 = tmp; }
    void set_var3(int tmp) { var3 = tmp; }
    void set_var4(int tmp) { var4 = tmp; }

private:
    int var4;
};

int main()
{
    Derive d;
    return 0;
}
```

2. 解决方法： 虚继承

```C++
#include <iostream>
using namespace std;

// 间接基类，即虚基类
class Base1
{
public:
    int var1;
};

// 直接基类 
class Base2 : virtual public Base1 // 虚继承
{
public:
    int var2;
};

// 直接基类 
class Base3 : virtual public Base1 // 虚继承
{
public:
    int var3;
};

// 派生类
class Derive : public Base2, public Base3
{
public:
    void set_var1(int tmp) { var1 = tmp; } 
    void set_var2(int tmp) { var2 = tmp; }
    void set_var3(int tmp) { var3 = tmp; }
    void set_var4(int tmp) { var4 = tmp; }

private:
    int var4;
};

int main()
{
    Derive d;
    return 0;
}
```

类之间的继承关系：
![4_15_2.png](https://pic.leetcode-cn.com/1661311024-kBHgoW-4_15_2.png)

由于使用多重继承很容易出现二义性的问题，将使得程序调试和维护工作变得非常复杂，`C++` 之后的很多面向对象的编程语言，例如 `Java、C#、PHP` 等，都不支持多继承。

参考资料：

+ [C++虚继承和虚基类详解](http://c.biancheng.net/view/2280.html)
+ [C++虚继承详解](https://blog.csdn.net/youaremyalllove/article/details/124324115)
+ [C++ Multiple, Multilevel and Hierarchical Inheritance](https://www.programiz.com/cpp-programming/multilevel-multiple-inheritance)
+ [Multiple Inheritance in C++](https://www.javatpoint.com/multiple-inheritance-in-cpp)
+ [Multiple Inheritance in C++](https://www.***.org/multiple-inheritance-in-c/)

## 深拷贝和浅拷贝的区别
如果一个类拥有资源，该类的对象进行复制时，如果资源重新分配，就是深拷贝，否则就是浅拷贝。

+ 深拷贝：该对象和原对象占用不同的内存空间，既拷贝存储在栈空间中的内容，又拷贝存储在堆空间中的内容。
+ 浅拷贝：该对象和原对象占用同一块内存空间，仅拷贝类中位于栈空间中的内容。
![4_25_1.png](https://pic.leetcode-cn.com/1661311283-TOfEBS-4_25_1.png)

当类的成员变量中有指针变量时，最好使用深拷贝。因为当两个对象指向同一块内存空间，如果使用浅拷贝，当其中一个对象的删除后，该块内存空间就会被释放，另外一个对象指向的就是垃圾内存。

+ **浅拷贝实例**：

```C++ []
#include <iostream>

using namespace std;

class Test
{
private:
	int *p;

public:
	Test(int tmp)
	{
		this->p = new int(tmp);
		cout << "Test(int tmp)" << endl;
	}
	~Test()
	{
		if (p != NULL)
		{
			delete p;
		}
		cout << "~Test()" << endl;
	}
};

int main()
{
	Test ex1(10);	
	Test ex2 = ex1; 
	return 0;
}
/*
运行结果：
Test(int tmp)
~Test()
*/
```

说明：上述代码中，类对象 `ex1、ex2` 实际上是指向同一块内存空间，对象析构时，`ex2` 先将内存释放了一次，之后析构对象 `ex1` 时又将这块已经被释放过的内存再释放一次。对同一块内存空间释放了两次，会导致程序崩溃。

+ 深拷贝实例：

```C++
#include <iostream>

using namespace std;

class Test
{
private:
	int *p;

public:
	Test(int tmp)
	{
		p = new int(tmp);
		cout << "Test(int tmp)" << endl;
	}
	~Test()
	{
		if (p != NULL)
		{
			delete p;
		}
		cout << "~Test()" << endl;
	}
	Test(const Test &tmp) // 定义拷贝构造函数
	{
		p = new int(*tmp.p);
		cout << "Test(const Test &tmp)" << endl;
	}

};

int main()
{
	Test ex1(10);	
	Test ex2 = ex1; 
	return 0;
}
/*
Test(int tmp)
Test(const Test &tmp)
~Test()
~Test()
*/
```

+ 编译器生成的默认拷贝函数均大部分都是浅拷贝，所有在特定场景下需要禁止编译器生成默认拷贝构造函数。在遇到需要使用堆内存的构造函数中，我们需要特别注意浅拷贝和深拷贝的使用方式，防止两个不同的对象指向同一块内存区域。

参考资料:

+ [Shallow Copy and Deep Copy in C++](https://www.***.org/shallow-copy-and-deep-copy-in-c/)
+ [What is the difference between a deep copy and a shallow copy?](https://stackoverflow.com/questions/184710/what-is-the-difference-between-a-deep-copy-and-a-shallow-copy)
+ [Deep Copy C++](https://linuxhint.com/deep-copy-cpp/)

## 单继承和多继承的虚函数表结构
+ 编译器将虚函数表的指针放在类的实例对象的内存空间中，该对象调用该类的虚函数时，通过指针找到虚函数表，根据虚函数表中存放的虚函数的地址找到对应的虚函数。
+ 如果派生类没有重新定义基类的虚函数 `A`，则派生类的虚函数表中保存的是基类的虚函数 `A` 的地址，也就是说基类和派生类的虚函数 `A` 的地址是一样的。
+ 如果派生类重写了基类的某个虚函数 `B`，则派生的虚函数表中保存的是重写后的虚函数 `B` 的地址，也就是说虚函数 `B` 有两个版本，分别存放在基类和派生类的虚函数表中。
+ 如果派生类重新定义了新的虚函数 `C`，派生类的虚函数表保存新的虚函数 `C` 的地址。

1. 单继承无虚函数覆盖的情况：

```C++ []
#include <iostream>
#include <memory>
using namespace std;
 
 
typedef void (*func)(void);

#include <iostream>
using namespace std;

class Base
{
public:
    virtual void B_fun1() { cout << "Base::B_fun1()" << endl; }
    virtual void B_fun2() { cout << "Base::B_fun2()" << endl; }
    virtual void B_fun3() { cout << "Base::B_fun3()" << endl; }
};

class Derive : public Base
{
public:
    virtual void D_fun1() { cout << "Derive::D_fun1()" << endl; }
    virtual void D_fun2() { cout << "Derive::D_fun2()" << endl; }
    virtual void D_fun3() { cout << "Derive::D_fun3()" << endl; }
};

void printVtable(unsigned long *vptr, int offset) {
	func fn = (func)*((unsigned long*)(*vptr) + offset);
	fn();	
}

int main()
{
    Base *p = new Derive();
    p->B_fun1(); // Base::B_fun1()
	unsigned long* vPtr = (unsigned long*)(p);
	printVtable(vPtr, 0);
	printVtable(vPtr, 1);
	printVtable(vPtr, 2);
	printVtable(vPtr, 3);
	printVtable(vPtr, 3);
	printVtable(vPtr, 4);
    cout<<sizeof(Base)<<endl; // 8
    cout<<sizeof(Derive)<<endl; // 8
    return 0;
}
/*
Base::B_fun1()
Base::B_fun1()
Base::B_fun2()
Base::B_fun3()
Derive::D_fun1()
Derive::D_fun2()
Derive::D_fun3()
8
8
*/
```

基类和派生类的继承关系：
![4_8_1.png](https://pic.leetcode-cn.com/1661224138-RbKIMW-4_8_1.png)
基类的虚函数表：
![4_3_1.png](https://pic.leetcode-cn.com/1661224148-AzSusP-4_3_1.png)
派生类的虚函数表：
![4_3_2.png](https://pic.leetcode-cn.com/1661224158-oAsuQx-4_3_2.png)

+ 虚函数按照声明顺序放在虚函数表里面。
+ 父类的虚函数在子类的虚函数前面。

2. 单继承有虚函数覆盖的情况：

```C++ []
#include <iostream>
#include <memory>
using namespace std;
 
 
typedef void (*func)(void);

class Base
{
public:
    virtual void fun1() { cout << "Base::fun1()" << endl; }
    virtual void B_fun2() { cout << "Base::B_fun2()" << endl; }
    virtual void B_fun3() { cout << "Base::B_fun3()" << endl; }
};

class Derive : public Base
{
public:
    virtual void fun1() { cout << "Derive::fun1()" << endl; }
    virtual void D_fun2() { cout << "Derive::D_fun2()" << endl; }
    virtual void D_fun3() { cout << "Derive::D_fun3()" << endl; }
};

void printVtable(unsigned long *vptr, int offset) {
	func fn = (func)*((unsigned long*)(*vptr) + offset);
	fn();	
}

int main()
{
    Base *p = new Derive();
	unsigned long* vPtr = (unsigned long*)(p);
	printVtable(vPtr, 0);
	printVtable(vPtr, 1);
	printVtable(vPtr, 2);
	printVtable(vPtr, 3);
	printVtable(vPtr, 4);
    cout<<sizeof(Base)<<endl; // 8
    cout<<sizeof(Derive)<<endl; // 8
    return 0;
}

/*
Derive::fun1()
Base::B_fun2()
Base::B_fun3()
Derive::D_fun2()
Derive::D_fun3()
8
8
*/
```

+ 派生类的虚函数表：
![4_9_1.png](https://pic.leetcode-cn.com/1663130295-EvbThl-4_9_1.png)

3. 多继承无虚函数覆盖的情况：

```C++ []
#include <iostream>
using namespace std;

class Base1
{
public:
    virtual void B1_fun1() { cout << "Base1::B1_fun1()" << endl; }
    virtual void B1_fun2() { cout << "Base1::B1_fun2()" << endl; }
    virtual void B1_fun3() { cout << "Base1::B1_fun3()" << endl; }
};
class Base2
{
public:
    virtual void B2_fun1() { cout << "Base2::B2_fun1()" << endl; }
    virtual void B2_fun2() { cout << "Base2::B2_fun2()" << endl; }
    virtual void B2_fun3() { cout << "Base2::B2_fun3()" << endl; }
};
class Base3
{
public:
    virtual void B3_fun1() { cout << "Base3::B3_fun1()" << endl; }
    virtual void B3_fun2() { cout << "Base3::B3_fun2()" << endl; }
    virtual void B3_fun3() { cout << "Base3::B3_fun3()" << endl; }
};

class Derive : public Base1, public Base2, public Base3
{
public:
    virtual void D_fun1() { cout << "Derive::D_fun1()" << endl; }
    virtual void D_fun2() { cout << "Derive::D_fun2()" << endl; }
    virtual void D_fun3() { cout << "Derive::D_fun3()" << endl; }
};

typedef void (*func)(void);

void printVtable(unsigned long *vptr, int offset) {
	func fn = (func)*((unsigned long*)(*vptr) + offset);
	fn();	
}

int main(){
    Base1 *p = new Derive();
    unsigned long* vPtr = (unsigned long*)(p);
	printVtable(vPtr, 0);
	printVtable(vPtr, 1);
	printVtable(vPtr, 2);
	printVtable(vPtr, 3);
	printVtable(vPtr, 4);
	printVtable(vPtr, 5);
	vPtr++;
	printVtable(vPtr, 0);
	printVtable(vPtr, 1);
	printVtable(vPtr, 2);
	vPtr++;
	printVtable(vPtr, 0);
	printVtable(vPtr, 1);
	printVtable(vPtr, 2);
    cout<<sizeof(Base1)<<endl; // 8
	cout<<sizeof(Base2)<<endl; // 8
	cout<<sizeof(Base3)<<endl; // 8
    cout<<sizeof(Derive)<<endl; // 8
    return 0;
}

/*
Base1::B1_fun1()
Base1::B1_fun2()
Base1::B1_fun3()
Derive::D_fun1()
Derive::D_fun2()
Derive::D_fun3()
Base2::B2_fun1()
Base2::B2_fun2()
Base2::B2_fun3()
Base3::B3_fun1()
Base3::B3_fun2()
Base3::B3_fun3()
8
8
8
24
*/
```

派生类的虚函数表：（基类的顺序和声明的顺序一致）
![4_9_2.png](https://pic.leetcode-cn.com/1661224203-PAsnVw-4_9_2.png)

4. 多继承有虚函数覆盖的情况：

```C++ []
#include <iostream>
using namespace std;

class Base1
{
public:
    virtual void fun1() { cout << "Base1::fun1()" << endl; }
    virtual void B1_fun2() { cout << "Base1::B1_fun2()" << endl; }
    virtual void B1_fun3() { cout << "Base1::B1_fun3()" << endl; }
};
class Base2
{
public:
    virtual void fun1() { cout << "Base2::fun1()" << endl; }
    virtual void B2_fun2() { cout << "Base2::B2_fun2()" << endl; }
    virtual void B2_fun3() { cout << "Base2::B2_fun3()" << endl; }
};
class Base3
{
public:
    virtual void fun1() { cout << "Base3::fun1()" << endl; }
    virtual void B3_fun2() { cout << "Base3::B3_fun2()" << endl; }
    virtual void B3_fun3() { cout << "Base3::B3_fun3()" << endl; }
};

class Derive : public Base1, public Base2, public Base3
{
public:
    virtual void fun1() { cout << "Derive::fun1()" << endl; }
    virtual void D_fun2() { cout << "Derive::D_fun2()" << endl; }
    virtual void D_fun3() { cout << "Derive::D_fun3()" << endl; }
};

typedef void (*func)(void);

void printVtable(unsigned long *vptr, int offset) {
	func fn = (func)*((unsigned long*)(*vptr) + offset);
	fn();	
}

int main(){
    Base1 *p1 = new Derive();
    Base2 *p2 = new Derive();
    Base3 *p3 = new Derive();
    p1->fun1(); // Derive::fun1()
    p2->fun1(); // Derive::fun1()
    p3->fun1(); // Derive::fun1()
    unsigned long* vPtr = (unsigned long*)(p1);
	printVtable(vPtr, 0);
	printVtable(vPtr, 1);
	printVtable(vPtr, 2);
	printVtable(vPtr, 3);
	printVtable(vPtr, 4);
	vPtr++;
	printVtable(vPtr, 0);
	printVtable(vPtr, 1);
	printVtable(vPtr, 2);
	vPtr++;
	printVtable(vPtr, 0);
	printVtable(vPtr, 1);
	printVtable(vPtr, 2);
    cout<<sizeof(Base1)<<endl; // 8
	cout<<sizeof(Base2)<<endl; // 8
	cout<<sizeof(Base3)<<endl; // 8
    cout<<sizeof(Derive)<<endl; // 8
    return 0;
}

/*
Derive::fun1()
Derive::fun1()
Derive::fun1()
Derive::fun1()
Base1::B1_fun2()
Base1::B1_fun3()
Derive::D_fun2()
Derive::D_fun3()
Derive::fun1()
Base2::B2_fun2()
Base2::B2_fun3()
Derive::fun1()
Base3::B3_fun2()
Base3::B3_fun3()
8
8
8
24
*/
```

基类和派生类的关系：
![4_9_3.png](https://pic.leetcode-cn.com/1661224230-yMQSbY-4_9_3.png)
派生类的虚函数表：
![4_9_4.png](https://pic.leetcode-cn.com/1661224240-QobANM-4_9_4.png)


参考资料：

+ [C++虚函数表分析——参考陈皓版](

## 如何禁止构造函数的使用
为类的构造函数增加 `= delete` 修饰符，可以达到虽然声明了构造函数但禁止使用的目的。

```C++ []
#include <iostream>

using namespace std;

class A {
public:
    int var1, var2;
    A(){
        var1 = 10;
        var2 = 20;
    }
    A(int tmp1, int tmp2) = delete;
};

int main()
{
    A ex1;    
    A ex2(12,13); // error: use of deleted function 'A::A(int, int)'
    return 0;
}
```

如果我们仅仅将构造函数设置为私有，类内部的成员和友元还可以访问，无法完全禁止。而在 `C++11` 以后，在成员函数声明后加 `"= delete"`则可以禁止该函数的使用，而需要保留的加 `"= default"`。

参考资料：

+ [Meaning of = delete after function declaration](https://stackoverflow.com/questions/5513881/meaning-of-delete-after-function-declaration)

## 什么是类的默认构造函数
默认构造函数（`default constructor`）就是在没有显式提供初始化式时调用的构造函数。它由不带参数的构造函数，或者为所有的形参提供默认实参的构造函数定义。如果定义某个类的变量时没有提供初始化时就会使用默认构造函数。

1. 用户定义的默认构造函数:

+ 用户自定义的不带参数的构造函数:

```C++ []
#include <iostream>

using namespace std;

class A
{
public:
    A(){ // 类的默认构造函数
        var = 10;
        c = 'q';
    }
    A(int val = 10)
    int var;
    char c;
};

int main()
{
    A ex;
    cout << ex.c << endl << ex.var << endl;
    return 0;
}
/*
运行结果：
q
10
*/
```

说明：上述程序中定义变量 `ex` 时，未提供任何实参，程序运行时会调用默认的构造函数。

+ 用户自定义的构造函数，但为所有形参提供默认值的构造函数:

```C++ []
#include <iostream>

using namespace std;

class A
{
public:
    A(int _var = 10, char _c = 'q'){ // 类的默认构造函数
        var = _var;
        c = _c;
    }
    int var;
    char c;
};

int main()
{
    A ex;
    cout << ex.c << endl << ex.var << endl;
    return 0;
}
/*
运行结果：
q
10
*/
```

说明：上述程序中定义变量 `ex` 时，未提供任何实参，程序运行时会调用所有形参提供默认值的构造函数。

2. 编译器自动分配的合成默认构造函数
   如果用户定义的类中没有显式的定义任何构造函数，编译器就会自动为该类型生成默认构造函数，称为合成的默认构造函数。

```C++ []
#include <iostream>

using namespace std;

class A
{
public:
    int var;
    char c;
};

int main()
{
    A ex;
    cout << ex.c << endl << ex.var << endl;
    return 0;
}
/*
运行结果：

0
*/
```

此时编译器会自动为 `A` 分配一个默认的构造函数，在上述示例中，类 `A` 中的变量 `c` 默认赋值为 `\0`，`var` 默认赋值为 `0`。
一般情况下，如果类中包含内置或复合类型的成员，则该类就不应该依赖于合成的默认构造函数，它应该定义自己的构造函数来初始化这些成员。多数情况下，编译器为类生成一个公有的默认构造函数，只有下面两种情况例外:

+ 一个类显式地声明了任何构造函数，编译器不生成公有的默认构造函数。在这种情况下，如果程序需要一个默认构造函数，需要由类的设计者提供。
+ 一个类声明了一个非公有的默认构造函数，编译器不会生成公有的默认构造函数。
  在大多数情况下，`C++` 编译器为未声明构造函数之 `class` 合成一个默认构造函数：
+ 如果该类没有任何构造函数，但是包含一个对象类型的成员变量，且该变量有一个显式的默认构造函数；
+ 如果该类没有任何构造函数，但是其父类含有显式的默认构造函数；
+ 如果该类没有任何构造函数，但是含有（或父类含有）虚函数；
+ 如果该类没有任何构造函数，但是带有一个虚基类；

参考资料：

+ [默认构造函数](https://baike.baidu.com/item/%E9%BB%98%E8%AE%A4%E6%9E%84%E9%80%A0%E5%87%BD%E6%95%B0/10132851)
+ [Default Constructors in C++](https://www.***.org/default-constructors-in-cpp/)
+ [Default constructors (C++ only)](https://www.ibm.com/docs/en/zos/2.2.0?topic=only-default-constructors-c)
+ [Default constructors](https://en.cppreference.com/w/cpp/language/default_constructor)

## 如何减少构造函数开销
在构造函数时尽量使用类初始化列表，会减少调用默认的构造函数产生的开销，具体原因可以参考本章《为什么用成员初始化列表会快一些？》这个问题。

```C++ []
class A
{
private:
    int val;
public:
    A()
    {
        cout << "A()" << endl;
    }
    A(int tmp)
    {
        val = tmp;
        cout << "A(int " << val << ")" << endl;
    }
};
class Test1
{
private:
    A ex;

public:
    Test1(): ex(1)  // 成员列表初始化方式
    {
        
    }
};
```


参考资料：

+ [When do we use Initializer List in C++?](https://www.***.org/when-do-we-use-initializer-list-in-c/)
+ [Constructors and member initializer lists](https://en.cppreference.com/w/cpp/language/constructor)
+ [What are initializer lists in C++?](https://www.educative.io/answers/what-are-initializer-lists-in-cpp)

## C++ 类对象的初始化顺序
1. 构造函数调用顺序：

+ 按照派生类继承基类的顺序，即派生列表中声明的继承顺序，依次调用基类的构造函数；
+ 在有虚继承和一般继承存在的情况下，优先虚继承。比如虚继承：`class C: public B, virtual public A`，此时应当先调用 `A` 的构造函数，再调用 `B` 的构造函数。
+ 按照派生类中成员变量的声明顺序，依次调用派生类中成员变量所属类的构造函数；
+ 执行派生类自身的构造函数。

2. 类对象的初始化顺序：

+ 按照构造函数的调用顺序，调用基类的构造函数
+ 按照成员变量的声明顺序，调用成员变量的构造函数函数，成员变量的初始化顺序与声明顺序有关；
+ 调用该类自身的构造函数；
+ 析构顺序和类对象的初始化顺序相反。

```C++ []
#include <iostream>
using namespace std;

class A
{
public:
    A() { cout << "A()" << endl; }
    ~A() { cout << "~A()" << endl; }
};

class B
{
public:
    B() { cout << "B()" << endl; }
    ~B() { cout << "~B()" << endl; }
};

class Test : public A, public B // 派生列表
{
public:
    Test() { cout << "Test()" << endl; }
    ~Test() { cout << "~Test()" << endl; }

private:
    B ex1;
    A ex2;
};

int main()
{
    Test ex;
    return 0;
}
/*
运行结果：
A()
B()
B()
A()
Test()
~Test()
~A()
~B()
~B()
~A()
*/
```

程序运行结果分析：

+ 首先调用基类 `A` 和 `B` 的构造函数，按照派生列表 `public A`, `public B` 的顺序构造；
+ 然后调用派生类 `Test` 的成员变量 `ex1` 和 `ex2` 的构造函数，按照派生类中成员变量声明的顺序构造；
+ 最后调用派生类的构造函数；
+ 接下来调用析构函数，和构造函数调用的顺序相反。

3. 类的成员初始化:
   类中可能含有静态变量和全局变量，由于静态变量和全局变量都被放在静态存储区，他们的初始化在 `main` 函数执行之前已被初始化，且 `static` 变量必须在类外进行初始化。

+ 成员变量在使用初始化列表初始化时，与构造函数中初始化成员列表的顺序无关，只与定义成员变量的顺序有关。因为成员变量的初始化次序是根据变量在内存中次序有关，而内存中的排列顺序早在编译期就根据变量的定义次序决定了。

+ 如果类不使用初始化列表初始化，而在类的构造函数内部进行初始化时，此时成员变量的初始化顺序与构造函数中代码逻辑有关。

+ 类成员在定义时，是不能初始化的

+ 类中 `const` 成员常量必须在构造函数初始化列表中初始化。

+ 类中 `static` 成员变量，必须在类外初始化。

参考资料

+ [C++成员变量的初始化顺序问题](https://blog.csdn.net/zhaojinjia/article/details/8785912)

## 成员初始化列表效率高的原因
对象的成员函数数据类型可分为语言内置类型和用户自定义类，对于用户自定义类型，利用成员初始化列表效率高。用户自定义类型如果使用类初始化列表，直接调用该成员变量对应的构造函数即完成初始化；如果在构造函数中初始化，由于 `C++` 规定对象的成员变量的初始化动作发生在进入自身的构造函数本体之前，那么在执行构造函数之前首先调用默认的构造函数为成员变量设初值，在进入函数体之后，再显式调用该成员变量对应的构造函数。因此使用列表初始化会减少调用默认的构造函数的过程，效率更高一些。

```C++ []
#include <iostream>
using namespace std;
class A
{
private:
    int val;
public:
    A()
    {
        cout << "A()" << endl;
    }
    A(int tmp)
    {
        val = tmp;
        cout << "A(int " << val << ")" << endl;
    }
};

class Test1
{
private:
    A ex;

public:
    Test1() : ex(1) // 成员列表初始化方式
    {
    }
};

class Test2
{
private:
    A ex;

public:
    Test2() // 函数体中赋值的方式
    {
        ex = A(2);
    }
};
int main()
{
    Test1 ex1;
    cout << endl;
    Test2 ex2;
    return 0;
}
/*
运行结果：
A(int 1)

A()
A(int 2)
*/
```

+ 说明：从程序运行结果可以看出，使用成员列表初始化的方式会省去调用默认的构造函数的过程。如果自定义的类型没有默认构造函数，此时必须使用初始化列表提供初值对这些类型进行初始化。


参考资料:

+ [When do we use Initializer List in C++?](https://www.***.org/when-do-we-use-initializer-list-in-c/)
+ [Constructors and member initializer lists](https://en.cppreference.com/w/cpp/language/constructor)
+ [What are initializer lists in C++?](https://www.educative.io/answers/what-are-initializer-lists-in-cpp)

## 友元函数的作用及使用场景
+ 友元函数的作用：友元（`friend`）提供了不同类的成员函数之间、类的成员函数与一般函数之间进行数据共享的机制。通过友元，一个普通的函数或另一个类中的成员函数可以访问类中的私有成员和保护成员。

**使用场景**：

1. 普通函数定义为类的友元函数，使得普通函数能够访问该类的私有成员和保护成员。

```C++ []
#include <iostream>

using namespace std;

class A
{
    friend ostream &operator<<(ostream &_cout, const A &tmp); // 声明为类的友元函数

public:
    A(int tmp) : var(tmp)
    {
    }

private:
    int var;
};

ostream &operator<<(ostream &_cout, const A &tmp)
{
    _cout << tmp.var;
    return _cout;
}

int main()
{
    A ex(4);
    cout << ex << endl; // 4
    return 0;
}
```

2. 友元类：
   由于类的 `private` 和 `protected` 成员变量只能由类的成员函数访问或者派生类访问，友元类则提供提供一种通用的方法，使得不同类之间可以访问其 `private` 和 `protected` 成员变量，用于不同类之间共享数据。

```C++ []
#include <iostream>

using namespace std;

class A
{
    friend class B;

public:
    A() : var(10){}
    A(int tmp) : var(tmp) {}
    void fun()
    {
        cout << "fun():" << var << endl;
    }

private:
    int var;
};

class B
{
public:
    B() {}
    void fun()
    {
        cout << "fun():" << ex.var << endl; // 访问类 A 中的私有成员
    }

private:
    A ex;
};

int main()
{
    B ex;
    ex.fun(); // fun():10
    return 0;
}
```

参考资料:

+ [Friend class and function in C++](https://www.***.org/friend-class-function-cpp/)
+ [Friendship and inheritance](https://cplusplus.com/doc/tutorial/inheritance/)
+ [C++ friend Function and friend Classes](https://www.programiz.com/cpp-programming/friend-function-class)
+ [Friend class](https://en.wikipedia.org/wiki/Friend_class)
+ [Friend function](https://en.wikipedia.org/wiki/Friend_function)
+ [Friend Functions and Friend Classes](https://www.cprogramming.com/tutorial/friends.html)

## 静态绑定和动态绑定的实现
静态类型和动态类型：

+ 静态类型：变量在声明时的类型，是在编译阶段确定的。静态类型不能更改。
+ 动态类型：目前所指对象的类型，是在运行阶段确定的。动态类型可以更改。
  静态绑定和动态绑定：
+ 静态绑定是指程序在**编译阶段**确定对象的类型（静态类型）。
+ 动态绑定是指程序在**运行阶段**确定对象的类型（动态类型）。
  静态绑定和动态绑定的区别：
+ 发生的时期不同：如上。
+ 对象的静态类型不能更改，动态类型可以更改。
  注：对于类的成员函数，只有虚函数是动态绑定，其他都是静态绑定。

```C++ []
#include <iostream>

using namespace std;

class Base
{
public:
	virtual void fun() { cout << "Base::fun()" << endl;
     }
};
class Derive : public Base
{
public:
	void fun() { cout << "Derive::fun()"; 
    }
};


int main()
{
	Base *p = new Derive(); // p 的静态类型是 Base*，动态类型是 Derive*
    p->fun(); // fun 是虚函数，运行阶段进行动态绑定
	return 0;
}
/*
运行结果：
Derive::fun()
*/
```

+ 动态绑定的实现原理：
  以下程序示例：

```C++ []
#include <iostream>
using namespace std;

class A{
private:
	int a1;
	int a2;
public:
	virtual void display(){ cout<<"A::display()"<<endl;}
	virtual void clone(){ cout<<"A::clone()"<<endl;}
};

class B: public A{
private:
    int b;
public:
    virtual void display(){ cout<<"B::display()"<<endl;} override
    virtual void init(){ cout<<"B::init()"<<endl;}
};

class C: public B{
private:
    int c;
public:
    virtual void display(){ cout<<"C::display()"<<endl;} override
    virtual void execute(){ cout<<"C::execute()"<<endl;} 
    virtual void init(){cout<<"C::init()"<<endl;} override
};

int main() {
    A *p1 = new B();
    A *p2 = new C();
    p1->display();
    p2->display();
    return 0;
}
```

我们对上述程序进行编译，并查看这里给出 `A`, `B`, `C` 三个类的虚函数表，如下图所示:
![4_24_1.png](https://pic.leetcode-cn.com/1661311210-yuOOTw-4_24_1.png)

可以得出以下结论：

+ 类的内存占用由成员变量和指向虚函数表的指针组成，同时派生类的成员变量是会把基类的成员变量都继承的
+ 同名虚函数在基类和派生类中的虚函数表中，在虚函数表中偏移位置是一致的，图 `A,B,C` 的 `display` 的偏移位置都为 `0`。同样名称的虚函数，在基类中定义的虚函数与派生类中定义的虚函数，在虚函数表中的偏移量都是一致的，只有这样才能保证动态绑定。
+ 如果派生类中定义了与基类同名的虚函数，那么派生类的虚函数表中响应函数的入口地址会被替换成覆盖后的函数的地址。
+ 一旦有新的虚函数定义，会加入到当前虚函数表的末端。
+ 派生类的成员变量顺序也按照声明的顺序依次在内存中分配。


我们可以分以一下动态绑定的实现：

+ 当我们用虚函数表指针去查找虚函数表中对应的函数的地址时，此时首先会找到函数地址的在虚函数表中的索引，这里 `display` 索引是 `0`。
+ 然后编译器会做一个替换，`（*(p->vptr)[0]）`，找到 `p` 指针的函数入口地址。
+ 程序运行后会执行这条语句 `*(p->vptr)[0]()`，完成函数的调用，实际即完成了动态绑定。

参考资料:

+ [Virtual Function in C++](https://www.***.org/virtual-function-cpp/?ref=gcse)
+ [Polymorphism in C++](https://www.***.org/polymorphism-in-c/)
+ [C++ 虚函数表](https://blog.csdn.net/nyist_zxp/article/details/80825031)

## 编译时多态和运行时多态的区别
+ 编译时多态：在程序编译过程中出现，发生在模板和函数重载中（泛型编程）。实际在编译器内部看来不管是重载还是模板，编译器内部都会生成不同的函数，在代码段中分别装有两个函数的不同实现。

+ 运行时多态：运行时多态也称动态绑定，在程序运行过程中出现，发生在继承体系中，是指通过基类的指针或引用访问派生类中的虚函数。

2. 编译时多态和运行时多态的区别：

+ 时期不同：编译时多态发生在程序编译过程中，运行时多态发生在程序的运行过程中；
+ 实现方式不同：编译时多态运用泛型编程来实现，运行时多态借助虚函数表来实现。


参考资料:

+ [C++动态绑定原理](https://blog.csdn.net/qq295109601/article/details/118981515)

## C++ 模板编程
模板是 `C++` 编程语言的一个特性，它允许函数和类使用泛型类型进行操作。这允许一个函数或类在许多不同的数据类型上工作，而无需为每个类型重写。`C++` 模板是泛型编程的基础，泛型编程即以一种独立于任何特定类型的方式编写代码，`C++` 中使用 `template` 关键字。模板是创建泛型类或函数的蓝图或公式。库容器，比如迭代器和算法，都是泛型编程的例子，它们都使用了模板的概念。
共有三种模板：函数模板、类模板以及自 `C++ 14` 以来的变量模板:

1. 函数模板:
   函数模板的行为类似于函数，只是模板可以有许多不同类型的参数。一个函数模板代表一个函数族。使用类型参数声明函数模板的格式是：

```C++
template<class identifier> declaration;
template<typename identifier> declaration;
```

上述两种表达方式完全相同，引入后一种时为了防止混淆。比如 `C++` 标准库包含 `max(x, y)` 返回较大的 `x` 和的函数模板 `y` 。该函数模板可以这样定义:

```C++
template<typename T> T max(T &a, T &b) { return a > b ? a : b; }
std :: cout << max ( 3 , 7 ) << '\n' ;         
std :: cout << max ( 3.0 , 7.0 ) << '\n' ;         
```

这个单一的函数定义适用于许多数据类型。具体来说，它适用于定义了 `>`（大于运算符）的所有数据类型。除了限制对一个函数描述的更改并使代码更易于阅读之外，函数模板的使用减少了源代码的编写，与为特定程序中使用的所有不同数据类型编写单独的函数相比，模板不会产生更小的目标代码，实际编译器在编译时，会为根据不同的类型编译产生不同的函数。

2. 类模板：
   类模板提供了基于参数生成类的规范。类模板通常用于实现容器。类模板通过将一组给定的类型作为模板参数传递给它来实例化。`C++` 标准库包含许多类模板，特别是改编自标准模板库的容器，例如 `vector`，`list`。

```C++ []
template <class T>
class Stack { 
  private: 
    vector<T> elements;     // 元素 
 
  public: 
    void push(T const&);  // 入栈
    void pop();               // 出栈
    T top() const;            // 返回栈顶元素
    bool empty() const{       // 如果为空则返回真。
        return elements.empty(); 
    } 
}; 
```

3. 变量模板：
   在 `C++14` 以后，变量也可以参数化为特定的类型，这称为变量模板。

```C++ []
template<typename T> 
constexpr T pi = T{3.141592653589793238462643383L}; // (Almost) from std::numbers::pi
```

使用变量模板时，必须显式地指定它的类型：

```C++ []
std::cout << pi<double> << '\n';
std::cout << pi<float> << '\n';
```

4. 函数重载与模板的区别:
   函数重载和模板都是面向对象多态特性的例子。当多个函数执行非常相似（不相同）的操作时使用函数重载，当多个函数执行相同操作时使用模板。当模板类或者模板函数中含有静态变量时，则每个模板的实例类型都含有一个静态成员。

```C++ []
template <class T>
class A { 
  public: 
	static T val; 
}; 
A<int> a; // 含有静态成员 val;
A<string> b; // 含有静态成员 val;
```


参考资料：

+ [Templates in C++ with Examples](https://www.***.org/templates-cpp/)
+ [C++ 模板](https://www.runoob.com/cplusplus/cpp-templates.html)
+ [Templates (C++)](https://docs.microsoft.com/en-us/cpp/cpp/templates-cpp?view=msvc-170)
+ [Template (C++)](https://en.wikipedia.org/wiki/Template_(C%2B%2B))

## 如何避免拷贝
最直观的想法是：将类的拷贝构造函数和赋值运算符重载声明为私有 `private`，但对于类的成员函数和友元函数依然可以调用，达不到完全禁止类的对象被拷贝的目的，而且程序会出现错误，因为未对函数进行定义。

1. 声明一个基类，具体做法如下。

+ 定义一个基类，将其中的拷贝构造函数和赋值运算符重载声明为私有 `private`。
+ 派生类以私有 `private` 的方式继承基类。

```C++
class Uncopyable
{
public:
    Uncopyable() {}
    ~Uncopyable() {}

private:
    Uncopyable(const Uncopyable &);            // 拷贝构造函数
    Uncopyable &operator=(const Uncopyable &); // 赋值运算符
};
class A : private Uncopyable // 注意继承方式
{ 
};
```

简单解释：

+ 能够保证，在派生类 `A` 的成员函数和友元函数中无法进行拷贝操作，因为无法调用基类 `Uncopyable` 的拷贝构造函数或赋值运算符重载。同样，在类的外部也无法进行拷贝操作。

2. 拷贝构造函数 `=delete` 修饰:
   `C++ 11` 支持 `delete` 直接禁用类的成员函数调用。

```C++
class Uncopyable
{
public:
    Uncopyable() {}
    ~Uncopyable() {}
     Uncopyable(const Uncopyable &) = delete;            // 禁用拷贝构造函数
     Uncopyable &operator=(const Uncopyable &) = delete; // 禁用赋值运算符
};
```

参考资料：

+ [C++禁止使用拷贝构造函数和赋值运算符方法](https://blog.csdn.net/qq_45662588/article/details/121032975)
+ [如何禁止自动生成拷贝构造函数？](https://www.jianshu.com/p/1ba360949452)

## 为什么拷贝构造函数必须声明为引用
1. 为什么拷贝函数必须为引用:
   原因：避免拷贝构造函数无限制的递归而导致栈溢出。

```C++ []
#include <iostream>
using namespace std;

class A
{
private:
    int val;

public:
    A(int tmp) : val(tmp) // 带参数构造函数
    {
        cout << "A(int tmp)" << endl;
    }

    A(const A &tmp) // 拷贝构造函数
    {
        cout << "A(const A &tmp)" << endl;
        val = tmp.val;
    }

    A &operator=(const A &tmp) // 赋值运算符重载
    {
        cout << "A &operator=(const A &tmp)" << endl;
        val = tmp.val;
        return *this;
    }

    void fun(A tmp)
    {
    }
};

int main()
{
    A ex1(1);
    A ex2(2);
    A ex3 = ex1;
    ex2 = ex1;
    ex2.fun(ex1);
    return 0;
}
/*
运行结果：
A(int tmp)
A(int tmp)
A(const A &tmp)
A &operator=(const A &tmp)
A(const A &tmp)
*/
```

+ 说明 `1`：`ex2 = ex1;` 和 `A ex3 = ex1;` 为什么调用的函数不一样？
  对象 `ex2` 已经实例化了，不需要构造，此时只是将 `ex1` 赋值给 `ex2`，只会调用赋值运算符的重载；但是 `ex3` 还没有实例化，因此调用的是拷贝构造函数，构造出 `ex3`，而不是赋值函数，这里涉及到构造函数的隐式调用。

+ 说明 2：如果拷贝构造函数中形参不是引用类型，`A ex3 = ex1;` 会出现什么问题？
  构造 `ex3`，实质上是 `ex3.A(ex1);`，假如拷贝构造函数参数不是引用类型，那么将使得 `ex3.A(ex1);` 相当于 `ex1` 作为函数 `A(const A tmp)` 的实参，在参数传递时相当于 `A tmp = ex1`，因为 `tmp` 没有被初始化，所以在 `A tmp = ex1` 中继续调用拷贝构造函数，接下来的是构造 `tmp`，也就是 `tmp.A(ex1)` ，必然又会有 `ex1` 作为函数 `A(const A tmp);` 的实参，在参数传递时相当于即 `A tmp = ex1`，那么又会触发拷贝构造函数，就这下永远的递归下去。

+ 说明 3：为什么 `ex2.fun(ex1);` 会调用拷贝构造函数？
  `ex1` 作为参数传递给 `fun` 函数， 即 `A tmp = ex1;`，这个过程会调用拷贝构造函数进行初始化。

2. 什么情况下会调用拷贝构造函数：

+ 直接初始化和拷贝初始化时

```C++ []
string dots("zhang"); //直接初始化
string dots = "zhang" //拷贝初始化
```

+ 将一个对象作为实参传递给一个非引用或非指针类型的形参时

+ 从一个返回类型为非引用或非指针的函数返回一个对象时

+ 用花括号列表初始化一个数组的元素或者一个聚合类（很少使用）中的成员时。

3. 何时调用复制构造函数：
   新建一个对象并将其初始化为同类现有对象时，复制构造函数都将被调用。这在很多情况下都可能发生，最常见的情况是新对象显式地初始化为现有的对象。例如，假设 `motto` 是一个 `StringBad` 对象，则下面 `4` 种声明都将调用复制构造函数：

```C++ []
StringBad ditto(motto);
StringBad metoo = motto;
StringBad also = StringBad(motto);
StringBad * pStringBad = new StringBad(motto);
```

其中中间的 `2` 种声明可能会使用复制构造函数直接创建 `metoo` 和 `also` ，也可能使用复制构造函数生成一个临时对象，然后将临时对象的内容赋给 `metoo` 和 `also`，这取决于具体的实现。最后一种声明使用 `motto` 初始化一个匿名对象，并将新对象的地址赋给 `pStringBad` 指针。


参考资料：

+ [拷贝构造函数在哪几种情况下会被调用](https://zhuanlan.zhihu.com/p/150367892?from_voters_page=true)
+ [拷贝构造函数何时调用？](https://www.zhihu.com/question/30726582)

## 如何禁止一个类被实例化
1. 方法一：

+ 在类中定义一个纯虚函数，使该类成为抽象基类，因为不能创建抽象基类的实例化对象；

```C++ []
#include <iostream>

using namespace std;


class A {
public:
    int var1, var2;
    A(){
        var1 = 10;
        var2 = 20;
    }
    virtual void fun() = 0; // 纯虚函数
};

int main()
{
    A ex1; // error: cannot declare variable 'ex1' to be of abstract type 'A'
    return 0;
}
```

2. 方法二：

+ 将类的所有构造函数声明为私有 `private`；

3. 方法三：

+ `C++ 11` 以后，将类的所有构造函数用 `=delete` 修饰；

## 实例化一个对象需要哪几个阶段
+ **分配空间**
  创建类对象首先要为该对象分配内存空间。不同的对象，为其分配空间的时机未必相同。全局对象、静态对象、分配在栈区域内的对象，在编译阶段进行内存分配；存储在堆空间的对象，是在运行阶段进行内存分配。

+ **初始化**
  首先明确一点：初始化不同于赋值。初始化发生在赋值之前，初始化随对象的创建而进行，而赋值是在对象创建好后，为其赋上相应的值。这一点可以联想下上一个问题中提到：初始化列表先于构造函数体内的代码执行，初始化列表执行的是数据成员的初始化过程，这个可以从成员对象的构造函数被调用看的出来。

+ **赋值**
  对象初始化完成后，可以对其进行赋值。对于一个类的对象，其成员变量的赋值过程发生在类的构造函数的函数体中。当执行完该函数体，也就意味着类对象的实例化过程完成了。（总结：构造函数实现了对象的初始化和赋值两个过程，对象的初始化是通过初始化列表来完成，而对象的赋值则才是通过构造函数的函数体来实现。）

注：对于拥有虚函数的类的对象，还需要给虚表指针赋值。

+ 没有继承关系的类，分配完内存后，首先给虚表指针赋值，然后再列表初始化以及执行构造函数的函数体，即上述中的初始化和赋值操作。
+ 有继承关系的类，分配内存之后，首先进行基类的构造过程，然后给该派生类的虚表指针赋值，最后再列表初始化以及执行构造函数的函数体，即上述中的初始化和赋值操作。

## 不允许修改类的成员变量的函数实现方法
如果想达到一个类的成员函数不能修改类的成员变量，只需用 `const` 关键字来修饰该函数即可。该问题本质是考察 `const` 关键字修饰成员函数的作用，只不过以实例的方式来考察，面试者应熟练掌握 `const` 关键字的作用。同时 `C++` 还存在与 `const` 相反的关键字 `mutable`。被 `mutable` 修饰的变量，将永远处于可变的状态，即使在一个 `const` 函数中。如果我们需要在 `const` 函数中修改类的某些成员变量，这时就需要用到 `mutable`。
使用 `mutable` 的注意事项：

+ `mutable` 只能作用于类的非静态和非常量数据成员。
+ 在一个类中，应尽量避免大量使用 `mutable`，大量使用 `mutable` 表示程序设计存在缺陷。

```C++ []
#include <iostream>

using namespace std;

class A
{
public:
    mutable int var1;
    int var2;
    A()
    {
        var1 = 10;
        var2 = 20;
    }
    void fun() const // 不能在 const 修饰的成员函数中修改成员变量的值，除非该成员变量用 mutable 修饰
    {
        var1 = 100; // ok
        var2 = 200; // error: assignment of member 'A::var1' in read-only object
    }
};

int main()
{
    A ex1;
    return 0;
}
```

我们可以看到在 `const` 函数中， `mutable` 修饰的变量可以修改，否则则不能修改。

参考资料:

+ [深入理解C++中的mutable关键字](https://www.iteye.com/blog/shansun123-398582)

## 对象创建限制在堆或栈
`C++` 中的类的对象的建立分为两种：静态建立、动态建立。如何限制类的对象只能在堆上创建？如何限制对象只能在栈上创建？

+ 静态建立：由编译器为对象在栈空间上分配内存，直接调用类的构造函数创建对象。例如：`A a`;
+ 动态建立：使用 `new` 关键字在堆空间上创建对象，底层首先调用 `operator new()` 函数，在堆空间上寻找合适的内存并分配；然后，调用类的构造函数创建对象。例如：`A *p = new A()`;

1. 限制对象只能建立在堆上：
   最直观的思想：避免直接调用类的构造函数，因为对象静态建立时，会调用类的构造函数创建对象。但是直接将类的构造函数设为私有并不可行，因为当构造函数设置为私有后，不能在类的外部调用构造函数来构造对象，只能用 `new` 来建立对象。但是由于 `new` 创建对象时，底层也会调用类的构造函数，将构造函数设置为私有后，那就无法在类的外部使用 `new` 创建对象了。因此，这种方法不可行。

+ 解决方法 1：
  将析构函数设置为私有。原因：静态对象建立在栈上，是由编译器分配和释放内存空间，编译器为对象分配内存空间时，会对类的非静态函数进行检查，即编译器会检查析构函数的访问性。当析构函数设为私有时，编译器创建的对象就无法通过访问析构函数来释放对象的内存空间，因此，编译器不会在栈上为对象分配内存。

```C++ []
class A
{
public:
    A() {}
    void destroy()
    {
        delete this;
    }

private:
    ~A()
    {
    }
};
```

该方法存在的问题：用 `new` 创建的对象，通常会使用 `delete` 释放该对象的内存空间，但此时类的外部无法调用析构函数，因此类内必须定义一个 `destroy()` 函数，用来释放 `new` 创建的对象。无法解决继承问题，因为如果这个类作为基类，析构函数要设置成 `virtual`，然后在派生类中重写该函数，来实现多态。但此时，析构函数是私有的，派生类中无法访问。

+ 解决方法 2：
  构造函数设置为 `protected`，并提供一个 `public` 的静态函数来完成构造，而不是在类的外部使用 `new` 构造；将析构函数设置为 `protected`。原因：类似于单例模式，也保证了在派生类中能够访问析构函数。通过调用 `create()` 函数在堆上创建对象。

```C++ []
class A
{
protected:
    A() {}
    ~A() {}

public:
    static A *create()
    {
        return new A();
    }
    void destroy()
    {
        delete this;
    }
};
```

2. 限制对象只能建立在栈上：

+ 解决方法：将 `operator new()` 设置为私有。原因：当对象建立在堆上时，是采用 `new` 的方式进行建立，其底层会调用 `operator new()` 函数，因此只要对该函数加以限制，就能够防止对象建立在堆上。

```C++ []
class A
{
private:
    void *operator new(size_t t) {}    // 注意函数的第一个参数和返回值都是固定的
    void operator delete(void *ptr) {} // 重载了 new 就需要重载 delete
public:
    A() {}
    ~A() {}
};
```

## 空类字节数及对应生成的成员函数
1. 空类声明时编译器不会生成任何成员函数：
   对于空类，声明编译器不会生成任何的成员函数，只会生成 `1` 个字节的占位符。由于在实际程序中，空类同样可以被实例化，而每个实例在内存中都有一个独一无二的地址，为了达到这个目的，编译器往往会给一个空类隐含的加一个字节，这样空类在实例化后在内存得到了独一无二的地址，所以 `sizeof(A)` 的大小为 `1`。

```C++ []
#include <iostream>
using namespace std;

class A
{
};

int main()
{
    A a;
    cout << "sizeof(A):" << sizeof(a) << endl; // sizeof(A):1
    return 0;
}
```

2. 空类定义时编译器会生成 6 个成员函数：    
   当空类 `A` 定义对象时，`sizeof(A)` 仍是为 `1`，但编译器会在需要时生成 `6` 个成员函数：缺省的构造函数、拷贝构造函数、析构函数、赋值运算符、两个取址运算符。

```C++ []
#include <iostream>
using namespace std;
/*
class A
{}; 该空类的等价写法如下：
*/
class A
{
public:
    A(){};                                       // 缺省构造函数
    A(const A &tmp){};                           // 拷贝构造函数
    ~A(){};                                      // 析构函数
    A &operator=(const A &tmp){};                // 赋值运算符
    A *operator&() { return this; };             // 取址运算符
    const A *operator&() const { return this; }; // 取址运算符（const 版本）
};

int main()
{
    A *p = new A(); 
    cout << "sizeof(A):" << sizeof(A) << endl; // sizeof(A):1
    delete p;       
    return 0;
}
```

参考资料：

+ [C++中空类详解](https://blog.csdn.net/zhouyiqiu1990/article/details/123846356)

## 类的大小
1. 类大小的计算:
   说明：类的大小是指类的实例化对象的大小，用 `sizeof` 对类型名操作时，结果是该类型的对象的大小。计算原则如下：

+ 遵循结构体的成员变量对齐原则。
+ 与普通成员变量有关，与成员函数和静态成员无关。即普通成员函数，静态成员函数，静态数据成员，静态常量数据成员均对类的大小无影响。因为静态数据成员被类的对象共享，并不属于哪个具体的对象。
+ 虚函数对类的大小有影响，是因为虚函数表指针的影响。
+ 虚继承对类的大小有影响，是因为虚基表指针带来的影响。
+ 空类的大小是一个特殊情况，空类的大小为 `1`，空类同样可以被实例化，而每个实例在内存中都有一个独一无二的地址，为了达到这个目的，编译器往往会给一个空类隐含的加一个字节，这样空类在实例化后在内存得到了独一无二的地址，所以`sizeof(A)` 的大小为 `1`。

2. 简单情况和空类情况:

```C++ []
/*
说明：程序是在 64 位编译器下测试的
*/
#include <iostream>

using namespace std;

class A
{
private:
    static int s_var; // 不影响类的大小
    const int c_var;  // 4 字节
    int var;          // 8 字节 4 + 4 (int) = 8
    char var1;        // 12 字节 8 + 1 (char) + 3 (填充) = 12
public:
    A(int temp) : c_var(temp) {} // 不影响类的大小
    ~A() {}                    // 不影响类的大小
};

class B
{
};
int main()
{
    A ex1(4);
    B ex2;
    cout << sizeof(ex1) << endl; // 12 字节
    cout << sizeof(ex2) << endl; // 1 字节
    return 0;
}
```

3. 带有虚函数的情况：
   注意：虚函数的个数并不影响所占内存的大小，因为类对象的内存中只保存了指向虚函数表的指针。由于不同平台、不同编译器厂商所生成的虚表指针在内存中的布局是不同的，有些将虚表指针置于对象内存中的开头处，有些则置于结尾处。在 `X64 GCC` 编译器下，虚指针在类的开头出，我们可以通过偏移量获取。
   程序示例，我们通过对象内存的开头处取出 `vptr`，并遍历对象虚函数表。

```C++ []
/*
说明：程序是在 64 位编译器下测试的
*/
#include <iostream>

using namespace std;

class A
{
private:
    static int s_var; // 不影响类的大小
    const int c_var;  // 4 字节
    int var;          // 8 字节 4 + 4 (int) = 8
    char var1;        // 12 字节 8 + 1 (char) + 3 (填充) = 12
public:
    A(int temp) : c_var(temp) {} // 不影响类的大小
    ~A() {}                      // 不影响类的大小
    virtual void f() { cout << "A::f" << endl; }

    virtual void g() { cout << "A::g" << endl; }

    virtual void h() { cout << "A::h" << endl; } // 24 字节 12 + 4 (填充) + 8 (指向虚函数的指针) = 24
};

typedef void (*func)(void);

void printVtable(unsigned long *vptr, int offset) {
	func fn = (func)*((unsigned long*)(*vptr) + offset);
	fn();	
}

int main()
{
    A ex1(4);
    A *p;
    cout << sizeof(p) << endl;   // 8 字节 注意：指针所占的空间和指针指向的数据类型无关
    cout << sizeof(ex1) << endl; // 24 字节
    unsigned long* vPtr = (unsigned long*)(&ex1);
    printVtable(vPtr, 0);
	printVtable(vPtr, 1);
	printVtable(vPtr, 2);
    return 0;
}
/*
8
24
A::f
A::g
A::h
*/
```

4. 含有虚继承的情况：

+ 不包含虚继承的情况，派生类直接继承了基类的成员变量，内存分布如下:
![4_17_1.png](https://pic.leetcode-cn.com/1661311121-oxqPRC-4_17_1.png)

```C++ []
#include <iostream>
using namespace std;

class A
{
public:
     int a;
};

class B : public A
{
public:
    int b;
    void bPrintf() {
    std::cout << "This is class B" << "\n";
    }
};

int main(){
    A a;
    B b;
    cout<<sizeof(a)<<endl;
    cout<<sizeof(b)<<endl;
    return 0;
}
/*
4
8
*/
```

+ 如果加入虚继承，此时对象中多了一个指向虚基类表的指针，对象 `B` 与对象 `C` 均多了一个指针变量 `vbptr`。

```C++ []
#include <iostream>
using namespace std; // 采用 4 字节对齐

#pragma pack(4)
class A
{
public:
     int a;
};

class B : virtual public A
{
public:
    int b;
    void bPrintf() {
    std::cout << "This is class B" << "\n";}
};

class C : virtual public A
{
public:
    int c;
    void cPrintf() {
    std::cout << "This is class C" << "\n";}
};

class D : public B, public C
{
public:
    int d;
    void dPrintf() {
    std::cout << "This is class D" << "\n";}
};

int main(){
    A a;
    B b;
    C c;
    D d;
    cout<<sizeof(a)<<endl;
    cout<<sizeof(b)<<endl;
    cout<<sizeof(c)<<endl;
    cout<<sizeof(d)<<endl;
    return 0;
}
/*
4
16
16
32
*/
```

我们可以看到:
实际的内存布局如下:
![4_17_2.png](https://pic.leetcode-cn.com/1661311144-AqbyVt-4_17_2.png)
虚基类表的填充内容如下:

+ 第一项表示派生类对象指针相对于虚基类表指针 `vbptr` 的偏移，在图中我们可以看到在 `B` 中，`B` 的起始地址相对于 `vptr` 的偏移量为 `12`；
+ 从第二项开始表示各个基类的地址相对于虚基类表指针 `vbptr` 的偏移，在图中我们可以看到在 `B` 中，`A` 的起始地址相对于 `vptr` 的偏移量为 `12`；
  虚继承的情况就比较复杂，虚继承需要额外加上一个指向虚基类表的指针。虚继承的基础上如果再加上虚函数，还需要额外加上虚函数表的指针占用的空间。

参考资料：

+ [C++ 虚继承实现原理（虚基类表指针与虚基类表）](https://www.cnblogs.com/zhjblogs/p/14274188.html)
+ [虚继承中，虚基类在派生类中的内存分布是如何？](https://www.zhihu.com/question/24858417?sort=created)
+ [【c++内存分布系列】虚基类表](https://www.cnblogs.com/budapeng/p/3305790.html)

## 如何让类不能被继承
+ 使用 `final` 关键字:
  使用 `final` 关键字修饰的类不能被继承。

```C++ []
#include <iostream>

using namespace std;

class Base final
{
};

class Derive: public Base{ // error: cannot derive from 'final' base 'Base' in derived type 'Derive'

};

int main()
{
    Derive ex;
    return 0;
}
```

+ 使用友元、虚继承和私有构造函数来实现

```C++ []
#include <iostream>
using namespace std;

template <typename T>
class Base{
    friend T;
private:
    Base(){
        cout << "base" << endl;
    }
    ~Base(){}
};

class B:virtual public Base<B>{   //一定注意 必须是虚继承
public:
    B(){
        cout << "B" << endl;
    }
};

class C:public B{
public:
    C(){}     // error: 'Base<T>::Base() [with T = B]' is private within this context
};


int main(){
    B b;  
    return 0;
}
```

说明：在上述代码中 `B` 类是不能被继承的类。
具体原因：

+ 虽然 `Base` 类构造函数和析构函数被声明为私有 `private`，在 `B` 类中，由于 `B` 是 `Base` 的友元，因此可以访问 `Base` 类构造函数，从而正常创建 `B` 类的对象；
+ `B` 类继承 `Base` 类采用虚继承的方式，创建 `C` 类的对象时，`C` 类的构造函数要负责 `Base` 类的构造，但是 `Base` 类的构造函数私有化了，`C` 类没有权限访问。因此，无法创建 `C` 类的对象， `B` 类是不能被继承的类。
+ 注意：在继承体系中，友元关系不能被继承，虽然 `C` 类继承了 `B` 类，`B` 类是 `Base` 类的友元，但是 `C` 类和 `Base` 类没有友元关系。


# C++ 语言特性相关
本章将重点涉及以下高频知识点：

## 左值和右值：区别、引用及转化
1. 左值与右值:

+ 左值：指表达式结束后依然存在的持久对象。可以取地址，可以通过内置（不包含重载） `&` 来获取地址，我们可以将一个右值赋给左值。
+ 右值：表达式结束就不再存在的临时对象。不可取地址，不可以通过内置（不包含重载） `&` 来获取地址。由于右值不可取地址，因此我们不能将任何值赋给右值。
+ 使用 `=` 进行赋值时，`=` 的左边必须为左值，右值只能出现在 `=` 的右边。 
  程序示例:

```C++ []
// x 是左值，666 为右值
int x = 666;   // ok 
int *y = x; // ok
int *z = &666 // error
666 = x; // error
int a = 9; // a 为左值
int b = 4; // b 为左值
int c = a + b // c 为左值 , a + b 为右值
a + b = 42; // error
```

+ 函数返回值即可以是左值，也可以是右值:

```C++ []
int setValue()
{
    return 6;
}

int global = 100;

int& setGlobal()
{
    return global;    
}
setValue() = 3; // error!
setGlobal() = 400; // OK
```


2. 左值引用和右值引用：
   引用的定义在之前的章节中已经介绍过。

+ 左值引用：
  + 左值引用可以区分为常量左值引用和非常量左值引用。左值引用的底层实现是指针实现。
  + 非常量左值引用只能绑定到非常量左值，不能绑定到常量左值和右值。如果绑定到非常量右值，就有可能指向一个已经被销毁的对象。
  + 常量左值引用能绑定到非常量左值，常量左值和右值；

```C++ []
int y = 10;
int& yref = y;  // ok
int& xref = 10; // error， 非常量左值引用绑定右值
const &xref = 10; // ok, 常量左值引用绑定右值
int a = 10;
int b = 20;
int& zref = a + b // error， a + b为右值


int &aref1 = a;  //ok, 非常量左值引用绑定非常量左值
const int &aRef2 = a; //ok, 常量左值引用绑定非常量左值
const int c = 4;   
int &cref1 = c;  // error，非常量左值不能绑定常量右值
const int &cref2 = c; //ok, 常量左值引用绑定常量左值
const int &ref2 = a + b;    //ok, 常量左值引用绑定到右值（表达式）
```

我们来观察一下函数运行:

+ 如果函数的形参定义为非常量的左值引用，则会出现错误，因为此时我们将一个左值引用绑定到右值上：

```C++ []
void fnc(int& x)
{
}
int main()
{
    fnc(10);  // error!
}
```

+ 如果函数的形参定义为常量的左值引用，则可以正常运行，因为此时我们将一个常量左值引用绑定到一个右值上：

```C++ []
void fnc(const int& x)
{
}
int main()
{
    int x = 10;
    fnc(x);   // ok!
    fnc(10);  // ok!
}
```

+ 右值引用：
  右值引用 （`Rvalue Referene`） 是 `C++ 11` 中引入的新特性 , 它实现了转移语义 （`Move Sementics`）和精确传递 （`Perfect Forwarding`），`&&` 作为右值引用的声明符。右值引用必须绑定到右值的引用，通过 `&&` 获得。右值引用只能绑定到一个将要销毁的对象上，因此可以自由地移动其资源。
  从实践角度讲，它能够完美解决 `C++` 中长久以来为人所诟病的临时对象效率问题。从语言本身讲，它健全了 `C++` 中的引用类型在左值右值方面的缺陷。从库设计者的角度讲，它给库设计者又带来了一把利器。从使用者的角度来看，可以获得效率的提升，避免对象在传递过程中重复创建。

右值引用两个主要功能：

+ 消除两个对象交互时不必要的对象拷贝，节省运算存储资源，提高效率。
+ 能够更简洁明确地定义泛型函数。

```C++ []
#include <iostream>
using namespace std;

int g_val = 10;

void ProcessValue(int &i) {                         // 左值引用
    cout << "lValue processed: " << i << endl;
}

void ProcessValue(int &&i) {                        // 右值引用
    cout << "rValue processed: " << i << endl;
}

int GetValue() { // 返回右值
    return 3; 
} 

int& getVal() { // 返回左值引用
    return g_val; 
}

int main() {
    int a = 0;
    int b = 1;
    int &alRef = a;             // 左值引用
    int &&rRef1 = 1;            // 临时对象是右值
    int &&rRef2 = GetValue();   // 调用的函数为右值
    ProcessValue(a);            // 左值
    ProcessValue(getVal());     // 左值引用
    ProcessValue(1);            // 临时对象是右值
    ProcessValue(GetValue());   // 调用的函数为右值
    ProcessValue(a+b);          // 表达式为右值
    return 0;
}
/*
lValue processed: 0
lValue processed: 10
rValue processed: 1
rValue processed: 3
rValue processed: 1
*/
```

有了右值引用后，函数调用可以写为如下，此时我们用右值引用绑定到右值上：

```C++ []
void fnc(int&& x)
{

}

int main()
{
    int x = 10;
    fnc(x);   // error, 右值引用不能绑定到左值上
    fnc(10);  // ok!
}
```


3. 左值转换成右值:

+ 左值转换为右值
  我们可以通过 `std::move` 可以将一个左值强制转化为右值，继而可以通过右值引用使用该值，以用于移动语义，从而完成将资源的所有权进行转移。

```C++ []
#include <iostream>
using namespace std;

void fun(int& tmp) 
{ 
  cout << "fun lvalue bind:" << tmp << endl; 
} 

void fun(int&& tmp) 
{ 
  cout << "fun rvalue bind:" << tmp << endl; 
} 

void fun1(int& tmp) 
{ 
  cout << "fun1 lvalue bind:" << tmp << endl; 
} 

int main() 
{ 
    int var = 11; 
    fun(12); // 右值引用
    fun(var); // 左值引用
    fun(std::move(var)); // 使用std::move转为右值引用
    fun(static_cast<int&&>(var));  // 使用static_cast转为右值引用
    fun((int&&)var); // 使用C风格强转为右值引用
    fun(std::forward<int&&>(var)); // 使用std::forwad<T&&>为右值引用
    fun1(12); // error
    return 0;
}
/*
fun rvalue bind:12
fun lvalue bind:11
fun rvalue bind:11
fun rvalue bind:11
fun rvalue bind:11
fun rvalue bind:11
*/
```

4. 引用折叠:
   通过类型别名或者通过模板参数间接定义，多重引用最终折叠成左值引用或者右值引用。有两种引用（左值和右值），所以就有四种可能的引用+引用的组合（左值 `+` 左值，左值 `+` 右值，右值 `+` 左值，右值 `+` 右值）。如果引用的引用出现在允许的语境，该双重引用会折叠成单个引用，规则如下：

+ 所有的右值引用叠加到右值引用上仍然还是一个右值引用；`T&& &&` 折叠成 `T&&`
+ 所有的其他引用类型之间的叠加都将变成左值引用。`T& &&,T&& &, T&&` 折叠成 `T&`。

```C++ []
#include <iostream>
using namespace std;

typedef int&  lref;
typedef int&& rref;

void fun(int&& tmp) 
{ 
    cout << "fun rvalue bind:" << tmp << endl; 
} 

void fun(int& tmp) 
{ 
    cout << "fun lvalue bind:" << tmp << endl; 
} 

int main() 
{ 
    int n = 11; 
    fun((lref&)n);
    fun((lref&&)n);
    fun((rref&)n);
    fun((rref&&)n);
    return 0;
}
/*
fun lvalue bind:11
fun lvalue bind:11
fun lvalue bind:11
fun rvalue bind:11
*/
```

5. 万能引用类型:
   在模板中 `T&& t` 在发生自动类型推断的时候，它是未定的引用类型（`universal references`），它既可以接受一个左值又可以接受一个右值。如果被一个左值初始化，它就是一个左值；如果它被一个右值初始化，它就是一个右值，它是左值还是右值取决于它的初始化。

示例代码如下:

```C++ []
template<typename T>
void f(T&& param); 

template<typename T>
class Test {
    Test(Test&& rhs); 
};
```

对于函数 `template<typename T>void f(T&& t)`，当参数为右值 `10` 的时候，根据 `universal references` 的特点，`t` 被一个右值初始化，那么 `t` 就是右值；当参数为左值 `x` 时，`t` 被一个左值引用初始化，那么 `t` 就是一个左值。
上面的例子中，`param` 是 `universal reference`，`rhs` 是 `Test&&` 右值引用，因为模版函数 `f` 发生了类型推断，而 `Test&&` 并没有发生类型推导，因为 `Test&&` 是确定的类型了。正是因为右值引用可能是左值也可能是右值，依赖于初始化，我们可以利用这一点来实现移动语义和完美转发。


参考资料：

+ [从4行代码看右值引用](https://www.cnblogs.com/qicosmos/p/4283455.html)
+ [谈谈C++的左值右值，左右引用，移动语意及完美转发](https://zhuanlan.zhihu.com/p/402251966)
+ [c++引用折叠](https://blog.csdn.net/kupepoem/article/details/119944958)
+ [Reference declaration](https://en.cppreference.com/w/cpp/language/reference)
+ [引用折叠和完美转发](https://zhuanlan.zhihu.com/p/50816420)
+ [Lvalues and Rvalues (C++)](https://docs.microsoft.com/en-us/cpp/cpp/lvalues-and-rvalues-visual-cpp?view=msvc-170)
+ [Reference declaration](https://en.cppreference.com/w/cpp/language/reference)
+ [Understanding lvalues and rvalues in C and C++](https://eli.thegreenplace.net/2011/12/15/understanding-lvalues-and-rvalues-in-c-and-c#id1)
+ [C++ Rvalue References Explained](http://thbecker.net/articles/rvalue_references/section_01.html)
+ [Understanding the meaning of lvalues and rvalues in C++](https://www.internalpointers.com/post/understanding-meaning-lvalues-and-rvalues-c)
+ [“New” Value Terminology](https://www.stroustrup.com/terminology.pdf)

## std::move() 函数的实现原理
1. `std::move()` 函数原型：
   `move` 函数是将任意类型的左值转为其类型的右值引用。

```C++ []
template <typename T>
typename remove_reference<T>::type&& move(T&& t)
{
	return static_cast<typename remove_reference<T>::type &&>(t);
}
```

首先需要了解一下，引用折叠原理:

+ 右值传递给上述函数的形参 `T&&` 依然是右值，即 `T&& &&` 相当于 `T&&`。
+ 左值传递给上述函数的形参 `T&&` 依然是左值，即 `T&& &` 相当于 `T&`。
  我们已经知道折叠原理，通过引用折叠原理可以知道，`move()` 函数的形参既可以是左值也可以是右值。

再次详细描述 `move` 函数的处理流程:

+ 首先利用万能模板将传入的参数 `t` 进行处理，我们知道右值经过 `T&&` 传递类型保持不变还是右值，而左值经过 `T&&` 变为普通的左值引用，以保证模板可以传递任意实参，且保持类型不变；对参数  `t` 做一次右值引用，根据引用折叠规则，右值的右值引用是右值引用，而左值的右值引用是普通的左值引用。万能模板既可以接受左值作为实参也可以接受右值作为实参。
+ 通过 `remove_refrence` 移除引用，得到参数 `t` 具体的类型 `type`；
+ 最后通过 `static_cast<>` 进行强制类型转换，返回 `type &&` 右值引用。


2. `remove_reference` 具体实现：
   `remove_reference` 主要作用是解除类型中引用并返回变量的实际类型。 

```C++ []
//原始的，最通用的版本
template <typename T> struct remove_reference{
    typedef T type;  //定义 T 的类型别名为 type
};
 
//部分版本特例化，将用于左值引用和右值引用
template <class T> struct remove_reference<T&> //左值引用
{ typedef T type; }
 
template <class T> struct remove_reference<T&&> //右值引用
{ typedef T type; }   
  
//举例如下,下列定义的a、b、c三个变量都是int类型
int i;
remove_refrence<decltype(42)>::type a;             //使用原版本，
remove_refrence<decltype(i)>::type  b;             //左值引用特例版本
remove_refrence<decltype(std::move(i))>::type  b;  //右值引用特例版本 
```

3. `forward` 的实现：
   `forward` 保证了在转发时左值右值特性不会被更改，实现完美转发。主要解决引用函数参数为右值时，传进来之后有了变量名就变成了左值。比如如下代码:

```C++ []
#include <iostream>
using namespace std;

template<typename T>
void fun(T&& tmp) 
{ 
    cout << "fun rvalue bind:" << tmp << endl; 
} 

template<typename T>
void fun(T& tmp) 
{ 
    cout << "fun lvalue bind:" << tmp << endl; 
} 

template<typename T>
void test(T&& x) {
    fun(x);
    fun(std::forward<T>(x));
}

int main() 
{ 
    int a = 10;
    test(10);
    test(a);
    return 0;
}
/*
fun lvalue bind:10
fun rvalue bind:10
fun lvalue bind:10
fun lvalue bind:10
*/
```

参数 `x` 为右值，到了函数内部则变量名则变为了左值，我们使用 `forward` 即可保留参数 `x` 的属性。
`forward` 函数实现如下:

```C++ []
  /**
   *  @brief  Forward an lvalue.
   *  @return The parameter cast to the specified type.
   *
   *  This function is used to implement "perfect forwarding".
   */
template<typename _Tp>
constexpr _Tp&&
forward(typename std::remove_reference<_Tp>::type& __t) noexcept
{ return static_cast<_Tp&&>(__t); }

/**
 *  @brief  Forward an rvalue.
 *  @return The parameter cast to the specified type.
 *
 *  This function is used to implement "perfect forwarding".
 */
template<typename _Tp>
constexpr _Tp&&
forward(typename std::remove_reference<_Tp>::type&& __t) noexcept
{
    static_assert(!std::is_lvalue_reference<_Tp>::value, "template argument"
        " substituting _Tp is an lvalue reference type");
    return static_cast<_Tp&&>(__t);
}
```

`forward` 函数的处理流程:

+ `forward` 同样利用引用折叠的特性，对参数 `t` 做一次右值引用，根据引用折叠规则，右值的右值引用是右值引用，而左值的右值引用是普通的左值引用。`forward` 的实现有两个函数：
  第一个，接受的参数是左值引用，只能接受左值。
  第二个，接受的参数是右值引用，只能接受右值。
  根据引用折叠的原理：
  + 如果传递的是左值，`_Tp` 推断为 `T &`，则返回变成`static_cast<T& &&>`，也就是 `static_cast<T&>`，所以返回的是左值引用。
  + 如果传递的是右值，`_Tp` 推断为 `T&&` 或者 `T`，则返回变成 `static_cast<T && &&>`，所以返回的是右值引用。
+ `forward` 与 `move` 最大的区别是，`move` 在进行类型转换时，利用 `remove_reference` 将外层的引用全部去掉，这样可以将 `t` 强制转换为指定类型的右值引用，而 `forward` 则利用引用折叠的技巧，巧妙的保留了变量原有的属性。
  以下示例代码就可以观察到 `move` 与 `forward` 的原理区别:

```C++ []
#include <iostream>
using namespace std;

typedef int&  lref;
typedef int&& rref;

void fun(int&& tmp) 
{ 
    cout << "fun rvalue bind:" << tmp << endl; 
} 

void fun(int& tmp) 
{ 
    cout << "fun lvalue bind:" << tmp << endl; 
} 

int main() 
{ 
    int a = 11; 
	int &b = a;
	int &&c = 100;
	fun(static_cast<lref &&>(b));
	fun(static_cast<rref &&>(c));
	fun(static_cast<int &&>(a));
	fun(static_cast<int &&>(b));
	fun(static_cast<int &&>(c));
    return 0;
}
/*
fun lvalue bind:11
fun rvalue bind:100
fun rvalue bind:11
fun rvalue bind:11
fun rvalue bind:100
*/
```

参考资料：

+ [谈谈C++的左值右值，左右引用，移动语意及完美转发](https://zhuanlan.zhihu.com/p/402251966)
+ [c++引用折叠](https://blog.csdn.net/kupepoem/article/details/119944958)
+ [引用折叠和完美转发](https://zhuanlan.zhihu.com/p/50816420)
+ [条款23.理解move和forward](https://blog.csdn.net/qq_36553387/article/details/116885439)

## 指针及其大小、用法
1. 指针的定义:
   指针是一种变量类型，其值为另一个变量的地址，即内存位置的直接地址。就像其他变量或常量一样，必须在使用指针存储其他变量地址之前，对其进行声明。在 `64` 位计算机中，指针占 `8` 个字节空间。使用指针时可以用以下几个操作：定义一个指针变量、把变量地址赋值给指针、访问指针变量中可用地址的值。通过使用一元运算符 `*` 来返回位于操作数所指定地址的变量的值。

```C++ []
#include<iostream>

using namespace std;

int main(){
    int *p = nullptr;
    cout << sizeof(p) << endl; // 8

    char *p1 = nullptr;
    cout << sizeof(p1) << endl; // 8
    return 0;
}
```

2. 指针的用法：

+ 空指针:
  `C` 语言中定义了空指针为 `NULL`，实际是一个宏，它的值是 `0`，即 `#define NULL 0`。`C++` 中使用 `nullptr` 表示空指针，它是 `C++ 11` 中的关键字，是一种特殊类型的字面值，可以被转换成任意其他类型。
+ 指针的运算:
  + 两个同类型指针可以比较大小；
  + 两个同类型指针可以相减；
  + 指针变量可以和整数类型变量或常量相加；
  + 指针变量可以减去一个整数类型变量或常量；
  + 指针变量可以自增，自减；

```C++ []
int a[10];
int *p1 = a + 1; // 指针常量相加
int *p2 = a + 4;
bool greater = p2 > p1; // 比较大小
int offset = p2 - a; // 相减
p2++; // 自增
p1--; // 自减
```

+ 指向普通对象的指针:

```C++ []
#include <iostream>

using namespace std;

class A
{
};

int main()
{
    A *p = new A();
    return 0;
}
```

+ 指向常量对象的指针：常量指针，`const` 修饰表示指针指向的内容不能更改。

```C++ []
#include <iostream>
using namespace std;

int main(void)
{
    const int c_var = 10;
    const int * p = &c_var;
    cout << *p << endl;
    return 0;
}
```

+ 指向函数的指针：函数指针。

```C++ []
#include <iostream>
using namespace std;

int add(int a, int b){
    return a + b;
}

typedef int (*fun_p)(int, int);

int main(void)
{
    fun_p fn = add;
    cout << fn(1, 6) << endl;
    return 0;
}
```

+ 指向对象成员的指针，包括指向对象成员函数的指针和指向对象成员变量的指针。
  特别注意：定义指向成员函数的指针时，要标明指针所属的类。

```C++ []
#include <iostream>

using namespace std;

class A
{
public:
    int var1, var2; 
	static int x;
	static int get() {
		return 100;
	}

    int add(){
        return var1 + var2;
    }
};



int main()
{
    A ex;
    ex.var1 = 3;
    ex.var2 = 4;
    int *p = &ex.var1; // 指向对象成员变量的指针
    cout << *p << endl;

    int (A::*fun_p)();
	int (*fun_q)();
    fun_p = &A::add; // 指向对象非静态成员函数的指针 fun_p
	fun_q = A::get; // 指向对象静态成员函数的指针 fun_q
	cout << (ex.*fun_p)() << endl;
    cout << (*fun_q)() << endl;
    return 0;
}
```

而对于函数类型到函数指针类型的默认转换，只有当函数类型是左值的时候才行。所有对于非静态的成员函数，就不存在这种从函数类型到函数指针类型的默认转换，于是编译器也就不知道这个 `p = A::add` 该怎么确定。

+ 由于非静态成员函数指针可以有多态行为，在编译期函数地址可能无法确定。
+ 静态成员函数指针在编译期函数地址则可以确定。

+ `this` 指针：指向类的当前对象的指针常量。

```C++ []
#include <iostream>
#include <cstring>
using namespace std;

class A
{
public:
    void set_name(string tmp)
    {
        this->name = tmp;
    }
    void set_age(int tmp)
    {
        this->age = age;
    }
    void set_sex(int tmp)
    {
        this->sex = tmp;
    }
    void show()
    {
        cout << "Name: " << this->name << endl;
        cout << "Age: " << this->age << endl;
        cout << "Sex: " << this->sex << endl;
    }

private:
    string name;
    int age;
    int sex;
};

int main()
{
    A *p = new A();
    p->set_name("Alice");
    p->set_age(16);
    p->set_sex(1);
    p->show();

    return 0;
}
```

参考资料：

+ [C++ 指针](https://www.runoob.com/cplusplus/cpp-pointers.html)
+ [c++指针运算](https://blog.csdn.net/maxzcl/article/details/117821601)

## 指针和引用的区别
+ 指针：指针是一个变量，它保存另一个变量的内存地址。需要使用 `*` 运算符指针才能访问它指向的内存位置。 
+ 引用：引用变量是别名，即已存在变量的另一个名称。对于编译器来说，引用和指针一样，也是通过存储对象的地址来实现的。实际可以将引用视为具有自动间接寻址的常量指针，编译器自动为引用使用 `*` 运算符。

1. 二者的区别

+ 是否可变:
  指针所指向的内存空间在程序运行过程中可以改变，而引用所绑定的对象一旦初始化绑定就不能改变。
+ 是否占内存:
  指针本身在内存中占有内存空间，引用相当于变量的别名，在内存中不占内存空间（实际底层编译器可能用指针实现的引用），当我们使用 `&` 对引用取地址时，将会得到绑定对象的地址。

```C++ []
#include <iostream>
using namespace std;

int main() 
{ 
    int a = 10;
    int &b = a;
    cout<<&a<<endl;
    cout<<&b<<endl;
    return 0;
}
```

+ 是否可为空：
  指针可以定义时不用初始化直接悬空，但是引用初始化时必须绑定对象。
+ 是否能为多级
  指针可以有多级，但是引用只能一级。我们可以定义指针的指针，但不能定义引用的引用。

参考资料：

+ [Differences between pointers and references in C++](https://www.educative.io/answers/differences-between-pointers-and-references-in-cpp)
+ [Pointers vs References in C++](https://www.***.org/pointers-vs-references-cpp/)
+ [What are the differences between a pointer variable and a reference variable?](https://stackoverflow.com/questions/57483/what-are-the-differences-between-a-pointer-variable-and-a-reference-variable)

## 常量指针和指针常量的区别
1. 常量指针：
   常量指针本质上是个指针，只不过这个指针指向的对象是常量。
   特点：`const` 的位置在指针声明运算符 `*` 的左侧。只要 `const` 位于 `*` 的左侧，无论它在类型名的左边或右边，都表示指向常量的指针。（可以这样理解：`*` 左侧表示指针指向的对象，该对象为常量，那么该指针为常量指针。）

```C++ []
const int * p;
int const * p;
```

+ `注意 1`：指针指向的对象不能通过这个指针来修改，也就是说常量指针可以被赋值为变量的地址，之所以叫做常量指针，是限制了通过这个指针修改变量的值。
  例如：

```C++ []
#include <iostream>
using namespace std;

int main()
{
    const int c_var = 8;
    const int *p = &c_var; 
    *p = 6;            // error: assignment of read-only location '* p'
    return 0;
}
```

+ `注意 2`：虽然常量指针指向的对象不能变化，可是因为常量指针本身是一个变量，因此，可以被重新赋值。
  例如：

```C++ []
#include <iostream>
using namespace std;

int main()
{
    const int c_var1 = 8;
    const int c_var2 = 8;
    const int *p = &c_var1; 
    p = &c_var2;
    return 0;
}
```

2. 指针常量：
   指针常量的本质上是个常量，只不过这个常量的值是一个指针。
   特点：`const` 位于指针声明操作符右侧，表明该对象本身是一个常量，`*` 左侧表示该指针指向的类型，即以 `*` 为分界线，其左侧表示指针指向的类型，右侧表示指针本身的性质。

```C++ []
const int var;
int * const c_p = &var; 
```

+ `注意 1`：指针常量的值是指针，这个值因为是常量，所以指针本身不能改变。

```C++ []
#include <iostream>
using namespace std;

int main()
{
    int var, var1;
    int * const c_p = &var;
    c_p = &var1; // error: assignment of read-only variable 'c_p'
    return 0;
}
```

+ `注意 2`：指针的内容可以改变。

```C++ []
#include <iostream>
using namespace std;

int main()
{
    int var = 3;
    int * const c_p = &var;
    *c_p = 12; 
    return 0;
}
```

3. 指向常量的指针常量:
   指向常量的指针常量，指针的指向不可修改，指针所指的内存区域中的值也不可修改。

```C++ []
#include <iostream>
using namespace std;

int main()
{
    int var, var1;
    const int * const c_p = &var;
    c_p = &var1; // error: assignment of read-only variable 'c_p'
    *c_p = 12; // error: assignment of read-only location '*c_p'
    return 0;
}
```

4. 部分特例:
   根据前三部分的结论，我们可以得到以下代码的表示内容:

```C++ []
int ** const p;  // p 是一指针常量，它是一个指向指针的指针常量；
int * const * p; // p 是一个指针，它是一个指向指针常量的指针；
int const ** p;  // p 是一个指针，它是一个指向常量的指针的指针；
int * const * const p; // p 是一指针常量，它是一个指向指针常量的指针常量；
```

参考资料：

+ [What is the difference between const int*, const int * const, and int const *?](https://stackoverflow.com/questions/1143262/what-is-the-difference-between-const-int-const-int-const-and-int-const)
+ [9.8 — Pointers and const](https://www.learncpp.com/cpp-tutorial/pointers-and-const/)
+ [Difference between const int*, const int * const, and int const *](https://www.***.org/difference-between-const-int-const-int-const-and-int-const/)

## 函数指针的定义
1. 函数指针：
   函数指针本质是一个指针变量，只不过这个指针指向一个函数。函数指针即指向函数的指针。我们知道所有的函数最终的编译都生成代码段，每个函数的都只是代码段中一部分而已，在每个函数在代码段中都有其调用的起始地址与结束地址，因此我们可以用指针变量指向函数的在代码段中的起始地址。

```C++ []
#include <iostream>
using namespace std;
int fun1(int tmp1, int tmp2)
{
  return tmp1 * tmp2;
}
int fun2(int tmp1, int tmp2)
{
  return tmp1 / tmp2;
}

int main()
{
  int (*fun)(int x, int y); 
  fun = fun1; // ok
  fun = &fun1; // ok 两种写法均可以
  cout << fun(15, 5) << endl; 
  fun = fun2;
  cout << fun(15, 5) << endl; 
  cout<<sizeof(fun1)<<endl; // error
  cout<<sizeof(&fun1)<<endl;
  return 0;
}
/*
运行结果：
75
3
*/
```

需要注意的是，对于 `fun1` 和 `&fun1`:

+ 函数名 `fun1` 存放的是函数的首地址，它是一个函数类型 `void`，`&fun1` 表示一个指向函数对象 `fun1` 的地址，是一个指针类型。它的类型是 `int (*)(int,int)`，因此 `fun1` 和 `&fun1` 的值是一样的；
+ `&fun1` 是一个表达式，函数此时作为一个对象，取对象的地址，该表达式的值是一个指针。
+ 通过打印 `sizeof` 即可知道 `fun1` 与 `&fun1` 的区别；

参考资料：

+ [为什么c语言中对函数名取地址和解引用得到的值一样？](https://www.zhihu.com/question/293674445)
+ [Use of '&' operator before a function name in C++](https://stackoverflow.com/questions/23776784/use-of-operator-before-a-function-name-in-c)

## 参数传递中：值传递、引用传递、指针传递的区别
1. 参数传递的三种方式：

+ 值传递：形参是实参的拷贝，函数对形参的所有操作不会影响实参。形参是实参的拷贝，改变形参的值并不会影响外部实参的值。从被调用函数的角度来说，值传递是单向的（实参->形参），参数的值只能传入。当函数内部可能需要改变参数具体的内容时，我们则采用形参，在组成原理上来说，对于值传递的方式我们采用直接寻址。
+ 指针传递：本质上是值传递，只不过拷贝的是指针的值，拷贝之后实参和形参是不同的指针，但指向的地址都相同。通过指针可以间接的访问指针所指向的对象，从而可以修改它所指对象的值。在组成原理上来说，对于指针传递的方式一般采用间接寻址。
+ 引用传递：当形参是引用类型时，我们说它对应的实参被引用传递。当然不同的编译器对于引用有不同的实现，部分编译器在底层也是使用指针来实现引用传递。

```C++ []
#include <iostream>
using namespace std;

void fun1(int tmp){ // 值传递
    cout << &tmp << endl;
}

void fun2(int * tmp){ // 指针传递
    cout << tmp << endl;
}

void fun3(int &tmp){ // 引用传递
    cout << &tmp << endl;
}

int main()
{
    int var = 5;
    cout << "var 在主函数中的地址：" << &var << endl;

    cout << "var 值传递时的地址：";
    fun1(var);

    cout << "var 指针传递时的地址：";
    fun2(&var);

    cout << "var 引用传递时的地址：";
    fun3(var);
    return 0;
}

/*
运行结果：
var 在主函数中的地址：0x23fe4c
var 值传递时的地址：0x23fe20
var 指针传递时的地址：0x23fe4c
var 引用传递时的地址：0x23fe4c
*/
```

说明：从上述代码的运行结果可以看出，只有在值传递时，形参和实参的地址不一样，在函数体内操作的不是变量本身。引用传递和指针传递，在函数体内操作的是变量本身。
我们知道函数调用的方式，大部分的编译器按照函数形参定义的逆序，依次将参数压入栈内，上述提到参数的形式，如果是值传递，则压入栈中的是一个临时变量，该变量与传入的值内容相同；如果是指针传递或者引用传递，则压入栈的可能是一个临时的指针变量，该指针指向与传入的指针指向的内容相同。从函数调用机制来开，不管何种调用所有实参的传入时都在栈中开辟了空间。


参考资料：

+ [c++值传递，指针传递，引用传递以及指针与引用的区别](https://www.cnblogs.com/huolong-blog/p/7588335.html)
+ [C++中引用传递与指针传递区别（进一步整理）](https://www.iteye.com/blog/xinklabi-653643)

## 迭代器的作用
迭代器：一种抽象的设计概念，在设计模式中有迭代器模式，即提供一种方法，使之能够依序寻访某个容器所含的各个元素，而无需暴露该容器的内部表述方式。迭代器只是一种概念上的抽象，具有迭代器通用功能和方法的对象都可以叫做迭代器。迭代器有很多不同的能力，可以把抽象容器和通用算法有机的统一起来。迭代器基本分为五种，输入输出迭代器，前向逆向迭代器，双向迭代器和随机迭代器。

+ 输入迭代器(`Input Iterator`)：只能向前单步迭代元素，不允许修改由该迭代器所引用的元素；
+ 输出迭代器(`Output Iterator`)：只能向前单步迭代元素，对由该迭代器所引用的元素只有写权限；
+ 向前迭代器(`Forward Iterator`)：该迭代器可以在一个区间中进行读写操作，它拥有输入迭代器的所有特性和输出迭代器的部分特性，以及向前单步迭代元素的能力；
+ 双向迭代器(`Bidirectional Iterator`)：在向前迭代器的基础上增加了向后单步迭代元素的能力；
+ 随机访问迭代器(`Random Access Iterator`)：不仅综合以后 `4` 种迭代器的所有功能，还可以像指针那样进行算术计算；
  在 `C++ STL` 中，容器 `vector`、`deque` 提供随机访问迭代器，`list` 提供双向迭代器，`set` 和 `map` 提供向前迭代器。
![5_17_1.png](https://pic.leetcode-cn.com/1661515579-ASMhMu-5_17_1.png)

使用迭代器的优点：

+ 代码编写方便：迭代器提供了通用接口来遍历元素，不用担心容器的大小，使用迭代器我们可以简单地使用成员函数 `end()` 来判断容器的结尾，遍历内容方便而简洁；
+ 代码可重用性高：：迭代器提供了一组通用的 `api` 访问和遍历容器中的元素。迭代器支持代码的可重用性，它们可以被使用访问任何容器的元素。
+ 容器可以动态处理：迭代器能够在需要时方便地从容器中动态添加或删除元素。


程序实例：

```C++ []
#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int> arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 0};
    vector<int>::iterator iter = arr.begin(); // 定义迭代器
    for (; iter != arr.end(); ++iter)
    {
        cout << *iter << " ";
    }
    return 0;
}
/*
运行结果：
1 2 3 4 5 6 7 8 9 0
*/
```

参考资料：

+ [Introduction to Iterators in C++](https://www.***.org/introduction-iterators-c/)
+ [iterator](https://cplusplus.com/reference/iterator/)
+ [Iterators in C++ STL](https://www.***.org/iterators-c-stl/)
+ [std::iterator](https://en.cppreference.com/w/cpp/iterator/iterator)
+ [C++ Iterators](https://users.cs.northwestern.edu/~riesbeck/programming/c++/stl-iterators.html)

## 野指针和悬空指针详解
+ 悬空指针：
  若指针指向一块内存空间，当这块内存空间被释放后，该指针依然指向这块内存空间，此时，称该指针为“悬空指针”。如果对悬空指针再次释放可能会出现不可预估的错误，比如可能该段内存被别的程序申请使用了，而此时对该段内存进行释放可能会产生不可预估的后果。
  举例：

```C++ []
void *p = malloc(size);
free(p); // 此时，p 指向的内存空间已释放， p 就是悬空指针。
p = NULL;
```

+ 野指针：
  “野指针” 是指不确定其指向的指针，未初始化的指针为“野指针”，未初始化的指针的初始值可能是随机的，如果使用未初始化的指针可能会导致段错误，从而程序会崩溃。

```C++ []
void *p; 
// 此时 p 是“野指针”。
```

+ 如何避免野指针:
  指针在定义时即初始化，指针在释放完成后，需要将其置为空。

参考资料：

+ [野指针](https://baike.baidu.com/item/%E9%87%8E%E6%8C%87%E9%92%88/9654046?fr=aladdin)
+ [What are Wild Pointers? How can we avoid?](https://www.***.org/what-are-wild-pointers-how-can-we-avoid/)
+ [What are Wild Pointers in C/C++?](https://www.tutorialspoint.com/what-are-wild-pointers-in-c-cplusplus)

## 强制类型转换的类型
1. `static_cast`：
   `static_cast` 是“静态转换”的意思，也即在编译期间转换，转换失败的话会抛出一个编译错误。一般用于如下:

+ 用于数据的强制类型转换，强制将一种数据类型转换为另一种数据类型。
+ 用于基本数据类型的转换。
+ 用于类层次之间的基类和派生类之间指针或者引用的转换（不要求必须包含虚函数，但必须是有相互联系的类），进行上行转换（派生类的指针或引用转换成基类表示）是安全的；进行下行转换（基类的指针或引用转换成派生类表示）由于没有动态类型检查，所以是不安全的，最好用 `dynamic_cast` 进行下行转换。
+ 可以将空指针转化成目标类型的空指针。
+ 可以将任何类型的表达式转化成 `void` 类型。
+ 不能用于在不同类型的指针之间互相转换，也不能用于整型和指针之间的互相转换，当然也不能用于不同类型的引用之间的转换。

2. `const_cast`：
   主要用于 `const` 与非 `const`、`volatile` 与非 `volatile` 之间的转换。强制去掉常量属性，不能用于去掉变量的常量性，只能用于去除指针或引用的常量性，将常量指针转化为非常量指针或者将常量引用转化为非常量引用（注意：表达式的类型和要转化的类型是相同的）。

3. `reinterpret_cast`：
   改变指针或引用的类型、将指针或引用转换为一个足够长度的整型、将整型转化为指针或引用类型。`reinterpret_cast` 转换时，执行的过程是逐个比特复制的操作。

4. `dynamic_cast`：

+ 其他三种都是编译时完成的，动态类型转换是在程序运行时处理的，运行时会进行类型检查。
+ 只能用于带有虚函数的基类或派生类的指针或者引用对象的转换，转换成功返回指向类型的指针或引用，转换失败返回 `NULL`；不能用于基本数据类型的转换。
+ 在向上进行转换时，即派生类的指针转换成基类的指针和 `static_cast` 效果是一样的，（注意：这里只是改变了指针的类型，指针指向的对象的类型并未发生改变）。

```C++ []
#include <iostream>
#include <cstring>

using namespace std;

class Base
{
};

class Derive : public Base
{
};

int main()
{
    Base *p1 = new Derive();
    Derive *p2 = new Derive();

    //向上类型转换
    p1 = dynamic_cast<Base *>(p2);
    if (p1 == NULL)
    {
        cout << "NULL" << endl;
    }
    else
    {
        cout << "NOT NULL" << endl; //输出
    }

    return 0;
}
```

+ 在下行转换时，基类的指针类型转化为派生类的指针类型，只有当要转换的指针指向的对象类型和转化以后的对象类型相同时，才会转化成功。

```C++ []
#include <iostream>
#include <cstring>

using namespace std;

class Base
{
public:
    virtual void fun()
    {
        cout << "Base::fun()" << endl;
    }
};

class Derive : public Base
{
public:
    virtual void fun()
    {
        cout << "Derive::fun()" << endl;
    }
};

int main()
{
    Base *p1 = new Derive();
    Base *p2 = new Base();
    Derive *p3 = new Derive();

    //转换成功
    p3 = dynamic_cast<Derive *>(p1);
    if (p3 == NULL)
    {
        cout << "NULL" << endl;
    }
    else
    {
        cout << "NOT NULL" << endl; // 输出
    }

    //转换失败
    p3 = dynamic_cast<Derive *>(p2);
    if (p3 == NULL)
    {
        cout << "NULL" << endl; // 输出
    }
    else
    {
        cout << "NOT NULL" << endl;
    }

    return 0;
}
```


参考资料：

+ [为什么说不要使用 dynamic_cast，需要运行时确定类型信息，说明设计有缺陷？](https://www.zhihu.com/question/22445339)
+ [C++四种类型转换运算符：static_cast、dynamic_cast、const_cast和reinterpret_cast](http://c.biancheng.net/cpp/biancheng/view/3297.html)
+ [static_cast reinterpret_cast dynamic_cast const_cast](https://zhuanlan.zhihu.com/p/352766472)
+ [(C++ 成长记录) —— C++强制类型转换运算符（static_cast、reinterpret_cast、const_cast和dynamic_cast）](https://zhuanlan.zhihu.com/p/368267441)
+ [When should static_cast, dynamic_cast, const_cast, and reinterpret_cast be used?](https://stackoverflow.com/questions/332030/when-should-static-cast-dynamic-cast-const-cast-and-reinterpret-cast-be-used)
+ [C++中的类型转换（static_cast、const_cast、dynamic_cast、reinterpret_cast）](https://blog.csdn.net/u012611878/article/details/78992132)
+ [Cast Operations](https://docs.oracle.com/cd/E19422-01/819-3690/Cast.html)

## 什么是类型萃取
类型萃取（`type traits`）使用模板技术来萃取类型（包含自定义类型和内置类型）的某些特性，用以判断该类型是否含有某些特性，从而在泛型算法中来对该类型进行特殊的处理用来提高效率或者得到其他优化。简单的来说类型萃取即确定变量去除引用修饰以后的真正的变量类型或者 `CV` 属性。`C++` 关于 `type traits` 的详细使用技巧可以参考头文件 `#include <type_traits>`。

+ 为什么需要 `type traits`：

  对于普通的变量来说，确定变量的类型比较容易，比如 `int a = 10;` 可以很容易确定变量的实际类型为 `int`，但在使用模板时确定变量的类型就比较困难，模板传入的类型为不确定性。为什么需要确定变量的实际类型？因为模板函数针对传入的对不同的类型可能作出不同的处理，这就需要我们在处理函数模板对传入的参数类型和特性进行提取。比如自定义拷贝函数 `copy(T *dest, const T *src)` ，如果 `T` 此时为 `int` 类型，则此时我们只需要 `*dest = *src` 即可，但是如果我们此时传入的 `T` 为 `char *` 字符串类型时，则就不能简单进行指针赋值，所以函数在实际处理时则需要对传入的类型进行甄别，从而针对不同的类型给予不同的处理，这样才能使得函数具有通用性。

+ `remove_reference_t` 的原理：
  `move` 函数在进行强制类型转换时，会使用到 `remove_reference_t`，该函数的作用是确定函数除去 `C-V` 和引用后的类型。以下为 `move` 的具体实现:

  ```C++ []
  template<typename T>
  remove_reference_t<T>&& move(T&& t) {
      return static_cast<remove_reference_t<T>&&>(t);
  }
  ```

  通过 `remove_reference_t<T>` 可以把 `t` 对应的类型上的引用给去掉，然后把 `t` 对应的类型的右值引用符号 `&&` 强制绑定在变量 `t` 上，这样就强制将变量 `t` 转换为右值引用类型。`remove_reference` 函数的原型如下:

  ```C++ []
  /// remove_reference
  template<typename _Tp>
  struct remove_reference
  { typedef _Tp   type; };
  
  template<typename _Tp>
  struct remove_reference<_Tp&>
  { typedef _Tp   type; };
  
  template<typename _Tp>
  struct remove_reference < _Tp&& >
  { typedef _Tp   type; };
  ```

  函数的实现非常简单，去掉绑定在类型中的引用，返回一个 实际类型 `type`。

+ `C++` 类型萃取一般用于模板中，当我们定义一个模板函数后，需要知道模板类型形参并加以运用时就奥数可以用类型萃取。通过确定变量的特征我们可以在模板中使用不同的处理方法。

参考资料：

+ [Type Traits](https://www.youtube.com/watch?v=eVtLOHoDbTo)
+ [A quick primer on type traits in modern C++](https://www.internalpointers.com/post/quick-primer-type-traits-modern-cpp)
+ [C++之类型萃取](https://blog.csdn.net/xuzhangze/article/details/78374890)

## C++ 11 nullptr 比 NULL 的优势比较
+ `NULL`：预处理变量，是一个宏，它的值是 `0`，定义在头文件 `<cstdlib>` 中，即 `#define NULL 0`。
+ `nullptr`：`C++ 11` 中的关键字，是一种特殊类型的字面值，可以被转换成任意其他类型。

二者相比 `nullptr` 的优势：

+ 有类型，类型是 `typdef decltype(nullptr) nullptr_t;`，使用 `nullptr` 提高代码的健壮性。
+ 函数重载：因为 `NULL` 本质上是 `0`，在函数调用过程中，若出现函数重载并且传递的实参是 `NULL`，可能会出现不知和哪一个函数匹配的情况；但是传递实参 `nullptr` 就不会出现这种情况。

```C++ []
#include <iostream>
#include <cstring>
using namespace std;

void fun(char const *p)
{
    cout << "fun(char const *p)" << endl;
}

void fun(int tmp)
{
    cout << "fun(int tmp)" << endl;
}

int main()
{
    fun(nullptr); // fun(char const *p)
    /*
    fun(NULL); // error: call of overloaded 'fun(NULL)' is ambiguous
    */
    return 0;
}
```


参考资料：

+ [nullptr (C++/CLI and C++/CX)](https://docs.microsoft.com/en-us/cpp/extensions/nullptr-cpp-component-extensions?view=msvc-170)
+ [Understanding nullptr in C++](https://www.***.org/understanding-nullptr-c/)

## 结构体相等的判断方式及 memcmp 函数的使用
1. 符号重载：
   需要重载操作符 `==` 判断两个结构体是否相等，不能用函数 `memcmp` 来判断两个结构体是否相等，因为 `memcmp` 函数是逐个字节进行比较的，而结构体存在内存空间中保存时存在字节对齐，字节对齐时补的字节内容是随机的，会产生垃圾值，所以无法比较。
   利用运算符重载来实现结构体对象的比较：

```C++
#include <iostream>

using namespace std;

struct A
{
    char c;
    int val;
    A(char c_tmp, int tmp) : c(c_tmp), val(tmp) {}

    friend bool operator==(const A &tmp1, const A &tmp2); //  友元运算符重载函数
};

bool operator==(const A &tmp1, const A &tmp2)
{
    return (tmp1.c == tmp2.c && tmp1.val == tmp2.val);
}

int main()
{
    A ex1('a', 90), ex2('b', 80);
    if (ex1 == ex2)
        cout << "ex1 == ex2" << endl;
    else
        cout << "ex1 != ex2" << endl; // 输出
    return 0;
}
```

参考资料：

+ [判断结构体相等](https://www.jianshu.com/p/857703dcc7db?utm_campaign=maleskine&utm_content=note&utm_medium=seo_notes&utm_source=recommendation)
+ [No == operator found while comparing structs in C++](https://stackoverflow.com/questions/5740310/no-operator-found-while-comparing-structs-in-c)

## 模板及其实现
1. 模板：创建类或者函数的蓝图或者公式，分为函数模板和类模板。
   实现方式：模板定义以关键字 `template` 开始，后跟一个模板参数列表。
   模板参数列表不能为空；
   模板类型参数前必须使用关键字 `class` 或者 `typename`，在模板参数列表中这两个关键字含义相同，可互换使用。

```C++ []
template <typename T, typename U, ...>
```

2. 函数模板：通过定义一个函数模板，可以避免为每一种类型定义一个新函数。

+ 对于函数模板而言，模板类型参数可以用来指定返回类型或函数的参数类型，以及在函数体内用于变量声明或类型转换。
+ 函数模板实例化：当调用一个模板时，编译器用函数实参来推断模板实参，从而使用实参的类型来确定绑定到模板参数的类型。

```C++ []
#include<iostream>

using namespace std;

template <typename T>
T add_fun(const T & tmp1, const T & tmp2){
    return tmp1 + tmp2;
}

int main(){
    int var1, var2;
    cin >> var1 >> var2;
    cout << add_fun(var1, var2);

    double var3, var4;
    cin >> var3 >> var4;
    cout << add_fun(var3, var4);
    return 0;
}
```

3. 类模板：类似函数模板，类模板以关键字 `template` 开始，后跟模板参数列表。但是，编译器不能为类模板推断模板参数类型，需要在使用该类模板时，在模板名后面的尖括号中指明类型。

```C++ []
#include <iostream>

using namespace std;

template <typename T>
class Complex
{
public:
    //构造函数
    Complex(T a, T b)
    {
        this->a = a;
        this->b = b;
    }

    //运算符重载
    Complex<T> operator+(Complex &c)
    {
        Complex<T> tmp(this->a + c.a, this->b + c.b);
        cout << tmp.a << " " << tmp.b << endl;
        return tmp;
    }

private:
    T a;
    T b;
};

int main()
{
    Complex<int> a(10, 20);
    Complex<int> b(20, 30);
    Complex<int> c = a + b;

    return 0;
}
```

4. 变量模板：
   在 `C++14` 以后，变量也可以参数化为特定的类型，这称为变量模板。

```C++ []
template<typename T> 
constexpr T pi = T{3.141592653589793238462643383L}; // (Almost) from std::numbers::pi
```

使用变量模板时，必须显式地指定它的类型：

```C++ []
std::cout << pi<double> << '\n';
std::cout << pi<float> << '\n';
```

5. 函数重载与模板的区别:
   函数重载和模板都是面向对象多态特性的例子。当多个函数执行非常相似（不相同）的操作时使用函数重载，当多个函数执行相同操作时使用模板，函数模板也可以重载。当模板类或者模板函数中含有静态变量时，则每个模板的实例类型都含有一个静态成员。

```C++ []
template <class T>
class A { 
  public: 
	static T val; 
}; 
A<int> a; // 含有静态成员 int val;
A<string> b; // 含有静态成员 string val;
```

参考资料：

+ [Templates in C++ with Examples](https://www.***.org/templates-cpp/)
+ [C++ 模板](https://www.runoob.com/cplusplus/cpp-templates.html)
+ [Templates (C++)](https://docs.microsoft.com/en-us/cpp/cpp/templates-cpp?view=msvc-170)
+ [Template (C++)](https://en.wikipedia.org/wiki/Template_(C%2B%2B))

## 函数模板和类模板的区别
+ 实例化方式不同：函数模板实例化由编译程序在处理函数调用时自动完成，类模板实例化需要在程序中显式指定。
+ 实例化的结果不同：函数模板实例化后是一个函数，类模板实例化后是一个类。
+ 默认参数：函数模板不允许有默认参数，类模板在模板参数列表中可以有默认参数。
+ 特化：函数模板只能全特化；而类模板可以全特化，也可以偏特化。
+ 调用方式不同：函数模板可以进行类型推导，可以隐式调用，也可以显式调用；类模板只能显式调用。
  函数模板调用方式举例：

```C++
#include<iostream>

using namespace std;

template <typename T>
T add_fun(const T & tmp1, const T & tmp2){
    return tmp1 + tmp2;
}

int main(){
    int var1, var2;
    cin >> var1 >> var2;
    cout << add_fun<int>(var1, var2); // 显式调用

    double var3, var4;
    cin >> var3 >> var4;
    cout << add_fun(var3, var4); // 隐式调用
    return 0;
}
```

参考资料：

+ [函数模板与类模板](https://zhuanlan.zhihu.com/p/381299879)
+ [Difference between Class Template and Function Template](https://stackoverflow.com/questions/14040329/difference-between-class-template-and-function-template)
+ [Templates in C++ with Examples](https://www.***.org/templates-cpp/)
+ [C++ Function Template and Class Template](https://programmer.group/c-function-template-and-class-template.html)
+ [Templates in C++](https://www.mygreatlearning.com/blog/templates-in-cpp/)

## 什么是模板特化
模板特化的原因：模板并非对任何模板实参都合适、都能实例化，某些情况下，通用模板的定义对特定类型不合适，可能会编译失败，或者得不到正确的结果。因此，当不希望使用模板版本时，可以定义类或者函数模板的一个特例化版本。
模板特化：模板参数在某种特定类型下的具体实现。分为函数模板特化和类模板特化

+ 函数模板特化：将函数模板中的全部类型进行特例化，称为函数模板特化。
+ 类模板特化：将类模板中的部分或全部类型进行特例化，称为类模板特化。
  特化分为全特化和偏特化：
+ 全特化：模板中的模板参数全部特例化。
+ 偏特化：模板中的模板参数只确定了一部分，剩余部分需要在编译器编译时确定。
  说明：要区分下函数重载与函数模板特化
  定义函数模板的特化版本，本质上是接管了编译器的工作，为原函数模板定义了一个特殊实例，而不是函数重载，函数模板特化并不影响函数匹配。

实例：

```C++ []
#include <iostream>
#include <cstring>

using namespace std;
//函数模板
template <class T>
bool compare(T t1, T t2)
{
    cout << "通用版本：";
    return t1 == t2;
}

template <> //函数模板特化
bool compare(char *t1, char *t2)
{
    cout << "特化版本：";
    return strcmp(t1, t2) == 0;
}

int main(int argc, char *argv[])
{
    char arr1[] = "hello";
    char arr2[] = "abc";
    cout << compare(123, 123) << endl;
    cout << compare(arr1, arr2) << endl;

    return 0;
}
/*
运行结果：
通用版本：1
特化版本：0
*/
```

参考资料：

+ [模板特化](https://blog.csdn.net/langminglang/article/details/64160983)
+ [模板特化](https://baike.baidu.com/item/%E6%A8%A1%E6%9D%BF%E7%89%B9%E5%8C%96/18760185)

## 泛型编程如何实现
泛型编程实现的基础：模板。模板是创建类或者函数的蓝图或者说公式，当时用一个 `vector` 这样的泛型，或者 `find` 这样的泛型函数时，编译时会转化为特定的类或者函数。
泛型编程涉及到的知识点较广，例如：容器、迭代器、算法等都是泛型编程的实现实例。面试者可选择自己掌握比较扎实的一方面进行展开。

+ 容器：涉及到 `STL` 中的容器，例如：`vector`、`list`、`map` 等，可选其中熟悉底层原理的容器进行展开讲解。
+ 迭代器：在无需知道容器底层原理的情况下，遍历容器中的元素。
+ 模板：可参考本章节中的模板相关问题。

泛型编程优缺点：

+ 通用性强：泛型算法是建立在语法一致性上，运用到的类型集是无限的/非绑定的。

+ 效率高：编译期能确定静态类型信息，其效率与针对某特定数据类型而设计的算法相同。

+ 类型检查严：静态类型信息被完整的保存在了编译期，在编译时可以发现更多潜在的错误。

+ 二进制复用性差：泛型算法是建立在语法一致性上，语法是代码层面的，语法上的约定无法体现在机器指令中。泛型算法实现的库，其源代码基本上是必须公开的，引用泛型中库都需要重新编译生成新的机器指令。而传统的 `C` 库全是以二进制目标文件形式发布的，需要使用这些库时直接动态链接加载使用即可，不需要进行再次编译。


参考资料：

+ [泛型编程](https://baike.baidu.com/item/%E6%B3%9B%E5%9E%8B%E7%BC%96%E7%A8%8B/6787248?fr=aladdin)
+ [泛型编程](https://www.jianshu.com/p/62aa00e2be32)

## switch 的 case 里为何不建议定义变量
`switch` 下面的这个花括号表示一块作用域，而不是每一个 `case` 表示一块作用域。如果在某一 `case` 中定义了变量，其作用域在这块花括号内，按理说在另一个 `case` 内可以使用该变量，但是在实际使用时，每一个 `case` 之间互不影响，是相对封闭的，参考如下实例。

实例：
下述代码中，在 `switch` 的 `case` 中定义的变量，没有实际意义，仅为了解释上述原因。

```C++ []
#include <iostream>
using namespace std;

int main()
{
    // 局部变量声明
    char var = 'D';

    switch (var)
    {
    case 'A':
        int cnt = 0; // 定义变量
        cout << "Excellent." << endl
             << cnt;
        break;
    case 'B':
    case 'C':
        ++cnt;
        cout << "Good." << endl
             << cnt;
        break;
    case 'D':
        cout << "Not bad." << endl
             << cnt;
        break;
    case 'F':
        cout << "Bad." << endl
             << cnt;
        break;
    default:
        cout << "Bad." << endl
             << cnt;
    }

    return 0;
}
```

简单解释：上述代码中在符合 `A` 的条件下定义了变量，当符合 `B` 或者 `C` 的条件时，对该变量进行自增操作，但是因为不符合条件 `A` 未对变量进行定义，该变量无法使用。

## 什么是可变参数模板
对于可变参数函数，在 `C` 语言中我们最熟悉的就是 `printf` 函数:

```C++
int printf(const char *format, ...)
```

在 `C++` 中的模板也可以支持可变参数：
可变参数模板：接受可变数目参数的模板函数或模板类。将可变数目的参数被称为参数包，包括模板参数包和函数参数包。

+ 模板参数包：表示零个或多个模板参数；
+ 函数参数包：表示零个或多个函数参数。
  用省略号来指出一个模板参数或函数参数表示一个包，在模板参数列表中，`class...` 或 `typename...` 指出接下来的参数表示零个或多个类型的列表；一个类型名后面跟一个省略号表示零个或多个给定类型的非类型参数的列表。当需要知道包中有多少元素时，可以使用 `sizeof...` 运算符。

```C++
template <typename T, typename... Args> // Args 是模板参数包
void foo(const T &t, const Args&... rest); // 可变参数模板，rest 是函数参数包
```

实例：

```C++
#include <iostream>

using namespace std;

template <typename T>
void print_fun(const T &t)
{
    cout << t << endl; // 最后一个元素
}

template <typename T, typename... Args>
void print_fun(const T &t, const Args &...args)
{
    cout << t << " ";
    print_fun(args...);
}

int main()
{
    print_fun("Hello", "world", "!");
    return 0;
}
/*运行结果：
Hello wolrd !

*/
```

说明：可变参数函数通常是递归的，第一个版本的 `print_fun` 负责终止递归并打印初始调用中的最后一个实参。第二个版本的 `print_fun` 是可变参数版本，打印绑定到 `t` 的实参，并用来调用自身来打印函数参数包中的剩余值。


参考资料：

+ [c++11-17 模板核心知识（四）—— 可变参数模板 Variadic Template](https://zhuanlan.zhihu.com/p/338785886)
+ [可变参数模板是什么](https://www.leixue.com/qa/what-are-variable-parameter-templates)


# C++ I/O 与进程同步
本章将重点涉及以下高频知识点：

## C++ 条件变量
1. 条件变量（`condition variable`）：
   在 `C` 语言中我们使用 `pthread_cond_wait` 函数作为条件变量，它是由操作系统实现的条件变量，需要详细了解它的运行机制就可以了解 `C++` 中条件变量的实现。在 `C++ 11` 以后，我们可以使用条件变量（`condition_variable`）实现多个线程间的同步操作；当条件不满足时，相关线程被一直阻塞，直到某种条件出现，这些线程才会被唤醒。`C++` 中包含的头文件在 `#include <condition_variable>` 中。
   条件变量是利用线程间共享的全局变量进行同步的一种机制，主要包括两个动作：

  + 一个线程因等待**条件变量的条件成立**而挂起；
  + 另外一个线程使**条件成立**从而给出唤醒线程的信号，从而唤醒被等待的线程；
    为了防止竞争，条件变量的使用总是和一个互斥锁结合在一起；通常情况下这个锁是 `std::mutex`，并且管理这个锁只能是 `std::unique_lock std::mutex` 等 `RAII` 模板类。分别是使用以下两个方法实现：
+ 等待条件成立使用的是 `condition_variable` 类成员 `wait`、`wait_for` 或 `wait_until`。
+ 唤醒信号使用的是 `condition_variable` 类成员 `notify_one` 或者 `notify_all` 函数。

`condition_variable` 支持的函数如下:

+ 构造函数: 它只有默认构造函数，拷贝构造函数和赋值符号重载均被禁止 `condition_variable(const condition_variable&) = delete;`，`operator= [delete]`；

+ `wait`：`wait` 目前支持 `wait`，`wait_for`，`wait_until` 等三种操作，分别对应不同的场景:

  + `wait`: 对应的函数原型为:

  ```C++ []
  void wait( std::unique_lock<std::mutex>& lock ); 
  ```

  当前线程执行时就被阻塞，直到等到被 `notify` 唤醒。在阻塞线程的那一刻，该函数自动调用 `lck.unlock()`，允许其他被 `lck` 锁定的线程继续运行。阻塞时被一旦某个线程 `notify` 时，实际可能为虚假唤醒，该函数将解除阻塞并调用 `lck.lock()`，获取互斥锁。

  ```C++ []
  template <class Predicate>
  void wait (unique_lock<mutex>& lck, Predicate pred);
  ```

  调用时检查 `pred`，如果为 `false`, 则阻塞线程，并且调用 `lock.unlock()`, 否则，继续执行。阻塞时被一旦某个线程 `notify` 时，实际可能为虚假唤醒，该函数将再次检查 `pred`，如果为 `true`，则解除阻塞并调用 `lck.lock()`，获取互斥锁；否则继续阻塞线程。

  + `wait_for`: 对应的函数原型为:

  ```C++ []
  template< class Rep, class Period, class Predicate >
  bool wait_for( std::unique_lock<std::mutex>& lock,
      const std::chrono::duration<Rep, Period>& rel_time,
      Predicate stop_waiting);
  ```

  调用时，检查两个条件是否满足: `stop_waiting` 返回是否为 `true`，时间是否超时，如果两个条件都不满足，则阻塞线程，并调用 `lock.unlock()`, 否则，到达一定等待时间或满足条件被唤醒。注意等待超过时间段后自动唤醒，判断条件一般需要使用者自己在合适的时候判断，并通过 `notify_one()` 或 `notify_all()` 唤醒，所以在使用时应当通过判断返回值来检测是其由于超时返回还是被正常唤醒，即状态是否为 `std::cv_status::timeout`。程序示例如下:

  ```C++ []
  #include <iostream>
  #include <atomic>
  #include <condition_variable>
  #include <thread>
  #include <chrono>
  using namespace std::chrono_literals;
  
  std::condition_variable cv;
  std::mutex cv_m;
  int i;
  
  void waits(int idx)
  {
      std::unique_lock<std::mutex> lk(cv_m);
      if (cv.wait_for(lk, idx*100ms, []{return i == 1;})) {
          std::cerr << "Thread " << idx << " finished waiting. i == " << i << '\n';
      } else {
          std::cerr << "Thread " << idx << " timed out. i == " << i << '\n';
      }
  }
  
  void signals()
  {
      std::this_thread::sleep_for(120ms);
      std::cerr << "Notifying...\n";
      cv.notify_all();
      std::this_thread::sleep_for(100ms);
      {
          std::lock_guard<std::mutex> lk(cv_m);
          i = 1;
      }
      std::cerr << "Notifying again...\n";
      cv.notify_all();
  }
  
  int main()
  {
      std::thread t1(waits, 1), t2(waits, 2), t3(waits, 3), t4(signals);
      t1.join(); // t1 等待 100ms 后未被唤醒，自动超时；
      t2.join(); // t2 在 120 ms 处被唤醒，但 condition 未满足，再此进入阻塞，200ms 时由于超时返回
      t3.join(); // t3 在 120 ms 处被唤醒，但 condition 未满足，再此进入阻塞，220ms 时被 notify ，正常返回。
      t4.join();
  }
  /*
  Thread 1 timed out. i == 0
  Notifying...
  Thread 2 timed out. i == 0
  Notifying again...
  Thread 3 timed out. i == 0
  */
  ```

  + `wait_until`: 对应的函数原型为:

  ```C++ []
  template <class Predicate>
  void wait (unique_lock<mutex>& lck, Predicate pred);
  ```

  `wait_for` 是通过 `wait_until` 实现的，到达指定截止时间或满足条件 `conditions` 时线程即被唤醒。不同的是，到达时间点是自动唤醒，而条件满足 `conditions` 时则是通过 `notify_one()` 或 `notify_all()` 唤醒，使用的时候注意判断返回值，根据返回值确定该线程是被超时唤醒还是被其他线程 `notify` 正常唤醒，即状态是否为 `std::cv_status::timeout`。

+ `notify`：

  + `notify_one` 唤醒一个阻塞的线程，线程唤醒的顺序可能是随机的，并没有特定的顺序。
    `notify_one` 程序示例如下，我们可以看到每次唤醒的顺序并不是确定的:

  ```C++ []
  // condition_variable::notify_one
  #include <iostream>           // std::cout
  #include <thread>             // std::thread
  #include <mutex>              // std::mutex, std::unique_lock
  #include <condition_variable> // std::condition_variable
  
  std::mutex mtx;
  std::condition_variable produce,consume;
  
  int cargo = 0;     // shared value by producers and consumers
  
  void consumer () {
  std::unique_lock<std::mutex> lck(mtx);
  while (cargo==0) consume.wait(lck);
  std::cout << cargo << '\n';
  cargo=0;
  produce.notify_one();
  }
  
  void producer (int id) {
  std::unique_lock<std::mutex> lck(mtx);
  while (cargo!=0) produce.wait(lck);
  cargo = id;
  consume.notify_one();
  }
  
  int main ()
  {
  std::thread consumers[10],producers[10];
  // spawn 10 consumers and 10 producers:
  for (int i=0; i<10; ++i) {
      consumers[i] = std::thread(consumer);
      producers[i] = std::thread(producer,i+1);
  }
  
  // join them back:
  for (int i=0; i<10; ++i) {
      producers[i].join();
      consumers[i].join();
  }
  
  return 0;
  }
  ```

  + `notify_all` 唤醒所有的阻塞在 `condition_variable` 下的线程。需要特别注意的是，可能唤醒所有阻塞的线程，但是唤醒的多个线程同一时间只能有一个线程可以持有 `lck` 锁，必须等待其执行 `wait` 之后的代码，并释放 `lck` 时，剩余被唤醒的线程才可以执行，我们可以观察到以下程序示例，唤醒的顺序都是随机的。

  ```C++ []
  #include <iostream>
  #include <condition_variable>
  #include <thread>
  #include <chrono>
  
  std::condition_variable_any cv;
  std::mutex cv_m; // This mutex is used for three purposes:
                  // 1) to synchronize accesses to i
                  // 2) to synchronize accesses to std::cerr
                  // 3) for the condition variable cv
  int i = 0;
  
  void waits(int idx)
  {
      std::unique_lock<std::mutex> lk(cv_m);
      std::cerr << "Waiting... \n";
      cv.wait(lk, []{return i == 1;});
      std::cerr << "thread:"<< idx <<" ...finished waiting. i == 1\n";
  }
  
  void signals()
  {
      std::this_thread::sleep_for(std::chrono::seconds(1));
      {
          std::lock_guard<std::mutex> lk(cv_m);
          std::cerr << "Notifying...\n";
      }
      cv.notify_all();
  
      std::this_thread::sleep_for(std::chrono::seconds(1));
  
      {
          std::lock_guard<std::mutex> lk(cv_m);
          i = 1;
          std::cerr << "Notifying again...\n";
      }
      cv.notify_all();
  }
  
  int main()
  {
      std::thread t1(waits, 1), t2(waits, 2), t3(waits, 3), t4(signals);
      t1.join(); 
      t2.join(); 
      t3.join();
      t4.join();
  }
  ```

2. 虚假唤醒以及如何避免虚假唤醒:
   当线程从等待已发出信号的条件变量中醒来，却发现它等待的条件未得到满足时，就会发生虚假唤醒。发生虚假唤醒通常是因为在发出条件变量信号和等待线程最终运行之间，另一个线程运行并更改了条件，导致 `wait` 的线程被唤醒后，实际条件却未满足。比如我们在 `notify_all()` 时多个线程都被唤醒，但此时实际共享区却只有少数几个线程可以操作，这时就会造成其他线程被虚假唤醒，可以在 `wait` 唤醒后再次进行检测 `condition` 解决虚假唤醒。

+ 虚假唤醒导致的后果：之前要等待的某个条件实际上并没有符合，被唤醒的线程将可能会执行一系列非法操作。
+ 通常的解决办法：在条件变量阻塞的代码处增加一个 `while` 循环，如果被唤醒就要检查一下条件是否符合，如果不符合则要再次进入阻塞等待。这样即避免了忙等待，又避免了虚假唤醒问题。

```C++ []
lock(mutex);
while( something not true ) {  
    condition_wait( cond, mutex);
}
do(something);
unlock(mutex);
```

参考资料：

+ [condition_variable](https://en.cppreference.com/w/cpp/thread/condition_variable)
+ [使用条件变量condition_variable, 什么条件下会虚假唤醒？](https://segmentfault.com/q/1010000010421523)
+ [C++ Threading #6: Condition Variable](https://www.youtube.com/watch?v=13dFggo4t_I&list=PL5jc9xFGsL8E12so1wlMS0r0hTQoJL74M&index=6)
+ [Spurious wakeup](https://en.m.wikipedia.org/wiki/Spurious_wakeup)
+ [为什么条件锁会产生虚假唤醒现象（spurious wakeup）？](https://www.zhihu.com/question/271521213)
+ [C语言中pthread_cond_wait 详解](https://blog.csdn.net/qq_39852676/article/details/121368186)

## 线程同步与异步
线程同步操作：
`C++` 标准库提供了以下几种线程同步的方式:

+ 互斥量（支持超时加锁、递归加锁）；
+ 读写锁（共享互斥量，也支持超时加锁）；
+ 互斥量包装器（基于 `RAII` 的思想）；
+ 条件变量；
+ 信号量（二元信号量、计数信号量）；
+ `barrier`；
+ `call_once`；

不同的同步方式具有不同的使用场景和性能，实际使用时根据不同的场景选择不同的同步方式，分别就几种以上几种方式进行简要介绍:

1. 互斥量（`mutex`）：
   互斥量（`mutex`）是防止同时访问共享资源的程序对象。为避免线程更新共享变量时所出现问题，必须使用互斥量（`mutex` 是 `mutual exclusion` 的缩写）来确保同时仅有一个线程可以访问某项共享资源。 即使用互斥量来实现原子访问操作，防止多个线程对临界区同时操作而产生不一致的问题。`mutex` 只有锁定（`locked`）和未锁定（`unlocked`）两种状态。任何时候，至多只有一个线程可以锁定互斥量。试图对已经锁定的互斥量再次加锁，将可能阻塞线程或者报错失败，`mutex` 的底层可能封装的是操作系统 `spinlock`，不同的操作系统下可能有不同的实现。`C++` 中关于 `mutex` 的头文件为 `#include <mutex>`。

```C++ []
#include <iostream>       
#include <thread>        
#include <mutex>          

std::mutex mtx;     

void print_block (int n, char c) {
  mtx.lock();
  for (int i=0; i<n; ++i) { std::cout << c; }
  std::cout << '\n';
  mtx.unlock();
}

int main ()
{
  std::thread th1 (print_block,50,'*');
  std::thread th2 (print_block,50,'$');

  th1.join();
  th2.join();

  return 0;
}
/*
****************************************
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*/
```

`C++` 中还定义了 `timed_mutex`：在 `mutex` 的基础上增加了超时加锁的功能。
`recursive_mutex`：在 `mutex` 的基础上增加了递归加锁的功能（此时，`lock()` 函数可以被同一线程在不释放锁的情况下多次调用）。

```C++ []
std::recursive_mutex mtx;

void fun1() {
    mtx.lock();
    mtx.unlock();
}

void fun2() {
    mtx.lock();
    fun1(); // recursive lock 
    mtx.unlock();
};
```

2. 共享互斥量:
   `std::shared_mutex` 是 `C++ 17` 标准中引入的，由 `unique_lock` 和 `shared_lock` 两个类模板配合 `shared_mutex` 使用，主要用于读写共享锁。`unique_lock` 用于写入时加锁，`shared_lock` 用于读取时加锁。对象在构造时自动对 `std::shared_mutex` 加锁，析构时自动对其解锁。头文件主要包含在 `#include <shared_mutex>`。`shared_mutex` 可用于保护共享数据不被多个线程同时访问。与其他便于独占访问的互斥锁类型相比，`shared_mutex` 具有两个访问级别：

+ `shared`：多个线程可以共享同一个互斥锁的所有权。
+ `exclusive `：只有一个线程可以拥有互斥锁。
  共享互斥锁通常用于多个读取操作可以同时访问同一资源而不会导致数据竞争，但只有一个写入操作的场景。

```C++ []
#include <iostream>
#include <mutex>  // For std::unique_lock
#include <shared_mutex>
#include <thread>
 
class ThreadSafeCounter {
 public:
  ThreadSafeCounter() = default;
 
  // 多个线程可以同时读取 countter 计数
  unsigned int get() const {
    std::shared_lock lock(mutex_);
    return value_;
  }
 
  // 只有1个线程可以修改 countter 计数
  void increment() {
    std::unique_lock lock(mutex_);
    value_++;
  }
 
  // 只有1个线程可以修改 countter 计数
  void reset() {
    std::unique_lock lock(mutex_);
    value_ = 0;
  }
 
 private:
  mutable std::shared_mutex mutex_;
  unsigned int value_ = 0;
};
 
int main() {
  ThreadSafeCounter counter;
 
  auto increment_and_print = [&counter]() {
    for (int i = 0; i < 3; i++) {
      counter.increment();
      std::cout << std::this_thread::get_id() << ' ' << counter.get() << '\n';
 
      // Note: Writing to std::cout actually needs to be synchronized as well
      // by another std::mutex. This has been omitted to keep the example small.
    }
  };
 
  std::thread thread1(increment_and_print);
  std::thread thread2(increment_and_print);
 
  thread1.join();
  thread2.join();
}
/*
139677317637888 2
139677317637888 3
139677309245184 4
139677309245184 5
139677309245184 6
139677317637888 6
*/
```

我们可以看到 `increment` 同时只能有一个线程对计数进行增加，但可能同时存在多个线程读取同一个计数。
`shared_timed_mutex` 是在 `shared_mutex` 的基础上增加了超时加锁的功能。

3. 互斥量包装器
   `lock_guard`：使用了 `RAII` 的机制对互斥量进行类模板封装，构造时加锁，析构时解锁。

```C++ []
#include <mutex>
std::mutex mtx;
void f()
{
  const std::lock_guard<std::mutex> lock(mtx);
  // ...
  // mtx is automatically released when lock goes out of scope
}
```

互斥量包装器对比原生的 `mutex` 来说，创建即加锁，作用域结束自动析构并解锁，无需手动解锁。缺点是不能中途解锁，不支持复制和移动。在需要加锁的地方，只需要任意实例化一个 `lock_guard`，调用构造函数成功上锁，出作用域时则 `lock_guard` 对象会被销毁，调用析构函数自动解锁可以有效避免死锁问题，但是提供的功能单一且不够灵活。

`unique_lock`：`unique_lock` 类模板也是采用 `RAII` 的方式对锁进行了封装，并且也是以独占所有权的方式管理 `mutex` 对象的上锁和解锁操作，即其对象之间不能发生拷贝。在构造（或移动 `move` 赋值）时，`unique_lock` 对象需要传递一个 `mutex` 对象作为它的参数，新创建的 `unique_lock` 对象负责传入的 `mutex` 对象的上锁和解锁操作。使用以上类型互斥量实例化 `unique_lock` 的对象时，自动调用构造函数上锁，`unique_lock` 对象销毁时自动调用析构函数解锁，可以很方便的防止死锁问题。与 `lock_guard` 不同的是，`unique_lock` 更加的灵活，提供了更多的成员函数：

+ 上锁/解锁操作：`lock`、`try_lock`、`try_lock_for`、`try_lock_until` 和 `unlock`；

+ 修改操作：支持移动赋值、交换（`swap`：与另一个 `unique_lock` 对象互换所管理的互斥量所有权）、释放（`release`：返回它所管理的互斥量对象的指针，并释放所有权）。

+ 获取属性：`owns_lock` （返回当前对象是否上了锁）、`operator bool()` （与 `owns_lock()` 的功能相同）、`mutex`（返回当前 `unique_lock` 所管理的互斥量的指针）。

4. 条件变量（`condition variable`）：
   在 `C++ 11` 以后，我们可以使用条件变量（`condition_variable`）实现多个线程间的同步操作；当条件不满足时，相关线程被一直阻塞，直到某种条件出现，这些线程才会被唤醒。`C++` 中包含的头文件在 `#include <condition_variable>` 中。
   条件变量是利用线程间共享的全局变量进行同步的一种机制，主要包括两个动作：

  + 一个线程因等待 `条件变量的条件成立` 而挂起；
  + 另外一个线程使 `条件成立` 从而给出唤醒线程的信号，从而唤醒被等待的线程；
    为了防止竞争，条件变量的使用总是和一个互斥锁结合在一起；通常情况下这个锁是 `std::mutex`，并且管理这个锁只能是 `std::unique_lock std::mutex` 等 `RAII` 模板类。分别是使用以下两个方法实现：
+ 等待条件成立使用的是 `condition_variable` 类成员 `wait` 、`wait_for` 或 `wait_until`。
+ 唤醒信号使用的是 `condition_variable` 类成员 `notify_one` 或者 `notify_all` 函数。
  我们可以看到 `wait` 函数如下：

```C++ []
template< class Predicate >
void wait( std::unique_lock<std::mutex>& lock, Predicate stop_waiting );
```

线程会一直挂起，直到 `stop_waiting` 为 `true` 为止。程序示例如下:

```C++ []
#include <iostream>
#include <string>
#include <thread>
#include <mutex>
#include <condition_variable>
 
std::mutex m;
std::condition_variable cv;
std::string data;
bool ready = false;
bool processed = false;
 
void worker_thread()
{
    std::unique_lock<std::mutex> lk(m);
    // worker 线程等待 ready
    cv.wait(lk, []{return ready;});
 
    // 唤醒执行
    std::cout << "Worker thread is processing data\n";
    data += " after processing";
 
    // processed 设置为 true, 唤醒 main 线程
    processed = true;
    std::cout << "Worker thread signals data processing completed\n";
 
    // 释放锁，防止再次被唤醒。
    lk.unlock();
    // 唤醒 main 线程
    cv.notify_one();
}
 
int main()
{
    std::thread worker(worker_thread);
    // 让 worker 线程先执行，再进行唤醒，否则可能出现 ready = true 先于 worker 线程的执行
    worker.detach();
    
    data = "Example data";
    // 设置 ready 为 true, 唤醒 worker 线程
    {
        std::lock_guard<std::mutex> lk(m);
        ready = true;
        std::cout << "main() signals data ready for processing\n";
    }
    // 唤醒 worker 线程
    cv.notify_one();
    // 等待 worker 线程
    {
        std::unique_lock<std::mutex> lk(m);
        cv.wait(lk, []{return processed;});
    }
    std::cout << "Back in main(), data = " << data << '\n';
    return 0;
}
```

5. 信号量：
   `C++ 20` 中添加了 `C++` 中的信号量为二元信号量与计数信号量，二元信号量实际为计数信号量模板的特化。
    + `binary_semaphore`：二元信号量类似于互斥量，信号量只有 `0` 与 `1` 。
    + `counting_semaphore`：计数信号量
      所有关于信号量的定义参考头文件 `#include <semaphore>`，计数信号量是一种轻量级同步原语，可以控制对共享资源的访问。与 `std::mutex` 不同的是，`acounting_semaphore` 至少允许 `LeastMaxValue` 并发访问者对同一资源进行多个并发访问。`Acounting_semaphore` 包含一个由构造函数初始化的内部计数器。该计数器可以通过 `acquire()` 获取资源访问权限，并通过调用 `release()` 来释放资源从而递增计数器。当计数器为零时，调用 `acquire()` 时就会阻塞直到计数器增加，但是调用 `try_acquire( )` 不阻塞；`try_acquire_for()` 和 `try_acquire_until()` 阻塞直到计数器增加或达到超时。

```C++ []
#include <iostream>
#include <thread>
#include <chrono>
#include <semaphore>
 
std::binary_semaphore
	smphSignalMainToThread{0},
	smphSignalThreadToMain{0};
 
void ThreadProc()
{	
    // 第一次进入阻塞
	smphSignalMainToThread.acquire();
	std::cout << "[thread] Got the signal\n"; // response message
	using namespace std::literals;
	std::this_thread::sleep_for(3s);
	std::cout << "[thread] Send the signal\n"; // message
    // 唤醒 main 线程
	smphSignalThreadToMain.release();
}
 
int main()
{
	std::thread thrWorker(ThreadProc);
	std::cout << "[main] Send the signal\n"; // message
    // 唤醒 ThreadProc 
	smphSignalMainToThread.release();
    // main 线程阻塞
	smphSignalThreadToMain.acquire();
	std::cout << "[main] Got the signal\n"; // response message
	thrWorker.join();
}
/*
[main] Send the signal
[thread] Got the signal
[thread] Send the signal
[main] Got the signal
*/
```

6. `barrier`:
   `C++ 20` 以后支持 `latch` 与 `barrier`，他们同样可以用来线程同步。

+ `latch`：类 `latch` 是 `std::ptrdiff_t` 类型的向下计数器，可用于同步线程。计数器的值在创建时初始化。线程可能会阻塞在锁存器上，直到计数器减为零。不能增加或重置计数器，这使得锁存器创建后不可重用。其内部维护着一个计数器，当计数不为 `0` 时，所有参与者（线程）都将阻塞在等待操作处，计数为 `0` 时，解除阻塞。计数器不可重置或增加，故它是一次性的，不可重用。与 `std::barrier` 不同，`std::latch` 参与线程可以多次递减。

```C++ []
#include <latch>

std::latch work_done(4);

work_done.count_down();			 // decrements the counter in a non-blocking manner
work_done.wait();				   // blocks until the counter reaches zero
bool ok = work_done.try_wait();	 // tests if the internal counter equals zero
work_done.arrive_and_wait();	    // decrements the counter and blocks until it reaches zero
```

+ `barrier`：类似于 `latch`，它会阻塞线程直到所有参与者线程都到达一个同步点，直到预期数量的线程到达设定的值则会接触阻塞。与 `latch` 不同的是，它是可重用的。
  一个 `barrier` 的生命周期包含多个阶段，每个阶段都定义了一个同步点。一个 `barrier` 阶段包含：
+ 期望计数（设创建时指定的计数为 `n`），当期望计数不为 `0` 时，参与者将阻塞于等待操作处；
+ 当期望计数为 `0` 时，会执行创建 `barrier` 时指定的阶段完成步骤，然后解除阻塞所有阻塞于同步点的参与者线程。
+ 当阶段完成步骤执行完成后，会重置期望计数为 `n - 调用arrive_and_drop()` 的次数，然后开始下一个阶段。

```C++ []
#include <barrier>
#include <iostream>
#include <string>
#include <thread>
#include <vector>
 
int main() {
  const auto workers = { "anil", "busara", "carl" };
 
  auto on_completion = []() noexcept { 
    // locking not needed here
    static auto phase = "... done\n" "Cleaning up...\n";
    std::cout << phase;
    phase = "... done\n";
  };

  std::barrier sync_point(std::ssize(workers), on_completion);
  auto work = [&](std::string name) {
    std::string product = "  " + name + " worked\n";
    std::cout << product;  // ok, op<< call is atomic
    sync_point.arrive_and_wait();
    // 全部到达后，进行下一阶段
    product = "  " + name + " cleaned\n";
    std::cout << product;
    sync_point.arrive_and_wait();
  };
 
  std::cout << "Starting...\n";
  std::vector<std::thread> threads;
  for (auto const& worker : workers) {
    threads.emplace_back(work, worker);
  }
  for (auto& thread : threads) {
    thread.join();
  }
}
/*
Starting...
  anil worked
  carl worked
  busara worked
... done
Cleaning up...
  busara cleaned
  anil cleaned
  carl cleaned
... done
*/
```

7. `call_once`:
   `C++ 11` 以后支持 `call_once`。确保某个操作只被执行一次（成功执行才算），即使是多线程环境下也确保只执行一次。

```C++ []
template< class Callable, class... Args >
void call_once( std::once_flag& flag, Callable&& f, Args&&... args );
```

如果在 `call_once` 被调用时，`flag` 表明 `f` 已经被调用，则 `call_once` 立即返回（这种调用 `call_once` 称为被动）。

```C++ []
#include <iostream>
#include <thread>
#include <mutex>
 
std::once_flag flag1, flag2;
 
void simple_do_once()
{
    std::call_once(flag1, [](){ std::cout << "Simple example: called once\n"; });
}
 
int main()
{
    std::thread st1(simple_do_once);
    std::thread st2(simple_do_once);
    std::thread st3(simple_do_once);
    std::thread st4(simple_do_once);
    st1.join();
    st2.join();
    st3.join();
    st4.join();
}
/*
Simple example: called once
*/
```

参考资料：

+ [mutex class (C++ Standard Library)](https://docs.microsoft.com/en-us/cpp/standard-library/mutex-class-stl?view=msvc-170)
+ [浅析mutex实现原理](https://zhuanlan.zhihu.com/p/390107537)
+ [Mutex example / tutorial?](https://stackoverflow.com/questions/4989451/mutex-example-tutorial)
+ [C++11 并发指南三(std::mutex 详解)](https://www.cnblogs.com/haippy/p/3237213.html)
+ [C++ 并发编程（二）：Mutex（互斥锁）](https://segmentfault.com/a/1190000006614695)
+ [unique_lock详解](https://blog.csdn.net/qq_37947660/article/details/120501119)
+ [C++—线程同步](https://segmentfault.com/a/1190000040628584?sort=newest)
+ [std::counting_semaphore, std::binary_semaphore](https://en.cppreference.com/w/cpp/thread/counting_semaphore)
+ [std::call_once](https://en.cppreference.com/w/cpp/thread/call_once)
+ [std::call_once](https://docs.w3cub.com/cpp/thread/call_once)

## C++ 互斥信号量
1. `std::thread`：
   我们可以通过 `thread` 创建一个线程（`C++ 11` 以后才支持 `thread` 标准库），`thread` 在构造相关线程对象完成后立即开始执行（实际需要等待 `OS` 对于线程的调度延迟）。`thread` 需要配合与 `join` 或者 `detach` 配合使用，不然可能出现不可预料的后果。

+ `join` 代表阻塞当前主线程，等待当前的 `join` 的子线程完成后主线程才会继续；
+ `detach` 表明当前子线程不阻塞主线程，且与主线程分离，子线程的运行不会影响到主线程。

```C++ []
#include <iostream>
#include <thread>
#include <string>
using namespace std;
void fn2(string st2) {
    cout<<st2<<endl;
}

void fn1(string st1) {
    cout<<st1<<endl;
}  

int main()
{
    thread thr1(fn1, "111111111\n"); 
    thread thr2(fn2, "222222222\n"); 
    return 0;
}
```

如在一个类中间，一个成员函数需要异步调用另一个函数的时候，需要绑定 `this`：

```C++ []
class Test{
    private:
    void func1(const std::string s1, int i) {
        std::cout << s1 << std::endl;
    }
    public:
    void func2() {
            std::thread t1(&Test::func1, this, "test", 0);
            t1.detach();
            std::cout << "func2" << std::endl;
    }
```

2. `std::async`:
   我们进行异步编程时，需要得到子进程的计算结果，常见的手段是我们可以通过共享变量或者消息队列的方式告知另一个线程当前的计算结果，但是操作和实现都比较麻烦，同时还要考虑线程间的互斥问题。`C++11` 中提供了一个相对简单的异步接口 `std::async`，通过这个接口可以简单地创建线程并通过 `std::future` 中获取结果，极大的方便了 `C++` 多线程编程。`std::async` 适合与需要取得结果的异步线程。`C++11` 中的 `std::async` 是个模板函数。`std::async` 异步调用函数，在某个时候以 `Args` 作为参数（可变长参数）调用函数，无需等待函数执行完成就可返回，返回结果是个 `std::future` 对象。函数返回的值可通过 `std::future` 对象的 `get` 成员函数获取。一旦完成函数的执行，共享状态将包含函数返回的值并 `ready`。

`async` 使用的函数原型和参数说明如下:

```C++ []
//(C++11 起) (C++17 前)
template< class Function, class... Args>
std::future<std::result_of_t<std::decay_t<Function>(std::decay_t<Args>...)>>
    async( Function&& f, Args&&... args );

//(C++11 起) (C++17 前)
template< class Function, class... Args >
std::future<std::result_of_t<std::decay_t<Function>(std::decay_t<Args>...)>>
    async( std::launch policy, Function&& f, Args&&... args );  
```

+ 第一个参数是 `std::async` 的启动策略类型以下两种方式：`async` 允许调用者选择特定的启动策略:
  + `std::launch::async`：在调用 `async` 就开始创建线程，该函数由新线程异步调用，并且将其返回值与共享状态的访问点同步。
  + `std::launch::deferred`：延迟启动线程，在访问共享状态时该线程才启动。对函数的调用将推迟到返回的 `std::future` 的共享状态被访问时（即使用 `std::future` 的 `wait` 或 `get` 函数）。如果 `get` 或 `wait` 没有被调用，函数就绝对不会执行。
+ 参数 `Function`：可以为函数指针、成员指针、任何类型的可移动构造的函数对象，也可以为匿名函数 `lambda`。`Function` 的返回值或异常存储在共享状态中以供异步的 `std::future` 对象检索。`std::future` 对象可以通过 `wait` 或 `get` 函数获取函数的返回值。
+ 参数 `Args`：传递给函数 `Function` 调用的参数，它们的类型应是可移动构造的。
  我们可以用多线程将程序分为子任务，用子任务求解，程序示例如下:

```C++ []
#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
#include <future>
#include <string>
#include <mutex>
  
template <typename RandomIt>
int parallel_sum(RandomIt beg, RandomIt end)
{
    auto len = end - beg;
    if (len < 1000)
        return std::accumulate(beg, end, 0);
 
    RandomIt mid = beg + len/2;
    auto handle = std::async(std::launch::async,
                             parallel_sum<RandomIt>, mid, end);
    int sum = parallel_sum(beg, mid);
    return sum + handle.get();
}

template <typename RandomIt>
int parallel_min(RandomIt beg, RandomIt end)
{
    auto len = end - beg;
    if (len < 1000)
        return *(std::min_element(beg, end));
 
    RandomIt mid = beg + len/2;
    auto handle = std::async(std::launch::async,
                             parallel_min<RandomIt>, mid, end);
    int ans = parallel_sum(beg, mid);
    return std::min(ans, handle.get());
}
 
int main()
{
    std::vector<int> v(10000, 1);
    std::cout << "The sum is " << parallel_sum(v.begin(), v.end()) << '\n';
    std::cout << "The min element is " << parallel_min(v.begin(), v.end()) << '\n';
} 
```

3. `std::future`:
   `std::future` 提供了一种访问线程异步操作结果的机制。从字面意思来看，`future` 表示未来，`std::async` 返回结果即为一个 `future`。在实际工程项目中，一个异步操作我们是不可能马上就获取操作结果的，只能在将来的某个时候获取，但是我们可以以同步等待的方式来获取结果，可以通过查询 `future` 的状态（`future_status`）来获取异步操作的结果。`future_status` 有三种状态：

+ `deferred`：异步操作还没开始；
+ `ready`：异步操作已经完成；
+ `timeout`：异步操作超时；
  获取 `future` 结果有三种方式：`get`、`wait`、`wait_for`，其中 `get` 等待异步操作结束并返回结果，`wait` 只是等待异步操作完成，没有返回值，`wait_for` 是超时等待返回结果。

```C++ []
#include <iostream>
#include <future>
#include <thread>
 
int main()
{
    // future from an async()
    std::future<int> f1 = std::async(std::launch::async, []{ return 8; });
 
    // future from a promise
    std::promise<int> p;
    std::future<int> f2 = p.get_future();
    std::thread( [&p]{ p.set_value_at_thread_exit(9); }).detach();
 
    std::cout << "Waiting..." << std::flush;
    f1.wait();
    f2.wait();
    std::cout << "Done!\nResults are: "
              << f1.get() << ' ' << f2.get() << '\n';
}
/*
Waiting...Done!
Results are: 8 9
*/
```

参考资料：

+ [C++中的异步编程](https://zhuanlan.zhihu.com/p/540239803)
+ [C++ 多线程异步(std::async)](https://blog.csdn.net/GreedySnaker/article/details/114300906)
+ [join](https://cplusplus.com/reference/thread/thread/join/)
+ [std::async](https://en.cppreference.com/w/cpp/thread/async)
+ [std::async的使用总结](https://segmentfault.com/a/1190000039083151)
+ [C++ std::async 用法与范例](https://shengyu7697.github.io/std-async/)
+ [（原创）用C++11的std::async代替线程的创建](https://www.cnblogs.com/leijiangtao/p/12076251.html)
+ [std::async 的两个坑](https://zhuanlan.zhihu.com/p/39757902)

## C++ I/O 操作
`C++` 保持与 `C` 兼容，因此也保留支持 `printf` 和 `scanf` 进行输出和输人的方法。`c++` 具有面向对象的特性，引入了新的输入输出。`C++` 通过 `I/O` 类库来实现丰富的 `I/O` 功能。在 `C++` 中，输入和输出以字节序列或更通常称为 `stream` 的形式执行。

+ 输入流（`inputstream`）：如果字节流的方向是从设备（例如键盘）到主存，那么这个过程称为输入。
+ 输出流（`outputstream`）：如果字节流的方向相反，即从主存到设备（显示屏），那么这个过程称为输出。
![6_1_1.png](https://pic.leetcode-cn.com/1661515629-ypuTEg-6_1_1.png)
  `C++` 采用了面向对象的思想对所有涉及 `I/O` 的操作进行了统一的封装，涉及到 `I/O` 操作的主要由 `
  <iostream>,<iomanip>,<fstream>` 三个头文件组成，`stream` 是其行为由类定义的对象，其中主要的类的继承关系如下图所示:
![6_1_2.png](https://pic.leetcode-cn.com/1661515645-WNnqbw-6_1_2.png)
  `C++` 中的 `Streams` 对象主要分为三种类型： 
+ `istream` ：这种类型的流对象只能从流中执行输入操作；
+ `ostream` ：这些对象只能用于输出操作；
+ `iostream` ：可用于输入和输出操作；

1. 标准输入输出:

+ 标准输出流（`cout`）：通常标准输出设备是显示器。`C++ cout` 语句是 `ostream` 类的实例。它用于在标准输出设备上产生输出。需要在屏幕上显示的数据使用插入运算符（`<<`） 插入到标准输出流（`cout`）中。
+ 标准输入流（`cin`）：通常计算机中的输入设备是键盘。`C++ cin` 语句是 `istream` 类的实例，用于从标准输入设备（通常是键盘）读取输入。 提取运算符 （`>>`） 与对象 `cin` 一起用于读取输入。提取运算符从使用键盘输入的对象 `cin` 中提取数据。

2. `I/O` 重定向：
   所有流对象都有一个关联的数据成员类 `streambuf`。简单地说，`streambuf` 对象就是流的缓冲区。当我们从流中读取数据时，我们不会直接从源中读取数据，而是从链接到源的缓冲区中读取数据。同样，输出操作首先在缓冲区上执行，然后在需要时刷新缓冲区（写入物理设备）。
   `C++` 允许我们为任何流设置流缓冲区，因此重定向流的任务简单地减少为更改与流关联的流缓冲区。因此，要将流 `A` 重定向到流 `B`，我们需要执行以下操作：

+ 获取 `A` 的流缓冲区并将其存储在某处；
+ 将 `A` 的流缓冲区设置为 `B` 的流缓冲区；
+ 如果需要将 `A` 的流缓冲区重置为其先前的流缓冲区；
  我们可以使用函数 `ios::rdbuf()` 来执行以下两个操作:

```C++ []
stream_object.rdbuf()：//获取返回指向stream_object的流缓冲区的指针
stream_object.rdbuf(streambuf * p)：//将流缓冲区设置为p指向的
```

以下为程序示例:

```C++ []
// Cpp program to redirect cout to a file
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

int main()
{
	fstream file;
	file.open("cout.txt", ios::out);
	string line;

	// 保存 cin 和 cout 的缓冲区 buffer
	streambuf* stream_buffer_cout = cout.rdbuf();
	streambuf* stream_buffer_cin = cin.rdbuf();

	// 获取文件 file 的缓冲区 buffer
	streambuf* stream_buffer_file = file.rdbuf();

	// cout 重定向文件
	cout.rdbuf(stream_buffer_file);
	cout << "This line written to file" << endl;

	// cout 恢复重定
	cout.rdbuf(stream_buffer_cout);
	cout << "This line is written to screen" << endl;

	file.close();
	return 0;
}
```

3. 在 `C/C++` 如何中清除输入缓冲区：
   所有标准输入和输出设备都包含一个输入和输出缓冲区。在标准 `C/C++` 中，流被缓冲。例如在标准输入的情况下，当我们按下键盘上的键时，它不会发送到您的程序，而是由操作系统发送到缓冲区，直到进程调度时才将其分配给该程序。
   在各种情况下，可能需要清除不需要的缓冲区，以便在所需的程序中立即获取下一个输入，而不是在前一个变量的缓冲区中。比如 `C` 遇到 `scanf()` 后，需要输入字符数组或字符，`C++` 遇到 `cin` 语句后，需要输入字符数组或字符。当我们从键盘获取一个字符串时，我们需要清除输入缓冲区，否则所需的输入被前一个变量的缓冲区占用。

```C++ []
#include<iostream>
#include<vector>
using namespace std;

int main()
{
    int a;
    char ch[80];
    cin >> a;
    cin.getline(ch,80);
    cout << a << endl;
    cout << ch << endl;
    return 0;
}
```

上述代码没有正确打印出字符串 `ch` 的值，原因是缓冲区被占用。`\n` 字符保留在缓冲区中，并作为下一个输入读取。因此我们在需要在输入 `ch` 之前，将缓冲区进行清除。

+ 使用 `cin.ignore`：
  使用 `cin.ignore(numeric_limits::max(),'\n');` ”，在 `cin` 语句之后丢弃输入流中的所有内容，包括换行符。

```C++ []
#include<iostream>
#include<ios> //used to get stream size
#include<limits> //used to get numeric limits
using namespace std;

int main()
{
    int a;
    char ch[80];
    cin >> a;
    cin.ignore(numeric_limits<streamsize>::max(),'\n');
    cin.getline(ch,80);
    cout << a << endl;
    cout << ch << endl;
    return 0;
}
/*
4 
C++
*/
```

+ 使用 `cin>>ws`：
  在 `cin` 语句之后输入 `cin>>ws` 告诉编译器忽略缓冲区并丢弃字符串或字符数组实际内容之前的所有空格。 

```C++ []
#include<iostream>
#include<ios> //used to get stream size
#include<limits> //used to get numeric limits
using namespace std;

int main()
{
    int a;
    char ch[80];
    cin >> a;
    cin.ignore(numeric_limits<streamsize>::max(),'\n');
    cin.getline(ch,80);
    cout << a << endl;
    cout << ch << endl;
    return 0;
}
```

参考资料：

+ [C++中的IO操作](https://blog.csdn.net/a1912157861/article/details/122324514)
+ [Clearing The Input Buffer In C/C++](https://www.***.org/clearing-the-input-buffer-in-cc/)
+ [Basic Input / Output in C++](https://www.***.org/basic-input-output-c/)
+ [C++ Basic Input/Output](https://www.tutorialspoint.com/cplusplus/cpp_basic_input_output.htm)
+ [Input/output library](https://en.cppreference.com/w/cpp/io)
+ [C++ Programming Language Stream IO and File IO](https://www3.ntu.edu.sg/home/ehchua/programming/cpp/cp10_io.html)


# 设计模式
本章将重点涉及以下高频知识点：

## 单例模式及其实现
**单例模式**：保证类的实例化对象仅有一个，并且提供一个访问他的全局访问点。


**应用场景**：

- 表示文件系统的类，一个操作系统一定是只有一个文件系统，因此文件系统的类的实例有且仅有一个。
- 打印机打印程序的实例，一台计算机可以连接好几台打印机，但是计算机上的打印程序只有一个，就可以通过单例模式来避免两个打印作业同时输出到打印机。


**实现方式：**
单例模式可以通过全局或者静态变量的形式实现，这样比较简单，但是这样会影响封装性，难以保证别的代码不会对全局变量造成影响。

- **默认的构造函数、拷贝构造函数、赋值构造函数声明为私有的**，这样禁止在类的外部创建该对象；
- 全局访问点也要定义成 **静态类型的成员函数**，没有参数，返回该类的指针类型。因为使用实例化对象的时候是通过类直接调用该函数，并不是先创建一个该类的对象，通过对象调用。

不安全的实现方式：
原因：考虑当两个线程同时调用 `getInstance` 方法，并且同时检测到 `instance` 是 `NULL`，两个线程会同时实例化对象，不符合单例模式的要求。

```C++ []
class Singleton{
private:
    static Singleton * instance;
    Singleton(){}
    Singleton(const Singleton& tmp){}
    Singleton& operator=(const Singleton& tmp){}
public:
    static Singleton* getInstance(){
        if(instance == NULL){
            instance = new Singleton();
        }
        return instance;
    }
};
Singleton* Singleton::instance = NULL;
```

**分类：**

- 懒汉模式：直到第一次用到类的实例时才去实例化，上面是懒汉实现。
- 饿汉模式：类定义的时候就实例化。

线程安全的懒汉模式实现：
方法：**加锁**
存在的问题：每次判断实例对象是否为空，都要被锁定，如果是多线程的话，就会造成大量线程阻塞。

```C++ []
class Singleton{
private:
    static pthread_mutex_t mutex;
    static Singleton * instence;
    Singleton(){
        pthread_mutex_init(&mutex, NULL); 
    }
    Singleton(const Singleton& tmp){}
    Singleton& operator=(const Singleton& tmp){}
public:
    static Singleton* getInstence(){
        pthread_mutex_lock(&mutex);
        if(instence == NULL){            
            instence = new Singleton();            
        }
        pthread_mutex_unlock(&mutex);
        return instence;
    }
};
Singleton* Singleton::instence = NULL;
pthread_mutex_t Singleton::mutex;
```

方法：**内部静态变量**，在全局访问点 `getInstance` 中定义静态实例。

```C++ []
class Singleton{
private:
    static pthread_mutex_t mutex;
    Singleton(){
        pthread_mutex_init(&mutex, NULL);
    }
    Singleton(const Singleton& temp){}
    Singleton& operator=(const Singleton& temp){}
public:
    static Singleton* getInstence(){ 
        static Singleton instence;
        return &instence;
    }
};
pthread_mutex_t Singleton::mutex; 
```

饿汉模式的实现：
饿汉模式本身就是线程安全的不用加锁。

```C++ []
class Singleton{
private:
    static Singleton* instence;
    Singleton(const Singleton& temp){}
    Singleton& operator=(const Singleton& temp){}
protected:
	 Singleton(){} 
public:
    static Singleton* getInstence(){ 
        return instence;    
    }
};
Singleton* Singleton::instence = new Singleton();
```

参考资料:

+ [单例模式](https://www.runoob.com/design-pattern/singleton-pattern.html)
+ [前言](https://www.cnblogs.com/xiketang/p/15493954.html)

## 工厂模式及其实现
**工厂模式**：包括简单工厂模式、抽象工厂模式、工厂方法模式。
**简单工厂模式**：主要用于创建对象。用一个工厂来根据输入的条件产生不同的类，然后根据不同类的虚函数得到不同的结果。
**工厂方法模式**：修正了简单工厂模式中不遵守开放封闭原则。把选择判断移到了客户端去实现，如果想添加新功能就不用修改原来的类，直接修改客户端即可。
抽象工厂模式：定义了一个创建一系列相关或相互依赖的接口，而无需指定他们的具体类。

1. **简单工厂模式**
   主要用于创建对象。用一个工厂来根据输入的条件产生不同的类，然后根据不同类的虚函数得到不同的结果。

+ **应用场景**：
  适用于针对不同情况创建不同类时，只需传入工厂类的参数即可，无需了解具体实现方法。例如：计算器中对于同样的输入，执行不同的操作：加、减、乘、除。
![7_3_1.png](https://pic.leetcode-cn.com/1661310698-GtQGFs-7_3_1.png)
<br>
+ **实现方式**：

```C++ []
#include <iostream>
#include <vector>
using namespace std;

// Here is the product class
class Operation
{
public:
    int var1, var2;
    virtual double GetResult()
    {
        double res = 0;
        return res;
    }
};

class Add_Operation : public Operation
{
public:
    virtual double GetResult()
    {
        return var1 + var2;
    }
};

class Sub_Operation : public Operation
{
public:
    virtual double GetResult()
    {
        return var1 - var2;
    }
};

class Mul_Operation : public Operation
{
public:
    virtual double GetResult()
    {
        return var1 * var2;
    }
};

class Div_Operation : public Operation
{
public:
    virtual double GetResult()
    {
        return var1 / var2;
    }
};

// Here is the Factory class
class Factory
{
public:
    static Operation *CreateProduct(char op)
    {
        switch (op)
        {
        case '+':
            return new Add_Operation();

        case '-':
            return new Sub_Operation();

        case '*':
            return new Mul_Operation();

        case '/':
            return new Div_Operation();

        default:
            return new Add_Operation();
        }
    }
};

int main()
{
    int a, b;
    cin >> a >> b;
    Operation *p = Factory::CreateProduct('+');
    p->var1 = a;
    p->var2 = b;
    cout << p->GetResult() << endl;

    p = Factory::CreateProduct('*');
    p->var1 = a;
    p->var2 = b;
    cout << p->GetResult() << endl;

    return 0;
}
```

2. **工厂方法模式**
   修正了简单工厂模式中不遵守开放封闭原则。把选择判断移到了客户端去实现，如果想添加新功能就不用修改原来的类，直接修改客户端即可。

+ **应用场景**：
  + 一个类不知道它所需要的对象的类：在工厂方法模式中，客户端不需要知道具体产品类的类名，只需要知道所对应的工厂即可，具体的产品对象由具体工厂类创建；客户端需要知道创建具体产品的工厂类。
  + 一个类通过其派生类来指定创建哪个对象：在工厂方法模式中，对于抽象工厂类只需要提供一个创建产品的接口，而由其派生类来确定具体要创建的对象，利用面向对象的多态性和里氏代换原则，在程序运行时，派生类对象将覆盖父类对象，从而使得系统更容易扩展。
  + 将创建对象的任务委托给多个工厂派生类中的某一个，客户端在使用时可以无须关心是哪一个工厂派生类创建产品派生类，需要时再动态指定，可将具体工厂类的类名存储在配置文件或数据库中。
![7_3_2.png](https://pic.leetcode-cn.com/1661310755-vFtGMk-7_3_2.png)
<br>
+ **实现方式**：

```C++ []
#include <iostream>
#include <vector>
using namespace std;

// Here is the product class
class Operation
{
public:
    int var1, var2;
    virtual double GetResult()
    {
        double res = 0;
        return res;
    }
};

class Add_Operation : public Operation
{
public:
    virtual double GetResult()
    {
        return var1 + var2;
    }
};

class Sub_Operation : public Operation
{
public:
    virtual double GetResult()
    {
        return var1 - var2;
    }
};

class Mul_Operation : public Operation
{
public:
    virtual double GetResult()
    {
        return var1 * var2;
    }
};

class Div_Operation : public Operation
{
public:
    virtual double GetResult()
    {
        return var1 / var2;
    }
};

class Factory
{
public:
    virtual Operation *CreateProduct() = 0;
};

class Add_Factory : public Factory
{
public:
    Operation *CreateProduct()
    {
        return new Add_Operation();
    }
};

class Sub_Factory : public Factory
{
public:
    Operation *CreateProduct()
    {
        return new Sub_Operation();
    }
};

class Mul_Factory : public Factory
{
public:
    Operation *CreateProduct()
    {
        return new Mul_Operation();
    }
};

class Div_Factory : public Factory
{
public:
    Operation *CreateProduct()
    {
        return new Div_Operation();
    }
};

int main()
{
    int a, b;
    cin >> a >> b;
    Add_Factory *p_fac = new Add_Factory();
    Operation *p_pro = p_fac->CreateProduct();
    p_pro->var1 = a;
    p_pro->var2 = b;
    cout << p_pro->GetResult() << endl;

    Mul_Factory *p_fac1 = new Mul_Factory();
    Operation *p_pro1 = p_fac1->CreateProduct();
    p_pro1->var1 = a;
    p_pro1->var2 = b;
    cout << p_pro1->GetResult() << endl;

    return 0;
}
```

3. **抽象工厂模式**
   定义了一个创建一系列相关或相互依赖的接口，而无需指定他们的具体类。

+ **应用场景**：
  + 一个系统不应当依赖于产品类实例如何被创建、组合和表达的细节，这对于所有类型的工厂模式都是重要的。
  + 系统中有多于一个的产品族，而每次只使用其中某一产品族。
  + 属于同一个产品族的产品将在一起使用，这一约束必须在系统的设计中体现出来。
  + 产品等级结构稳定，设计完成之后，不会向系统中增加新的产品等级结构或者删除已有的产品等级结构。
![7_3_3.png](https://pic.leetcode-cn.com/1661310791-KLoZet-7_3_3.png)
<br>
+ **实现方式**：

```C++ []
#include <iostream>
#include <vector>
using namespace std;

// Here is the product class
class Operation_Pos
{
public:
    int var1, var2;
    virtual double GetResult()
    {
        double res = 0;
        return res;
    }
};

class Add_Operation_Pos : public Operation_Pos
{
public:
    virtual double GetResult()
    {
        return var1 + var2;
    }
};

class Sub_Operation_Pos : public Operation_Pos
{
public:
    virtual double GetResult()
    {
        return var1 - var2;
    }
};

class Mul_Operation_Pos : public Operation_Pos
{
public:
    virtual double GetResult()
    {
        return var1 * var2;
    }
};

class Div_Operation_Pos : public Operation_Pos
{
public:
    virtual double GetResult()
    {
        return var1 / var2;
    }
};
/*********************************************************************************/
class Operation_Neg
{
public:
    int var1, var2;
    virtual double GetResult()
    {
        double res = 0;
        return res;
    }
};

class Add_Operation_Neg : public Operation_Neg
{
public:
    virtual double GetResult()
    {
        return -(var1 + var2);
    }
};

class Sub_Operation_Neg : public Operation_Neg
{
public:
    virtual double GetResult()
    {
        return -(var1 - var2);
    }
};

class Mul_Operation_Neg : public Operation_Neg
{
public:
    virtual double GetResult()
    {
        return -(var1 * var2);
    }
};

class Div_Operation_Neg : public Operation_Neg
{
public:
    virtual double GetResult()
    {
        return -(var1 / var2);
    }
};
/*****************************************************************************************************/

// Here is the Factory class
class Factory
{
public:
    virtual Operation_Pos *CreateProduct_Pos() = 0;
    virtual Operation_Neg *CreateProduct_Neg() = 0;
};

class Add_Factory : public Factory
{
public:
    Operation_Pos *CreateProduct_Pos()
    {
        return new Add_Operation_Pos();
    }
    Operation_Neg *CreateProduct_Neg()
    {
        return new Add_Operation_Neg();
    }
};

class Sub_Factory : public Factory
{
public:
    Operation_Pos *CreateProduct_Pos()
    {
        return new Sub_Operation_Pos();
    }
    Operation_Neg *CreateProduct_Neg()
    {
        return new Sub_Operation_Neg();
    }
};

class Mul_Factory : public Factory
{
public:
    Operation_Pos *CreateProduct_Pos()
    {
        return new Mul_Operation_Pos();
    }
    Operation_Neg *CreateProduct_Neg()
    {
        return new Mul_Operation_Neg();
    }
};

class Div_Factory : public Factory
{
public:
    Operation_Pos *CreateProduct_Pos()
    {
        return new Div_Operation_Pos();
    }
    Operation_Neg *CreateProduct_Neg()
    {
        return new Div_Operation_Neg();
    }
};

int main()
{
    int a, b;
    cin >> a >> b;
    Add_Factory *p_fac = new Add_Factory();
    Operation_Pos *p_pro = p_fac->CreateProduct_Pos();
    p_pro->var1 = a;
    p_pro->var2 = b;
    cout << p_pro->GetResult() << endl;

    Add_Factory *p_fac1 = new Add_Factory();
    Operation_Neg *p_pro1 = p_fac1->CreateProduct_Neg();
    p_pro1->var1 = a;
    p_pro1->var2 = b;
    cout << p_pro1->GetResult() << endl;

    return 0;
}
```

参考资料:

+ [工厂模式](https://www.runoob.com/design-pattern/factory-pattern.html)

## 观察者模式及其实现
**观察者模式**：定义一种一（被观察类）对多（观察类）的关系，让多个观察对象同时监听一个被观察对象，被观察对象状态发生变化时，会通知所有的观察对象，使他们能够更新自己的状态。

观察者模式中存在两种角色：

+ **观察者**：内部包含被观察者对象，当被观察者对象的状态发生变化时，更新自己的状态。（接收通知更新状态）
+ **被观察者**：内部包含了所有观察者对象，当状态发生变化时通知所有的观察者更新自己的状态。（发送通知）

+ **应用场景**：
  + 当一个对象的改变需要同时改变其他对象，且不知道具体有多少对象有待改变时，应该考虑使用观察者模式；
  + 一个抽象模型有两个方面，其中一方面依赖于另一方面，这时可以用观察者模式将这两者封装在独立的对象中使它们各自独立地改变和复用。

+ **实现方式**：

```C++ []
#include <iostream>
#include <string>
#include <list>
using namespace std;

class Subject;
//观察者 基类 （内部实例化了被观察者的对象sub）
class Observer
{
protected:
    string name;
    Subject *sub;

public:
    Observer(string name, Subject *sub)
    {
        this->name = name;
        this->sub = sub;
    }
    virtual void update() = 0;
};

class StockObserver : public Observer
{
public:
    StockObserver(string name, Subject *sub) : Observer(name, sub)
    {
    }
    void update();
};

class NBAObserver : public Observer
{
public:
    NBAObserver(string name, Subject *sub) : Observer(name, sub)
    {
    }
    void update();
};
//被观察者 基类 （内部存放了所有的观察者对象，以便状态发生变化时，给观察者发通知）
class Subject
{
protected:
    list<Observer *> observers;

public:
    string action; //被观察者对象的状态
    virtual void attach(Observer *) = 0;
    virtual void detach(Observer *) = 0;
    virtual void notify() = 0;
};

class Secretary : public Subject
{
    void attach(Observer *observer)
    {
        observers.push_back(observer);
    }
    void detach(Observer *observer)
    {
        list<Observer *>::iterator iter = observers.begin();
        while (iter != observers.end())
        {
            if ((*iter) == observer)
            {
                observers.erase(iter);
                return;
            }
            ++iter;
        }
    }
    void notify()
    {
        list<Observer *>::iterator iter = observers.begin();
        while (iter != observers.end())
        {
            (*iter)->update();
            ++iter;
        }
    }
};

void StockObserver::update()
{
    cout << name << " 收到消息：" << sub->action << endl;
    if (sub->action == "梁所长来了!")
    {
        cout << "我马上关闭股票，装做很认真工作的样子！" << endl;
    }
}

void NBAObserver::update()
{
    cout << name << " 收到消息：" << sub->action << endl;
    if (sub->action == "梁所长来了!")
    {
        cout << "我马上关闭NBA，装做很认真工作的样子！" << endl;
    }
}

int main()
{
    Subject *dwq = new Secretary();
    Observer *xs = new NBAObserver("xiaoshuai", dwq);
    Observer *zy = new NBAObserver("zouyue", dwq);
    Observer *lm = new StockObserver("limin", dwq);

    dwq->attach(xs);
    dwq->attach(zy);
    dwq->attach(lm);

    dwq->action = "去吃饭了！";
    dwq->notify();
    cout << endl;
    dwq->action = "梁所长来了!";
    dwq->notify();
    return 0;
}
```


参考资料:

+ [观察者模式](https://www.runoob.com/design-pattern/observer-pattern.html)

## 常见设计模式
《大话设计模式》一书中提到 `24` 种设计模式，这 `24` 种设计模式没必要面面俱到，但一定要深入了解其中的几种，最好结合自己在实际开发过程中的例子进行深入的了解。

设计模式有 `6` 大设计原则：

+ 单一职责原则：就一个类而言，应该仅有一个引起它变化的原因。
+ 开放封闭原则：软件实体可以扩展，但是不可修改。即面对需求，对程序的改动可以通过增加代码来完成，但是不能改动现有的代码。
+ 里氏代换原则：一个软件实体如果使用的是一个基类，那么一定适用于其派生类。即在软件中，把基类替换成派生类，程序的行为没有变化。
+ 依赖倒转原则：抽象不应该依赖细节，细节应该依赖抽象。即针对接口编程，不要针对实现编程。
+ 迪米特原则：如果两个类不直接通信，那么这两个类就不应当发生直接的相互作用。如果一个类需要调用另一个类的某个方法的话，可以通过第三个类转发这个调用。
+ 接口隔离原则：每个接口中不存在派生类用不到却必须实现的方法，如果不然，就要将接口拆分，使用多个隔离的接口。
  设计模式分为三类：
+ 创造型模式：单例模式、工厂模式、建造者模式、原型模式
+ 结构型模式：适配器模式、桥接模式、外观模式、组合模式、装饰模式、享元模式、代理模式
+ 行为型模式：责任链模式、命令模式、解释器模式、迭代器模式、中介者模式、备忘录模式、观察者模式、状态模式、策略模式、模板方法模式、访问者模式
  下面介绍常见的几种设计模式：
+ 单例模式：保证一个类仅有一个实例，并提供一个访问它的全局访问点。
+ 工厂模式：包括简单工厂模式、抽象工厂模式、工厂方法模式
+ 简单工厂模式：主要用于创建对象。用一个工厂来根据输入的条件产生不同的类，然后根据不同类的虚函数得到不同的结果。
+ 工厂方法模式：修正了简单工厂模式中不遵守开放封闭原则。把选择判断移到了客户端去实现，如果想添加新功能就不用修改原来的类，直接修改客户端即可。
+ 抽象工厂模式：定义了一个创建一系列相关或相互依赖的接口，而无需指定他们的具体类。
+ 观察者模式：定义了一种一对多的关系，让多个观察对象同时监听一个主题对象，主题对象发生变化时，会通知所有的观察者，使他们能够更新自己。
+ 装饰模式：动态地给一个对象添加一些额外的职责，就增加功能来说，装饰模式比生成派生类更为灵活。


参考资料:

+ [设计模式简介](https://www.runoob.com/design-pattern/design-pattern-intro.html)
+ [什么是设计模式？](https://blog.csdn.net/weixin_57504000/article/details/124195306)
+ [23种设计模式总结](https://blog.csdn.net/lgxzzz/article/details/124970034)

