
# 面试为什么会考概率
大家好，我是潮汐，这里我们将开启新的一个专题：概率题面试突击。

为什么想写这个专题呢，主要是因为最近几年在程序员面试中，尤其是校招面试中，经常会问到一些与概率、期望相关的问题，一方面是考查候选人的数学素养，另一方面是概率在计算机中的应用确实很多。这些题零零散散出现在各个平台的面经，周围同学朋友的口述，以及自己的面试实践中，没有一个系统的梳理，因此本专栏的目的就是详细梳理程序员面试中常见的知识点与题目。

当然，本专栏不只是适合程序员。算法工程师、策略产品经理，数据分析师都是最近几年新出现并且比较热门的岗位，而概率在这些岗位中是通用基础，面试中基本上都会问到。此外，很多程序员会去金融科技工作，而金融业中的技术岗位，概率是必考的，并且会重点考。准备这些岗位的同学，有时间的话都可以学习本专栏，将来一定会有用。

我工作至今的职位一直都是算法工程师，这里我从算法工程师的角度谈一谈概率。

最近几年人工智能、数据科学已成为一项推动业务发展的重要技术。而进入这个领域的人，基本上一定会翻阅领域内的文章，以及参与相关任务。那么你会发现与概率有关的问题基本上绕不开：

要过滤垃圾邮件，这需要贝叶斯思维；要从文本中提取出名称实体，有赖于概率图模型研究；要做语音识别，离不开随机过程中的隐马尔可夫模型；要通过样本推断某类对象的总体特征，则需要建立估计理论和大数定理；要进行统计推断，必不可少的一类应用广泛的采样方法则是蒙特卡罗方法以及马尔可夫过程的稳定性。

可以看到，概率理论既是程序员面试的高频考点，又是解决实际问题的现实工具。

除了理论以外，运用好 Python 工具，例如 Numpy、Scipy、Matplotlib、Pandas 等，也有助于强化对知识的理解，后面的基础知识介绍中会穿插有这方面的内容。

本专栏是一个连载专栏，主要讨论程序员面试中的高频概率问题，包括知识点和题目，但不涉及机器学习中的概率进阶理论知识。其目录规划如下：

第一章为序言，也就是本小节的内容。 

第二章简述随机模拟，并以一实例加深大家对随机模拟的思考过程，附 Python 代码。

第三章简要梳理面试中概率核心考点。 

第四章为连载部分，将持续更新概率计算问题及其解答。 

第五章为附录，主讲概率在计算机中的现实应用。

# 随机模拟的方法论
由于随机模拟往往可验证概率问题的结果，因此它在后面解题中基本都会用到。 

本章首先介绍随机模拟方法的背景，然后以一个例题来阐述实际场景中随机模拟怎么用、具体流程有哪些，最后进行总结。

## 随机模拟方法
大量实际问题都存在不确定性，如：交通路况、商品库存变动、金融市场交易量变化、服务排队情况等。这些问题的共同点是要求我们用概率方法对系统进行建模，然后分析系统的行为特征。但要求解这类随机模型非常困难，我们甚至无法获得解析解。而随机模拟对于解决上述问题就显得尤为重要了。

随机模拟方法是通过**仿真随机系统的运行**来获得系统的状态变化与输出结果的大量数据，进而对所得数据进行统计分析，估算系统行为的某些特征，并将估计的误差控制在一定范围内。这里的仿真其实是另一个单独的话题，里面也有很多分类，在这里我们只关注对随机系统的仿真。

随机模拟方法除了在解析解很困难或没有解析解的情况下是很有力的方法，在有解析解的时候，还可以用于验证解析解的正确性。

- 随机模拟有一个基本的方法论，它是一种用随机模拟解决问题的一个思路框架。有了这个方法论，拿到实际问题的时候就可以快速形成思路。这其中会分为描述系统、设置变量、运行规则、模拟系统、抽样与统计、解释结果这几步。
- 正确地描述系统的输入输出，以及运行规则，需要对系统进行数学建模。数学建模常见的模型有图论模型（例如二分图匹配）、概率统计模型（例如逻辑回归模型）、动态模型（例如常微分方程）、优化模型（例如线性规划）等。
- 对系统建模是需要准确找到随机事件是什么。这需要一些数学基础，主要是概率论和随机过程。
- 对系统中的随机事件，需要正确地为该随机事件配置随机数，这需要随机数采样的技术，常见的连续型和离散型分布可以直接生成，而一些特殊分布需要一些算法，例如逆变换法，接受拒绝法，抽样多维联合分布法。
- 蒙特卡洛法是对系统进行模拟的重要方法，主要包括马尔可夫链蒙特卡洛法，蒙特卡洛优化，蒙特卡洛积分。
- 随机服务系统，随机游走，以及元胞自动机是随机模拟的比较大的应用。

下面我们以一个实际问题来看一下**随机模拟的方法论**。

## 随机模拟方法论实践：电池问题
考虑一个由充电电池构成的供电系统，一共有两个电池和一个充电器。其中一个电池给设备供电，另一个电池备用。

电池的耗尽时间为 1, 2, 3, 4, 5, 6 小时的其中一种情况，并且随机。耗尽的电池充满电需要 2.5 小时。

初始状态两个电池都是充满电的。

问：设备可以持续工作多长时间。

### 解析解

刚开始的时候，设备上的电池无论随机到的耗尽时间是多少，都会继续供电，因为备用电池在初始的时候是就绪的。

第一次更换电池后，新电池开始供电，备用电池开始充电。此时新电池随机到的耗尽时间就很关键了。

由于充电时间是 2.5，因此如果随机到的耗尽时间为 1, 2，那么耗尽后供电就会终止。如果随机到的耗尽时间是 3, 4, 5, 6，那么耗尽时备用电池已就绪，可以回到前面刚刚更换电池的状态，也就是【新电池开始供电，备用电池开始充电】的状态。

这个过程可以用有向图建模


![有向图2.2.png](https://pic.leetcode-cn.com/1646278540-IRlXDD-middle_img_v2_8afc05f1-3929-4fea-b054-e1a682a3a87g.png)


在图中，我们定义状态：

S0: 新电池开始供电，备用电池已就绪，也就是初始状态  
S1: 新电池开始供电，备用电池开始充电，也就是过程中会不断重复的状态  
S2: 无新电池可用，也就是供电停止的状态

状态的转移概率，以及状态转移时对应的期望时间间隔标注在图中。

定义 x 为从初始到停止供电的总时间的期望，y 为从第一次换电池到停止供电的时间的期望。根据图中的状态转移关系，我们可以写出
$$
x =  (1 + 2 + 3 + 4 + 5 + 6) / 6 + y = 3.5 + y \\
y =  \frac{1}{3} * (1 + 2)/ 2 + \frac{2}{3} * ((3 + 4 + 5 + 6) / 4 + y)= \frac{1}{3} \times 1.5 + \frac{2}{3}(4.5 + y) \\
$$

解得 x = 14


### 随机模拟

随机模拟大致分为六个步骤。

#### step1: 描述系统

输入：新开始供电的电池的耗尽时间 r。
状态：S0（2 块备用电池就绪，也就是初始状态），S1（1 块备用电池就绪，也就是正常换电池的状态），S2（无备用电池就绪，也就是停止供电的状态）。
随机事件：换电池，ti 表示第 i 次随机事件（换电池）的时间点。
输出：第 m 次随机事件时，状态处于 S2，则 tm 为停止时间

#### step2: 设置变量

r 是 1 ~ 6 的离散均匀分布。用随机数发生器产生一系列随机数作为输入。

#### step3: 运行规则

产生一系列随机数后，随机事件的发生也就取决于这些随机数。

#### step4: 模拟系统

首先导入必要的包。其中 font 是字体对象，在 step6 中画图的时候需要用到。

```python
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
font = FontProperties(fname="/home/ppp/anaconda3/envs/python-3.6/lib/python3.6/site-packages/matplotlib/mpl-data/fonts/ttf/simhei.ttf")
import seaborn as sns
```

初始 t0 = 0, s = 0，然后模拟并产生输出即可。

代码如下

```python
class PowerSupplySystem:
    def __init__(self, s0=0, t0=0.0, N=int(1e5)):
        self.N = N
        self.charging_time = 2.5
        self.s0 = s0
        self.t0 = t0
        self.reset()

    def reset(self):
        self.t = self.t0
        self.s = self.s0
        self.rs = np.random.randint(1, 7, self.N)
        self.i = 0

    def exhaust_time(self):
        nxt_t = self.rs[self.i]
        self.i += 1
        return nxt_t

    def __call__(self):
        np.random.seed()
        self.t += self.exhaust_time()
        self.s = 1
        while self.s != 2 and self.i < self.N:
            t = self.exhaust_time()
            self.t += t
            if t < self.charging_time:
                self.s = 2
        tmp = self.t
        self.reset()
        return tmp
```

`system = PowerSupplySystem()` 创建一个供电系统实例后，调用该实例后，会进行一次试验。并返回停止供电时间。

#### step5: 抽样与统计

重复模拟试验，对结果进行统计。

```python
system = PowerSupplySystem()
T = int(1e5)
ts = np.zeros(T)
for i in range(T):
    ts[i] = system()

avg_ts = np.zeros(T)
avg_ts[0] = ts[0]
for i in range(1, ts.shape[0]):
    avg_ts[i] = (avg_ts[i - 1] * i + ts[i]) / (i + 1)

print("平均停止供电时间: {:.6f}".format(avg_ts[-1]))
```

模拟结果

```plain
平均停止供电时间: 13.991030
```

#### step6: 解释结果

下面我们画一下平均停止时间随着试验次数的变化图，以及停止时间的分布图。

```python


fig = plt.figure()
ax1 = fig.add_subplot(1, 2, 1)
ax2 = fig.add_subplot(1, 2, 2)
ax1.plot(avg_ts)
ax1.set_title("供电系统", fontproperties=font)
ax1.set_xlabel("试验次数", fontproperties=font)
ax1.set_ylabel("平均断电时间", fontproperties=font)
ax2.hist(ts, bins=int(ts.max()))
ax2.set_title("供电系统", fontproperties=font)
ax2.set_xlabel("断电时间", fontproperties=font)
ax2.set_ylabel("频率", fontproperties=font)
plt.show()
```

- 平均停止时间随着试验次数的变化图

![2.jpg](https://pic.leetcode-cn.com/1646278592-HsJKLC-2.jpg)


- 停止时间的分布图

![3.jpg](https://pic.leetcode-cn.com/1646278609-kgIvXa-3.jpg)

## 随机模拟的方法论总结
通过电池问题，我们简单实现了随机模拟过程，现进一步总结如下：

- 描述系统
    - 系统的输入、状态、输出。
    - 随机事件是什么
- 设置变量
    - 为系统的输入、状态、输出设置变量
    - 为随机事件设定随机数
- 运行规则
    - 系统状态如何变化
    - 随机数如何产生
- 模拟系统
    - 给定系统初始情况
    - 给出系统的输出
- 抽样与统计
    - 大量重复模拟试验
    - 对结果进行统计
- 解释结果
    - 解释模拟结果
    - 必要时改变某些设定重新模拟


# 概率论基础知识
本章目标为梳理面试中概率问题的高频知识点，共分为7部分：

1. 概率的定义，性质
2. 期望和方差的定义，性质
3. 常见的离散型分布，二项分布，泊松分布
4. 常见的连续型分布，均匀分布，指数分布，正态分布
5. 全概率公式
6. 全期望公式
7. 贝叶斯公式

各个部分会穿插一些 Python 代码，其中，5～7 又是面试中的考察重点，我们会通过借助例题加深大家的理解。 

另外，本章并未收录如几何概型、连续型随机变量、联合分布随机变量等考点，若在后续题目中遇到，我们会及时同步到本章的框架中。

## 概率的定义和性质
本小节简要介绍概率的几种定义及常用性质，要点如下：

- 概率的定义
    - 古典定义
    - 统计定义
    - 主观定义
    - 公理化定义
- 概率的性质
    - 加法法则
    - 乘法公式
    - 条件概率
    - 事件独立性

### 概率的定义

#### 古典定义

具有以下特征的随机试验模型，称为古典概率模型。

1. 试验的所有可能结果只有有限个，即样本空间中的基本事件只有有限个。
2. 各试验结果出现的可能性相等，即所有基本事件的发生是等可能的。
3. 试验所有可能出现的结果两两互不相容。

某一事件 A 发生的概率为该事件所包含的基本事件个数 m 与样本空间所包含的基本事件个数 n 的比值，记为 P(A)。

#### 统计定义

在相同条件下进行 n 次重复试验，如果随机事件 A 发生的次数为 m，m/n 称为随机事件 A 发生的频率。随着 n 逐渐增大，随机事件发生的频率越来越接近某一数值 p，p 称为随机事件 A 的概率。

#### 主观定义

有的随机事件的发生的可能性不能**通过等可能事件个数**来计算，也不能**根据大量重复试验中该事件发生的频率**来获得，此时需要应用主观概率。

古典概率和统计概率属于客观概率，它们的确定完全取决于对客观条件进行的理论分析，或者是大量重复试验的结果，不以个人的意志为转移。而主观概率的确定则很灵活，它依赖于个人的主观判断，不同的人对同一事件给出的概率值往往有一定差异。

#### 公理化定义

1933 年，柯尔莫哥洛夫给出概率的公理化定义。

满足以下 3 个性质的事件发生可能性大小的度量为概率的公理化定义。

- 非负性：对任意随机事件 A，都有 P(A) >= 0
- 规范性：必然事件的概率为 1，$P(\Omega) = 1$
- 可列可加性：随机事件 A1, A2, ..., An, ... 两两互不相容，则 

$$
P(A1 \cup A2 \cup ... \cup An \cup ...) = P(A1) + P(A2) + ... + P(An) + ...
$$

###  概率的性质

#### 概率的加法法则

- 两个互斥事件之和的概率等于两个事件概率的和

$$
P(A\cup B) = P(A) + P(B)
$$

例如一枚骰子，求掷出奇数或掷出 6 的概率。由于奇数和 6 是互斥的，因此可以将两个概率直接相加。

- 任意两个随机事件，它们之和的概率为两个事件的概率之和减去两事件相交的概率

$$
P(A\cup B) = P(A) + P(B) - P(A\cap B)
$$

#### 条件概率与乘法公式

- 条件概率

$$
P(B|A) = \frac{P(AB)}{P(A)}, P(A) > 0
$$

- 乘法公式

$$
P(AB) = P(A)P(B|A) = P(B)P(A|B)
$$

- 事件的独立性

A 的发生与否不影响 B 的发生，也就是

$$
P(B|A) = P(B)
$$

于是由乘法公式得

$$
P(AB) = P(A)P(B)
$$

## 常见的离散型概率分布
本小节简要介绍一下常见的两种离散型概率分布，二项分布和泊松分布。

- 离散型随机变量的概率分布
    - 二项分布
    - 泊松分布

### 二项分布

$$
X ～ B(n, p)
$$

$$
P(X=k) = \binom{n}{k}p^{k}q^{n-k}
$$

Python代码: `scipy.stats.binom.pmf`

```python
n = 10
p = 0.5
k = np.arange(0, 11) # 有 0 ~ 10 次正面朝上的可能
binomial = scipy.stats.binom.pmf(k, n, p)
print("0~10次正面朝上的概率分别为: {:.6f}".format(binomial))
```

### 泊松分布

$$
X ～ Poi(\lambda)
$$

$$
P(X=k) = \frac{\lambda^{k}}{k!}e^{-\lambda}
$$

Python代码: `scipy.stats.poisson.pmf`

```python
rate = 2
n = np.arange(0, 11) # 有 0 ~ 10 次发生事故的可能
poisson = scipy.stats.poisson.pmf(n, rate)
print("发生4次事故的概率为: {:.6f}".format(poisson[4]))
```

## 常见的连续型概率分布
本小节简要介绍一下常见的三种连续型概率分布，均匀分布和指数分布和正态分布。

- 连续型随机变量的概率分布
    - 均匀分布
    - 指数分布
    - 正态分布

### 均匀分布

$$
X ～ Uniform(a, b)
$$

$$
f(x) = 
\left\{
\begin{matrix}
\frac{1}{b-a} \quad\quad x \in (a, b) \\  
0 \quad\quad x \notin (a, b) \\  
\end{matrix}  
\right.
$$

Python代码: `scipy.stats.uniform.pdf(x, loc, scale)`

loc 为 a，scale 为 b - a

```python
a = 120
b = 140
k = 134.8
uniform = scipy.stats.uniform.pdf(k, a, b - a)
print("X={}的概率为: {:.6f}".format(k, uniform))
```

### 指数分布

$$
X ～ \epsilon(\lambda)
$$

$$
f(x) = 
\left\{
\begin{matrix}
\lambda e^{-\lambda x} \quad\quad x \geq 0 \\  
0 \quad\quad x < 0 \\  
\end{matrix}  
\right.
$$

Python代码: `scipy.stats.expon.pdf(x, scale)`

scale 是 lambda 的倒数。

```python
x = np.arange(0, 11) # x 有 0 ~ 10 年 11 种可能
expon = scipy.stats.expon.pdf(x, scale=1/3)
print("0~10的概率分别为: {}".format(expon))
```

### 正态分布

$$
X ～ N(\mu, \sigma^{2})
$$

$$
f(x) = \frac{1}{\sqrt{2\pi \sigma^{2}}}exp[-\frac{(x - \mu)^{2}}{2\sigma^{2}}]
$$

标准正态分布的 PDF 如下

$$
\phi(x) = \frac{1}{\sqrt{2\pi}}exp[-\frac{x^{2}}{2}]
$$

Python代码: `scipy.stats.norm.pdf(x, loc, scale)`

loc 为 mu, scale 为 sigma

```python
mu = 40
sigma = 4
k = 50.0
scipy.stats.norm.pdf(k, mu, sigma)
```

## 期望和方差的定义与性质
本小节简要介绍一下期望和方差的定义和性质，以及常见分布的期望和方差。

- 数学期望
    - 定义
    - 性质
    - 常见分布的数学期望
- 方差
    - 定义
    - 性质
    - 常见分布的方差

### 期望

#### 定义

$$
E(X) = \sum\limits_{j}x_{j}p_{j} \\
E(X) = \int_{-\infty}^{\infty}xf(x)dx
$$

#### 性质

a 是常数, X, Y 是随机变量

1. $E(a) = a$ 
2. $E(aX) = aE(X)$ 
3. $E(X+Y) = E(X) + E(Y)$ 
4. 如果 X, Y 独立，则 $E(XY) = E(X)E(Y)$

#### 离散分布的数学期望

##### 二项分布

$$
X ～ B(n, p)
$$

$$
E(X) = np
$$

Python代码: `scipy.stats.binom.mean`

```python
scipy.stats.binom.mean(n, p, loc=0)
```

##### 泊松分布

$$
X ～ Poi(\lambda)
$$

$$
E(X) = \lambda
$$

Python代码: `scipy.stats.poisson.mean`

```python
scipy.stats.poisson.mean(mu, loc=0)
# mu 是 lambda 的值
```

#### 连续分布的数学期望

##### 均匀分布

$$
X ～ Uniform(a, b)
$$

$$
E(X) = \frac{1}{b - a}
$$

Python代码: `scipy.stats.randint.mean`

```python
scipy.stats.randint.mean(low, high, loc=1)
```

##### 指数分布

$$
X ～ \epsilon(\lambda)
$$

$$
E(X) = \frac{1}{\lambda}
$$

Python代码: `scipy.stats.expon.mean`

```python
scipy.stats.expon.mean(loc=0, scale=1)
# scale 是 lambda 的倒数
```

##### 正态分布

$$
X ～ N(\mu, \sigma^{2})
$$

$$
E(X) = \mu
$$

Python代码: `scipy.stats.norm.mean`

```python
scipy.stats.norm.mean(loc=0, scale=1)
# loc 是 mu 的值
```

---

### 方差

#### 定义

如果 $E(X)$ 存在，且 $[X - E(X)]^{2}$ 也存在，则 X 的方差如下

$$
var(X) = E[X - E(X)]^{2}
$$

#### 性质

$$
var(X) = E(X^{2}) - [E(X)]^{2}
$$

#### 离散分布的方差

##### 二项分布

$$
X ～ B(n, p)
$$

$$
var(X) = np(1 - p)
$$

Python代码: `scipy.stats.binom.var`

```python
scipy.stats.binom.var(n, p, loc=0)
```

##### 泊松分布

$$
X ～ Poi(\lambda)
$$

$$
var(X) = \lambda
$$

Python代码: `scipy.stats.poisson.var`

```python
scipy.stats.poisson.var(mu, loc=0)
# mu 是 lambda 的值
```

#### 连续分布的方差

##### 均匀分布

$$
X ～ Uniform(a, b)
$$

$$
var(X) = \frac{(b - a)^{2}}{12}
$$

Python代码: `scipy.stats.randint.var`

```python
scipy.stats.randint.var(low, high, loc=1)
```

##### 指数分布

$$
X ～ \epsilon(\lambda)
$$

$$
var(X) = \frac{1}{\lambda^{2}}
$$

Python代码: `scipy.stats.expon.var`

```python
scipy.stats.expon.var(loc=0, scale=1)
# scale 是 lambda 的倒数
```

##### 正态分布

$$
X ～ N(\mu, \sigma^{2})
$$

$$
var(X) = \sigma^{2}
$$

Python代码: `scipy.stats.norm.var`

```python
scipy.stats.norm.var(loc=0, scale=1)
# loc 是 mu 的值
```

## 全概率公式
全概率公式如下，其中 X, Y 为随机变量。

$$
P(X) = \sum\limits_{y}P(Y=y)P(X|Y=y)
$$

基于【全概率公式】，我们可以通过概率 DP 求 X 的概率。下面我们通过一个例题看一下具体是怎么做的。

### 例题

以下三件事哪件的概率更大

- 投掷 6 枚骰子至少一个是 6
- 投掷 12 枚骰子至少两个是 6
- 投掷 18 枚骰子至少三个是 6

#### 思路参考: 全概率公式 + 概率DP

假设我们要求投掷 n 枚骰子，至少 m 枚是 6 的概率。

如果 m 是 0，则概率是 1，因为不论最终多少枚是 6，都符合“至少 0 枚是 6”的情况。

如果 m 大于 n，则概率是 0，因为不可能投掷出 6 的个数比骰子的个数还多。

当 0 < m < n 时，我们考虑其中一枚骰子的两种情况：

(1) 该骰子是 6，概率 1/6，则剩下的 n - 1 枚骰子需要至少 m - 1 枚是 6
(2) 该骰子不是 6，概率 5/6，则剩下的 n - 1 枚骰子需要至少 m 枚是 6

综合以上分析，再结合全概率公式

$$
P(X) = \sum\limits_{y}P(Y=y)P(X|Y=y)
$$

我们可以用概率DP的方式解决，算法如下

```plain
状态定义
dp[i][j] := 投掷 i 枚骰子，至少 j 个是 6 的概率

初始化
dp[i][0] = 1.0
dp[i][j] = 0 (j > i)

答案
dp[6][1]
dp[12][2]
dp[18][3]

状态转移
dp[i][j] = 1/6 * dp[i - 1][j - 1] + 5/6 * dp[i - 1][j]
```

下面编程计算 dp[n][m]

```cpp
#include <vector>
#include <iostream>

using namespace std;

int main()
{
    int n, m;
    cin >> n >> m;
    vector<vector<double>> dp(n + 1, vector<double>(m + 1, 0.0));
    for(int i = 0; i <= n; ++i)
        dp[i][0] = 1.0;
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= min(i, m); ++j)
            dp[i][j] = 1 / 6.0 * dp[i - 1][j - 1] + 5 / 6.0 * dp[i - 1][j];
    cout << dp[n][m] << endl;
}
```

计算结果: 

```plain
dp[6][1] = 0.665
dp[12][2] = 0.619
dp[18][3] = 0.597。
```

因此第一个事件的概率更大。

## 全期望公式
全期望公式如下，其中 X, Y 为随机变量，公式的形式与全概率公式差不多。

$$
E_{X}(X) = E_{Y}(E_{X|Y}(X|Y)) \\
= \sum\limits_{y}p(Y=y) \times E_{X|Y=y}(X|Y=y) \\
$$

公式告诉我们在求 X 的均值（期望）时可转化为求 X 在 Y = yi ( i = 1, 2, ...）条件下的条件期望 E_{X|Y = yi}(X|Y = yi) 再加权求和。

基于【全期望公式】，我们可以通过期望 DP 求 X 的期望。下面我们通过一个例题看一下具体是怎么做的。

### 例题

8 个男人和 7 个女人订了电影院的一排座，一排刚好有 15 个座位。

问：平均有多少个相邻座位是异性？

#### 思路参考 1: 全期望公式 + 期望 DP

定义 f(x, y) 表示 x 个男，y 个女排一排，相邻座位是异性的平均个数。当 x, y 任意一个为 0 的时候，值为零：f(x, 0) = 0, f(0, y) = 0

当 x > 0, y > 0 时，考虑最左边的座位，它有两种可能性，一种是男的，概率 p1 = x/(x+y), 另一种是女的，概率 p2 = y/(x+y)

(1) 如果最左边是男的: 

则期望的相邻座位是异性的个数分为两部分，第一部分是 f(x-1 , y)，第二部分是最左边男人的相邻座位，当相邻位置为女人时，可以贡献 1，概率为 y/(x-1+y)。

(2) 如果最左边是女的: 

则期望的相邻座位是异性的个数分为两部分，第一部分是 f(x , y-1)，第二部分是最左边女人的相邻座位，当相邻位置为男人时，可以贡献 1，概率为 x/(y-1+x)。

![期望.png](https://pic.leetcode-cn.com/1646120246-QMUcbG-%E6%9C%9F%E6%9C%9B.png){:style="max-height:350px"}

综合以上若干条，再结合全期望公式

$$
E(Y) = \sum\limits_{X}E_{X}(E_{Y|X}(Y|X)) \\
= \sum\limits_{x}P(X = x)E_{Y|X=x}(Y|X=x)) \\
$$

可以写出 f(x, y) 的转移方程。

```plain
f(x, y) = p1 * (f(x - 1, y) + y / (x - 1 + y)) 
          + p2 * (f(x, y - 1) + x / (y - 1 + x))
```

下面通过期望 DP 的方式解决以上问题，算法如下

```plain
状态定义
dp[i][j] := i 个男人，j 个女人的情况，相邻座位是异性的个数的期望

初始化
dp[i][0] = 0
dp[0][j] = 0

答案
dp[8][7]

状态转移
dp[i][j] = i / (i + j) * (dp[i - 1][j] + (j / (i - 1 + j)))
           + j / (i + j) * (dp[i][j - 1] + (i / (j - 1 + i)))
```

下面编程计算 dp[8][7]，代码如下

```cpp
#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n = 8, m = 7;
    vector<vector<double>> dp(n + 1, vector<double>(m + 1, 0));
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= m; ++j)
        {
            dp[i][j] = (double)i / (i + j) * (dp[i - 1][j] + ((double)j / (i - 1 + j)))
                        + (double)j / (i + j) * (dp[i][j - 1] + ((double)i / (j - 1 + i)));
        }
    cout << dp[n][m] << endl;
}
```

计算结果为 `dp[8][7] = 7.46667`

#### 思路参考2: 单独考虑每个相邻座位

一共有 14 个相邻座位。对于每个相邻座位，我们要考虑的都是【从 8 个男人和 7 个女人中选两个人放这个相邻座位的左右两边，这两个人是否为异性】这件事。

假设这个概率为 p，则一个相邻座位可以形成的异性的个数的期望就是 E = p，14 个相邻座位中为异性的期望个数就是 `p * 14`。

考虑一个相邻作为的左边这个座位：
- 左边座位是男人的概率为 8/15，在此情况下右边座位是女人的概率为 7/14。
- 左边座位是女人的概率为 7/15，在此情况下右边座位是男人的概率为 8/14。

因此一个相邻座位能够形成异性的概率为

$$
p = \frac{8}{15} \times \frac{7}{14} + \frac{7}{15} \times \frac{8}{14} = \frac{8}{15}
$$

14 个相邻座位中，异性的个数的期望为 `8/15 * 14 = 7.46667`。

#### 随机模拟验证结果

```python
import numpy as np
import operator
from multiprocessing import Pool
from functools import reduce

persons = [1] * 8 + [0] * 7

def run():
    l = np.random.permutation(persons)
    ans = 0
    for i in range(len(l) - 1):
        if l[i] != l[i + 1]:
            ans += 1
    return ans

def test(T):
    np.random.seed()
    y = (run() for _ in range(T))
    n = reduce(operator.add, y)
    return n / T

T = int(1e6)
args = [T] * 8
pool = Pool(8)
ts = pool.map(test, args)
for t in ts:
    print("{:.6f} pairs of adjacent are the opposite sex".format(t))
```

模拟结果

```plain
7.467305 pairs of adjacent are the opposite sex
7.466081 pairs of adjacent are the opposite sex
7.470136 pairs of adjacent are the opposite sex
7.465220 pairs of adjacent are the opposite sex
7.465871 pairs of adjacent are the opposite sex
7.467655 pairs of adjacent are the opposite sex
7.464980 pairs of adjacent are the opposite sex
7.467260 pairs of adjacent are the opposite sex
```

## 贝叶斯公式
我们有一个假设 H，可能成立可能不成立，也就是 H 是有一定概率成立的，记为 P(H)。例如我们有三个盒子，名称分别为 a，b，c。现在随机取出一个盒子，我们可以猜测该盒子的名称，如果我们猜 a，这就构成了一个假设：随机抽到的盒子的名称是 a。因为盒子共有 3 个，且盒子是随机取的，我们可以认为 P(H) = 1/3，这个概率称为先验概率。先验概率是根据经验来的，前面的例子的 1/3 就是一个经验值。

现在我们得到了一条证据 e，这个证据一般是某个实验的观察值。还是以三个盒子举例，a, b, c 三个盒子内均有一些球，其中 a 中有 10 个黑球，b 中有 10 个白球，c 中有 5 个黑球 5 个白球。我们可以针对盒子名称做实验：抽出一个球看颜色。假设看到的颜色是白色，我们就得到了一条证据：随机抽出一个球的颜色是白色。根据实际情况，证据 e 可能加强假设 H 成立的可能性，也可能削弱假设 H 成立的可能性。我们想知道的是当我们拿到证据 e 之后，假设 H 成立的概率是多少，这个概率记为 P(H|e)，称为后验概率，后验概率是根据数据（也就是证据）来的。

下面这个根据先验概率 P(H) 和证据 e，计算后验概率 P(H|e) 的公式称为贝叶斯公式。

$$
P(H|e) = \frac{P(e|H)P(H)}{P(e)} \\
=\frac{P(e|H)P(H)}{P(e|H)P(H) + P(e|\overline{H})P(\overline{H})}
$$

拿到一个贝叶斯公式的概率问题，首先要确定“假设是什么”及“证据是什么”，然后再代入公式。这样就不容易出错了。

### 例题: 不公平的硬币

有 10 枚硬币，其中有 1 枚是不公平的，随机抛出正面的概率为 0.8，另外 9 枚都是公平的，也就是随机抛出正面的概率是 0.5。

现在从 10 枚硬币中随机取出 1 枚，随机地抛了 3 次，结果为"正正反"。求该硬币为不公平硬币的概率。

#### 思路参考

根据题目描述，假设 H 是 "该硬币为不公平硬币"，证据 e 是 "随机抛出该硬币 3 次的结果为正正反"

现在我们要求的是当我们有了证据 e 的条件下，假设 H 成立的概率是多少，也就是 P(H|e)

贝叶斯公式如下

$$
P(H|e) = \frac{P(e|H)P(H)}{P(e)} \\
=\frac{P(e|H)P(H)}{P(e|H)P(H) + P(e|\overline{H})P(\overline{H})}
$$

其中 P(H) 是先验概率，根据业务理解，也就是本题给的条件，是 1/10。相应地 $P(\overline{H})$ 就是 9/10。

P(e|H) 是当假设 H 成立时，在一次观察中获得证据 e 的概率。也就是如果该硬币为不公平硬币，随机抛3次得到正正反的概率。

$$
P(e|H) = \frac{4}{5} \times \frac{4}{5} \times \frac{1}{5} = \frac{16}{125} \\
P(e|\overline{H}) = (\frac{1}{2})^{3} = \frac{1}{8} \\
$$

有了以上概率值，我们就可以根据贝叶斯公式计算后验概率 P(H|e) 了

$$
P(H|e) = \frac{P(e|H)P(H)}{P(e|H)P(H) + P(e|\overline{H})P(\overline{H})} \\
= \frac{\frac{16}{125} \times \frac{1}{10}}{\frac{16}{125} \times \frac{1}{10} + \frac{1}{8} \times \frac{9}{10}} \\
= 0.102155
$$

#### 模拟验证结果

```python
import numpy as np
from multiprocessing import Pool

def flip(p):
    # 如果投掷结果为正，返回 True
    return np.random.rand() < p

def test(ps):
    np.random.seed()
    N = 0 # 记录实验结果为"正正反"的次数
    n = 0 # 记录实验结果为"正正反"时，不公平硬币的次数
    T = int(1e7)
    for _ in range(T):
        # 随机取到的硬币，如果 idx 为 9 则取到不公平硬币
        idx = np.random.randint(0, 10)
        p = ps[idx]
        # 实验: 投 3 次，如果结果为"正正反"则记录
        if not flip(p):
            continue
        if not flip(p):
            continue
        if flip(p):
            continue
        N += 1
        if idx == 9:
            n += 1
    return n / N

p1 = 0.5 # 公平硬币出正面的概率为 0.5
p2 = 0.8 # 不公平硬币出正面的概率为 0.8
ps = [p1] * 9 + [p2] # 10 枚硬币，其中 1 枚为不公平硬币
args = [ps] * 8
pool = Pool(8)
ts = pool.map(test, args)
for i in range(len(args)):
    t = ts[i]
    print("P(不公平硬币|投掷结果为\"正正反\"): {:.6f}".format(t))
```

模拟结果

```plain
P(不公平硬币|投掷结果为"正正反"): 0.102335
P(不公平硬币|投掷结果为"正正反"): 0.102071
P(不公平硬币|投掷结果为"正正反"): 0.102196
P(不公平硬币|投掷结果为"正正反"): 0.102102
P(不公平硬币|投掷结果为"正正反"): 0.102111
P(不公平硬币|投掷结果为"正正反"): 0.102182
P(不公平硬币|投掷结果为"正正反"): 0.102154
P(不公平硬币|投掷结果为"正正反"): 0.102363
```


# 概率面试题（连载）


## 1. 抽屉中的袜子
抽屉里有红袜子和黑袜子，随机抽出两只，两只全红的概率为 1/2。

问:
a. 抽屉里的袜子最少有多少只？  
b. 如果黑袜子为偶数只，则抽屉里的袜子最少有多少只？ 

# 思路参考

## a 

设抽屉里有 x 只红袜子，y 只黑袜子，总共 N = x + y 只袜子，记随机抽两只均为红色的概率为 P

$$
P = \frac{\binom{x}{2}}{\binom{x+y}{2}} = \frac{x(x-1)}{(x+y)(x+y-1)} = \frac{1}{2} \\
\Rightarrow 2x(x-1) = N(N-1)
$$

问题变成解以上不定方程 N > 2 的最小正整数解

### 解析解

由于对于 y > 0, x > 1，有以下不等式

$$
\frac{x}{x+y} > \frac{x-1}{x+y-1}
$$

再结合

$$
\frac{\binom{x}{2}}{\binom{x+y}{2}} = \frac{x(x-1)}{(x+y)(x+y-1)} = \frac{1}{2}
$$

我们可以得到不等式

$$
(\frac{x}{x + y})^{2} > \frac{1}{2} > (\frac{x-1}{x+y-1})^{2} \\
\Rightarrow  \frac{x}{x + y} > \frac{1}{\sqrt{2}} > \frac{x-1}{x+y-1}
$$

从左半部分不等式可以计算出

$$
(\sqrt{2} + 1)y < x
$$

从右半部分不等式可以计算出

$$
x < (\sqrt{2} + 1)y + 1 
$$

因此对于 y = 1, x 的范围在 $[1 + \sqrt{2}, 3 + \sqrt{2}]$，所以 x = 3 是一个候选答案

### 数值解

暴力解法代码如下, 从 y = 1, x = 2 开始枚举，判断是否满足方程。

```python
y = 1
found = False
while True:
    x = 2
    while True:
        N = x + y
        if 2 * x * (x - 1) == N * (N - 1):
            print("N: {}, x: {}".format(x, N))
            found = True
            break
        elif 2 * x * (x - 1) > N * (N - 1):
            break
        x += 1
    if found:
        break
    y += 1
```

得到 N = 4, x = 3

## b

### 解析解

利用在此前已经推出的以下公式

$$
(\sqrt{2} + 1)y < x < (\sqrt{2} + 1)y + 1 
$$

这里规定了 y 是偶数。依次考虑 y = 2, 4, 6, ...，对每一个 y，我们可以知道 x 的范围，这个范围的长度正好为 1，因此也就是可以知道对应的 x 具体是多少。考察这对 (x, y) 是否满足 P = 1/2 即可。

第一个满足的就是答案。

### 数值解

依然用暴力法解，只需要把 y 的初始值改为 2, 每轮 y 的增加量改为 2 即可

```python
y = 2
found = False
while True:
    x = 2
    while True:
        N = x + y
        if 2 * x * (x - 1) == N * (N - 1):
            print("N: {}, x: {}".format(x, N))
            found = True
            break
        elif 2 * x * (x - 1) > N * (N - 1):
            break
        x += 1
    if found:
        break
    y += 2
```

得到 N = 21, x = 15

## 2. 轻率的陪审团
有一个 3 人组成的陪审团，其中两个人独立做决定均有 p 概率做对，另一个人通过抛硬币做决定
还有一个 1 人的陪审团，那个人做决定也有 p 概率做对。
问：哪个陪审团更优可能做出正确决定？

# 思路参考

第一个陪审团做出正确决定的概率记为 P1, 第二个陪审团做出正确决定的概率记为 P2。

$$
P1 = p \\
P2 = p \times p + 2 \times p \times (1 - p) \times \frac{1}{2} = p
$$

因此 P1 = P2，两个陪审团做出正确决定的可能性相等。

## 构造数据验证

```python
T = 10
n_trails = int(1e6)

for t in range(T):
    p = np.random.random()
    # 模拟第一个陪审团 3 个人各自做出的判断，1为正确判断
    # 模拟 n_trails 次
    c1 = np.random.binomial(1, p, size=n_trails)
    c2 = np.random.binomial(1, p, size=n_trails)
    c3 = np.random.binomial(1, 0.5, size=n_trails)
     # c 中记录了 n_trails 次模拟中每次是否做出了正确判断
    c = ((c1 + c2 + c3) >= 2).astype(int)
    print("P2 = {:.5f}, P1 = {:.5f}".format(p, np.mean(c)))
```

实验结果

```plain
P2 = 0.34158, P1 = 0.34095
P2 = 0.55780, P1 = 0.55776
P2 = 0.07460, P1 = 0.07439
P2 = 0.01918, P1 = 0.01919
P2 = 0.39175, P1 = 0.39233
P2 = 0.82699, P1 = 0.82643
P2 = 0.84726, P1 = 0.84769
P2 = 0.00396, P1 = 0.00395
P2 = 0.09100, P1 = 0.09023
P2 = 0.45738, P1 = 0.45741
```

## 3. 系列赛中连续获胜
Elmer 如果在三场的系列赛中赢下连续的两场，则可以得到奖励，系列赛的对手安排有两种

1. 爸爸-冠军-爸爸
2. 冠军-爸爸-冠军

这里冠军的水平高于爸爸，问：Elmer 应该选择哪一组，得到奖励的概率更大？

---

# 思路参考

一方面，由于冠军水平比爸爸高，应该尽可能少与冠军比赛，另一方面，中间的那一场是更重要的一场，因为如果中间那场输了就不可能连赢两场。

Elmer 与爸爸比赛获胜概率为 P1，与冠军比赛获胜概率为 P2，由于冠军水平高于爸爸，所以 P1 > P2。

对于一组系列赛，Elmer 要得到奖励有两种可能性，一种是前两场都赢了，此时不用看第三场，另一种是第一场输了，但第二第三场都赢了。

下面分别考虑两组系列赛，计算得到奖励的概率

第一组系列赛，前两场都赢的概率为 `P1 * P2`，第一场输但是第二、三场都赢的概率为 `(1 - P1) * P2 * P1`，得到奖励概率记为 Pa

$$
Pa = P1 \times P2 + (1 - P1) \times P2 \times P1
$$

第二组系列赛，前两场都赢的概率为 `P2 * P1`，第一场输但是第二、三场都赢的概率为 `(1 - P2) * P1 * P2`，得到奖励概率记为 Pb

$$
Pb = P2 \times P1 + (1 - P2) \times P1 \times P2
$$

做差比零

$$

Pa - Pb = (P1 \times P2 + (1 - P1) \times P2 \times P1) - (P2 \times P1 + (1 - P2) \times P1 \times P2) \\
= ((1 - P1) - (1 - P2)) \times P1 \times P2 \\
= (P2 - P1) \times P1 \times P2 \\
&< 0 \\

$$

所以 Pa < Pb，Elmer 应该选择第二组系列赛。

## 构造数据验证

```python
import numpy as np

step = 0.2

for P1 in np.arange(step, 1 + step, step):
    for P2 in np.arange(step, P1 - step, step):
        print("P1: {:.2f}, P2: {:.2f}".format(P1, P2))
        Pa = P1 * P2 + (1 - P1) * P2 * P1
        Pb = P2 * P1 + (1 - P2) * P1 * P2
        print("Pa: {:.2f}, Pb: {:.2f}".format(Pa, Pb))
        print("----")
```

结果如下：可看到 Pb 的值始终比 Pa 大

```plain
P1: 0.60, P2: 0.20
Pa: 0.17, Pb: 0.22
----
P1: 0.60, P2: 0.40
Pa: 0.34, Pb: 0.38
----
P1: 0.80, P2: 0.20
Pa: 0.19, Pb: 0.29
----
P1: 0.80, P2: 0.40
Pa: 0.38, Pb: 0.51
----
P1: 0.80, P2: 0.60
Pa: 0.58, Pb: 0.67
----
P1: 1.00, P2: 0.20
Pa: 0.20, Pb: 0.36
----
P1: 1.00, P2: 0.40
Pa: 0.40, Pb: 0.64
----
P1: 1.00, P2: 0.60
Pa: 0.60, Pb: 0.84
----
P1: 1.00, P2: 0.80
Pa: 0.80, Pb: 0.96
----
```

## 4. 试验直到第一次成功
一枚骰子掷出第一个 6 平均需要掷多少次。

# 思路参考 1

记 p(k) := 第一个 6 需要掷 k 次的概率。p := 在一次投掷中得到 6 的概率；q := 在一次投掷中不是 6 的概率，由定义 q = 1 - p。

```plain
k = 1: p(1) = p
k = 2: p(2) = pq
k = 3: p(3) = pq^2
...
```

总结规律后可以得到

$$
p(k) = pq^{k-1}
$$

数学期望为

$$

E(k) = \sum\limits_{k=1}\limits^{\infty} k \times p(k) \\
= \sum\limits_{k=1}\limits^{\infty} kpq^{k-1} \\

$$

处理上面的级数的技巧如下，首先两边都乘以 q。

$$

qE(k) = q\sum\limits_{k=1}\limits^{\infty} kpq^{k-1} \\
= \sum\limits_{k=1}\limits^{\infty} kpq^{k} \\

$$

让两式相减

$$

(1-q)E(k) = \sum\limits_{k=1}\limits^{\infty} kpq^{k-1} - \sum\limits_{k=1}\limits^{\infty} kpq^{k} \\
= p + \sum\limits_{k=2}\limits^{\infty} kpq^{k-1} - \sum\limits_{k=1}\limits^{\infty} kpq^{k} \\
= p + \sum\limits_{k=1}\limits^{\infty} (k+1)pq^{k} - \sum\limits_{k=1}\limits^{\infty} kpq^{k} \\
= p + \sum\limits_{k=1}\limits^{\infty}pq^{k} \\
= p\sum\limits_{k=0}\limits^{\infty}q^{k} \\

$$

其中几何级数那部分的公式如下

$$
\sum\limits_{k=0}\limits^{\infty}q^{k} = 1 + q + q^{2} + ... = \frac{1}{1-q}
$$

将上面的公式代入到两式相减的公式中

$$
pE(k) = p\frac{1}{1-q} = 1 \\
\Rightarrow E(k) = \frac{1}{p}
$$

将 p = 1/6 代入，E(k) = 6

---

# 思路参考 2

这里我们仍沿用思路参考 1 的数学记号。

记 m 为第一个 6 平均需要的次数（即期望）。

由全期望公式【随机变量 k 的期望就是**各种条件下 k 的期望加权求和**】。这里条件期望有两种情况：1）当第一次投掷成功时，则需要的平均次数是 1（该情况下期望是 1，对应权重即发生概率为 p）；2）当第一次投掷失败时，则需要的平均次数是 1 + m （该情况下期望是 1 + m，权重为 q），可列出如下等式：
$$
m = p \times 1 + q \times (1 + m) \\
\Rightarrow m = \frac{1}{p} \\
$$

---

# 蒙特卡洛模拟验证结果

```python
import numpy as np

p = 1/6

def test():
    T = int(1e6)
    mapping = {}
    for t in range(T):
        i = 1
        while True:
            if np.random.rand() < p:
                break
            i += 1
        if i not in mapping:
            mapping[i] = 0
        mapping[i] += 1

    E = 0
    for k in mapping:
        E += k * (mapping[k] / T)
    print("Average times is {:.4f}".format(E))

for i in range(5):
    test()
```

实验结果

```plain
Average times is 6.0025
Average times is 5.9918
Average times is 6.0018
Average times is 6.0038
Average times is 6.0059
```

## 5. 装备升级
回顾在之前 [试验直到第一次成功](https://leetcode-cn.com/leetbook/read/probability-problems/ne4zfe/) 中解决的一个问题，问题和解法如下 

>一枚骰子掷出第一个 6 平均需要掷多少次。

当时我们用两种方法解决了这个问题:

### 期望的定义

第一种是直接用期望的定义求期望

$$
E(X) = \sum\limits_{i}i \times p(i)
$$

由于 i 的所有可能取值和 p(i) 我们都可以算出来，于是通过定义再加上一些公式推导技巧我们求出了 E(X) 的解析解。

### 全期望公式

第二种是基于 [全期望公式](https://leetcode-cn.com/leetbook/read/probability-problems/n9iofv/) 求期望

$$

E_{X}(X) = E_{Y}(E_{X|Y}(X|Y)) \\
= \sum\limits_{y}p(Y=y) \times E_{X|Y=y}(X|Y=y) \\

$$

当时在那篇文章中的思路是这么写的

>记 m 为第一个 6 需要的次数
>当第一次投掷成功时，则需要的平均次数是 1
>当第一次投掷失败时，则需要的平均次数是 1 + m
>于是有以下公式，进而可以求出 m
>m = p \* 1 + q \* (1 + m)

从全期望公式的角度看

X 是掷出第一个 6 的次数，m 就是 E(X)；
Y 是第一次投掷出的点数是否为 6，是则记 Y=1，否则记 Y=0；
Y=1 的概率为 p，Y=0 的概率为 q；
E(X|Y=1) = 1，E(X|Y=0) = 1 + E(X)

代入公式即可得到解题思路中用的公式 `m = p * 1 + q * (1 + m)`

$$

E(X) = p(Y=1)E(X|Y=1) + p(Y=0)E(X|Y=0) \\
= p \times 1 + q \times (1 + E(X)) \\

$$

### 有向图

全期望公式的应用难点在于找出 E(X|y)。上述问题中 E[X| y=0] = (1 + E(X)), E[X| y=1] = 1 比较简单，我们能快速看出 E[X|y]，而在稍微复杂的问题上，我们需要有一种找到 E[X|y] 的方法论 -- 有向图。

用全期望公式求期望的过程可以用有向图的方式表示出来。以上述问题为例，我们可以画出下面的有向图。

![image.png](https://pic.leetcode-cn.com/1646113031-amwqtX-image.png){:style="max-height:250px"}　


其中节点 0 表示未投掷出 6 的状态，节点 1 为表示掷出 6 的状态。0 为起点，1 为终点。

图中的每条有向边有一个概率值，还有另一个权值，节点有一个期望值。

我们要求的是从起始状态走向终点状态要走的步数的期望，每个节点有一个期望值表示从该节点走到终点节点的期望。由于 1 是终点，所以 E[1] = 0。0 是起点，我们要求的就是 E[0]。

从节点 0 会伸出两条边，一条回到 0，表示当前的投掷没有掷出 6，另一条通向 1，表示当前的投掷掷出了 6。边上的概率值表示当前投掷的各个值的概率，而投掷一次步数加一，因此额外的边权都是 1。

定义好这个图之后，我们就可以写出 E[0] 的表达式了 

```plain
E[0] = p * (1 + E[1]) + q * (1 + E[0])
```

这个表达式就是全期望公式，只是将全期望公式中 E(X|y) 的部分用图中点权和边权的方式定义了计算方法。

### 期望 DP

通过以上的分析可以发现，当根据具体问题定义好有向图 D，起点 s，终点 t 后，我们就可以用类似于动态规划的方式求从 s 到 t 的某个指标的期望。

```
状态定义
dp[u] := 从 u 到 t 的某个指标的期望

初始化
dp[t]

答案
dp[s]

状态转移
dp[u] = g(node[u], sum(p[u][v] * f(w[u][v], dp[v])))
```

其中 f 是边权 w[u][v] （在上面的题中是 1） 和下一点的期望 dp[v] 的函数，g 是当前点的点权 node[u]（在上面的题中没有）和 sum(p[u][v] * f) 的函数, 具体的函数形式取决于问题（在上面的题中 f 就是简单的 w[u][v] + dp[v], g 没有），需要具体分析。

求解 dp[s] 的过程：对反图（将原图中的每条有向边的方向反转之后形成的图）进行拓扑排序，按照拓扑排序的顺序依次求解各个节点 u 的 dp[u]，直至求解到 dp[s]。

### 高斯消元

当建出的有向图中有环的时候，求解 E[s] 的过程如果直接用期望 DP 从 dp[t] 向 dp[s] 推导的话是不行的，因为在推导 DP 状态时会出现类似于下面的情况（就是后面的【用户一次游戏带来的收入】那道题的转移方程，这里提前看一下）

```plain
dp[0] = dp[1]
dp[1] = 1 + 0.7 * dp[2] + 0.3 * dp[0]
dp[2] = 2 + 0.6 * dp[3] + 0.4 * dp[1]
dp[3] = 3 + 0.5 * dp[4] + 0.5 * dp[2]
dp[4] = 0
```

这种情况 dp 状态的转移形成了环，比如要求 dp[1] 要先知道 dp[2]，要求 dp[2] 就要先知道 dp[1]，没法求了。

如果方程组是线性方程组，还有有办法的，解决办法是利用高斯消元的方式整体解这个线性方程组。

关于高斯消元的推导、代码、题目，可以找相关资料学习。

---

### 方法总结

现总结求解这类期望问题的方法论。 

1、理论基础：全期望公式； 

2、处理具体问题时，我们先分析建图所需的信息： 

1）起点 s 和终点 t 状态是什么，还有哪些状态节点； 

2）求出各个状态节点一步可以走到哪些状态节点，概率又分别是多少； 

3）分析目标期望是否需要额外的点权和边权。 

3、建图，初始化 dp[t]； 

4、分析状态转移方程中的 g，f 并写出实际的转移方程； 

5、求解 dp[s]，这里注意两点： 

- 如果图没有环，直接按拓扑排序的顺序应用动态规划的方式推导； 
- 如果图中有环，还需进一步看方程组的形式，若是线性方程组我们可以用高斯消元法求解，对于其他形式方程这里暂不作讨论。

---

### 题目: 装备升级

下面开始今天要看的题目。题目描述如下:

玩家的装备有从 0 到 4 这 5 个等级，每次升级都需要一个工序，一共有 0->1, 1->2, 2->3, 3->4 这 4 个工序，成功率分别为 0.9, 0.7, 0.6, 0.5。工序成功，玩家的装备就会升一级，但如果失败，玩家的装备就要倒退一级。例如玩家当前的等级为 2，目前执行 2->3 这个工序，如果成功，则装备等级从 2 升为 3，如果失败，装备等级就从 2 降到 1。

问：玩家装备初始等级为 0, 升到 5 平均要经历多少个工序。

#### 思路参考

##### 步骤 1： 建图

按照前面的方法总结。我们首先分析题目并建图，点状态是 0，终点状态是 4，此外还有 1, 2, 3 这三个中间状态。题目描述中明确给出了状态间的转移方向以及概率。我们要求的是从 s=0 走到 t=4 平均需要走的步数。

由于每经过一条边都相当于走了一步，所以边上有额外的权 1。除此之外没有别的权，节点上也没有权。根据这些信息，我们首先把图建出来，如下

![image.png](https://pic.leetcode-cn.com/1646112703-nzhvor-image.png)


##### 步骤 2：期望DP

期望 DP 的方程组如下:

```plain
dp[0] = 0.9 * (1 + dp[1]) + 0.1 * (1 + dp[0])
dp[1] = 0.7 * (1 + dp[2]) + 0.3 * (1 + dp[0])
dp[2] = 0.6 * (1 + dp[3]) + 0.4 * (1 + dp[1])
dp[3] = 0.5 * (1 + dp[4]) + 0.5 * (1 + dp[2])
dp[4] = 0
```

这是一个有环的图，且方程是线性方程组，面试的时候手推就可以。

如果要编程的话，需要整理成标准形式后用高斯消元解决。

##### 步骤3 ：高斯消元

标准形式如下

$$
\begin{gathered}
\begin{bmatrix} 
0.9 & -0.9 & 0 & 0 & 0  \\
-0.3 & 1 & -0.7 & 0 & 0 \\
0 & -0.4 & 1 & -0.6 & 0 \\
0 & 0 & -0.5 & 1 & -0.5 \\
0 & 0 & 0 & 0 & 1 \\
\end{bmatrix}
\begin{bmatrix} 
dp[0] \\
dp[1] \\
dp[2] \\
dp[3] \\
dp[4] \\
\end{bmatrix}
=
\begin{bmatrix}
1 \\
1 \\
1 \\
1 \\
0 \\
\end{bmatrix} 
\end{gathered}
$$

高斯消元求解

```cpp
#include <vector>
#include <cmath>
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    // 系数矩阵
    vector<vector<double>> c{{0.9, -0.9, 0, 0, 0}
                            ,{-0.3, 1, -0.7, 0, 0}
                            ,{0, -0.4, 1, -0.6, 0}
                            ,{0, 0, -0.5, 1, -0.5}
                            ,{0, 0, 0, 0, 1}
                            };
    // 常数列
    vector<double> b{1, 1, 1, 1, 0};
    int n = 5;
    const double EPS = 1e-10;

    // 高斯消元, 保证有唯一解
    for(int i = 0; i < n; ++i)
    {
        // 找到 x[i] 的系数不为零的一个方程
        for(int j = i; j < n ;++j)
        {
            if(fabs(c[j][i]) > EPS)
            {
                for(int k = 0; k < n; ++k)
                    swap(c[i][k], c[j][k]);
                swap(b[i], b[j]);
                break;
            }
        }
        // 消去其它方程的 x[i] 的系数
        for(int j = 0; j < n; ++j)
        {
            if(i == j) continue;
            double rate = c[j][i] / c[i][i];
            for(int k = i; k < n; ++k)
                c[j][k] -= c[i][k] * rate;
            b[j] -= b[i] * rate;
        }
    }
    cout << std::fixed << std::setprecision(6);
    for(int i = 0; i < n; ++i)
    {
        cout << "dp[" << i << "] = " << b[i] / c[i][i] << endl;
    }
}
```

求解结果 

```plain
dp[0] = 10.888889
dp[1] = 9.777778
dp[2] = 7.873016
dp[3] = 4.936508
dp[4] = 0.000000
```

## 蒙特卡洛模拟验证结果

```python
import numpy as np
import bisect

class Game:
    def __init__(self, p):
        self.n = p.shape[0]
        self.p = p
        for i in range(self.n):
            for j in range(1, self.p.shape[1]):
                self.p[i][j] += self.p[i][j - 1]

    def step(self, pos):
        return bisect.bisect_left(self.p[pos]
                                 ,np.random.rand())

    def __call__(self):
        pos = 0
        n_steps = 0
        while pos != self.n:
            pos = self.step(pos)
            n_steps += 1
        return n_steps

p = np.array([[0.1, 0.9, 0.0, 0.0, 0.0]
             ,[0.3, 0.0, 0.7, 0.0, 0.0]
             ,[0.0, 0.4, 0.0, 0.6, 0.0]
             ,[0.0, 0.0, 0.5, 0.0, 0.5]
             ])
game = Game(p)

def test():
    T = int(1e7)
    total_n_steps = 0
    for t in range(T):
        total_n_steps += game()
    print("Average Steps: {:.6f}".format(total_n_steps / T))

for i in range(10):
    test()
```

模拟结果

```plain
Average Steps: 10.890664
Average Steps: 10.887758
Average Steps: 10.882893
Average Steps: 10.889820
Average Steps: 10.891342
Average Steps: 10.888397
Average Steps: 10.888496
Average Steps: 10.891009
Average Steps: 10.890464
Average Steps: 10.886080
```

## 6. 一次游戏通关带来的收入
在前一小节中我们通过【有向图+期望DP+高斯消元】这个方法论解决了装备问题，题目描述和解法可以参考前一小节。

下面我们在装备升级问题上做一些变化，我们保持图结构不变，但是我们把期望 DP 转移方程中的边权改为节点的权。

我们考虑一个在游戏相关岗位面试常见的问题: 一次游戏通关带来的收入

>一个游戏有四关，通过概率依次为0.9, 0.7, 0.6, 0.5。
>第一关不收费，第二到四关每次收费分别为1块, 2块, 3块。
>用户每玩一次都会无限打下去直至通关，通关后用户可以提现 10 块钱作为奖励。
>问: 公司可以在每次用户游戏中平均挣多少钱。

### 思路参考

我们首先考虑【公司可以在每次用户游戏中收费多少钱】，然后减去 10 块钱的奖励就是挣的钱。

#### 建图

图与上面的装备升级那道题一样，只是边权没有了，节点有权重表示费用。

![image.png](https://pic.leetcode-cn.com/1646112809-VOCilM-image.png)


#### 期望 DP

期望 DP 的方程组如下:

```plain
dp[0] = dp[1]
dp[1] = 1 + 0.7 * dp[2] + 0.3 * dp[0]
dp[2] = 2 + 0.6 * dp[3] + 0.4 * dp[1]
dp[3] = 3 + 0.5 * dp[4] + 0.5 * dp[2]
dp[4] = 0
```

这是一个有环的图，且方程是线性方程组，面试的时候手推就可以。

如果要编程的话，需要整理成标准形式后用高斯消元解决。

#### 高斯消元

标准形式如下

$$
\begin{gathered}
\begin{bmatrix} 
1 & -1 & 0 & 0 & 0  \\
-0.3 & 1 & -0.7 & 0 & 0 \\
0 & -0.4 & 1 & -0.6 & 0 \\
0 & 0 & -0.5 & 1 & -0.5 \\
0 & 0 & 0 & 0 & 1 \\
\end{bmatrix}
\begin{bmatrix} 
dp[0] \\
dp[1] \\
dp[2] \\
dp[3] \\
dp[4] \\
\end{bmatrix}
=
\begin{bmatrix}
0 \\
1 \\
2 \\
3 \\
0 \\
\end{bmatrix} 
\end{gathered}
$$

高斯消元求解

```cpp
#include <vector>
#include <cmath>
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    // 系数矩阵
    vector<vector<double>> c{{1, -1, 0, 0, 0}
                            ,{-0.3, 1, -0.7, 0, 0}
                            ,{0, -0.4, 1, -0.6, 0}
                            ,{0, 0, -0.5, 1, -0.5}
                            ,{0, 0, 0, 0, 1}
                            };
    // 常数列
    vector<double> b{0, 1, 2, 3, 0};
    int n = 5;
    const double EPS = 1e-10;

    // 高斯消元, 保证有唯一解
    for(int i = 0; i < n; ++i)
    {
        // 找到 x[i] 的系数不为零的一个方程
        for(int j = i; j < n ;++j)
        {
            if(fabs(c[j][i]) > EPS)
            {
                for(int k = 0; k < n; ++k)
                    swap(c[i][k], c[j][k]);
                swap(b[i], b[j]);
                break;
            }
        }
        // 消去其它方程的 x[i] 的系数
        for(int j = 0; j < n; ++j)
        {
            if(i == j) continue;
            double rate = c[j][i] / c[i][i];
            for(int k = i; k < n; ++k)
                c[j][k] -= c[i][k] * rate;
            b[j] -= b[i] * rate;
        }
    }
    cout << std::fixed << std::setprecision(6);
    for(int i = 0; i < n; ++i)
    {
        cout << "dp[" << i << "] = " << b[i] / c[i][i] << endl;
    }
}
```

求解结果

```cpp
dp[0] = 16.000000
dp[1] = 16.000000
dp[2] = 14.571429
dp[3] = 10.285714
dp[4] = 0.000000
```

因此公司可以在每次用户游戏中收费 dp[0] = 16 块钱，减去用户通关的 10 块钱奖金，公司可以挣 6 块钱。

## 蒙特卡洛模拟验证结果

```python
import numpy as np
import bisect

class Game:
    def __init__(self, transfer, cost):
        self.n = transfer.shape[0]
        self.cost = cost
        self.transfer = transfer
        for i in range(self.n):
            for j in range(1, self.transfer.shape[1]):
                self.transfer[i][j] += self.transfer[i][j - 1]

    def step(self, pos):
        return bisect.bisect_left(self.transfer[pos]
                                 ,np.random.rand())

    def __call__(self):
        pos = 0
        pay = 0
        while pos != self.n:
            pay += self.cost[pos]
            pos = self.step(pos)
        pay += self.cost[self.n]
        return pay

transfer = np.array([[0.1, 0.9, 0.0, 0.0, 0.0]
                    ,[0.3, 0.0, 0.7, 0.0, 0.0]
                    ,[0.0, 0.4, 0.0, 0.6, 0.0]
                    ,[0.0, 0.0, 0.5, 0.0, 0.5]
                    ])
cost = np.array([0.0, 1.0, 2.0, 3.0, -10.0])
game = Game(transfer, cost)

def test():
    T = int(1e5)
    total_pay = 0
    for t in range(T):
        total_pay += game()
    print("Average income: {:.4f}".format(total_pay / T))

for i in range(10):
    test()
```

模拟结果

```plain
Average income: 5.9768
Average income: 6.0043
Average income: 5.9052
Average income: 6.0664
Average income: 6.0720
Average income: 5.9687
Average income: 6.0101
Average income: 6.0450
Average income: 5.9871
Average income: 6.0704
```

## 7. 祝你好运
“祝你好运”一种赌博游戏，经常在嘉年华和赌场玩。

玩家可以在 1, 2, 3, 4, 5, 6 中的某个数上下注。然后投掷 3 个骰子。

如果玩家下注的数字在这三次投掷中出现了 x 次，则玩家获得 x 倍原始投注资金，并且原始投注资金也会返还，也就是总共拿回 (x + 1) 倍原始投注资金。如果下注的数字没有出现，则原始投注资金不会返还。

问：每单位原始投注资金，玩家期望会输多少？

### 思路参考

设原始投注资金为 s，下注的数字在三次投掷中出现了 x 次，x 的取值为 0, 1, 2, 3，下面我们分别考虑这四种情况。

$$
P(x = 3) = (\frac{1}{6})^{3} = \frac{1}{216}\\
P(x = 2) = \binom{3}{1} \times \frac{5}{6} \times (\frac{1}{6})^{2} = \frac{15}{216} \\
P(x = 1) = \binom{3}{2} \times (\frac{5}{6})^{2} \times \frac{1}{6} = \frac{75}{216} \\
p(x = 0) = (\frac{5}{6})^{3} = \frac{125}{216} \\
$$

按照期望的定义

$$
E(X) = \sum\limits_{i} i \times p(i)
$$

拿回的钱的期望为 

$$

E = 4s \times P(x = 3) + 3s \times P(x = 2) + 2s \times P(x = 1) \\
= 4s \times \frac{1}{216} + 3s \times \frac{15}{216} + 2s \times \frac{75}{216} \\
= \frac{4 + 45 + 150}{216}s = \frac{199}{216}s

$$

每单位投注资金的损失为 `17/216 = 0.0787`

### 蒙特卡洛模拟

```python
import numpy as np

def game():
    x = 0
    for _ in range(3):
        if np.random.randint(1, 7) == 1:
            x += 1
    if x == 0:
        return 0
    return x + 1

def test():
    T = int(1e6)
    total_income = 0
    for t in range(T):
        total_income += game()
    print("expected loss: {:.6f}".format((T - total_income) / T))

for i in range(10):
    test()
```

模拟结果

```plain
expected loss: 0.078817
expected loss: 0.078182
expected loss: 0.078731
expected loss: 0.078875
expected loss: 0.078526
expected loss: 0.078657
expected loss: 0.078634
expected loss: 0.079033
expected loss: 0.079353
expected loss: 0.079307
```

## 8. 仓促的决斗
在某一天的决斗场，有两个人会在 5 点到 6 点之间随机的某一分钟到来，然后 5 分钟后离开。
如果某一时刻这两个人同时在场，会发生决斗。
问：这两个人发生决斗的概率是多少？

---

# 思路参考

记两个人分别为 a 和 b，如图所示，横轴 x 是 a 到达的时间，纵轴 y 是 b 到达的时间，到达的时间范围均为 0 ~ 1。

![image.png](https://pic.leetcode-cn.com/1646112881-UdWmWJ-image.png){:style="max-height:350px"}　


(x, y) 会随机地在图中的正方形区域中产生，如果两个人的时间间隔小于 1/12 则会发生决斗，也就是 `abs(x - y) < 1/12`，这对应于图中的阴影部分。

(x, y) 落在阴影的概率是阴影面积与正方形面积的比值。

$$
P = 1 - (\frac{11}{12})^{2} = \frac{23}{144} = 0.159722
$$

---

# 蒙特卡洛模拟

```python
import numpy as np
from multiprocessing import Pool

def test(T):
    array_arrival_times = 60 * np.random.random(size=(T, 2))
    array_diff = np.abs(np.diff(array_arrival_times))
    return np.mean(array_diff <= 5)

T = int(1e7)
args = [T] * 8
pool = Pool(8)
ts = pool.map(test, args)
print("发生决斗的概率: {:.6f}".format(sum(ts) / len(ts)))
```

模拟结果

```plain
发生决斗的概率: 0.159805
```

## 9. 帮助赌徒戒赌
布朗沉迷于轮盘赌，并且强迫症地总是在 13 这个数字上押注 1 美元。

轮盘赌有 38 个等概率的数字，如果玩家押注的数字出现，则拿到 35 倍投注金额，加上原始投注金额，共 36 倍，如果押注的数字没出现，则损失原始投注金额。

好朋友为了帮助布朗戒赌，设计了一个赌注，与布朗等额投注 20 美元（好朋友和布朗均需要出 20 美元），赌以下事情：布朗在第 36 次游戏完成之后会亏钱（如果果真亏钱了，则朋友得到双方的筹码共 40 美元，否则布朗得到这 40 美元）。

问：这个戒赌方案是否有效（如果布朗能挣钱，说明无效，如果布朗会亏钱则说明有效）。

# 思路参考

布朗每次游戏的获胜概率为 p = 1/38，期望从赌场拿回的钱为 `36 * p`。

考虑 36 次游戏。布朗需要付出 36 美元与赌场的押注金额，以及 20 美元与朋友的押注金额。下面我们看布朗期望能够拿回多少钱。

布朗拿回的钱中，一部分来自赌场，另一部分来自朋友。

来自赌场的部分，布朗每次期望拿回 `36 * p`，36 次期望拿回 `36 * 36 * p`。

下面考虑来自朋友的部分:

每一次获胜，布朗会获得 36 美元。也就是说布朗只要赢一次就已经不亏了，也就意味着他只要不是 36 场全输了，就可以从朋友那里拿回 40 美元。

布朗在 36 次游戏中至少赢一次的概率为:
$$
1 - (1 - p)^{36}
$$

因此布朗期望从好朋友那里拿回的金额为 `40 * (1 - (1 - p) ^ 36)`

把两部分加在一起，布朗在 36 次游戏中拿回金额的期望（平均可拿到金额）为

$$
E = 40(1 - (1 - p)^{36}) + 36 \times 36 \times p
$$

这个数只要大于 36 + 20 = 56 美元，那么朋友设计的这个戒赌方案反而会助长布朗去赌博，戒赌方案就无效。下面我们编程计算这个数

```python
def E(p):
    q = (1 - p) ** 36
    return 40 * (1 - q) + 36 * 36 * p

income = E(1 / 38)
print("Except Income: {:.6f}".format(income))
```

计算结果

```plain
Except Income: 58.790419
```

由于期望能拿回 58.790419 美元，比 56 美元多，布朗能够挣钱，朋友设计的戒赌方案无效。

# 蒙特卡洛模拟

```python
from multiprocessing import Pool
import numpy as np

p = 1/38

def game1():
    # 1 次游戏，返回游戏结束拿回的钱
    if np.random.rand() < p:
        return 36
    return 0

def game36():
    # 36 次游戏，返回36次游戏结束拿回的钱
    w = 0
    for _ in range(36):
        w += game1()
    if w >= 36:
        return w + 40
    return w

def test(T):
    np.random.seed()
    total = 0
    for _ in range(T):
        total += game36()
    return total / T

T = int(1e6)
args = [T] * 8
pool = Pool(8)
incomes = pool.map(test, args)
for x in incomes:
    print("Average Income: {:.6f}".format(x))
```

模拟结果

```plain
Average Income: 58.894648
Average Income: 58.697580
Average Income: 58.741948
Average Income: 58.745660
Average Income: 58.757380
Average Income: 58.819856
Average Income: 58.800196
Average Income: 58.767288
```

## 10. 较短的一节木棍
一根棍子，随机选个分割点，将棍子分为两根。  
a. 较小的那一根的长度平均是多少？  
b. 较小的那一根与较长的那一根的比例平均是多少？

---

# 思路参考

假设木棍长度为 1，分隔点 X 是 (0, 1) 上的均匀分布，也就是 X ~ U(0, 1)，概率密度函数 $f_{X}(x) = 1$, 0 < x < 1。

记较短的那一根的长度为 Y，y 与 x 的关系如下

$$Y = g(x)
\left\{\begin{matrix}
X \quad\quad X \in (0, 1/2) \\  
1 - X \quad\quad X \in (1/2, 1) \\  
\end{matrix}\right.$$

下面我们来看 (a) 和 (b) 两问：

## (a)

要求 Y 的期望，我们还需要两个知识点，一个是连续型随机变量的期望，一个是连续型随机变量函数的概率密度函数。

## 知识点复习

### (1) 连续型随机变量的期望

$$
E(X) = \int^{+\infty}_{-\infty}xf_{X}(x)dx
$$

### (2) 随机变量函数的概率密度函数

X 的概率密度函数为 $f_{X}(x)$，Y = g(X)，Y 的概率密度函数是多少？

解决这个问题可借助下面通用流程： 

- 根据 X 的范围（记作 Rx）求出 Y 的范围（记作 Ry）； 
- 对 Ry 中的每一个 y，求出分布函数 $F_{Y}(y)$。【一般用积分的方法】 

$$
F_{Y}(y) = P(Y\leq y) = P(g(X) \leq y) = P(X \in Ry) = \int_{Ry}f_{X}(x)dx
$$

**其中 $x\in Ry$ 与 $g(X) \leq y$ 是相同的随机事件。$Ry = \{x: g(x) \leq y\}$**

- 对分布函数 $F_{Y}(y)$ 求导得到密度函数 $f_{Y}(y)$。

而如果 g(X) 是严格单调函数，x = h(y) 为相应的反函数，且可导，则 Y = g(X) 的密度函数可以直接给出

$$
h = g^{-1} \\
f_{Y}(y) = f_{X}(h(y))|h^{'}(y)| \\
$$

## 计算

有了以上两个知识点，我们就可以开始计算了，下面我们推导 Y 的概率密度函数。

g 是一个分段函数，在 (0, 1/2) 上，Y = X，单调递增，在 (1/2, 1) 上，Y = 1 - X，单调递减。因此我们可以对这两个范围分别来看。

### (1) 对于 0 < x < 1/2

在 0 < x < 1/2 范围内，y = g(x) = x，因此 0 < y < 1/2，其反函数 x = h(y) = y，导数 h'(y) = 1。y 的密度函数如下

$$

f_{Y}(y) = f_{X}(h(y))|h^{'}(y)| = 1

$$

y 的期望如下

$$

E(y) = \int^{+\infty}_{-\infty}yf_{Y}(y)dy \\
= \int^{\frac{1}{2}}_{0}ydy = \left.\frac{1}{2}y^{2}\right|^{\frac{1}{2}}_{0} = \frac{1}{8} \\

$$

### (2) 对于 1/2 < x < 1

在 1/2 < x < 1 范围内，y = g(x) = 1 - x，因此 0 < y < 1/2，其反函数 x = h(y) = 1 - y，导数 h'(y) = -1。y 的密度函数如下

$$

f_{Y}(y) = f_{X}(h(y))|h^{'}(y)| = 1

$$

y 的期望如下

$$

E(y) = \int^{+\infty}_{-\infty}yf_{Y}(y)dy \\
= \int^{\frac{1}{2}}_{0}ydy = \left.\frac{1}{2}y^{2}\right|^{\frac{1}{2}}_{0} = \frac{1}{8} \\

$$

将两部分加到一起即可得到所求的期望值，答案为 1/4。

## (b)

要求较小的那一根与较长的那一根的比例的期望，也就是求 y / (1 - y) 的期望。

由 (a)，我们已经知道 Y 的范围是 (0, 1/2)，并且 $f_{Y}(y)$ 根据 X 的取值来源于两部分，第一部分是 1 < X < 1/2，第二部分是 1/2 < X < 1。将 X 取值在这两个范围时的 $f_{Y}(y)$ 相加，可以得到：

$$
f_{Y}(y) = 2 \quad\quad y \in (0, 1/2)
$$

这里 $f_{Y}(y) = 2$，但是 y 的取值是 (0, 1/2)，这是一个均匀分布。基于 Y，我们定义随机变量 Z = Y / (1 - Y)

$$
z = g(y) = \frac{y}{1 - y}
$$

g(y) 是严格单调的，其反函数为 h(z) = z / (z + 1)，其导数为 $h'(z) = (z + 1)^{-2}$, z 的范围为 (0, 1)，因此 z 的密度函数如下

$$
f_{Z}(z) = f_{Y}(h(z))|h^{'}(z)| = 2 \times (z + 1)^{-2}
$$

Z 的期望如下

$$

E(z) = \int^{+\infty}_{-\infty}zf_{Z}(z)dz \\
= \int^{1}_{0}2z \times (z + 1)^{-2}dz \\
= \int^{2}_{1}\frac{2u - 2}{u^{2}}du \\
= 2\left.\ln u\right|^{2}_{1} - 2\left.(-u^{-1})\right|^{2}_{1} \\
= 2\ln 2 - 1 = 0.386294

$$

# 蒙特卡洛模拟

```python
import numpy as np

def pyfunc(x):
    """
    0 < x < 1
    """
    if x > 0.5:
        x = 1 - x
    return x

def pyfunc2(x):
    """
    0 < x < 0.5
    """
    return x / (1 - x)

func = np.frompyfunc(pyfunc, 1, 1)
func2 = np.frompyfunc(pyfunc2, 1, 1)

def test(T):
    X = np.random.uniform(0, 1, T)
    X = func(X)
    Y = func2(X)
    return (np.mean(X), np.mean(Y))

T = int(1e7)
m1, m2 = test(T)
print("较短的木棍的期望长度: {:.6f}".format(m1))
print("较短的木棍与较长的木根长度比值的期望: {:.6f}".format(m2))
```

模拟结果

```plain
较短的木棍的期望长度: 0.249920
较短的木棍与较长的木根长度比值的期望: 0.386187
```

## 11. 完美手牌
从一副洗好的牌（52张）中抽 13 张，拿到完美手牌（拿到的 13 张是同花色）的概率是多少。

# 思路参考

52 张牌一共有 52! 中排列顺序。

完美手牌需要抽取的 13 张是同一花色，这 13 张同一花色的牌有 13! 种排列顺序，未被抽到的 39 张牌有 39! 中排列顺序。

因此对于指定花色，所有抽到的牌都是这一指定花色的概率为

$$
p = \frac{13! \times (39)!}{52!} 
$$

一共有四种花色，因此拿到完美手牌的概率为

$$
4p = \frac{4 \times 13! \times (39)!}{52!}
$$

编程计算

```python
from math import factorial as fac

p = 4.0 * fac(13) * fac(39) / fac(52)
print("{:.6e}".format(p))
```

计算结果

```plain
6.299078e-12
```

## 12. 双骰子赌博
双骰子赌博是美国的流行游戏，规则如下： 

每次同时投掷两个骰子并且只看点数和。第一次投掷的点数和记为 x。若 x 是 7 或 11，玩家获胜，游戏结束；若 x 是 2、3 或 12，则输掉出局，其余情况则需要继续投掷。从第二次投掷开始，如果投掷出第一次的点数和 x，则获胜；如果投掷出 7，则输掉出局。重复投掷直至分出胜负。 

问：获胜的概率是多少？

---

# 思路参考

## 首先考虑第一次投掷

第一次投掷一共有直接输，直接赢，需要继续投掷三种可能性。

(1) 直接输的情况是两枚骰子的和为 2、3、12，两个骰子各自的点数情况有 (1, 1), (2, 1), (1, 2), (6, 6) 这 4 中可能性。而两个骰子各自点数共有 `6 * 6 = 36` 种可能性，因此第一次投掷直接输的概率为 1/9。

(2) 直接赢的情况是两枚骰子的和为 7, 11，两个骰子各自的点数情况有 (1, 6), (2, 5), (3, 4), (4, 3), (5, 2), (6, 1), (5, 6), (6, 5) 共 8 种可能性，概率 2/9。

(3) 剩下 2/3 概率的情况，需要继续投掷，我们记此前的第 1 次投掷的点数和为 x。

## 考虑第二次以及后续可能的投掷

从第 2 次开始，以后每次投掷的输、赢、继续投掷的条件都一样。因此我们可以只考虑第 2 次投掷，如果投掷结果是需要继续投掷，递归处理即可。

记某次投掷直接赢的概率为 p(x)，与第一次的投掷结果 x 有关，直接输的概率为 q，与第一次的投掷结果 x 无关，则需要继续投掷的概率为 (1 - p(x) - q)，下面我们看输和赢的具体条件：

(1) 输的情况是投掷出 7，两个骰子各自的点数情况共有 (1, 6), (2, 5), (3, 4), (4, 3), (5, 2), (6, 1) 共 6 种情况，概率 q = 1 / 6。

(2) 赢的情况是投掷出 x。两个骰子各自的点数情况需要看 x。下面我们枚举 x 可能取值（4、5、6、8、9、10）： 

- x = 4: (1, 3), (2, 2), (3, 1)，概率为 1/12； 
- x = 5: (1, 4), (2, 3), (3, 2), (4, 1)，概率为 1/9； 
- x = 6: (1, 5), (2, 4), (3, 3), (2, 4), (5, 1)，概率为 5/36； 
- x = 8: (2, 6), (3, 5), (4, 4), (5, 3), (6, 2)，概率为 5/36； 
- x = 9: (3, 6), (4, 5), (5, 4), (6, 3)，概率为 1/9； 
- x = 10: (4, 6), (5, 5), (6, 4)，概率为 1/12。

总结一下，直接赢的概率 p(x) 与 x 的所有可能取值的对应关系如下

```plain
p(4) = 1/12
p(5) = 1/9
p(6) = 1/36
p(8) = 1/36
p(9) = 1/9
p(10) = 1/12
```

(3) 剩下的情况是需要继续投掷的，概率为 (1 - p(x) - q) 

综合以上 3 条，从第二次投掷开始，最终能赢有两种情况，一种是第二次投掷直接赢，另一种是需要继续投掷，并在后续投掷中赢了。记 P(x) 为从第二次投掷开始，最终会赢的概率。

$$
P(x) = p(x) + (1 - p(x) - q) \times P(x) \\
P(x) = \frac{p(x)}{p(x) + q}
$$

将第一次投掷直接赢和进入第二次投掷并最终赢这两种情况合起来，就是最终能赢的两种情况，概率记为 prob

$$
prob = \frac{2}{9} + \sum\limits_{x} p(x) \times P(x) \\
其中 x = 4,5,6,8,9,10
$$

下面编程计算 prob 这个数

```python
mapping = {
    4: 1/12,
    5: 1/9,
    6: 5/36,
    8: 5/36,
    9: 1/9,
    10: 1/12,
}

q = 1/6

prob = 2/9
for x, p in mapping.items():
    P = p / (p + q)
    prob += p * P
print("Probability of win: {:.6f}".format(prob))
```

计算结果

```plain
Probability of win: 0.492929
```

# 蒙特卡洛模拟

```python
from multiprocessing import Pool
import numpy as np

def throw2(x0):
    # 第二次以后的投掷
    x1 = np.random.randint(1, 7)
    x2 = np.random.randint(1, 7)
    x = x1 + x2
    if x == 7:
        return 0
    elif x == x0:
        return 1
    else:
        return throw2(x0)

def throw1():
    # 第一次投掷
    x1 = np.random.randint(1, 7)
    x2 = np.random.randint(1, 7)
    x = x1 + x2
    if x == 7 or x == 11:
        return 1
    elif x == 2 or x == 3 or x == 12:
        return 0
    else:
        return throw2(x)

def test(T):
    np.random.seed()
    n = 0
    for _ in range(T):
        n += throw1()
    return  n / T

T = int(1e7)
args = [T] * 8
pool = Pool(8)
probs = pool.map(test, args)
for prob in probs:
    print("Probability of win: {:.6f}".format(prob))
```

模拟结果

```plain
Probability of win: 0.492935
Probability of win: 0.492876
Probability of win: 0.492793
Probability of win: 0.492726
Probability of win: 0.493062
Probability of win: 0.493019
Probability of win: 0.493142
Probability of win: 0.492961
```

## 13. 收集优惠券
每个盒子中有一张优惠券，优惠券共有 5 种，编号为 1 到 5。必须收集所有5张优惠券才能获得奖品。

问：收集到一套完整的优惠券平均需要打开多少盒子？

# 思路参考

单独考虑每个优惠券。

记 T1 为一个随机变量，表示拿到第一个编号所需盒子数。P(T1 = 1) = 1，E(T1) = 1

记 T2 为一个随机变量，表示拿到第二个编号所需要的额外盒子数。根据**全期望公式**

$$

E(T_{2}) = \sum\limits_{X}E_{X}(E_{T_{2}|X}(T_{2}|X)) \\
= \sum\limits_{x}P(X = x)E_{T_{2}|X=x}(T_{2}|X=x) \\

$$

这里 X 表示新开盒子编号是否见过，共有两种情况： 

- 前面开盒子时见过，概率为 1/5，此时平均需要的额外盒子数（即期望）为 1 + E(T2)；【可参考$4-4 方法二、有向图总结】 
- 前面开盒子时没见过，概率为 4/5，此时平均需要的额外盒子数为 1。

$$
E(T_{2}) = \frac{4}{5} + \frac{1}{5}(1 + E(T_{2})) \\
E(T_{2}) = \frac{5}{4}
$$

记 T3 为一个随机变量，表示从第二个编号开始到拿到第三个新编号所需的额外盒子数。根据**全期望公式**

$$

E(T_{3}) = \sum\limits_{X}E_{X}(E_{T_{3}|X}(T_{3}|X)) \\
= \sum\limits_{x}P(X = x)E_{T_{3}|X=x}(T_{3}|X=x) \\

$$

这里的 X 是新开的盒子的数字是否是见过的那 2 个。共有两种情况
- 是前面见过的那2个，概率 2/5，此时额外的盒子数的期望是 1 + E(T3)
- 不是前面见过的那2个，概率 3/5，此时额外的盒子数就是 1

$$
E(T_{3}) = \frac{3}{5} + \frac{2}{5}(1 + E(T_{3})) \\
E(T_{3}) = \frac{5}{3}
$$

记 T4 为一个随机变量，表示从第三个编号开始到拿到第四个新编号所需的额外盒子数。根据**全期望公式**

$$

E(T_{4}) = \sum\limits_{X}E_{X}(E_{T_{4}|X}(T_{4}|X)) \\
= \sum\limits_{x}P(X = x)E_{T_{4}|X=x}(T_{4}|X=x) \\

$$

这里 X 表示新开盒子编号是否已出现过，分为两种情况： 

- 前面开盒子时见过，概率为 3/5，此时平均需要额外盒子数（期望）为 1 + E(T4)； 
- 前面开盒子时没见过，概率为 2/5，此时平均需要额外盒子数（期望）为 1。

$$
E(T_{4}) = \frac{2}{5} + \frac{3}{5}(1 + E(T_{4})) \\
E(T_{4}) = \frac{5}{2}
$$

记 T5 为一个随机变量，表示从第四个编号开始到拿到第五个新编号所需的额外盒子数。根据**全期望公式**

$$

E(T_{5}) = \sum\limits_{X}E_{X}(E_{T_{5}|X}(T_{5}|X)) \\
= \sum\limits_{x}P(X = x)E_{T_{5}|X=x}(T_{5}|X=x)) \\

$$

这里 X 表示新开盒子编号是否已出现过，分为两种情况： 

- 前面开盒子时见过，概率为 4/5，此时平均需要额外盒子数（期望）为 1 + E(T5)； 
- 前面开盒子时没见过，概率为 1/5，此时平均需要额外盒子数（期望）为 1。

$$
E(T_{5}) = \frac{1}{5} + \frac{4}{5}(1 + E(T_{5})) \\
E(T_{5}) = 5
$$

收集到一套完整的优惠券需要打开的盒子个数的期望为 E1 + E2 + E3 + E4 + E5 = 137/12 = 11.416667


# 蒙特卡洛模拟

```python
import numpy as np
import operator
from multiprocessing import Pool
from functools import reduce

def run():
    setting = set()
    n = 0
    while True:
        n += 1
        x = np.random.randint(1, 6)
        if x in setting:
            continue
        setting.add(x)
        if len(setting) == 5:
            break
    return n

def test(T):
    np.random.seed()
    y = (run() for _ in range(T))
    n = reduce(operator.add, y)
    return n / T

T = int(1e7)
args = [T] * 8
pool = Pool(8)
ts = pool.map(test, args)
for t in ts:
    print("{:.6f} coupons on average are required".format(t))
```

```plain
11.415423 coupons on average are required
11.417857 coupons on average are required
11.415529 coupons on average are required
11.417148 coupons on average are required
11.416793 coupons on average are required
11.413937 coupons on average are required
11.416149 coupons on average are required
11.416380 coupons on average are required
```

## 14. 第 2 强的选手拿亚军
![image.png](https://pic.leetcode-cn.com/1646113138-kJGCDt-image.png)


一场由 8 个人组成的淘汰赛，对阵图如上图。8 个人随机被分到图中的 1~8 号位置。
第二强的人总是会输给最强的人，同时也总是会赢剩下的人。决赛输的人拿到比赛的亚军。
问: 第二强的人拿到亚军的概率是多少？

# 思路参考

第二强的人拿到亚军，等价于最强的人和第二强的人在决赛遇到，等价于这两个人一个被分到 1~4，另一个被分到 5~8。

x1: 最强的人被分到 1~4
x2: 最强的人被分到 5~8
y1: 第二强的人被分到 1~4
y2: 第二强的人被分到 5~8

$$

P(x1y2) = P(x1) \times P(y2|x1) \\
= \frac{1}{2} \times \frac{4}{7} \\
= \frac{2}{7} \\

$$

$$

P(x2y1) = P(x2) \times P(y1|x2) \\
= \frac{1}{2} \times \frac{4}{7} \\
= \frac{2}{7} \\

$$

第二强的人获得亚军的概率为 `2/7+2/7=0.571428`

---

# 蒙特卡洛模拟

```python
import numpy as np
import operator
from multiprocessing import Pool
from functools import reduce

ladder = range(8)

def run():
    l = np.random.permutation(ladder)
    x = int(np.where(l == 0)[0][0])
    y = int(np.where(l == 1)[0][0])
    return (x <= 3 and y >= 4) or (x >= 4 and y <= 3)

def test(T):
    np.random.seed()
    y = (run() for _ in range(T))
    n = reduce(operator.add, y)
    return n / T

T = int(1e7)
args = [T] * 8
pool = Pool(8)
ts = pool.map(test, args)
for t in ts:
    print("P(the second-best player wins the runner-up cup): {:.6f}".format(t))
```

模拟结果

```plain
P(the second-best player wins the runner-up cup): 0.571250
P(the second-best player wins the runner-up cup): 0.571030
P(the second-best player wins the runner-up cup): 0.571432
P(the second-best player wins the runner-up cup): 0.571021
P(the second-best player wins the runner-up cup): 0.571379
P(the second-best player wins the runner-up cup): 0.571495
P(the second-best player wins the runner-up cup): 0.571507
P(the second-best player wins the runner-up cup): 0.571226
```

## 15. 孪生骑士
![image.png](https://pic.leetcode-cn.com/1646113206-AxhsVp-image.png)

(a)

8 个骑士进行淘汰赛，对阵图与上图这样的网球对阵图类似。8 个骑士的水平一样，任意一组比赛双方的获胜概率均为 0.5。8 个骑士中有两个人是孪生兄弟。
问：这两个孪生兄弟在比赛过程中相遇的概率？

(b)

将 8 个骑士的淘汰赛改为 `2^n` 个人的淘汰赛，问这两个孪生兄弟相遇的概率？

---

# 思路参考

## (a)

8 个骑士的比赛共有 3 轮，我们一轮一轮地考虑。

记事件 X1 为孪生骑士在第一轮相遇，若想在第一轮相遇，则它们必须同时被分到 (1, 2), (2, 1), (3, 4), (4, 3), (6, 5), (5, 6), (8, 7), (7, 8) 这八种情况之一。概率为

$$
P(X1) = \frac{1}{8}\times\frac{1}{7}\times 8
$$

记事件 X2 为孪生骑士在第二轮相遇，若想在第二轮相遇，则需要它们两个被分到以下十六种情况的一种，同时它们两个还要都赢了

```plain
(1, 3), (1, 4), (2, 3), (2, 4), (5, 7), (5, 8), (6, 7), (6, 8) 
(3, 1), (4, 1), (3, 2), (4, 2), (7, 5), (8, 5), (7, 6), (8, 6) 
```

概率为

$$
P(X2) = \frac{1}{8}\times\frac{1}{7}\times 16 \times (\frac{1}{2})^{2}
$$

记事件 X3 为孪生骑士在第三轮相遇，若想在第三轮相遇，需要它们两个其中一个被分到 [1..4] 中的一个，另一个被分到 [5..8] 中的一个。且他们在前两轮的共四场比赛都要赢，概率为

$$
P(X3) = \frac{4}{8}\times\frac{4}{7} \times 2 \times (\frac{1}{2})^{4}
$$

把 X1, X2, X3 这三种情况的概率加起来，得到孪生骑士相遇的概率

$$

\sum\limits_{i=1}\limits^{3}P(Xi) = \frac{1}{8}\times\frac{1}{7}\times 8 + \frac{1}{8}\times\frac{1}{7}\times 16 \times (\frac{1}{2})^{2} + \frac{4}{8}\times\frac{4}{7} \times 2 \times (\frac{1}{2})^{4} \\
= \frac{1}{4} = 0.25 \\

$$


## (b)

记事件 Xi 为孪生骑士在第 i 轮相遇，其中 i 取值为 1, 2, ..., n，共 `T = 2^n` 人。

对第 i 轮，将 `1 ~ 2^n` 连续地分为 `B = (2^n)/(2^(i-1))` 个桶，每个桶 `C = 2^(i-1)` 个元素。孪生骑士需要在编号为 (2k+1, 2k+2) 的相邻桶中（k=0,1,...,(2^n)/(2^i) - 1），相邻桶的组数为 `N = (2^n)/(2^i)`，孪生骑士在满足要求的桶中的概率为

$$
N \times \frac{C}{T}\times\frac{C}{T-1} \times 2 \\
= \frac{2^{n}}{2^{i}} \times \frac{2^{i-1}}{2^{n}}\times\frac{2^{i-1}}{2^{n}-1} \times 2 \\
= \frac{2^{i-1}}{2^{n} - 1}
$$

孪生骑士在第 1,2,...,i-1 轮中，共有 `(i-1) * 2` 场比赛。这些比赛还要赢，概率为 

$$
(\frac{1}{2})^{2(i-1)}
$$

将两个概率相乘就是孪生骑士在第 i 轮相遇的概率

$$
P(Xi) = \frac{1}{2^{n}-1} \times \frac{1}{2^{i-1}}
$$

孪生骑士相遇的概率为

$$

P(n) = \sum\limits_{i=1}\limits^{n}P(Xi) = \frac{1}{2^{n}-1} \times \sum\limits_{i=1}\limits^{n}\frac{1}{2^{i-1}} \\
= \frac{1}{2^{n}-1}\times\frac{1 - (\frac{1}{2})^{n}}{1 - \frac{1}{2}} \\
= \frac{1}{2^{n-1}}

$$

---

# 蒙特卡洛模拟

```python
import numpy as np
import operator
from multiprocessing import Pool
from functools import reduce

def P(n):
    return 1 / (2 ** (n - 1))

def run(n):
    l = np.random.permutation(ladder)
    for _ in range(1, n + 1):
        for i in range(0, len(l), 2):
            if l[i] + l[i + 1] == 1:
                return 1
            if np.random.rand() < 0.5:
                l[int(i / 2)] = l[i]
            else:
                l[int(i / 2)] = l[i + 1]
        l = l[:int(len(l) / 2)]
    return 0

def test(n):
    T = int(1e5)
    np.random.seed()
    y = (run(n) for _ in range(T))
    return reduce(operator.add, y) / T

def main(n):
    print("n = {}: P(n) = {}".format(n, P(n)))
    args = [n] * 8
    pool = Pool(8)
    ts = pool.map(test, args)
    for t in ts:
        print("P(twin knight meet): {:.6f}".format(t))
    print()

for n in range(3, 7):
    global ladder
    ladder = range(2 ** n)
    main(n)
```

模拟结果

```plain
n = 3: P(n) = 0.25           
P(twin knight meet): 0.249970
P(twin knight meet): 0.249815
P(twin knight meet): 0.250011
P(twin knight meet): 0.249984
P(twin knight meet): 0.249990
P(twin knight meet): 0.250079
P(twin knight meet): 0.249889
P(twin knight meet): 0.250108 

n = 4: P(n) = 0.125
P(twin knight meet): 0.124822
P(twin knight meet): 0.124963
P(twin knight meet): 0.124807
P(twin knight meet): 0.125172
P(twin knight meet): 0.124867
P(twin knight meet): 0.124937
P(twin knight meet): 0.124887
P(twin knight meet): 0.124992

n = 5: P(n) = 0.0625
P(twin knight meet): 0.062401
P(twin knight meet): 0.062294
P(twin knight meet): 0.062492
P(twin knight meet): 0.062508
P(twin knight meet): 0.062588
P(twin knight meet): 0.062417
P(twin knight meet): 0.062393
P(twin knight meet): 0.062459

n = 6: P(n) = 0.03125
P(twin knight meet): 0.031231
P(twin knight meet): 0.031373
P(twin knight meet): 0.031206
P(twin knight meet): 0.031259
P(twin knight meet): 0.031189
P(twin knight meet): 0.031246
P(twin knight meet): 0.031311
P(twin knight meet): 0.031256
```

## 16. 有放回抽样还是无放回抽样
两个桶 A, B，桶内有红色和黑色的球，其中：

- A 桶有 2 个红球和 1 个黑球。
- B 桶有 101 个红球和 100 个黑球。

随机选出一个桶放到你面前，然后从中抽样两个球，基于这两个球的颜色猜该桶是 A 还是 B。

你可以选择有放回抽样或者无放回抽样，也就是你可以决定在抽取第二个球之前，是否将抽出的第一个球放回去再抽第二次。

问：为了使得猜中桶名的概率最大，应该有放回抽样还是无放回抽样，猜中的概率是多少？

# 思路参考

本题的目标是根据抽样两个球的结果，来猜当前是哪个桶。有两种获取证据的方式，一种是有放回抽样抽两个球，另一种是无放回抽样抽两个球。我们要选择使得猜中概率更大的那个抽样方式。

根据第 3 章总结，我们应先确定“证据是什么”、“假设有哪些”，然后计算似然值，再推公式计算。

## (1) 假设和证据

首先我们看都有哪些可能的证据。由于抽样两个球，且球的种类有红和黑，因此无论有放回抽样还是无放回抽样，观察到的证据都可能有 ”两红”、”一红一黑”、”两黑” 这三种，分别记为 e1, e2, e3。

然后我们看都有哪些可能的假设。由于有 A 和 B 这两种桶，因此针对随机取出的桶有两种假设：桶名为 A 和 桶名为 B，分别记为 H1, H2。

不论抽样是否有放回，都有上述的三种证据和两种假设。

## (2) 先验概率

由于一共两个桶，随机抽取一个，因此抽到 A 或 B 的先验概率为 1/2，与抽样是否有放回无关。

$$
P(H_{1}) = \frac{1}{2} \\
P(H_{2}) = \frac{1}{2} \\
$$

## (3) 似然值

- 有放回抽样

对于 A 桶，有放回抽样两个球，得到 e1, e2, e3 三种证据的概率分别为

$$
P(e_{1}|A) = (\frac{2}{3})^{2}  = \frac{4}{9}\\
P(e_{3}|A) = (\frac{1}{3})^{2} = \frac{1}{9}\\
P(e_{2}|A) = 1 - P(e_{3}|A) - P(e_{1}|A) = \frac{4}{9} \\
$$

对于 B 桶，有放回抽样两个球，得到 e1, e2, e3 三种证据的概率分别为

$$
P(e_{1}|B) = (\frac{101}{201})^{2} = 10201/40401 \\
P(e_{3}|B) = (\frac{100}{201})^{2} = 10000/40401 \\
P(e_{2}|B) = 1 - P(e_{3}|B) - P(e_{1}|B) = 20200/40401 \\
$$

- 无放回抽样

对于 A 桶，无放回抽样两个球，得到 e1, e2, e3 三种证据的概率分别为

$$
P(e_{1}|A) = \frac{2}{3} \times \frac{1}{2} = \frac{1}{3} \\
P(e_{3}|A) = 0 \\
P(e_{2}|A) = 1 - P(e_{3}|A) - P(e_{1}|A) = \frac{2}{3} \\
$$

对于 B 桶，无放回抽样两个球，得到 e1, e2, e3 三种证据的概率分别为

$$
P(e_{1}|B) = \frac{101}{201} \times \frac{100}{200} = \frac{101}{402}\\
P(e_{3}|B) = \frac{100}{201} \times \frac{99}{200} = \frac{99}{402} \\
P(e_{2}|B) = 1 - P(e_{3}|B) - P(e_{1}|B) = \frac{202}{402} \\
$$

## (4) 推导 P(T)

记 P(T) 为猜测正确的概率。P(T|e) 表示获取到的证据为 e 时，猜测正确的概率。
$$

P(T) = \sum\limits_{i}P(e_{i})P(T|e_{i}) \\
= \sum\limits_{i}P(e_{i})\max\limits_{j}P(H_{j}|e_{i}) \\
= \sum\limits_{i}P(e_{i})\max\limits_{j}\frac{P(e_{i}|H_{j})P(H_{j})}{P(e_{i})} \\
= \sum\limits_{i}\max\limits_{j}P(e_{i}|H_{j})P(H_{j}) \\

$$

其中 P(ei|Hj) 是我们之前算好的似然值，P(Hj) 是之前算好的先验概率。

## (5) 计算

我们分别计算在有放回抽样和无放回抽样 2 次时，预测正确的概率 P(T)

- 有放回抽样

$$

P(T) = \sum\limits_{i}\max\limits_{j}P(e_{i}|H_{j})P(H_{j}) \\
= max(\frac{1}{2}\times\frac{4}{9}, \frac{1}{2}\times\frac{10201}{40401}) \\
 \quad\quad + max(\frac{1}{2}\times\frac{1}{9}, \frac{1}{2}\times\frac{10000}{40401}) \\ \quad\quad + max(\frac{1}{2}\times\frac{4}{9}, \frac{1}{2}\times\frac{20200}{40401}) \\
= \frac{4}{18} + \frac{10000}{80802} + \frac{20200}{40401} \\
= 0.595975 \\

$$

- 无放回抽样

$$

P(T) = \sum\limits_{i}\max\limits_{j}P(e_{i}|H_{j})P(H_{j}) \\
= max(\frac{1}{2}\times\frac{1}{3}, \frac{1}{2}\times\frac{101}{402}) \\
 \quad\quad + max(0, \frac{1}{2}\times\frac{99}{402}) \\
 \quad\quad + max(\frac{1}{2}\times\frac{2}{3}, \frac{1}{2}\times\frac{202}{402}) \\
= \frac{1}{6} + \frac{99}{804} + \frac{202}{804} \\
= 0.623134 \\

$$

---

# 蒙特卡洛模拟

```python
import numpy as np
from multiprocessing import Pool

class Box:
    def __init__(self, nR, nB, t):
        # 当前子在盒子中的
        self.nR = nR
        self.nB = nB
        # 抽出未放回的
        self.mR = 0
        self.mB = 0
        self.t = t

    def sample_with_replacement(self):
        if np.random.randint(0, self.nR + self.nB) < self.nR:
            return "R"
        else:
            return "B"

    def sample_without_replacement(self):
        if np.random.randint(0, self.nR + self.nB) < self.nR:
            self.nR -= 1
            self.mR += 1
            return "R"
        else:
            self.nB -= 1
            self.mB += 1
            return "B"

    def reset(self):
        self.nB += self.mB
        self.mB = 0
        self.nR += self.mR
        self.mR = 0

    def sample(self, method):
        if method == "with":
            return self.sample_with_replacement()
        else:
            return self.sample_without_replacement()

class Model:
    def __init__(self, boxs, method):
        self.boxs = boxs
        self.method = method
        # mapping 记录每种证据下两种盒子种类的次数
        # 共有 6 个参数
        self.mapping = {"RR": np.array([0, 0])
                       ,"RB": np.array([0, 0])
                       ,"BB": np.array([0, 0])
                       }

    def update(self, e, idx):
        """
        根据数据 (e, idx) 更新 mapping 的参数
        数据的含义是证据 e 对应硬币种类 idx
        """
        self.mapping[e][idx] += 1

    def train(self):
        """
        随机生成数据训练
        """
        n_train = int(1e5)
        for i in range(n_train):
            idx = np.random.randint(0, len(self.boxs))
            box = self.boxs[idx]
            # 抽取两次，获取证据
            e = [box.sample(self.method), box.sample(self.method)]
            if e[0] == "B" and e[1] == "R":
                e[1], e[0] = e[0], e[1]
            e = "".join(e)
            self.update(e, box.t)
            box.reset()
        for k, v in self.mapping.items():
            print("证据 {} 下的A桶有{}个, B桶有{}个".format(k, v[0], v[1]))
        print("===训练结束===")

    def predict(self, e):
        """
        根据证据 e 猜盒子种类，返回 0 或 1
        """
        return np.argmax(self.mapping[e])

    def test(self, T):
        correct = 0
        np.random.seed()
        for _ in range(T):
            # 随机选盒子
            idx = np.random.randint(0, len(self.boxs))
            box = self.boxs[idx]
            # 抽取 2 次，获取证据
            e = [box.sample(self.method), box.sample(self.method)]
            if e[0] == "B" and e[1] == "R":
                e[1], e[0] = e[0], e[1]
            e = "".join(e)
            # 根据证据猜硬币种类
            if self.predict(e) == box.t:
                correct += 1
            box.reset()
        return correct / T

class Solver:
    def __init__(self, method):
        self.method = method
        self.boxs = [Box(2, 1, 0), Box(101, 100, 1)]
        self.ans = -1

    def __call__(self):
        model = Model(self.boxs, self.method)
        model.train()
        T = int(1e7)
        args = [T] * 8
        pool = Pool(8)
        ts = pool.map(model.test, args)
        self.ans = sum(ts) / len(ts)

solver1 = Solver("with")
solver1()
print("有放回时，P(T): {:.6f}".format(solver1.ans))
solver2 = Solver("without")
solver2()
print("无放回时，P(T): {:.6f}".format(solver2.ans))
```

模拟结果

```plain
证据 RR 下的A桶有22280个, B桶有12755个
证据 RB 下的A桶有21997个, B桶有24808个
证据 BB 下的A桶有5561个, B桶有12599个
===训练结束===
有放回时，P(T): 0.596081
证据 RR 下的A桶有16452个, B桶有12755个
证据 RB 下的A桶有33433个, B桶有25112个
证据 BB 下的A桶有0个, B桶有12248个
===训练结束===
无放回时，P(T): 0.623070
```

## 17. 圆周上取 3 个点构成锐角三角形
在一个圆环上随机取 3 点，求这 3 个点组成一个锐角三角形的概率。

### 思路参考

![image.png](https://pic.leetcode-cn.com/1646113288-ZmJuES-image.png){:width="600px"}

如图，在圆周上取不同的两个点 X, Y，当 X, Y 确定后，再在圆周上取点 Z，要 $\Delta XYZ$ 构成锐角三角形，需要 X 在圆弧 AB 上，如果超出圆弧 AB 的范围，有以下几种情况，哪一种都会使得 $\Delta XYZ$ 不成为锐角三角形。

- Z 如果在圆弧 AX 上，则角 X 就会变成钝角
- Z 如果在圆弧 YB 上，则角 Y 就会变成钝角
- Z 如果在圆弧 XY 上，则角 Z 就会变成钝角

当弧 XY 确定后，对应的圆心角为 $\theta$，该圆心角的范围是 `[0, pi)`，其概率密度函数为 

$$
p(\theta) = \frac{1}{\pi}
$$

此时再取点 Z 落在弧 AB 上的概率为 AB 对应的圆心角，也就是 $\theta$ 与整个圆的角度范围的比值

$$
P(A|\theta) = \frac{\theta}{2\pi}
$$

由**连续型随机变量的全概率公式**

$$

P(A) = \int_{0}^{\pi}P(A|\theta)P(\theta)d\theta \\
= \left.\frac{\theta^{2}}{4\pi^{2}}\right|_{0}^{\pi} \\
= \frac{1}{4} \\

$$

# 蒙特卡洛模拟

```python
import numpy as np
import math
from multiprocessing import Pool

def dist(x, y):
    return (x[0] - y[0]) ** 2 + (x[1] - y[1]) ** 2

def test(T):
    n = 0
    np.random.seed()
    for _ in range(T):
        theta_x = np.random.uniform(0.0, 2 * math.pi)
        theta_y = np.random.uniform(0.0, 2 * math.pi)
        theta_z = np.random.uniform(0.0, 2 * math.pi)
        x = (math.cos(theta_x), math.sin(theta_x))
        y = (math.cos(theta_y), math.sin(theta_y))
        z = (math.cos(theta_z), math.sin(theta_z))
        d_xy = dist(x, y)
        d_yz = dist(y, z)
        d_zx = dist(z, x)
        if not d_xy + d_yz > d_zx:
            continue
        if not d_yz + d_zx > d_xy:
            continue
        if not d_zx + d_xy > d_yz:
            continue
        n += 1
    return n / T

T = int(1e6)
args = [T] * 8
pool = Pool(8)
ts = pool.map(test, args)
for t in ts:
    print("锐角三角形的概率: {:.6f}".format(t))

```

模拟结果

```plain
锐角三角形的概率: 0.249651
锐角三角形的概率: 0.250418
锐角三角形的概率: 0.249653
锐角三角形的概率: 0.249947
锐角三角形的概率: 0.250386
锐角三角形的概率: 0.250427
锐角三角形的概率: 0.250429
锐角三角形的概率: 0.250860
```

## 18. 选票盒
一场选举两个候选人 A 和 B，选票盒里有 A, B 两个候选人的选票，其中 A 有 a 张票，B 有 b 张票，a > b。选票被随机抽出并宣布。

问：从宣布第一张票开始直至盒子中的票宣布完，双方已宣布票数至少出现一次平局的概率？

---

# 思路参考

假设抽过几轮之后，现在还剩 i 张 A 选票，j 张 B 选票，也就是之前已经抽出了 a - i 张 A 选票，以及 b - j 张 B 选票。这种情况下我们记【从下一次抽取选票开始，直到盒子中的剩余票抽取完，双方已宣布票数至少出现一次平局】的概率为 dp[i][j]。在这个定义下，我们要求的就是 dp[a][b]。

此时已经抽出的 A 的票数 a - i，B 的票数 b - j，A 比 B 多出的差值是 k = a - i - (b - j)

我们考虑下一次抽取选票的两种情况，第一种是抽到 a，记为事件 Xa，概率为 Pa = i / (i + j)，第二种是抽到 b，记为事件 Xb，概率为 Pa = j / (i + j)。

由全概率公式，我们可以写出 dp[i][j] 的转移方程

```plain
dp[i][j] = pa * dp[i - 1][j] + pb * dp[i][j - 1]
```

## dp[i][j] 的边界值

我们首先看一下 dp[i][j] 的一些边界值

- i = 0 且 j = 0

当 i, j 均为 0 时，盒子中已经没有票可以抽出，当然也就无法在后续的抽票中达成平局，dp[i][j] = 0。

- i = 0, j != 0

当 i 为 0，后续的抽票只会抽出 B 选票。因此 dp[i][j] 取决于已经抽出的 A 比 B 多出的部分 k 与还剩的 B 的张数 j

如果 k > 0 且 j >= k，则 dp[i][j] = 1，否则 dp[i][j] = 0。

- j = 0, i != 0

当 j 为 0，后续的抽票只会抽出 A 选票。因此 dp[i][j] 取决于已经抽出的 A 比 B 多出的部分 k 与还剩的 A 的张数 i

如果 k < 0 且 i >= -k，则 dp[i][j] = 1，否则 dp[i][j] = 0。

## dp[i][j] 的转移方程

下面我们分别考虑转移方程中的 `ans1 = pa * dp[i - 1][j]` 和 `ans2 = pb * dp[i][j - 1]` 这两部分结果。

- 下一次抽出的是 A 的选票

如果 k = -1，那么这次抽到 a 后就出现了双方平局的结果，因此 `ans1 = pa * 1`；

否则就要继续算 `ans1 = pa * dp[i - 1][j]`。

- 下一次抽出的是 B 的选票

如果 k = 1，那么这次抽到 b 后就出现了双方平局的结果，因此 `ans2 = pb * 1`；

否则就要继续算 `ans2 = pb * dp[i][j - 1]`。

## 概率 DP

有了以上推导之后，我们就可以用概率 DP 算法计算答案了，算法如下

```plain
状态定义
dp[i][j] := 还剩 i 张 A 选票，j 张 B 选票时，后续抽取过程中会出现平局的概率

答案
dp[a][b]

初始化
dp[0][0] = 0
dp[i][0] = 1    if i >= -k
         = 0    other
dp[0][j] = 1    if j >= k
         = 0    other

状态转移
ans1 = pa                   if k == -1
       pa * dp[i - 1][j]    other
ans2 = pb                   if k == 1
       pb * dp[i][j - 1]    other
dp[i][j] = ans1 + ans2
```

## 编程计算答案 

Python 代码如下

```python
@lru_cache(maxsize=int(1e6))
def solve(i, j):
    if i == 0 and j == 0:
        return 0.0
    k = (a - i) - (b - j)
    if i == 0:
        if k > 0 and j >= k:
            return 1.0
        return 0.0
    if j == 0:
        if k < 0 and i >= -k:
            return 1.0
        return 0.0
    pa = i / (i + j)
    pb = 1.0 - pa
    if k == -1:
        ans1 = pa
    else:
        ans1 = pa * solve(i - 1, j)
    if k == 1:
        ans2 = pb
    else:
        ans2 = pb * solve(i, j - 1)
    return ans1 + ans2
```

以 a = 5, b = 8 为例，计算结果为 0.769231

---

# 蒙特卡洛模拟

```python
import numpy as np
from functools import lru_cache
from multiprocessing import Pool
import sys
sys.setrecursionlimit(int(1e5))

class Box:
    def __init__(self, a, b):
        self.na = a
        self.nb = b
        self.ma = self.mb = 0

    def solve(self):
        self.reset()
        return self._solve(self.na, self.nb)

    @lru_cache(maxsize=int(1e6))
    def _solve(self, i, j):
        if i == 0 and j == 0:
            return 0.0
        k = (self.na - i) - (self.nb - j)
        if i == 0:
            if k > 0 and j >= k:
                return 1.0
            return 0.0
        if j == 0:
            if k < 0 and i >= -k:
                return 1.0
            return 0.0
        pa = i / (i + j)
        pb = 1.0 - pa
        if k == -1:
            ans1 = pa
        else:
            ans1 = pa * self._solve(i - 1, j)
        if k == 1:
            ans2 = pb
        else:
            ans2 = pb * self._solve(i, j - 1)
        return ans1 + ans2

    def reset(self):
        self.na += self.ma
        self.nb += self.mb
        self.ma = self.mb = 0

    def draw(self):
        if np.random.randint(0, self.na + self.nb) < self.na:
            self.na -= 1
            self.ma += 1
        else:
            self.nb -= 1
            self.mb += 1
        return self.ma == self.mb

    def empty(self):
        return self.na + self.nb == 0

def test(args):
    a, b = args
    box = Box(a, b)
    ans = box.solve()
    np.random.seed()
    T = int(1e7)
    n_tie = 0
    for _ in range(T):
        while not box.empty():
            if box.draw():
                n_tie += 1
                break
        box.reset()
    return a, b, ans, n_tie / T

args = [(5, 5), (5, 6), (5, 7), (5, 8), (5, 9), (5, 10), (5, 11), (5, 12)]
pool = Pool(8)
ts = pool.map(test, args)
for t in ts:
    a, b, ans, sim = t
    print("a={}, b={}".format(a, b))
    print("    计算结果:{:.6f}".format(ans))
    print("    模拟结果:{:.6f}".format(sim))
```

模拟结果

```plain
a=5, b=5
    计算结果:1.000000
    模拟结果:1.000000
a=5, b=6
    计算结果:0.909091
    模拟结果:0.908938
a=5, b=7
    计算结果:0.833333
    模拟结果:0.833231
a=5, b=8
    计算结果:0.769231
    模拟结果:0.769221
a=5, b=9
    计算结果:0.714286
    模拟结果:0.714182
a=5, b=10
    计算结果:0.666667
    模拟结果:0.666567
a=5, b=11
    计算结果:0.625000
    模拟结果:0.624997
a=5, b=12
    计算结果:0.588235
    模拟结果:0.588035
```

## 19. 向正方形区域扔硬币
在一个游戏中，一个玩家从 5 英尺远的地方把一分钱硬币扔到一张 1 12英寸正方形的桌子上，硬币直径为 3/4 英寸。

如果硬币完全落在正方形内，则玩家赢。

如果硬币落在桌上，他赢的机会有多大？

### 思路参考

如果硬币可以落在桌子上，那么硬币的重心在正方形范围内。


![image.png](https://pic.leetcode-cn.com/1646113354-dEWblU-image.png){:style="max-height:350px"}　


如果硬币完全落在正方形内，硬币重心到正方形四条边的距离都要大于硬币的半径。

硬币半径为 3/8 英寸。设硬币重心为 (x, y)，那么要满足以上条件，需要

$$
\left\{
\begin{matrix}
x >= 3/8 \\
y >= 3/8 \\
1 - x >= 3/8 \\
1 - y >= 3/8 \\
\end{matrix}  
\right.
$$

求出 x，y 的范围均是 [3/8, 5/8]。根据几何概型概率公式，当硬币落到桌子上时，赢的机会有 (5/8 - 3/8) * (5/8 - 3/8) / 1 = 1/16 = 0.0625。

### 蒙特卡洛模拟

```python
import numpy as np

def check(x, y):
    return x >= 3/8 and (1 - x) >= 3/8 and y >= 3/8 and (1 - y) >= 3/8

def test():
    T = int(1e7)
    s = 0
    for t in range(T):
        x = np.random.rand()
        y = np.random.rand()
        if check(x, y):
            s += 1
    print("his chance to win: {:.6f}".format(s / T))

for i in range(10):
    test()
```

模拟结果

```plain
his chance to win: 0.062507
his chance to win: 0.062518
his chance to win: 0.062433
his chance to win: 0.062596
his chance to win: 0.062261
his chance to win: 0.062555
his chance to win: 0.062552
his chance to win: 0.062652
his chance to win: 0.062406
his chance to win: 0.062344
```

## 20. 不公平的硬币 2
在第三章 [贝叶斯公式](https://leetcode-cn.com/leetbook/read/probability-problems/n9u5bj/) 例题中，我们解决了初级的「不公平的硬币」问题。

[不公平的硬币 2](https://leetcode-cn.com/leetbook/read/probability-problems/nom0vc/)，[不公平的硬币 3](https://leetcode-cn.com/leetbook/read/probability-problems/noavni/)，[不公平的硬币 4](https://leetcode-cn.com/leetbook/read/probability-problems/no2a2e/)  均为该题的变种，考察点也是贝叶斯公式，并且解题过程也类似。

下面是不公平的硬币 2 的描述。

有 2 枚硬币，一枚是普通硬币，也就是随机抛出正面的概率是 0.5，另一枚是特殊硬币，两面都是正面，也就是随机抛出正面的概率是 1。

现在随机取出一枚硬币，允许抛出 2 次并根据两次抛出结果来预测该硬币是普通硬币还是特殊硬币。

问预测正确的概率是多少？

### 思路参考

本题与最终要解决的问题整体上是一样的，只是做了以下三点简化:

- 原问题是 10 枚硬币，其中有 1 枚不公平硬币；本题简化为 2 枚，其中 1 枚不公平；
- 原问题不公平硬币抛出正面的概率是 0.8，本题简化为 1.0；
- 原问题可以抛 3 次，本题简化为抛 2 次。

**我们的目标是在各种可能的证据下，求各种可能的假设成立的条件概率，取其中条件概率最大的假设作为预测。进而计算整体的预测正确的概率。**

具体地分为 3 个步骤:

- 用贝叶斯公式求出在**各种可能的证据**下，**各种可能的假设**成立的条件概率；
- 对每一种可能的证据，取各种可能的假设中条件概率最大的假设作为预测，该条件概率就是拿到该证据时预测正确的概率；
- 用全概率公式计算整体的预测正确的概率。

下面我们分别看这三个步骤

#### step1: 

首先我们看可能有哪些证据。由于可以抛出 2 次，因此观察到的证据可能有“正正”、“正反”、“反正”、“反反”这四种。分别记为 e1, e2, e3, e4。

然后我们看可能有哪些假设。由于有公平和不公平这两种硬币，因此针对随机取出的硬币有两种假设，“公平” 和 “不公平”，分别记为 H1, H2。

我们目标所求的`在各种可能的证据下，求各种可能的假设成立的条件概率`，就是 P(H1|e1), P(H1|e2), P(H1|e3), P(H1|e4), P(H2|e1), P(H2|e2), P(H2|e3), P(H2|e4) 这八个条件概率。

由于 H1 和 H2 是对立事件，因此 P(H2|e) = 1 - P(H1|e)，我们实际上只需要求 4 个条件概率，P(H1|e1), P(H1|e2), P(H1|e3), P(H1|e4)。

我们在上一期解决的问题是**给定一个特定的证据**下，求**特定的假设**成立的条件概率。相当于求这里的 4 个条件概率中的 1 个。我们用同样的方法分别求出 4 个条件概率即可。

下面我们以 P(H1|e1) 为例，首先写出用贝叶斯公式计算 P(H1|e1) 的公式

$$

P(H_{1}|e_{1}) = \frac{P(e_{1}|H_{1})P(H_{1})}{P(e_{1})} \\
= \frac{P(e_{1}|H_{1})P(H_{1})}{P(e_{1}|H_{1})P(H_{1}) + P(e_{1}|H_{2})P(H_{2})} \\

$$

由于硬币是 2 枚中有 1 枚不公平，因此随机取出 1 枚的两种假设的先验概率分别为 P(H1) = P(H2) = 0.5。

下面我们看两种假设下，抛两次产生 e1 这个证据的**似然值**

- 如果取出的是正常硬币(H1)，抛两次产生 e1 这个证据的概率是 P(e1|H1) = 1/4
- 如果取出的是特殊硬币(H2)，抛两次产生 e1 这个证据的概率是 P(e1|H2) = 1

有了以上先验概率和似然值，我们就可以用贝叶斯公式计算条件概率了。

$$

P(H_{1}|e_{1}) = \frac{P(e_{1}|H_{1})P(H_{1})}{P(e_{1}|H_{1})P(H_{1}) + P(e_{1}|H_{2})P(H_{2})} \\ 
= \frac{\frac{1}{4} \times \frac{1}{2}}{\frac{1}{4} \times \frac{1}{2} + 1 \times \frac{1}{2}} \\ 
= \frac{1}{5}

$$

P(H1|e2), P(H1|e3), P(H1|e4) 也可以类似地算出，首先我们把所需的似然值写出来。

- 如果取出的是正常硬币(H1)，抛两次产生 e2 这个证据的概率是 P(e2|H1) = 1/4
- 如果取出的是特殊硬币(H2)，抛两次产生 e2 这个证据的概率是 P(e2|H2) = 0
- 如果取出的是正常硬币(H1)，抛两次产生 e3 这个证据的概率是 P(e3|H1) = 1/4
- 如果取出的是特殊硬币(H2)，抛两次产生 e3 这个证据的概率是 P(e3|H2) = 0
- 如果取出的是正常硬币(H1)，抛两次产生 e4 这个证据的概率是 P(e4|H1) = 1/4
- 如果取出的是特殊硬币(H2)，抛两次产生 e4 这个证据的概率是 P(e4|H2) = 0

$$

P(H_{1}|e_{2}) = \frac{P(e_{2}|H_{1})P(H_{1})}{P(e_{2}|H_{1})P(H_{1}) + P(e_{2}|H_{2})P(H_{2})} \\ 
= 1 \\ 
P(H_{1}|e_{3}) = \frac{P(e_{3}|H_{1})P(H_{1})}{P(e_{3}|H_{1})P(H_{1}) + P(e_{3}|H_{2})P(H_{2})} \\ 
= 1 \\ 
P(H_{1}|e_{4}) = \frac{P(e_{4}|H_{1})P(H_{1})}{P(e_{4}|H_{1})P(H_{1}) + P(e_{4}|H_{2})P(H_{2})} \\ 
= 1 \\ 

$$

#### step2: 

对证据 e1, e2, e3, e4，分别取各种可能的假设中条件概率最大的假设作为预测，该条件概率就是拿到该证据时预测正确的概率

$$
P(T|e_{1}) = max(P(H_{1}|e_{1}), P(H_{2}|e_{1})) = \frac{4}{5} \\
P(T|e_{2}) = max(P(H_{1}|e_{2}), P(H_{2}|e_{2})) = 1 \\
P(T|e_{3}) = max(P(H_{1}|e_{3}), P(H_{2}|e_{3})) = 1 \\
P(T|e_{4}) = max(P(H_{1}|e_{4}), P(H_{2}|e_{4})) = 1 \\
$$

#### step3: 

用全概率公式计算整体的预测正确的概率

$$

P(T) = P(e_{1})P(T|e_{1}) + P(e_{2})P(T|e_{2}) + P(e_{3})P(T|e_{3}) + P(e_{4})P(T|e_{4}) \\
= \frac{5}{8} \times \frac{4}{5} + \frac{1}{8} \times 1 + \frac{1}{8} \times 1 + \frac{1}{8} \times 1  \\
= \frac{7}{8}

$$

#### **总结**

这里我们对这类问题做个总结，首先**我们的目标是在各种可能的证据下，求各种可能的假设成立的条件概率，取其中条件概率最大的假设作为预测。进而计算整体的预测正确的概率。**

基于这个大方向，具体做的时候分为 3 个步骤:

- 用贝叶斯公式求出在**各种可能的证据**下，**各种可能的假设**成立的条件概率

具体地，在证据 ei 下，假设 Hj 成立的条件概率为 

$$
P(H_{j}|e_{i}) = \frac{P(e_{i}|H_{j})P(H_{j})}{P(e_{i})}
$$

- 对每一种可能的证据，取各种可能的假设中条件概率最大的假设作为预测，该条件概率就是拿到该证据时预测正确的概率

具体地，在证据 ei 下，预测正确的概率为 

$$
P(T|e_{i}) = \max\limits_{j}P(H_{j}|e_{i})
$$

- 用全概率公式计算整体的预测正确的概率

$$
P(T) = \sum\limits_{i}P(e_{i})P(T|e_{i})
$$

**逐层代入之后，会发现 P(T) 的最终公式中 P(ei) 是被削掉了**，如下

$$

P(T) = \sum\limits_{i}P(e_{i})P(T|e_{i}) \\
= \sum\limits_{i}P(e_{i})\max\limits_{j}P(H_{j}|e_{i}) \\
= \sum\limits_{i}P(e_{i})\max\limits_{j}\frac{P(e_{i}|H_{j})P(H_{j})}{P(e_{i})} \\
= \sum\limits_{i}(\max\limits_{j}P(e_{i}|H_{j})P(H_{j})) \\

$$

其中 P(Hj) 是先验概率，也就是说我们其实**只需要求出所有似然值 P(ei|Hj) 即可套下面的最终公式了**，而无需做一步用贝叶斯公式求后验概率了，因此**证据因子 P(ei)** 不用算了。

$$
P(T) = \sum\limits_{i}(\max\limits_{j}P(e_{i}|H_{j})P(H_{j}))
$$

前面为了思路的连贯性，还是按步骤推的答案。如果套最终公式，计算过程就是下面这样

$$

P(T) = \sum\limits_{i}(\max\limits_{j}P(e_{i}|H_{j})P(H_{j})) \\
= \frac{1}{2} \times (1 + \frac{1}{4} + \frac{1}{4} + \frac{1}{4}) \\
= \frac{7}{8} \\

$$

### 蒙特卡洛模拟

模拟的核心是当得到证据 e 之后，如何给出预测结果，也就是代码中 model 实例中的 predict 方法。根据前面的推导，这取决于 8 个后验概率，这 8 个后验概率可以直接根据计算结果手动写进去，也可以用数据模拟出这 8 个后验概率，类似于用训练数据学出模型的 8 个参数，然后再用模型和另一批数据模拟预测正确的概率。

代码中实现的是后者，也就是先随机生成数据模拟出 8 个后验概率（代码中 model 实例的 train 方法），再随机生成数据模拟预测正确的概率（代码中 model 实例的 test 方法）。

```python
import numpy as np
from multiprocessing import Pool

class Coin:
    def __init__(self, p):
        self.p = p

    def flip(self):
        """
        如果抛出正面，返回 True
        """
        return np.random.rand() < self.p

class Model:
    def __init__(self, coins):
        self.coins = coins
        # mapping 记录每种证据下两种硬币种类的次数
        # 共有 8 个参数
        self.mapping = {(0, 0): np.array([0, 0])
                       ,(0, 1): np.array([0, 0])
                       ,(1, 0): np.array([0, 0])
                       ,(1, 1): np.array([0, 0])
                       }

    def update(self, e, idx):
        """
        根据数据 (e, idx) 更新 mapping 的参数
        数据的含义是证据 e 对应硬币种类 idx
        """
        self.mapping[e][idx] += 1

    def train(self):
        """
        随机生成数据训练
        """
        n_train = int(1e7)
        for i in range(n_train):
            idx = np.random.randint(0, 2)
            coin = self.coins[idx]
            r1 = coin.flip()
            r2 = coin.flip()
            e = (int(r1), int(r2))
            self.update(e, idx)
            if (i + 1) % int(2e6) == 0:
                print("训练进度: {}/{}".format((i + 1), n_train))
                for k, v in self.mapping.items():
                    print("    证据 {} 下的正常硬币有{}个, 特殊硬币有{}个".format(k, v[0], v[1]))
        print("===训练结束===")

    def predict(self, e):
        """
        根据证据 e 猜硬币种类，返回 0 或 1
        """
        return np.argmax(self.mapping[e])

    def test(self, T):
        correct = 0
        np.random.seed()
        for _ in range(T):
            # 随机选硬币
            idx = np.random.randint(0, 2)
            coin = coins[idx]
            # 抛出两次，获取证据
            r1 = coin.flip()
            r2 = coin.flip()
            e = (int(r1), int(r2))
            # 根据证据猜硬币种类
            if self.predict(e) == idx:
                correct += 1
        return correct / T

coins = [Coin(0.5), Coin(1.0)]
model = Model(coins)
model.train()
T = int(1e6)
args = [T] * 8
pool = Pool(8)
ts = pool.map(model.test, args)
for t in ts:
    print("猜正确的概率是: {:.6f}".format(t))
```

模拟结果

```plain
训练进度: 2000000/10000000
    证据 (0, 0) 下的正常硬币有250160个, 特殊硬币有0个
    证据 (0, 1) 下的正常硬币有250105个, 特殊硬币有0个
    证据 (1, 0) 下的正常硬币有249805个, 特殊硬币有0个
    证据 (1, 1) 下的正常硬币有251115个, 特殊硬币有998815个
训练进度: 4000000/10000000
    证据 (0, 0) 下的正常硬币有499945个, 特殊硬币有0个
    证据 (0, 1) 下的正常硬币有499713个, 特殊硬币有0个
    证据 (1, 0) 下的正常硬币有499823个, 特殊硬币有0个
    证据 (1, 1) 下的正常硬币有501512个, 特殊硬币有1999007个
训练进度: 6000000/10000000
    证据 (0, 0) 下的正常硬币有749591个, 特殊硬币有0个
    证据 (0, 1) 下的正常硬币有750072个, 特殊硬币有0个
    证据 (1, 0) 下的正常硬币有750249个, 特殊硬币有0个
    证据 (1, 1) 下的正常硬币有750605个, 特殊硬币有2999483个
训练进度: 8000000/10000000
    证据 (0, 0) 下的正常硬币有999616个, 特殊硬币有0个
    证据 (0, 1) 下的正常硬币有1000364个, 特殊硬币有0个
    证据 (1, 0) 下的正常硬币有1000514个, 特殊硬币有0个
    证据 (1, 1) 下的正常硬币有1000868个, 特殊硬币有3998638个
训练进度: 10000000/10000000
    证据 (0, 0) 下的正常硬币有1249086个, 特殊硬币有0个
    证据 (0, 1) 下的正常硬币有1250621个, 特殊硬币有0个
    证据 (1, 0) 下的正常硬币有1251428个, 特殊硬币有0个
    证据 (1, 1) 下的正常硬币有1249869个, 特殊硬币有4998996个
===训练结束===
猜正确的概率是: 0.874737
猜正确的概率是: 0.875113
猜正确的概率是: 0.874732
猜正确的概率是: 0.874939
猜正确的概率是: 0.874946
猜正确的概率是: 0.874690
猜正确的概率是: 0.875392
猜正确的概率是: 0.874712
```

## 21. 不公平的硬币 3
在第三章的 [贝叶斯公式](https://leetcode-cn.com/leetbook/read/probability-problems/n9u5bj/) 贝叶斯公式的例题中，我们解决了基础版的不公平的硬币问题。

[不公平的硬币 2](https://leetcode-cn.com/leetbook/read/probability-problems/nom0vc/)，[不公平的硬币 3](https://leetcode-cn.com/leetbook/read/probability-problems/noavni/)，[不公平的硬币 4](https://leetcode-cn.com/leetbook/read/probability-problems/no2a2e/) 均为该题的变种，考察点也是贝叶斯公式，并且解题过程也类似。

下面是不公平的硬币 3 的描述。

有 10 枚硬币，其中有 3 枚是不公平的，随机抛出正面的概率为 0.8，另外 7 枚都是公平的，也就是随机抛出正面的概率是 0.5。

现在从 10 枚硬币中随机取出 1 枚，可以随机地抛 3 次，根据结果来预测该硬币是否为不公平硬币。求预测正确的概率。

### 思路参考

#### (1) 题目对比

在 [贝叶斯公式](https://leetcode-cn.com/leetbook/read/probability-problems/n9u5bj/)  例题中的基础版问题是**给定一个特定的证据**下，求**特定的假设**成立的条件概率。修改后的新问题是在**各种可能的证据**下，求**各种可能的假设**成立的条件概率，进而取其中条件概率最大的假设作为预测。

我们在 [不公平的硬币 2](https://leetcode-cn.com/leetbook/read/probability-problems/nom0vc/) 中先解决了一个简化版的问题，并总结了这类题的方法。为了方便对比，我们把简化版题目抄在下面。

>有 2 枚硬币，一枚是普通硬币，也就是随机抛出正面的概率是 0.5，另一枚是特殊硬币，两面都是正面，也就是随机抛出正面的概率是 1。
>
>现在随机取出一枚硬币，允许抛出 2 次并根据两次抛出结果来预测该硬币是普通硬币还是特殊硬币。
>
>问预测正确的概率是多少。

可以看出，本题相比于我们已经解决的简化版问题，主要复杂在以下 3 点上：

- 复杂点一：本题是 10 枚硬币，其中有 3 枚不公平硬币；简化版为 2 枚硬币，其中 1 枚不公平；
- 复杂点二：本题不公平硬币抛出正面的概率是 0.8，简化版为 1.0；
- 复杂点三：本题可以抛 3 次，简化版为抛 2 次。

#### (2) 方法回顾

我们直接用解决简化版问题时总结的方法解决本题，下面我们把方法再梳理一下。

**我们的目标是在各种可能的证据下，求各种可能的假设成立的条件概率，取其中条件概率最大的假设作为预测。进而计算整体的预测正确的概率。**

基于这个大方向，具体做的时候分为 3 个步骤:

- 用贝叶斯公式求出在**各种可能的证据**下，**各种可能的假设**成立的条件概率

具体地，在证据 ei 下，假设 Hj 成立的条件概率为 

$$
P(H_{j}|e_{i}) = \frac{P(e_{i}|H_{j})P(H_{j})}{P(e_{i})}
$$

- 对每一种可能的证据，取各种可能的假设中条件概率最大的假设作为预测，该条件概率就是拿到该证据时预测正确的概率

具体地，在证据 ei 下，预测正确的概率为 

$$
P(T|e_{i}) = \max\limits_{j}P(H_{j}|e_{i})
$$

- 用全概率公式计算整体的预测正确的概率

$$
P(T) = \sum\limits_{i}P(e_{i})P(T|e_{i})
$$

**逐层代入之后，会发现 P(T) 的最终公式中 P(ei) 是被削掉了**，如下

$$

P(T) = \sum\limits_{i}P(e_{i})P(T|e_{i}) \\
= \sum\limits_{i}P(e_{i})\max\limits_{j}P(H_{j}|e_{i}) \\
= \sum\limits_{i}P(e_{i})\max\limits_{j}\frac{P(e_{i}|H_{j})P(H_{j})}{P(e_{i})} \\
= \sum\limits_{i}(\max\limits_{j}P(e_{i}|H_{j})P(H_{j})) \\

$$

其中 P(Hj) 是先验概率，也就是说我们其实**只需要求出所有似然值 P(ei|Hj) 即可套下面的最终公式了**，而无需做一步用贝叶斯公式求后验概率了，因此**证据因子 P(ei)** 不用算了。

$$
P(T) = \sum\limits_{i}(\max\limits_{j}P(e_{i}|H_{j})P(H_{j}))
$$

#### (3) 假设和证据

首先我们看都有哪些可能的证据。由于可以抛出 3 次(复杂点一)，因此观察到的证据可能有"正正正"、"正正反"、"正反正"、"正反反", "反正正"、"反正反"、"反反正"、"反反反"这八种。分别记为 e1, e2, e3, e4, e5, e6, e7, e8。

然后我们看都有哪些可能的假设。由于有公平和不公平这两种硬币，因此针对随机取出的硬币有两种假设，"公平" 和 "不公平"，分别记为 H1, H2。

下面我们基于这些可能的假设和证据，推导一下先验概率和似然值。

#### (4) 先验概率

由于本题是 10 枚硬币(复杂点二)，其中有 3 枚不公平硬币，因此 

$$
P(H_{1}) = \frac{7}{10} \\
P(H_{2}) = \frac{3}{10} \\
$$

#### (5) 似然值 

公平硬币抛出正面的概率为 p = 0.5，不公平硬币抛出正面的概率是 q = 0.8（复杂点三）。

如果硬币是公平硬币，则得到 8 种证据的概率均为 1/8，也就是 8 个似然值均为 1/8

$$
P(e_{i}|H_{1}) = p^{3} = \frac{1}{8}
$$

如果硬币是不公平硬币，则得到 8 种证据的概率分别为

$$
P(e_{1}|H_{2}) = q^{3} = \frac{64}{125}\\
P(e_{2}|H_{2}) = q^{2}(1 - q) = \frac{16}{125} \\
P(e_{3}|H_{2}) = q^{2}(1 - q) = \frac{16}{125} \\
P(e_{4}|H_{2}) = q(1 - q)^{2} = \frac{4}{125} \\
P(e_{5}|H_{2}) = q^{2}(1 - q) = \frac{16}{125} \\
P(e_{6}|H_{2}) = q(1 - q)^{2} = \frac{4}{125} \\
P(e_{7}|H_{2}) = q(1 - q)^{2} = \frac{4}{125} \\
P(e_{8}|H_{2}) = (1 - q)^{3} = \frac{1}{125} \\
$$

#### (6) 套公式

记 P(T) 为猜测正确的概率，P(T|e) 为当获取到证据为 e 时，猜测正确的概率。 
$$

P(T) = \sum\limits_{i}(\max\limits_{j}P(e_{i}|H_{j})P(H_{j})) \\
= \max(P(e_{1}|H_{1})P(H_{1}), P(e_{1}|H_{2})P(H_{2})) \\
 \quad\quad + \max(P(e_{2}|H_{1})P(H_{1}), P(e_{2}|H_{2})P(H_{2})) \\
 \quad\quad + \max(P(e_{3}|H_{1})P(H_{1}), P(e_{3}|H_{2})P(H_{2})) \\
 \quad\quad + \max(P(e_{4}|H_{1})P(H_{1}), P(e_{4}|H_{2})P(H_{2})) \\
 \quad\quad + \max(P(e_{5}|H_{1})P(H_{1}), P(e_{5}|H_{2})P(H_{2})) \\
 \quad\quad + \max(P(e_{6}|H_{1})P(H_{1}), P(e_{6}|H_{2})P(H_{2})) \\
 \quad\quad + \max(P(e_{7}|H_{1})P(H_{1}), P(e_{7}|H_{2})P(H_{2})) \\
\quad\quad + \max(P(e_{8}|H_{1})P(H_{1}), P(e_{8}|H_{2})P(H_{2})) \\
= \max(\frac{1}{8}\times\frac{7}{10}, \frac{64}{125}\times\frac{3}{10}) \\
 \quad\quad + \max(\frac{1}{8}\times\frac{7}{10}, \frac{16}{125}\times\frac{3}{10}) \\
 \quad\quad + \max(\frac{1}{8}\times\frac{7}{10}, \frac{16}{125}\times\frac{3}{10}) \\
 \quad\quad + \max(\frac{1}{8}\times\frac{7}{10}, \frac{4}{125}\times\frac{3}{10}) \\
 \quad\quad + \max(\frac{1}{8}\times\frac{7}{10}, \frac{16}{125}\times\frac{3}{10}) \\
 \quad\quad + \max(\frac{1}{8}\times\frac{7}{10}, \frac{4}{125}\times\frac{3}{10}) \\
 \quad\quad + \max(\frac{1}{8}\times\frac{7}{10}, \frac{4}{125}\times\frac{3}{10}) \\
 \quad\quad + \max(\frac{1}{8}\times\frac{7}{10}, \frac{1}{125}\times\frac{3}{10}) \\
= \frac{64}{125}\times\frac{3}{10} + \frac{1}{8}\times\frac{7}{10} \times 7 \\
= \frac{192}{1250} + \frac{49}{80} \\
= \frac{7661}{10000} = 0.7661 \\

$$

可以看到，由于正常硬币的先验概率是 0.7，我们直接预测正常硬币可以得到 0.7 的正确概率。有了抛出三次的结果作为证据，我们可以得到 0.7661 的正确概率，有所提高，说明数据还是有用的。

### 蒙特卡洛模拟

模拟的核心是当得到证据 e 之后，如何给出预测结果，也就是代码中 model 实例中的 predict 方法。根据前面的推导，这取决于 16 个似然值。首先随机生成数据模拟出 8 个后验概率（代码中 model 实例的 train 方法），再随机生成数据模拟预测正确的概率（代码中 model 实例的 test 方法）。

```python
import numpy as np
from multiprocessing import Pool

class Coin:
    def __init__(self, p, t):
        self.p = p
        self.t = t # 硬币种类 id

    def flip(self):
        """
        如果抛出正面，返回 True
        """
        return np.random.rand() < self.p

class Model:
    def __init__(self, coins, n_flip):
        self.coins = coins
        self.n_flip = n_flip
        # mapping 记录每种证据下两种硬币种类的次数
        # 共有 16 个参数
        self.mapping = {}
        for i in range(1 << n_flip):
            e = [0] * n_flip
            for j in range(n_flip):
                e[n_flip - 1 - j] = i >> j & 1
            self.mapping[tuple(e)] = np.array([0, 0])

    def update(self, e, idx):
        """
        根据数据 (e, idx) 更新 mapping 的参数
        数据的含义是证据 e 对应硬币种类 idx
        """
        self.mapping[e][idx] += 1

    def train(self):
        """
        随机生成数据训练
        """
        n_train = int(1e5)
        for i in range(n_train):
            idx = np.random.randint(0, len(self.coins))
            coin = self.coins[idx]
            e = []
            for _ in range(self.n_flip):
                e.append(int(coin.flip()))
            e = tuple(e)
            self.update(e, coin.t)
        for k, v in self.mapping.items():
            print("证据 {} 下的正常硬币有{}个, 特殊硬币有{}个".format(k, v[0], v[1]))
        print("===训练结束===")

    def predict(self, e):
        """
        根据证据 e 猜硬币种类，返回 0 或 1
        """
        return np.argmax(self.mapping[e])

    def test(self, T):
        correct = 0
        np.random.seed()
        for _ in range(T):
            # 随机选硬币
            idx = np.random.randint(0, len(self.coins))
            coin = self.coins[idx]
            # 抛出三次，获取证据
            e = []
            for _ in range(self.n_flip):
                e.append(int(coin.flip()))
            e = tuple(e)
            # 根据证据猜硬币种类
            if self.predict(e) == coin.t:
                correct += 1
        return correct / T

coins = [Coin(0.5, 0)] * 7 + [Coin(0.8, 1)] * 3
model = Model(coins, 3)
model.train()
T = int(1e7)
args = [T] * 8
pool = Pool(8)
ts = pool.map(model.test, args)
for t in ts:
    print("猜正确的概率是: {:.6f}".format(t))
```

模拟结果

```plain
证据 (0, 0, 0) 下的正常硬币有8775个, 特殊硬币有239个
证据 (0, 0, 1) 下的正常硬币有8857个, 特殊硬币有988个
证据 (0, 1, 0) 下的正常硬币有8803个, 特殊硬币有933个
证据 (0, 1, 1) 下的正常硬币有8708个, 特殊硬币有3729个
证据 (1, 0, 0) 下的正常硬币有8686个, 特殊硬币有953个
证据 (1, 0, 1) 下的正常硬币有8764个, 特殊硬币有3858个
证据 (1, 1, 0) 下的正常硬币有8685个, 特殊硬币有3774个
证据 (1, 1, 1) 下的正常硬币有8913个, 特殊硬币有15335个
===训练结束===
猜正确的概率是: 0.765926
猜正确的概率是: 0.765982
猜正确的概率是: 0.766050
猜正确的概率是: 0.766293
猜正确的概率是: 0.766128
猜正确的概率是: 0.765904
猜正确的概率是: 0.766045
猜正确的概率是: 0.766111
```

## 22. 不公平的硬币 4
在第三章的 [贝叶斯公式](https://leetcode-cn.com/leetbook/read/probability-problems/n9u5bj/) 的例题中，我们解决了基础版的不公平的硬币问题。

[不公平的硬币 2](https://leetcode-cn.com/leetbook/read/probability-problems/nom0vc/)，[不公平的硬币 3](https://leetcode-cn.com/leetbook/read/probability-problems/noavni/)，[不公平的硬币 4](https://leetcode-cn.com/leetbook/read/probability-problems/no2a2e/) 均为该题的变种，考察点也是贝叶斯公式，并且解题过程也类似。

下面是不公平的硬币 4 的描述。

我们在以上 [不公平的硬币 3](https://leetcode-cn.com/leetbook/read/probability-problems/noavni/) 的变种的基础上，再换一种问法，本题由于比较复杂，需要**用有向图来对整体流程进行建模**。下面我们来看这个题。

有 10 枚硬币，其中有 3 枚是不公平的，随机抛出正面的概率为 0.8，另外 7 枚都是公平的，也就是随机抛出正面的概率是 0.5。

现在从 10 枚硬币中随机取出 1 枚，可以随机地抛 3 次，根据结果来预测该硬币是否为不公平硬币。

目前已经抛出了第 1 次。

(1) 如果第一次抛出的结果是正面，则三次抛出完成后预测正确的概率是多少？
(2) 如果第一次抛出的结果是反面，则三次抛出完成后预测正确的概率是多少？

## (1) 问题对比

本题与文章 [不公平的硬币 3](https://leetcode-cn.com/leetbook/read/probability-problems/noavni/) 解决的问题相比，仅仅是增加了一个已知第一次抛出的结果，求的是已知第一次抛出结果后，预测正确的条件概率。为了方便对比，我们首先把上一期的题目抄一遍如下

>有 10 枚硬币，其中有 3 枚是不公平的，随机抛出正面的概率为 0.8，另外 7 枚都是公平的，也就是随机抛出正面的概率是 0.5。
>
>现在从 10 枚硬币中随机取出 1 枚，可以随机地抛 3 次，根据结果来预测该硬币是否为不公平硬币。求预测正确的概率。

该题求的是未知第一次抛出结果时的预测正确的概率，答案是 0.7661，计算过程可以参考上一期文章。

对于本题，我们还是先把**假设**和**证据**分别是什么列清楚，然后把各个假设的**先验概率**以及各个假设下得到各个证据的**似然值**梳理清楚，再分析已知第一次抛出的结果后，预测正确的条件概率的计算。

## (2) 假设和证据

首先我们看都有哪些可能的证据。由于可以抛出 3 次，因此观察到的证据可能有”正正正”、”正正反”、”正反正”、”正反反”, “反正正”、”反正反”、”反反正”、”反反反”这八种。分别记为 e1, e2, e3, e4, e5, e6, e7, e8。

然后我们看都有哪些可能的假设。由于有公平和不公平这两种硬币，因此针对随机取出的硬币有两种假设，”公平” 和 “不公平”，分别记为 H1, H2。

## (3) 先验概率

由于本题是 10 枚硬币，其中有 3 枚不公平硬币，因此 

$$
P(H_{1}) = \frac{7}{10} \\
P(H_{2}) = \frac{3}{10} \\
$$

## (4) 似然值 

公平硬币抛出正面的概率为 p = 0.5，不公平硬币抛出正面的概率是 q = 0.8。

如果硬币是公平硬币，则得到 8 种证据的概率均为 1/8，也就是 8 个似然值均为 1/8

$$
P(e_{i}|H_{1}) = p^{3} = \frac{1}{8}
$$

如果硬币是不公平硬币，则得到 8 种证据的概率分别为

$$
P(e_{1}|H_{2}) = q^{3} = \frac{64}{125}\\
P(e_{2}|H_{2}) = q^{2}(1 - q) = \frac{16}{125} \\
P(e_{3}|H_{2}) = q^{2}(1 - q) = \frac{16}{125} \\
P(e_{4}|H_{2}) = q(1 - q)^{2} = \frac{4}{125} \\
P(e_{5}|H_{2}) = q^{2}(1 - q) = \frac{16}{125} \\
P(e_{6}|H_{2}) = q(1 - q)^{2} = \frac{4}{125} \\
P(e_{7}|H_{2}) = q(1 - q)^{2} = \frac{4}{125} \\
P(e_{8}|H_{2}) = (1 - q)^{3} = \frac{1}{125} \\
$$

## (5) 第一次抛出后的情况

第一次抛出可能有两种结果：正面和反面，分别记为 X1 和 X2。如果是正面，最终预测对的概率就是 P(T|X1)，如果是反面，最终预测对的概率就是 P(T|X2)。

P(T|X1) 和 P(T|X2) 正是我们要求的值。这两个值在整个获取证据流程中是中间的位置，上游有整体的正确概率 P(T)；下游有三次抛出完成后，各个证据下的正确概率 P(T|e)，还是有点复杂的，我们借助有向图来理解会比较直观。

## (6) **有向图建模**

X1 对应 e1, e2, e3, e4 这四种证据，因此问当第一次抛出结果为 X1 时预测正确的概率，相当于问 3 次抛出结果后取得的证据为 e1, e2, e3, e4 这四种之一时预测正确的概率。

$$

P(T|X_{1}) = \sum\limits_{i=1}\limits^{4}P(e_{i}|X_{1})P(T|e_{i}) \\

$$

X2 对应 e5, e6, e7, e8 这四种证据，因此问当第一次抛出结果为 X2 时预测正确的概率，相当于问 3 次抛出结果后取得的证据为 e5, e6, e7, e8 这四种之一时预测正确的概率。

$$

P(T|X_{2}) = \sum\limits_{i=5}\limits^{8}P(e_{i}|X_{2})P(T|e_{i}) \\

$$

为了理解以上的公式，我们把整个流程抽象成一个有向图，如下：


![middle_img_v2_3557214e-adaa-421f-ab69-55736e97c36g.png](https://pic.leetcode-cn.com/1646281876-KCKMHU-aWSCdvDMoi.png)


三层**节点**的含义如下

- 根节点（第一层节点）表示一次还没有抛出，还可以抛出 3 次的状态，该状态的值表示整体的预测正确的概率。
- 第二层节点表示还剩下两次没有抛出的状态，根据第一次的结果可以分为两种状态，状态的值表示在该状态下预测正确的概率。
- 第三层节点表示三次抛出均完成的状态，根据三次抛出的结果可以分为八种状态（8 种可能证据），状态的值表示在该证据下下预测正确的概率。

**有向边**表示从一个状态跳向另一个状态的概率。**要计算某节点表示的状态对应的预测正确概率，只需找到该节点的所有出边对应的下一个节点持有的概率值，与边权表示的状态转移概率进行加权求和后就可以得到。**

例如在上图中，如果我们要求 P(T)，只需要找到两个出边对应的下游节点 P(T|X1) 和 P(T|X2)，以及转移概率 P(X1) 和 P(X2)，即可得到

$$
P(T) = P(X_{1})P(T|X_{1}) + P(X_{2})P(T|X_{2})
$$

如果要求 P(T|X1)，只需要找到四个出边对应的下游节点 P(T|e1), P(T|e2), P(T|e3), P(T|e4)，以及转移概率 P(e1|X1), P(e2|x1), P(e3|X1), P(e4|x1)，即可得到

$$

P(T|X_{1}) = P(e_{1}|X_{1})P(T|e_{1}) + P(e_{2}|X_{1})P(T|e_{2}) \\ \nonumber
& \quad\quad + P(e_{3}|X_{1})P(T|e_{3}) + P(e_{4}|X_{1})P(T|e_{4}) \\

$$

## (7) 推导 P(T|X)

$$

P(T|X_{1}) = \sum\limits_{i=1}\limits^{4}P(e_{i}|X_{1})P(T|e_{i}) \\  
= \sum\limits_{i=1}\limits^{4}P(e_{i}|X_{1})\max\limits_{j}P(H_{j}|e_{i}) \\  
= \sum\limits_{i=1}\limits^{4}P(e_{i}|X_{1})\max\limits_{j}\frac{P(e_{i}|H_{j})P(H_{j})}{P(e_{i})} \\  
= \sum\limits_{i=1}\limits^{4}\frac{P(e_{i}|X_{1})}{P(e_{i})}\max\limits_{j}P(e_{i}|H_{j})P(H_{j}) \\

$$

其中 P(ei|Hj) 是我们之前算好的似然值，P(Hj) 是之前算好的先验概率。

**由于 X1 包含 ei，即 ei 成立则 X1 一定也成立，所以**

$$
P(e_{i}) = P(e_{i}X_{1}) = P(X_{1})P(e_{i}|X_{1})
$$

因此 P(T|X1) 和Ｐ(T|X2) 的最终计算公式如下

$$
P(T|X_{1}) = \frac{1}{P(X_{1})}\sum\limits_{i=1}\limits^{4}\max\limits_{j}P(e_{i}|H_{j})P(H_{j}) \\
P(T|X_{2}) = \frac{1}{P(X_{2})}\sum\limits_{i=5}\limits^{8}\max\limits_{j}P(e_{i}|H_{j})P(H_{j}) \\
$$

这里 P(X1) 和 P(X2) 需要额外算一下，用到全概率公式

$$

P(X_{1}) = P(X_{1}|H_{1})P(H_{1}) + P(X_{1}|H_{2})P(H_{2}) \\
= \frac{1}{2}\frac{7}{10} + \frac{4}{5}\frac{3}{10} \\
= \frac{59}{100} \\
P(X_{2}) = 1 - P(X_{1}) = \frac{41}{100}

$$

## (8) 计算 P(T|X)

将先验概率，似然值，和刚刚算好的 P(X1), P(X2) 代入公式计算

$$

P(T|X_{1}) = \frac{1}{P(X_{1})}\sum\limits_{i=1}\limits^{4}\max\limits_{j}P(e_{i}|H_{j})P(H_{j}) \\
= \frac{100}{59} \times (\frac{64}{125} \times \frac{3}{10} + \frac{1}{8} \times \frac{7}{10} \times 3) \\
= 0.7052542 \\
P(T|X_{2}) = \frac{1}{P(X_{2})}\sum\limits_{i=5}\limits^{8}\max\limits_{j}P(e_{i}|H_{j})P(H_{j}) \\
= \frac{100}{41} \times (\frac{1}{8} \times \frac{7}{10} \times 4) \\
= 0.8536585 \\

$$

---

# 蒙特卡洛模拟

模拟的逻辑与 $4-21 中的基本一样：模拟的核心是当得到证据 e 之后，如何给出预测结果，也就是代码中 model 实例中的 predict 方法。根据前面的推导，这取决于 16 个似然值。首先随机生成数据模拟出 8 个后验概率(代码中 model 实例的 train 方法)，再随机生成数据模拟预测正确的概率（代码中 model 实例的 test 方法）。**只是在预测的时候，增加了对条件概率 P(T|X1) 和 P(T|X2) 的模拟，验证前面的推导过程。**

```python
import numpy as np
from multiprocessing import Pool

class Coin:
    def __init__(self, p, t):
        self.p = p
        self.t = t # 硬币种类 id

    def flip(self):
        """
        如果抛出正面，返回 True
        """
        return np.random.rand() < self.p

class Model:
    def __init__(self, coins, n_flip):
        self.coins = coins
        self.n_flip = n_flip
        # mapping 记录每种证据下两种硬币种类的次数
        # 共有 16 个参数
        self.mapping = {}
        for i in range(1 << n_flip):
            e = [0] * n_flip
            for j in range(n_flip):
                e[n_flip - 1 - j] = i >> j & 1
            self.mapping[tuple(e)] = np.array([0, 0])

    def update(self, e, idx):
        """
        根据数据 (e, idx) 更新 mapping 的参数
        数据的含义是证据 e 对应硬币种类 idx
        """
        self.mapping[e][idx] += 1

    def train(self):
        """
        随机生成数据训练
        """
        n_train = int(1e5)
        for i in range(n_train):
            idx = np.random.randint(0, len(self.coins))
            coin = self.coins[idx]
            e = []
            for _ in range(self.n_flip):
                e.append(int(coin.flip()))
            e = tuple(e)
            self.update(e, coin.t)
        for k, v in self.mapping.items():
            print("证据 {} 下的正常硬币有{}个, 特殊硬币有{}个".format(k, v[0], v[1]))
        print("===训练结束===")

    def predict(self, e):
        """
        根据证据 e 猜硬币种类，返回 0 或 1
        """
        return np.argmax(self.mapping[e])

    def test(self, T):
        correct = 0
        np.random.seed()
        n_X1 = 0
        n_X2 = 0
        n_X1_corrent = 0
        n_X2_corrent = 0
        for _ in range(T):
            # 随机选硬币
            idx = np.random.randint(0, len(self.coins))
            coin = self.coins[idx]
            # 抛出 n_flip 次，获取证据
            e = []
            # 抛出 n_flip 次
            for _ in range(self.n_flip):
                e.append(int(coin.flip()))
            e = tuple(e)
            if e[0] == 1:
                n_X1 += 1
            else:
                n_X2 += 1
            # 根据证据猜硬币种类
            if self.predict(e) == coin.t:
                correct += 1
                if e[0] == 1:
                    n_X1_corrent += 1
                else:
                    n_X2_corrent += 1
        return correct / T, n_X1_corrent / n_X1, n_X2_corrent / n_X2

coins = [Coin(0.5, 0)] * 7 + [Coin(0.8, 1)] * 3
model = Model(coins, 3)
model.train()
T = int(1e7)
args = [T] * 8
pool = Pool(8)
ts = pool.map(model.test, args)
ans = [0, 0, 0]
for t in ts:
    ans[0], ans[1], ans[2] = t
print("P(T): {:.6f}".format(ans[0]))
print("P(T|X1): {:.6f}".format(ans[1]))
print("P(T|X2): {:.6f}".format(ans[2]))
```

模拟结果

```plain
证据 (0, 0, 0) 下的正常硬币有8849个, 特殊硬币有216个
证据 (0, 0, 1) 下的正常硬币有8689个, 特殊硬币有908个
证据 (0, 1, 0) 下的正常硬币有8718个, 特殊硬币有988个
证据 (0, 1, 1) 下的正常硬币有8765个, 特殊硬币有3892个
证据 (1, 0, 0) 下的正常硬币有8747个, 特殊硬币有926个
证据 (1, 0, 1) 下的正常硬币有8846个, 特殊硬币有3902个
证据 (1, 1, 0) 下的正常硬币有8709个, 特殊硬币有3810个
证据 (1, 1, 1) 下的正常硬币有8669个, 特殊硬币有15366个
===训练结束===
无额外决策的结果
P(T): 0.766069
P(T|X1): 0.705227
P(T|X2): 0.853590
```


# 附录：概率论在计算机中的运用
概论除了是机器学习核心工具外，在其他计算机领域也有许多重要应用。本章简要给出算法分析、概率数据结构、随机算法三方面因子。若要深入，这三方面的内容内容是可以单独开展专栏讨论的，后续我们再深入展开话题。

## 算法分析
### 算法的概率分析

算法分析中常见的方法有概率分析、摊销分析、竞争分析等等。

其中概率分析主要是用概率手段对算法进行**平均情况分析**。

如果是确定性算法，只需要考虑所有输入分布即可，而如果是随机算法，处理考虑输入分布以外，算法的随机步骤也需要考虑。

下面以一个例子来看一下概率分析的过程。

### 问题: 梦幻情人的代价

我去婚介所寻求对象，婚介所一次性给我 n 个人的资料，那么我需要一种算法从中选出最好的人。

每个人的资料只能访问一次，但是访问顺序可以自己定，初始顺序就是婚介所给我这 n 个人时排列好的顺序。

#### 确定性算法: 见好就变

这里我直接给出一种算法: 见好就变算法，具体如下

用一个变量 best 记录当前的最佳对象。依次枚举 n 位候选人，每枚举一位需要支付介绍费用 $C_{i}$，如果当前枚举到的候选人 i 比当前最佳对象 best 优秀，那么就把 i 作为当前最佳对象，首先要支付 $c_{s}$ 分手费，然后支付介绍成功费 $C_{i}$，并且要支付与新最佳对象的相处费 $C_{d}$。

问，这个见好就变的恋爱算法需要支付多大成本。

##### 分析

###### step1: 伪代码和各行成本

首先我们将算法写成伪代码，并在每一行后面标注该行对应的成本。

```plain
best = 0
for i = 1..n do                                 // 介绍费 Cj
    if 候选人 i 比当前最佳对象 best 优秀 then   // 分手费 Cs
        best = i                                // 介绍成功费 Cj
        约会新最佳对象 i                        // 相处费 Cd
```

###### step2: 最好与最坏情况

首先通过伪代码和每一行的成本，我们可以直接写出大 O 分析结果 $O(nC_{i} + mC_{d} + mC_{j} + (m-1)C_{s})$

为了方便，记 $C = C_{d} + C_{j} + C_{s}$，于是问题变为了分析 $mC$。其中 m 是 if 判定成功的次数。

最坏情况是 m = n，也就是严格按照从坏到好的顺序介绍，此时结果为 $O(nC_{i} + nC)$，由生活经验，$C >> C_{i}$，结果可以写为 $O(nC)$

最好情况是 m = 1，也就是一上来就介绍了最好的，后面的顺序不重要。此时结果为 $O(nC_{i} + 1C)$，这里能否写为 $O(nC_{i})$ 就要看 $C >> nC_{i}$ 是否满足了。

###### step3: 输入分布随机时的平均情况

平均情况是需要用到概率分析的地方。想当然的认为结果是 $O(nC_{i} + \frac{n}{2}C)$ 是错的。

下面进行概率分析。

记 rank(1) 是第一个候选人的排名，取值 1 ~ n。

<rank(1), rank(2), ..., rank(n)> 是数列 <1, 2, ..., n> 的一个排列。

现在有一个**针对算法输入**的重要假设: 候选人出现的顺序随机。

记随机变量 $X_{i}$ 表示第 i 个人是否被我看中，若看中则为 1 否则为 0。

于是我的总恋爱次数为随机变量和 $X = X_{1} + X_{2} + ... + X_{n}$。

**我们概率分析的目标是求 $E[X]$**

由于候选人出现顺序随机，因此 i 被我看中（也就是 i 比前面的 i - 1 个人都强）的概率是 $\frac{1}{i}$，于是 $E[X_{i}] = \frac{1}{i}$。

所以

$$
E[X] = E[\sum\limits_{i=1}\limits^{n}X_{i}] = \sum E[X_{i}] \\
= \sum\limits_{i=1}\limits^{n}\frac{1}{i} = \ln(n) + O(1)
$$

因此平均情况的结果为 $O(C\ln(n))$

###### step4: 对输入分布的先验知识

注意前面针对输入的假设不一定成立，也就是候选人出现的顺序不一定随机，例如婚介所就是从坏到好给我介绍。那么平均情况的结果不会是前面推导的 $O(C\ln(n))$，而是最坏情况的结果。这也是前面为什么说概率分析需要考虑输入分布的原因。

而婚介所因为要多挣钱，所以它基本上会按照最坏情况的顺序该我，这就是我们**对输入分布的先验知识**。

那么对于这种情况，我们该怎么办呢，大致有以下三种方案。

1. 搞情况候选人介绍顺序到底是什么分布，但这基本不现实，因为对方一般不会提前告知数据分布。
2. 承认婚介所会按从坏到好的顺序介绍，我就做最坏打算，但这也不现实，因为我不接受。
3. 既然对方给我的顺序是按最坏情况来的（先验知识），那我自己做随机化好了。

也就是在执行见好就变算法前，我自己把 n 个候选人的顺序随机排列一下，然后再依次访问各个候选人资料。

其中随机排列算法如下：

```plain
for i = 1..n do
    swap A[i] A[Random(i, n)]  // 成本 O(1)
```

按以上算法，随机排列的成本为 O(n)，总成本就变为 $O(n + C\ln(n))$，这比最坏情况的 $O(nC)$ 要好。

## 概率数据结构
如果大家刷过一些面经的话，会发现经常见到一些大数据算法的问题，比如上来给你 400 亿个数/字符串，然后完成某种需求。

大数据算法涵盖的面比较广，随机算法，近似算法，外存算法，并行算法，分布式算法等都可以算是大数据算法。

其中随机算法是很重要的一种算法，而随机算法的实现需要用到一些概率数据结构，也就是应用了概率知识的数据结构。

这种概率数据结构有一些经典场景，比如哈希、相似性、排名、频率、成员关系、元素种类数等等。每个场景下有几个经典数据结构，具体可以看下图，其中有红旗标志的是 Redis 里有的，可以参考一下。

![1.png](https://pic.leetcode-cn.com/1646278713-jpiFHT-1.png)

## 随机算法
随机算法就是在算法中引入随机因素，即通过随机数选择算法的下一步操作。

随机算法是一种算法，它采用了一定程度的随机性作为其逻辑的一部分。

该算法通常使用均匀随机数作为辅助输入来指导自己的行为，在力扣上有 10 道与随机算法相关的题目，主要涉及下面这些知识点，这里把知识点与题目列出来了，感兴趣的同学可以研究一下。

- 洗牌
    - [384. 打乱数组](https://leetcode-cn.com/problems/shuffle-an-array/)
- 拒绝采样
    - [478. 在圆内随机生成点](https://leetcode-cn.com/problems/generate-random-point-in-a-circle/)
    - [470. 用 Rand7() 实现 Rand10()](https://leetcode-cn.com/problems/implement-rand10-using-rand7/)
- 蓄水池抽样
    - [398. 随机数索引](https://leetcode-cn.com/problems/random-pick-index/)
    - [382. 链表随机节点](https://leetcode-cn.com/problems/linked-list-random-node/)
- 加权蓄水池抽样
    - [528. 按权重随机选择](https://leetcode-cn.com/problems/random-pick-with-weight/)
- 黑名单映射
    - [710. 黑名单中的随机数](https://leetcode-cn.com/problems/random-pick-with-blacklist/)
    - [519. 随机翻转矩阵](https://leetcode-cn.com/problems/random-flip-matrix/solution/)
- 加权随机事件二分
    - [528. 按权重随机选择](https://leetcode-cn.com/problems/random-pick-with-weight/)
    - [497. 非重叠矩形中的随机点](https://leetcode-cn.com/problems/random-point-in-non-overlapping-rectangles/)

## 本书参考文献
1. Schwarz W. 40 Puzzles and Problems in Probability and Mathematical Statistics[M]. Springer New York, 2008.
3. Mosteller F. Fifty challenging problems in probability with solutions[M]. Dover Publications, Inc., New York, 1987
3. 陈希孺.概率论与数理统计［M].中国科学技术大学出版社，2009
4. Ross Sheldon M.概率论基础教程（原书第9版）［M].机械工业出版社，2014
5. 邹恒明. 算法之道（第2版）[M]. 机械工业出版社, 2012


# 测试
本章针对本书的知识点进行测试。

## 简答题
<!DOCTYPE html>
<html>
<head>
<style>
label:hover   {color: #3172cc;}
.nav-con{display: none;}
.nav-box{display: none;}
.nav-con:checked ~ .nav-box{display: block;}
.nav-btn{font-size:16px; font-weight: bold;}
</style>
</head>
<body>

<p>1. 随机模拟方法是什么？</p>
<label for="control1" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box">  
	是通过仿真随机系统的运行来获得系统的状态变化与输出结果的大量数据，进而对所得数据进行统计分析，估算系统行为的某些特征，并将估计的误差控制在一定范围内。
   </p>
</div>
<br>

<p>2. 随机模拟大致分为哪六个步骤？</p>
<label for="control2" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box">  
	描述系统、设置变量、运行规则、模拟系统、抽样与统计、解释结果。
    </p>
</div>
<br>

<p>3. 设置变量的一步中做了什么？</p>
<label for="control3" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box">  
	• 为系统的输入、状态、输出设置变量 <br>
	• 为随机事件设定随机数
    </p>
</div>
<br>

<p>4. 运行规则的一步中做了什么？</p>
<label for="control4" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box">  
	• 系统状态如何变化 <br>
	• 随机数如何产生
    </p>
</div>
<br>

<p>5. 古典概率模型有哪些特征？</p>
<label for="control5" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control5" class="nav-con">
    <p class="nav-box">  
• 试验的所有可能结果只有有限个，即样本空间中的基本事件只有有限个。 <br>
• 各试验结果出现的可能性相等，即所有基本事件的发生是等可能的。 <br>
• 试验所有可能出现的结果两两互不相容。
</p>
</div>
<br>

<p>6. 请写出条件概率的公式。</p>
<label for="control6" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control6" class="nav-con">
    <p class="nav-box">  
	
	P(B∣A)=P(AB)/P(A),P(A)>0
	
    </p>
</div>
<br>

<p>7. 常见的两种离散型概率分布有哪两种？</p>
<label for="control7" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control7" class="nav-con">
    <p class="nav-box">  
	二项分布和泊松分布。
    </p>
</div>
<br>

<p>8. 常见的连续型随机变量的概率分布有哪三种？</p>
<label for="control8" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control8" class="nav-con">
    <p class="nav-box">  
	• 均匀分布 <br>
	• 指数分布 <br>
	• 正态分布
    </p>
</div>
<br>

<p>9. 均匀分布的loc和scale是多少？</p>
<label for="control9" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control9" class="nav-con">
    <p class="nav-box">  
	loc 为 a，scale 为 b - a。
   </p>
</div>
<br>

<p>10. 请写出二项分布的数学期望和 Python 代码。
</p>
<label for="control10" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control10" class="nav-con">
    <p class="nav-box">  
X～B(n,p)
E(X)=np
Python代码: scipy.stats.binom.mean
    </p>
</div>
<br>

<p>11. 请写出全概率公式。</p>
<label for="control11" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control11" class="nav-con">
    <p class="nav-box">  
	
	P(X)=y∑P(Y=y)P(X∣Y=y)（X, Y 为随机变量）
	
    </p>
</div>
<br>

<p>12. 请写出全期望公式。</p>
<label for="control12" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control12" class="nav-con">
    <p class="nav-box">  

EX(X)=EY(EX∣Y(X∣Y))=y∑p(Y=y)×EX∣Y=y(X∣Y=y)

    </p>
</div>
<br>

<p>13. 拿到一个贝叶斯公式的概率问题，首先要确定什么？</p>
<label for="control13" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control13" class="nav-con">
    <p class="nav-box">  
	
	首先要确定“假设是什么”及“证据是什么”，然后再代入公式。
	
    </p>
</div>
<br>

<p>14. 概率分析是什么？</p>
<label for="control14" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control14" class="nav-con">
    <p class="nav-box">  
	概率分析主要是用概率手段对算法进行平均情况分析。
    </p>
</div>
<br>

<p>15. 确定性算法和随机算法分别要考虑什么？</p>
<label for="control15" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control15" class="nav-con">
    <p class="nav-box">  
	如果是确定性算法，只需要考虑所有输入分布即可，而如果是随机算法，处理考虑输入分布以外，算法的随机步骤也需要考虑。
    </p>
</div>
<br>

<p>16. 随机算法通常使用什么作为辅助输入来指导自己的行为？</p>
<label for="control16" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control16" class="nav-con">
    <p class="nav-box">  
	均匀随机数。
    </p>
</div>
<br>

</body>
</html>

## 选择题
fyct2fc4icfbglifjq7efftdgxhhlwv

