
# JavaScirpt


## ES3


### a = ?, a==1 && a==2 && a==3 成立
## `==` 会触发隐式转换，`===` 不会
### 对象转字符串
* 先尝试调用对象的 toString()
* 对象无 toString(）或 toString 返回非原始值，调用 valueOf() 方法
    * 将该值转为字符串，并返回字符串结果
* 否则，抛出类型错误
### 对象转数字
* 先尝试调用对象的 valueOf()，将返回原始值转为数字
* 对象无 valueOf() 或 valueOf 返回不是原始值，调用 toString() 方法，将返回原始值转为数字
* 否则，抛出类型错误
### 对象转布尔值
* True
### 代码

```JavaScript []
const a = {
	count: 0,
	valueOf() {
		return ++this.count
	}
}
```

## 数组
隐式转换会调用数组的 join 方法，改写此方法

```JavaScript []
const a = [1, 2, 3]
a.join = a.shift
```

### null == undefined 结果
比较 null 和 undefined 的时候，不能将 null 和 undefined 隐式转换，规范规定结果为相等

### 常见的类型转换
|类型|值|to Boolean|to Number|to String|
|:----|:----|:----|:----|:----|
|Boolean|true|true|1|"true"|
|Boolean|false|false|0|"false"|
|Number|123|true|123|"123"|
|Number|Infinity|true|Infinity|"Infinity"|
|Number|0|false|0|"0"|
|Number|NaN|false|NaN|"NaN"|
|String|""|false|0|""|
|String|"123"|true|123|"123"|
|String|"123abc"|true|NaN|"123abc"|
|String|"abc"|true|NaN|"abc"|
|Null|null|false|0|"null"|
|Undefined|undefined|false|NaN|"undefined"|
|Function|function() {}|true|NaN|"function(){}"|
|Object|{}|true|NaN|"[object Object]"|
|Array|[]|true|0|""|
|Array|["abc"]|true|NaN|"abc"|
|Array|["123"]|true|123|"123"|
|Array|["123", "abc"]|true|NaN|"123, abc"|

### 对比 get 和 Object.defineProperty
## 相同点

都可以定义属性被查询时的函数

## 不同点

在 `classes` 内部使用
* `get` 属性将被定义到 实例原型
* `Object.defineProperty` 属性将被定义在 实例自身

### 对比 escape encodeURI 和 encodeURIComponent
## escape
对字符串编码
ASCII 字母、数字 @ * / + - _ . 之外的字符都被编码
## encodeURI
对 URL 编码
ASCII 字母、数字 @ * / + 和 ~ ! # $ & () =, ; ?- _ . '之外的字符都被编码
## encodeURIComponent
对 URL 编码
ASCII 字母、数字 ~ ! * ( ) - _ . ' 之外的字符都被编码


## 事件


### 事件传播的过程
## 事件冒泡
- DOM0 和 IE支持（DOM1 开始是 W3C 规范）
- 从事件源向父级，一直到根元素（HTML）
- 某个元素的某类型事件被触发，父元素同类型事件也会被触发
## 事件捕获
- DOM2 支持
- 从根元素（HTML）到事件源
- 某个元素的某类型事件被触发，先触发根元素，再向子一级，直到事件源
## 事件流
- 事件的流向：事件捕获 → 事件源 → 事件冒泡
## 阻止事件冒泡
- 标准：`event.stopPropagation()`
- IE：`event.cancelBubble = true`

### Event  Loop 的执行顺序？
## 宏任务
- Task Queue
- 常见宏任务：`setTimeout`、`setInterval`、`setImmediate`、`I/O`、`script`、`UI rendering`
## 微任务
- Job Queue
- 常见微任务：
    - 浏览器：`Promise`、`MutationObserver`
    - Node.js：`process.nextTick`
## 执行顺序
- 首先执行同步代码，宏任务
- 同步栈为空，查询是否有异步代码需要执行
- 执行所有微任务
- 执行完，是否需要渲染页面
- 重新开始 Event  Loop，执行宏任务中的异步代码

### 为什么 Vue.$nextTick 通常比 setTimeout 优先级高，渲染更快生效？
* `Vue.$nextTick` 需要异步执行队列，异步函数的实现优先使用
    * `Promise`、`MutationObserver`、`setImmediate`
    * 都不兼容时，使用 `setTimeout`
* `Promise`、`MutationObserver`、`setImmediate` 是微任务
* `setTimeout`、`UI rendering` 是宏任务
* 根据执行顺序
    * `Promise`、`MutationObserver`、`setImmediate` 创建微任务，添加到当前宏任务微任务队列。队列任务执行完，如需渲染，即可渲染页面
    * `setTimeout` 创建宏任务，如果此时正在执行微任务队列，需要等队列执行完，渲染一次后，重新开始 Event Loop，执行宏任务中的异步代码后再渲染


## ES6


### 列举 ES6、ES7、ES8、ES9、ES10、ES11+ 新特性
* ES6
    * `let` 和 `const` 
    * `Promise`
    * `Class`
    * 箭头函数
    * 函数参数默认值
    * 模版字符串
    * 解构赋值
    * 展开语法
        * 构造数组，调用函数时，将 数组表达式 或  `string` 在语法层面展开
    * 对象属性缩写
        * 键名和键值相同
        * 函数省略  `function` 
    * 模块化
* ES7
    * `includes()` 
    * 指数操作符  `**` 
* ES8
    * `async` / `await` 
    * `Object.values()` 
    * `Object.entries()` 
    * `Object.getOwnPropertyDescriptors()` 
    * 填充字符串到指定长度： `padStart` `padEnd` 
    * `ShareArrayBuffer`  和  `Atomics` ，共享内存位置读取和写入
    * 函数最后参数有 尾逗号，与 数组 和 对象 保持一致
* ES9
    * 异步迭代： `for await (let i of array)` 
    * `Promise.prototype.finally()` 
    * 展开语法
        * 构造字面量对象时，将对象按照键值对展开，克隆属性或浅拷贝
    * 非转义序列的模版字符串
    * 正则表达式
        * 命名捕获组：
```javascript
const match = /(?<year>\d{4})/.exec('2022')
console.log(match.groups.year) // 2022
```
        * 反向断言：
            * 肯定反向断言 
```javascript
const match = /(?<=\D)\d+/.exec('a123')
console.log(match[0]) // 123
```
            * 否定反向断言 
```javascript
const match = /(?<!\d)\d+/.exec('a123')
console.log(match[0]) // 123
```
        * dotAll 模式：增加  `s` 修饰符，让 `.` 可以匹配换行符
        * Unicode 转义：新的匹配符合 Unicode 某属性所有字符写法 `\p{...}` 和 `\P{...}`
```javascript
/^\p{Number}+$/u.test('①②③¼½¾¹²³ⅠⅡⅢ') // 匹配各种数字
 /^\P{Number}+$/u.test('Ab.<(中文)>') // 匹配非数字
```
        * 非转义序列的模版字符串
            * `\u` unicode转义
            * `\x` 十六进制转义
            * `\` 后跟数字，八进制转义
* ES10
    * `JSON.stringify` 
        * `\ud800`到 `\udfff` 单独转换，返回转义字符串
        * `\ud800`到 `\udfff` 成对转换，对应字符存在，返回字符。不存在，返回转义字符串
    * `flat` 和  `flatMap` 
    * `trimStart` 和  `trimEnd` 去除字符串首尾空白字符
    * `Object.fromEntries()` 传入键值对列表，返回键值对对象
    * `Symbol.prototype.description` 
```javascript
const sym = Symbol('description')
sym.description // description
```
    * `String.prototype.matchAll` 返回包含所有匹配正则表达式和分组捕获结果的迭代器
    * `Function.prototype.toString()` 返回精确字符，包括空格和注释
    * 修改  `catch` 绑定
    * 新基本数据类型  `BigInt`
    * `globalThis` 
    * `import()` 
* ES11+
    *  `String.prototype.replaceAll` 
    *  `Promise.any` 
        * 一个 `resolve` 返回第一个  `resolve` 状态
        * 所有  `reject` 返回请求失败
    *  `WeakRefs` 
        * 通过  `WeakMap`  `WeakSet` 创建
        * 创建对象的弱引用：该对象可被回收，即使它仍被引用
    * 逻辑运算符赋值表达式
        * ||=
```plain
a ||= b // 若 a 不存在，则 a = b
```
        * &&=
```plain
a &&= b // 若 a 存在，则 a = b
```
        * ??=
```plain
a ??= b // 若 a 为 null 或 undefined，则 a = b
```
    * 访问对象未定义属性
        * ?.
```javascript
const a = {}
a?.b?.c // undefined，不报错
```
    * 数字分隔符
```plain
123_1569_9128 // 12315699128
```

### `==`  `===` 和  `Object.is()` 区别
`==`  相等，如果两边类型不一致，进行隐式转换后，再比较。`+0` 和  `-0` 相等， `NaN` 不等于任何数 

`===` 严格相等，如果类型不一致，就不相等。 `+0` 和  `-0` 相等， `NaN` 不等于任何数

`Object.is()` 严格相等，`+0` 和  `-0` 不相等， `NaN` 等于自身

### a = []，a.push(...[1, 2, 3]) ，a = ？
a =  [1, 2, 3]，考核点如下：
- [].push：调用数组 push 方法
- apply：
    - 第一参数：指定 push 执行时的 this，即正在调用 push 的对象为数组 a
    - 第二参数：传入数组或类数组对象作为参数数组，展开作为 push 的参数列表
- push的语法：支持将一个或多个元素添加到数组末尾
```
arr.push(element1, ..., elementN)
```

综上，题目等同于

```
a.push(1, 2, 3) // [1, 2, 3]
```


## 变量


### 列举类数组对象
（1）定义

* 拥有 `length` 属性
* 若干索引属性的任意对象

（2）举例

* `NodeList`
* `HTML Collections`
* 字符串
* `arguments`
* `$` 返回的 `jQuery` 原型对象

（3）类数组对象转数组

* 新建数组，遍历类数组对象，将每个元素放入新数组
* `Array.prototype.slice.call(ArrayLike)` 或 `[].slice.call(ArrayLike)`
* `Array.from(ArrayLike)`
* `apply` 第二参数传入，调用数组方法

```JavaScript []
Array.prototype.push.apply([], ArrayLike)
```


## 闭包


### 什么是闭包？
闭包是由函数以及声明该函数的词法环境组合而成

* 一个函数和对其周围状态（词法环境）的引用捆绑在一起（或者说函数被引用包围），这样的组合就是闭包
* 可以在内层函数中访问到其外层函数的作用域
* 每当创建一个函数，闭包就会在函数创建的同时被创建出来

### 什么是词法？
词法，英文 lexical ，词法作用域根据源代码**声明变量的位置**来确定变量在何处可用

嵌套函数可访问声明于它们外部作用域的变量

### 什么是函数柯里化？
函数调用：一个参数集合应用到函数

部分应用：只传递部分参数，而非全部参数

柯里化（curry）：使函数理解并处理部分应用的过程

* 保存调用 curry 函数时传入的参数，返回一个新函数
* 结果函数在被调用后，要让新的参数和旧的参数一起应用到入参函数


## bind / apply / call / new


### 手写 bind
* 第一个参数接收 this 对象
* 返回函数，根据使用方式
    * 直接调用
        * 改变 this 指向
        * 拼接参数
        * 调用函数
    * 构造函数
        * 不改变 this 指向，忽略第一参数
        * 拼接参数
        * new 函数

```JavaScript []
Function.prototype.myBind = function(_this, ...args) {
	const fn = this
	return function F(...args2) {
		return this instanceof F ? new fn(...args, ...args2)
		: fn.apply(_this, args.concat(args2))
	}
}
//使用
function Sum (a, b) {
	this.v= (this.v || 0)+ a + b
	return this
}
const NewSum = Sum.myBind({v: 1}, 2)
NewSum(3) // 调用：{v: 6}
new NewSum(3) // 构造函数：{v: 5} 忽略 myBind 绑定this
```

### 手写 call
* 第一参数接收 this 对象
* 改变 this 指向：将函数作为传入 this 对象的方法
* 展开语法，支持传入和调用参数列表
* 调用并删除方法，返回结果

```JavaScript []
Function.prototype.myCall = function(_this, ...args) {
	if (!_this) _this = Object.create(null)
	_this.fn = this
	const res = _this.fn(...args)
	delete _this.fn
	return res
}
// 使用
function sum (a, b) {
	return this.v + a + b
}
sum.myCall({v: 1}, 2, 3) // 6
```

### 手写 apply
* 第一参数接收 this 对象
* 改变 this 指向：将函数作为传入 this 对象的方法
* 第二个参数默认数组
* 展开语法，支持调用参数列表
* 调用并删除方法，返回结果

```JavaScript []
Function.prototype.myApply = function(_this, args = []) {
	if (!_this) _this = Object.create(null)
	_this.fn =this
	const res = _this.fn(...args)
	delete _this.fn
	return res
}
// 使用
function sum (a, b) {
	return this.v + a + b
}
sum.myApply({v: 1}, [2, 3]) // 6
```

### 手写 new
* 第一参数作为构造函数，其余参数作为构造函数参数
* 继承构造函数原型创建新对象
* 执行构造函数
* 结果为对象，返回结果，反之，返回新对象

```JavaScript []
function myNew(...args) {
	const Constructor = args[0]
	const o = Object.create(Constructor.prototype)
	const res = Constructor.apply(o, args.slice(1))
	return res instanceof Object ? res : o
}
// 使用
function P(v) {
	this.v = v
}
const p = myNew(P, 1) // P {v: 1}
```

### 手写防抖
* 声明定时器
* 返回函数
* 一定时间间隔，执行回调函数
* 回调函数
    * 已执行：清空定时器
    * 未执行：重置定时器

```JavaScript []
function debounce(fn, delay) {
	let timer = null
	return function (...args) {
		if (timer) clearTimeout(timer)
		timer = setTimeout(() => {
			timer = null
			fn.apply(this, args)
		}, (delay + '') | 0 || 1000 / 60)
	}
}
```

### 手写节流
* 声明定时器
* 返回函数
* 一定时间间隔，执行回调函数
* 回调函数
    * 已执行：清空定时器
    * 未执行：返回

```JavaScript []
function throttle(fn, interval) {
	let timer = null
	return function (...args) {
		if (timer) return
		timer = setTimeout(() => {
			timer = null
			fn.apply(this, args)
		}, (interval +'')| 0 || 1000 / 60)
	}
}
```


## 原型链


### 对比各种继承？
（1）原型链继承

子类原型指向父类实例

```JavaScript []
function Parent() {}
function Child() {}
Child.prototype = new Parent()
const child = new Child()
```

好处：
* 子类可以访问到父类新增原型方法和属性

坏处：

* 无法实现多继承
* 创建实例不能传递参数

（2）构造函数

```JavaScript []
function Parent() {}
function Child(...args) {
	Parent.call(this, ...args) // Parent.apply(this, args)
}
const child = new Child(1)
```

好处：
* 可以实现多继承
* 创建实例可以传递参数

坏处：

* 实例并不是父类的实例，只是子类的实例
* 不能继承父类原型上的方法

（3）组合继承

```JavaScript []
function Parent() {}
function Child(...args) {
	Parent.call(this, ...args)
}
Child.prototype = Object.create(Parent.prototype)
Child.prototype.constructor = Child
const child = new Child(1)
```

好处：
* 属性和原型链上的方法都可以继承
* 创建实例可以传递参数

（4）对象继承

* Object.create

```JavaScript []
const Parent = { property: 'value', method() {} }
const Child = Object.create(Parent)
```

* create

```JavaScript []
const Parent = { property: 'value', method() {} }
function create(obj) {
	function F() {}
	F.prototype = obj
	return new F()
}
const child  = create(Parent)
```

好处：
* 可以继承属性和方法

坏处：

* 创建实例无法传递参数
* 传入对象的属性有引用类型，所有类型都会共享相应的值

（5）寄生组合继承

```JavaScript []
function Parent() {}
function Child(...args) {
	Parent.call(this, args)
}
function create(obj) {
	function F() {}
	F.prototype =  obj
	return F
}
function extend(Child, Parent) {
	const clone = create(Parent.prototype)
	clone.constructor = Child
	Child.prototype = clone
}
extend(Child, Parent)
const child = new Child(1)
```

（6）ES6继承


```JavaScript []
class Parent {
	constructor(property) {
		this.property = property
	}
	method() {}
}
class Child extends Parent {
	constructor(property) {
		super(property)
	}
}
```

### 什么是原型链 ？
（1）什么是原型对象，原型链 ？

* JavaScript 是动态的，本身不提供一个 `class` 的实现。ES2015 / ES6 引入 `class` 关键字，只是语法糖，JavaScript 仍然基于原型
* JavaScript 只有一种结构：对象
    * 每个**实例对象**（Object）都有一个**私有属性**（称之为 __proto__ ）指向它的构造函数的**原型对象**（prototype）
    * 该**原型对象**也有一个自己的**原型对象**（__proto__），层层向上直到一个对象的原型对象为 `null` 
    * `null` 没有原型，是这个**原型链**中的**最后一个环节**
* JavaScript 中的对象都是位于原型链顶端的 Object 的实例
综上，原型链就是从实例对象，指向原型对象，最终指向  `null` 的链接

（2）基于原型链的继承

* 继承属性
    * JavaScript 对象是动态的属性“包”
    * JavaScript 对象有一个指向一个原型对象的链
    * 试图访问一个对象的属性时，不仅在该对象上搜寻，还会搜寻对象的原型，以及该对象的原型的原型，依次层层向上搜索，直到找到一个名字匹配的属性或到达原型链的末尾
    * 指向原型对象的和标准属性
        * `someObject.[[Prototype]]` 符号是用于指向  `someObject` 的原型
        * 从 ECMAScript 6 开始，`[[Prototype]]` 可以通过 `Object.getPrototypeOf()` 和 `Object.setPrototypeOf()` 访问器来访问
        * 等同于 JavaScript 的非标准但许多浏览器实现的属性  `__proto__` 
        * 不能与构造函数 `func` 的  `prototype` 属性相混淆
            * 被构造函数创建的实例对象的  `[[Prototype]]` 指向 `func` 的 `prototype` 属性
            * `Object.prototype` 属性表示 `Object` 的原型对象
        * 除内置  `getter` 或  `setter` 属性外，给对象设置属性会创建自有属性
* 继承方法
    * JavaScript 没有其他基于类的语言所定义的“方法”
    * JavaScript 任何函数都可以添加到对象上作为对象的属性
    * 函数继承与属性继承没有差别，包括“属性遮蔽”，即属性可被重写
    * 当继承函数被调用时， `this` 指向的是当前继承对象，而不是继承函数所在原型对象

### 什么是作用域 ？
作用域即代码中的变量、函数和对象的作用范围，变量、函数和对象只在这个范围内有效，可以被访问，超出范围失效或不可见

作用域可以提高程序逻辑的局部性、增强可靠性，减少命名冲突

ES6 之前，JavaScript 有：

* 全局作用域
    * 最外层变量、函数和对象拥有全局作用域
    * 全局对象，例如 global，window 等拥有全局作用域
    * ES5 以下及 ES5 非严格模式，函数内未定义的变量，自动挂载在全局对象下，拥有全局作用域
* 函数作用域
    * 函数内部的变量、函数和对象拥有函数作用域，仅在函数内部可以被访问
    使用  `var` 声明的变量和函数，如果不在作用域顶部，会进行变量提升，初始值为  `undefined` 

使用  `function` 声明的函数，如果不再作用域顶部，会进行函数提升，函数声明及函数体都会提升到顶部

ES6 及之后，JavaScript 增加：

* 块级作用域，即花括号包裹的内部
使用  `let`  及  `const` 声明的变量和函数，不会变量提升，存在暂时性死区，即不能不声明直接使用，仅在块级作用域下可用，同一作用域下，不可重复声明

作用域链：

外层作用域不可访问内层作用域，内层作用域可以访问外层作用域

如果内层作用域使用的变量、函数、对象在内层和外层作用域都找不到，会继续向外层作用域的更外层作用域寻找，直到找到或到最外层为止，这便是作用域链。


## 模块化


### webpack 中 loader 和 plugin  的区别？
## loader
* 在打包前或期间调用
* 根据不同匹配条件处理资源
* 调用顺序与书写顺序相反
* 写在前面的接收写在后面的返回值作为输入值
## plugin
* 基于 `Tapable` 实现
* 事件触发调用，监听 webpack 广播的事件
* 不同生命周期改变输出结果

### 如何自定义一个 webpack 插件？
* 声明一个自定义命名的类或函数
* 在原型中新增 `apply` 方法
* 声明由 `Compiler` 模块暴露的生命周期函数
* 使用 webpack 提供的 API 或 自行处理内部实例的数据
* 处理完成后，调用 webpack 提供的回调函数

示例：

实现一个 MyPlugin，获取指定图片，新增静态资源到本地

```JavaScript []
class MyPlugin { // 声明类
	apply(compiler) { // 新增 apply 方法
		// 声明生命周期函数
		compiler.hooks.additionalAssets.tapAsync('MyPlugin', (compilation, callback) => {
			download('https://img.shields.io/npm/v/webpack.svg', res => {
				if (res.status === 200) {
					// 调用 API
					compilation.assets['webpack-version.svg'] = toAsset(res)
					// 异步处理后，调用回调函数
					callback()
				} else {
					callback(new Error('[webpack-example-plugin] Unable to download the image'))
				}
			})
		})
	}
}
```

### 对比 import、import() 和 requrie
|    |import|import()|require|
|:----|:----|:----|:----|
|规范|ES6Module|ES6Module|CommonJS|
|执行阶段|静态 编译阶段|动态 执行阶段|动态 执行阶段|
|顺序|置顶最先|异步|同步|
|缓存|√|√|√|
|默认导出|default|default|直接赋值|
|导入赋值|解构赋值，传递引用|在then方法中解构赋值，属性值是仅可读，不可修改|基础类型 赋值，引用类型 浅拷贝|

### 如何实现一个深拷贝，要点是什么？
## JSON
* 不支持 Symbol，BigInt，Function
* 不支持 循环引用
* 丢失值为 undefined 的键

```JavaScript []
function deepCopy(o) {
	return JSON.parse(JSON.stringify(o))
}
```

## 递归
* 递归处理 引用类型
* 保持数组类型

```JavaScript []
function deepCopy(target) {
	if (typeof target === 'object') {
		const newTarget = Array.isArray(target) ? [] : Object.create(null)
		for (const key in target) {
			newTarget[key] = deepCopy(target[key])
		}
		return newTarget
	} else {
		return target
	}
}
```

## 递归
* 哈希表 Map  支持 循环引用
    * Map 支持引用类型数据作为键

```JavaScript []
function deepCopy(target, h = new Map) {
	if (typeof target === 'object') {
		if (h.has(target)) return h.get(target)
		const newTarget = Array.isArray(target) ? [] : Object.create(null)
		for (const key in target) {
			newTarget[key] = deepCopy(target[key], h)
		}
		h.set(target, newTarget)
		return newTarget
	} else {
		return target
	}
}
```

## 递归
* 哈希表 WeakMap 代替 Map
    * WeakMap 的键是弱引用，告诉 JS 垃圾回收机制，当键回收时，对应 WeakMap 也可以回收，更适合大量数据深拷贝

```JavaScript []
function deepCopy(target, h = new WeakMap) {
    if (typeof target === 'object') {
      if (h.has(target)) return h.get(target)
      const newTarget = Array.isArray(target) ? [] : Object.create(null)
      for (const key in target) {
        newTarget[key] = deepCopy(target[key], h)
      }
      h.set(target, newTarget)
      return newTarget
    } else {
      return target
    }
}
```

## 可以继续完善点
* 递归 改 迭代，预防 栈溢出
* 支持 null 、Symbol、BigInt、布尔对象、正则对象、Date对象等 深拷贝
* 使用 while / for 代替遍历数组，使用 Object.keys() 代替遍历对象

### 0.1 + 0.2 !== 0.3 的原因，如何解决？
* 计算机采用二进制表示十进制
    * 将十进制的 0.1 转为二进制

```plain
0.1 * 2 = 0.2 0
0.2 * 2 = 0.4 0
0.4 * 2 = 0.8 0
0.8 * 2 = 1.6 1
0.6 * 2 = 1.2 1
0.2 * 2 = 0.4 0
...
```

用科学计数法表示：2 ^ -4  * 1.10011(0011)
* 将十进制的 0.2 转为二进制

```plain
0.2 * 2 = 0.4 0
0.4 * 2 = 0.8 0
0.8 * 2 = 1.6 1
0.6 * 2 = 1.2 1
0.2 * 2 = 0.4 0
...
```

用科学计数法表示：2 ^ -3 * 1.10011(0011)
* JS 采用 IEEE 754 双精度版本（64位）
    * 64位 = 符号位（1位） + 整数（11位） + 小数（52位）
    * 小数超出 52位，四舍五入
        * 0.1：2 ^ -4 * 1.10011(0011 * 12)01
        * 0.2：2 ^ -3 * 1.10011(0011 * 12)010
        * 0.1 + 0.2：2 ^ -3 后面部分相加

```plain
0.1100110011001100110011001100110011001100110011001101
+  1.1001100110011001100110011001100110011001100110011010
—————————————————————————————————————————————————————————
= 10.0110011001100110011001100110011001100110011001100111
```

* 超出52位，四舍五入：2 ^ -2 * 1.0011(0011 * 12)01
* 转换为十进制：2 ^ -2 + 2 ^ -5 + 2 ^ -6 + 2 ^ -9 + 2 ^ -10 + 2 ^ -13 + 2 ^ -14 + ... + 2 ^ -49 + 2 ^ -50 + 2 ^ -52

```JavaScript []
let q = -2, sum = 2 ** -2
while ((q -= 3) >= -50) sum += 2 ** q + 2 ** --q
sum += 2 ** -52 // 0.30000000000000004
```

* 2 ^ -2 * 1.0011(0011 * 12)01 = 0.30000000000000004 > 0.3
* 如何解决 0.1 + 0.2 !== 0.3 ？
    * Number.EPSILON
        * 表示 1 与 Number 间可表示的大于 1 的最小的浮点数之间的差值
        * 接近于 Math.max(2, -52)，Number.EPSILON !== Math.max(2, -52)

```JavaScript []
const equal = (a, b, c) => {
	return Math.abs(c - a - b) < Number.EPSILON
}
```

* toFixed(digits) digits 属于 0 到 20 间，默认 0，实际支持更大范围
    * 使用定点表示法来格式化一个数值，返回给定数字的字符串
```JavaScript []
const equal = (a, b, c) => {// 产生 0.1 + 0.2 === 0.333 结果
return (a + b).toFixed(1) === c.toFixed(1)
}
```
* 小数转整数运算

```JavaScript []
const sum = (a, b) => {
	const len = Math.max((a + '').split('.')[1].length, (b + '').split('.')[1].length)
	return (a * len + b * len) / len
}
```

使用`bignumber.js`、`bigdecimal.js` 等 JS 库


## 正则表达式


### 实现 trim ，去除首尾空格
## 方法一：ES5

```JavaScript []
''.trim()
```

## 方法二：正则

```JavaScript []
''.replace(/^\s+|\s+$/g, '')
```

### 匹配查询字符串
```JavaScript []
/**
 * 获取指定的 querystring 中指定 name 的 value
 * @param {String} name 查询名
 * @param {String} querystring 查询到的值
 * @return {String|undefined} 查询到返回String，没有返回undefined
 */
function query (name, querystring) {
  if (name && name.match(/(?:http[s]?:|^)\/{2}.*?(?:\.)/)) name = encodeURIComponent(name) // 仅编码Url
  const r = (querystring + '').match(new RegExp('(?:^|&)\\s*?' + name + '\\s*=\\s*(.*?)\\s*(?:&|$)')) 
  return r === null ? undefined : decodeURIComponent(r[1])
}
```


## 异步编程


### Promise 都有哪些静态方法
所有 Promise 的静态方法都返回 Promise 对象

`Promise.all(iterable)` 

* 接收可迭代对象
    * 可迭代对象包含非 Promise 值，值将被忽略并放入返回数组
    * 可迭代对象为空，同步返回已完成 `resolved` 状态的 Promise 
* 其中所有 Promise 对象都成功才会触发成功
    * 返回 Promise 状态异步地变成完成，并传入返回数组
* 任何一个 Promise 对象失败立即触发失败
    * 返回 Promise 状态异步地变成拒绝，返回失败原因，不管其它 Promise 是否完成
     `Promise.allSettled(iterable)` 

* 接收可迭代对象
* 其中所有 Promise 对象都已经完成或拒绝返回结果
    * 返回 Promise 结果数组，每个对象对应一个 Promise 结果
        * `status` 为 `fulfilled` ，结果在 `value` 
        * `status` 为  `rejected` ，拒绝原因在  `reason` 
         `Promise.any(iterable)` 

* 接收可迭代对象
    * 可迭代对象为空，同步返回已失败 `rejected` 状态的 Promise
    * 可迭代对象不包含任何  Promise ，返回一个异步完成的 Promise
* 只要传入的迭代对象中的任何一个 Promise 变成成功状态
    * 返回 Promise 异步地变成成功状态
* 所有的 Promise 都失败
    * 返回 Promise 状态异步地变成拒绝，返回 AggregateError 对象，失败原因在`errors` 
     `Promise.race(iterable)` 

* 接收可迭代对象
    * 可迭代对象为空，返回永远  `pending` 状态的 Promise
    * 可迭代对象包含非 Promise 或已完成或拒绝的 Promise，返回迭代中找到的第一个值
     `Promise.reject(reason)` 

* 接收拒绝原因
* 返回一个被拒绝状态的 Promise
 `Promise.resolve(value)` 

* 接收被 Promise 对象解析的参数，类型不限
* 返回一个被传入值解析过的 Promise 对象
 `Promise.finally()` 

* 接收 Promise 结束后调用的 Function
* 返回一个设置了`finally` 回调函数的 Promise 对象

### 如何终止Promise
## Promises / A+ 标准
- 原 Promise 对象的状态与新对象保持一致
- 返回一个`pending`状态的 Promise 对象，后续的函数都不会调用
## Promise.race 竞速
- 其中一个 Promise 先到达`resolve`状态，其他 Promise 不会执行
## 抛出错误
- 其中一个 Promise 抛出一个错误后，错误信息将沿着 链路 向后传递，直至被捕获
- 错误被捕获前的函数不会被调用

### async/await 的错误捕获
* try catch
    * await 函数外，包裹 try {}，当 catch (error) 时，捕获错误
* catch
    * async 函数返回的 Promise，调用 then 方法，然后 catch(error)
* 错误优先原则

```JavaScript []
function async get(data) {
  return new Promise((resolve, reject) => {
    setTimeout(() => data ? resolve('res') : reject('error'), 1000)
  })
}2. 
function done (data) {
  return get(data).then(res => [null, res]).catch(err => [err, null])
}
[error, res] = await done()
```

### 手写 Promise
```JavaScript []
const PENDING = 'pending'
const RESOLVED = 'resolved'
const REJECTED = 'rejected'
function Promise(callback) {
  this.state = PENDING
  this.value = null
  this.resolvedCallbacks = []
  this.rejectedCallbacks = []
  
  callback(value => {
    if (this.state === PENDING) {
      this.state = RESOLVED
      this.value = value
      this.resolvedCallbacks.map(callback => callback(value))
    }
  }, value => {
    if (this.state === PENDING) {
      this.state = REJECTED
      this.value = value
      this.rejectedCallbacks.map(callback => callback(value))
    }
  })
}
Promise.prototype.then = function (onFulfilled = () => {}, onRejected = () => {}) {
  if (this.state === PENDING) {
    this.resolvedCallbacks.push(onFulfilled)
    this.rejectedCallbacks.push(onRejected)
  }
  if (this.state === RESOLVED) {
    onFulfilled(this.value)
  }
  if (this.state === REJECTED) {
    onRejected(this.value)
  }
}
```

### 实现异步请求的方式
AJAX - Asynchronous JavaScript and XML

```javascript
const xhr = new XMLHttpRequest()
xhr.open('GET', 'https://leetcode-cn.com', true)
xhr.responeseType = 'json'
xhr.onreadystatechange = function() {
  if (xhr.readyState === 4 && xhr.status === 200) {
    console.log(xhr.response)
  }
}
xhr.ontimeout = function() {
  console.log('超时')
}
xhr.setRequestHeader('Content-Type', 'application/json')
xhr.send({ requestBody: 1 })
```

$.ajax

```javascript
$.ajax({
  url: 'https://leetcode-cn.com',
  data: {
    requestBody: 1
  },
  suceess(data) {
    console.log(data)
  }
}).done(data) { // jQuery 1.5+ 支持
  console.log(data)
}
```

Axios

```javascript
axios({
  url: 'https://leetcode-cn.com',
  data: {
    requestBody: 1
  }
}).then(data => console.log(data))
```

Fetch

```javascript
fetch('https://leetcode-cn.com', {
  requestBody: 1
}).then(res => res.json()).then(res => res)
```

### async / await 的原理是什么？
`async` 是自带自动执行器的 Generator 迭代器函数的语法糖和改进，与`await`关键字一起让我们可以用一种更简洁的方式写出基于 `Promise`的异步行为，而无需刻意地链式调用`promise` 

基于`Promise`和`generator`实现`async`:

```javascript
const fn = async () => {}
// 等价于
const fn = () => autoRun(function* () {})
// autoRun 是 Generator 迭代器函数的自动执行器，其实现如下
const autoRun= generator => new Promise((resolve, reject) => {
  const gen = generator()
  const step = nextFn => {
    let next
    try {
      next = nextFn()
    } catch (e) {
      return reject(e)
    }
    if (next.done) return resolve(next.value)
    Promise.resolve(next.value).then(
      v => step(() => gen.next(v)),
      e => step(() => gen.throw(e))
    )
  }
  step(() => gen.next(undefined))
})
```
调用：
```javascript
const fn = () => autoRun(function * () {
	const result = yield new Promise(resolve => setTimeout(() => resolve(1), 1000))
	console.log(result)
})
```
结果：
![image.png](https://pic.leetcode-cn.com/1642579538-CyIZVu-image.png)

### 如何顺序或并发执行 async / await ？
```javascript
function log(n) {
  console.log(n + ':' + new Date().toLoaleString())
}
function a() {
  return new Promise((resolve ,reject) => {
    setTimeout(() => {
      log('a')
      resolve('a')
    }, 1000)
  })
}
function b() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      log('b')
      resolve('b')
    }, 1000)
  })
}
```
* 顺序执行 async / await
    * 顺序书写
```javascript
(async () => {
  console.log(await a())
  console.log(await b())
})()
```
    * 循环调用
```javascript
(async () => {
  const q = [a, b]
  for (const f of q) console.log(await f())
})()
```
* 并行执行 async / await
    * `Promise.all` 
```javascript
(async () => {
  const [x, y] = await Promise.all([a(), b()])
  console.log(x)
  console.log(y)
})()
```
    * 先调用获得 Promise 顺序书写
```javascript
(async () => {
  const [x, y] = [a(), b()]
  console.log(await x)
  console.log(await y)
})()
```
    * 先调用获得 Promise 循环输出结果
```javascript
(async () => {
  const q = [a(), b()]
  for (const f of q) console.log(await f)
})()
```
    * 先调用获得 Promise forEach 输出结果
```javascript
(async () => {
  [a(), b()].forEach(async f => console.log(await f))
})
```

### 如何实现大文件断点续传？
* 大文件上传
    * 用 Blob.prototype.slice 将文件分成多个切片，并发上传
    * 所有切片上传完成，发送合并请求，通知服务端合并切片
    * 服务端接收并存储切片，接收合并请求，合并切片为原始文件类型
    * 上传进度 = 已上传切片数 / 总切片数 + 当前已上传切片大小 /  总切片大小 * （100 / 总切片数）
* 断点续传
    * 用 spark-md5 计算文件内容 hash
    * 通过 hash 查找文件，文件已存储，秒传。反之查找切片数，跳过已上传的切片


## 性能


### JavaScript 垃圾回收机制
* 内存分配回收是自动的，垃圾回收器定时找出不再使用的数据，释放内存空间
## 两种回收检测模式
### 引用计数：
清除没有任何引用指向的数据。无法处理循环引用。IE6使用
### 标记清除：
标记可达数据，清除不可达数据。可处理循环引用。现代浏览器广泛使用
* 从根出发：包括 全局变量、本地函数的局部变量、参数、调用链上其它函数的局部变量和函数等
* 标记相连的对象为可达和访问过
* 直到引用链上没有未访问过的对象为止
* 删除没有被标记过，即不可达对象
#### 标记清除的优化：
标记清除存在 内存不连续，回收效率低，偶尔卡顿 的缺点
* 只在CPU空间时进行
* 分代回收：
    * 新生代：存活时间短，新生或经过一次垃圾回收的对象
        * 复制：复制 From 的可达对象 到 To 空间，释放 不可达对象
            * 晋升：复制时，To 空间使用超过 25%，晋升到 老生代
        * 交换：交换 From 和 To 空间
    * 老生代：存活时间长，经过一次被晋升或多次垃圾回收的对象
        * 标记清除
        * 标记整理：清除阶段先整理，将可达对象连续放置一起，再释放之外的内存
        * 增量标记：用增量标记代替全暂停，在回收间歇执行应用逻辑，避免卡顿

### 详解标记整理算法
* 标记完成
* 存活对象向内存空间一端移动
* 移动完成，清理掉边界外的所有内存

### 前端常见的内存溢出途径，如何避免？
占用内存且无法被垃圾回收机制回收对象，容易导致内存溢出（泄漏），让应用程序占用本应回收或不需要占用的内存

## 意外的全局变量：
全局变量是标记清除中的「根」，除非定义为空 或 重新分配，不可回收
* 非严格模式下，没有使用 var let const 声明的变量
* 挂载在 this 下的属性

**避免**：尽量不使用全局变量，在 JavaScript 头部使用严格模式

## 未清除的计时器
* setInterval 自身及其回调函数内的对象，即使不被引用，也需要计时器停止才能清除

**避免**：使用 requestAnimationFrame / setTimeout +递归 代替 setInterval，并设置边界

## 删除不完全的对象
* addEventListener 监听的对象已不可达，但监听没有移除。现代浏览器会自动移除
* JS 中引用了 DOM 对象，对象已从 DOM Tree 中移除，但 JS 中依旧保持引用

**避免**：

* 移除对象前，移除监听。需大量监听对象，使用事件代理监听父元素
* 移除 DOM 后，设置引用该 DOM 的变量为空
## 闭包中未使用函数引用了可从根访问的父级变量

```JavaScript []
var global = 0
function closure () {
	let fromGlobal = global // 引用全局变量 global
	function unused () { // 闭包内不使用的函数
		if (fromGlobal) return // 引用父级变量 fromGlobal，导致 unused 占用内存
	}
	global = {} // 每次调用闭包 global 都会重新赋值
	/** 避免 **/
	fromGlobal = null
	closure()
}
```



# 阶段测Ⅰ
本章阶段测针对第一章 Javascript 的知识点进行测试。

## 简答题
<!DOCTYPE html>
<html>
<head>
<style>
label:hover   {color: #3172cc;}
.nav-con{display: none;}
.nav-box{display: none;}
.nav-con:checked ~ .nav-box{display: block;}
.nav-btn{font-size:16px; font-weight: bold;}
</style>
</head>
<body>

<p>1. encodeURI 对 URL 编码哪些字符会被编码？</p>
<label for="control7" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control7" class="nav-con">
    <p class="nav-box">  
	ASCII 字母、数字 @ * / + 和 ~ ! # $ & () =, ; ?- _ . '之外的字符都被编码
    </p>
</div>

<p>2. 请列举几个常见宏任务。</p>
<label for="control8" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control8" class="nav-con">
    <p class="nav-box">  
	setTimeout、setInterval、setImmediate、I/O、script、UI rendering
    </p>
</div>

<p>3. 请列举几个常见微任务。</p>
<label for="control9" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control9" class="nav-con">
    <p class="nav-box">  
	• 浏览器：Promise、MutationObserver <br>
	• Node.js：process.nextTick
   </p>
</div>

<p>4. 请简述一下 Event Loop 的执行顺序？</p>
<label for="control10" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control10" class="nav-con">
    <p class="nav-box">  
	• 首先执行同步代码，宏任务 <br>
	• 同步栈为空，查询是否有异步代码需要执行 <br>
	• 执行所有微任务 <br>
	• 执行完，是否需要渲染页面 <br>
	• 重新开始 Event Loop，执行宏任务中的异步代码
    </p>
</div>

<p>5. 什么是闭包？</p>
<label for="control11" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control11" class="nav-con">
    <p class="nav-box">  
	一个函数和对其周围状态（词法环境）的引用捆绑在一起（或者说函数被引用包围），这样的组合就是闭包
    </p>
</div>

<p>6. 什么是词法？</p>
<label for="control12" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control12" class="nav-con">
    <p class="nav-box">  
	英文 lexical ，词法作用域根据源代码声明变量的位置来确定变量在何处可用
    </p>
</div>

<p>7. 柯里化（curry）是什么？</p>
<label for="control13" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control13" class="nav-con">
    <p class="nav-box">  
	使函数理解并处理部分应用的过程
    </p>
</div>

<p>8. 请简述手写 call 的过程。</p>
<label for="control14" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control14" class="nav-con">
    <p class="nav-box">  
	• 第一参数接收 this 对象 <br>
	• 改变 this 指向：将函数作为传入 this 对象的方法 <br>
	• 展开语法，支持传入和调用参数列表 <br>
	• 调用并删除方法，返回结果
    </p>
</div>

<p>9. 请简述手写 apply 的过程。</p>
<label for="control15" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control15" class="nav-con">
    <p class="nav-box">  
	• 第一参数接收 this 对象 <br>
	• 改变 this 指向：将函数作为传入 this 对象的方法 <br>
	• 第二个参数默认数组 <br>
	• 展开语法，支持调用参数列表 <br>
	• 调用并删除方法，返回结果
    </p>
</div>

<p>10. 请简述手写 new 的过程。</p>
<label for="control16" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control16" class="nav-con">
    <p class="nav-box">  
	• 第一参数作为构造函数，其余参数作为构造函数参数  <br>
	• 继承构造函数原型创建新对象  <br>
	• 执行构造函数  <br>
	• 结果为对象，返回结果，反之，返回新对象
    </p>
</div>

<p>11. 请简述一下原型链继承的好处</p>
<label for="control17" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control17" class="nav-con">
    <p class="nav-box">  
	子类可以访问到父类新增原型方法和属性
    </p>
</div>

<p>12. 请简述一下构造函数的坏处。</p>
<label for="control18" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control18" class="nav-con">
    <p class="nav-box">  
	• 实例并不是父类的实例，只是子类的实例  <br>
	• 不能继承父类原型上的方法
    </p>
</div>

<p>13. 请简述一下对象继承的坏处</p>
<label for="control19" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control19" class="nav-con">
    <p class="nav-box">  
	• 创建实例无法传递参数 <br>
	• 传入对象的属性有引用类型，所有类型都会共享相应的值
    </p>
</div>


<p>14. 简述一下基于原型链的继承方法</p>
<label for="control20" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control20" class="nav-con">
    <p class="nav-box">  
	• JavaScript 没有其他基于类的语言所定义的“方法” <br>
	• JavaScript 任何函数都可以添加到对象上作为对象的属性 <br>
	• 函数继承与属性继承没有差别，包括“属性遮蔽”，即属性可被重写 <br>
	• 当继承函数被调用时， this 指向的是当前继承对象，而不是继承函数所在原型对象
    </p>
</div>

<p>15. 什么是作用域？</p>
<label for="control21" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control21" class="nav-con">
    <p class="nav-box">  
	作用域即代码中的变量、函数和对象的作用范围，变量、函数和对象只在这个范围内有效，可以被访问，超出范围失效或不可见
    </p>
</div>

<p>16. 简述一下自定义一个 webpack 插件的过程。</p>
<label for="control22" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control22" class="nav-con">
    <p class="nav-box">  
	• 声明一个自定义命名的类或函数 <br>
	• 在原型中新增 apply 方法 <br>
	• 声明由 Compiler 模块暴露的生命周期函数 <br>
	• 使用 webpack 提供的 API 或 自行处理内部实例的数据 <br>
	• 处理完成后，调用 webpack 提供的回调函数
    </p>
</div>

<p>17. 简述以下 Promise.race 竞速如何终止 Promise？</p>
<label for="control23" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control23" class="nav-con">
    <p class="nav-box">  
	其中一个 Promise 先到达resolve状态，其他 Promise 不会执行
    </p>
</div>

<p>18. 如何实现大文件上传？</p>
<label for="control24" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control24" class="nav-con">
    <p class="nav-box">  
	• 用 Blob.prototype.slice 将文件分成多个切片，并发上传 <br>
	• 所有切片上传完成，发送合并请求，通知服务端合并切片 <br>
	• 服务端接收并存储切片，接收合并请求，合并切片为原始文件类型 <br>
	• 上传进度 = 已上传切片数 / 总切片数 + 当前已上传切片大小 / 总切片大小 * （100 / 总切片数）
    </p>
</div>

<p>19. 两种回收检测模式分别是哪两种？</p>
<label for="control25" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control25" class="nav-con">
    <p class="nav-box">  
	引用计数和标记清除
    </p>
</div>

<p>20. 前端常见的内存溢出途径有哪些？</p>
<label for="control26" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control26" class="nav-con">
    <p class="nav-box">  
	意外的全局变量、未清除的计时器、删除不完全的对象、闭包中未使用函数引用了可从根访问的父级变量
    </p>
</div>

</body>
</html>

## 选择题
x5l233x5ip8mx5ueu1x5txi7x5tjl5x58y06


# Canvas 绘图


## 什么是 Canvas ?
Canvas 是 HTML5 新增元素，它允许 JavaScript 脚本语言动态渲染位图像。常用于动画、游戏画面、数据可视化、图片编辑和实时视频处理等

Canvas 包括

* HTML 的 `<canvas>` 标签
* 操作  `<canvas>` 元素的 API
    * Canvas API
        * `HTMLCanvasElement.getContext('2d')` 建立  `CanvasRenderingContext2D` 二维渲染上下文
    * WebGL API
        * `HTMLCanvasElement.getContext('webgl')` 建立  `WebGLRenderingContext` 三维渲染上下文
        * `HTMLCanvasElement.getContext('webgl2')` 建立  `WebGL2RenderingContext` 三维渲染上下文
    * ImageBitmapRendering API
        * `HTMLCanvasElement.getContext('bitmaprenderer')` 建立  `ImageBitmapRenderingContext` 将 canvas 内容转为 ImageBitmap
* 其它 HTMLCanvasElement API
    * 属性
        * `width` 宽度，默认值 300
        * `height` 高度，默认值 150
    * 方法
        * `toDataURL()` 将 canvas 转成指定格式的 base64 编码图像
        * `toBlob()` 将 canvas 转成指定格式的图像文件对象

## 使用标签属性和 CSS 设置 Canvas 的宽和高有什么不同 ？
`<canvas>` 元素自身存在  `width` 和  `height` 属性。作为可替换元素，其默认宽度为 300 像素，高度为 150 像素

 `<canvas>` 同样支持内联  `style` 属性，或者在 CSS 中定义  `width` 和  `height` 

两者区别如下：

* 设置尺寸不同
    * 标签属性设置的是 Canvas 本身的宽度和高度，相当于图片的原始宽度和高度
        * `<img>` 
            * 读取图片原始宽度和高度前，会使用  `width` 和  `height` 属性计算宽高比占位
            * 读取图片原始宽度和高度后，会修正宽高比
        *  `<canvas>` 的宽度和高度从  `width` 和  `height` 读取，未设置使用默认值
        如图所示：在只设置  `height` 的情况下，图片和  `<canvas>` 都保持了原始比例，图片并没有遵守  `width` 和  `height` 的设置值，而是读取的原始宽度和高度 

```xml
<img src="cat.jpg" width="300px" height="150px" style="height:100px">
<canvas width="300" height="150" style="background:pink;height:100px"></canvas>
```
![image.png](https://pic.leetcode-cn.com/1642573051-vKIKRk-image.png)
    * CSS 属性设置的是 Canvas 的渲染宽度和高度，与 Canvas 本身的宽度和高度不同时，会缩放以适应渲染宽度和高度
        * 自适应和响应式设计时，只更改 CSS 宽度，会影响 Canvas 的清晰度。需要让 Canvas 本身的宽度同样跟随浏览器可视区域宽度变化
* 支持单位不同
    * 标签属性的单位为像素（px），不传或其它单位都将按像素设置
    * CSS 属性支持
        * 绝对长度单位，如：厘米（cm），毫米（mm），四分之一毫米（Q），英寸（in），十二点活字（pc），点（pt），像素（px）
        * 相对长度单位，如：相对于父元素字体大小（em），相对于字符 `x` 高度（ex），相对于数字  `0` 宽度（ch），相对于根元素的字体大小（rem），相对于元素的行高（lh），相对于视窗宽度的 1%（vw），相对于视窗高度的 1%（vh），相对于视窗较小尺寸的 1%（vmin），相对于视窗较大尺寸的 1%（vmax）
* 默认值不同
    * 标签属性的宽度默认值为 300，高度默认值为 150
    * CSS 属性的宽度默认值为 auto，高度默认值为 auto，即由浏览器计算并选择值，通常是  `<cavas>` 的标签属性值
* 对负值的处理不同
    * 标签属性的宽度和高度中的负值，现代浏览器会被重置为默认值，IE 会重制为 0
    * CSS 属性的宽度和高度中的负值，将被作为无效属性值舍弃，等同于默认值  `auto`

## 什么是渲染上下文 ？
渲染上下文，即 RenderingContext 是一个辅助类型，它通过使用 `<canvas>` 标签创建的元素  `HTMLCanvasElement.getContext()` 方法返回，用于绘图，共有四种类型，分别对应 `getContext(contextType)` 的四种  `contextType` ：

* `2d`返回 `CanvasRenderingContext2D` 二维渲染上下文，用于绘制形状、文本、图像等对象
* `webgl` 返回  `WebGLRenderingContext` 三维渲染上下文，在实现基于 OpenGL ES 2.0 的 WebGL 1.0 浏览器实现 3D 硬件加速渲染
* `webgl2` 返回  `WebGL2RenderingContext` 三维渲染上下文，在实现基于 OpenGL ES 3.0 的 WebGL 2.0 浏览器实现 3D 硬件加速渲染
*  `bitmaprenderer` 返回  `ImageBitmapRenderingContext` 渲染上下文，提供方法  `transferFromImageBitmap()` 使用指定 `ImageBitmap` 替换  `canvas`

## Canvas 画布的起点在哪里 ？
Canvas 画布的坐标系与网页坐标系一致，原点即起点为  `<canvas>` 标签的左上角， `x` 轴向右为正值，向左为负值。  `y` 轴向下为正值，向上为负值
![image.png](https://pic.leetcode-cn.com/1642573230-pHdPDe-image.png)

## 如何绘制矩形 ？
Canvas API 的 CanvasRenderingContext2D 提供了 `3` 种方法绘制矩形

* fillRect(x, y, width, height) 填充矩形，起始点`(x, y)` ，宽为`width` 高为`height` ，填充样式由  `fillStyle` 设置
* clearRect(x, y, width, height) 擦出矩形，起始点`(x, y)` ，宽为`width` 高为`height` ，该区域的像素会被设置为  `rgba(0, 0, 0, 0)` 
* strokeRect(x, y, width, height) 描边矩形，起始点`(x, y)` ，宽为`width` 高为`height`
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillRect(0, 0, 100, 100)
ctx.clearRect(10, 10, 80, 80)
ctx.strokeRect(20, 20, 60, 60)
```
![image.png](https://pic.leetcode-cn.com/1642573313-LkYHso-image.png)

## 如何绘制直线路径 ？
Canvas API 的 CanvasRenderingContext2D 提供了 `2` 种方法绘制直线路径

* moveTo(x, y) 新建路径的起点为  `(x, y)` 
* lineTo(x, y) 使用直线连接子路径的终点到  `(x, y)` ，使用  `stroke` 按非零环绕规则，根据当前的画线样式，绘制已经存在的路径
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.moveTo(0, 0)
ctx.lineTo(300, 0)
ctx.moveTo(300, 100)
ctx.lineTo(0, 100)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642573366-OMzrPI-image.png)

## 如何绘制圆 ？
Canvas API 的 CanvasRenderingContext2D 提供了 `5`  种方法绘制圆弧

* arc(x, y, radius, startAngle, endAngle, anticlockwise) 新建圆心为  `(x, y)` 半径为  `radius` 。从 x 轴开始，起始角度为  `startAngle` 终止角度为  `endAngle` ，沿  `anticlockwise` 方向（ `true` 为逆时针， `false` 为顺时针）绘制圆弧路径
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.arc(100, 100, 100, 0, 2 * Math.PI, true)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642573416-EzMQvL-image.png)

* arcTo(x1, y1, x2, y2, radius) 当前位置为起始点，根据控制点  `(x1, y1)` 和  `(x2, y2)` 半径为  `radius` 绘制圆弧
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.moveTo(0, 0)
ctx.arcTo(100, 0, 100, 100, 100)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642573454-UXylYu-image.png)

* ellipse(x, y, radiusX, radiusY, rotation, startAngle, endAngle, anticlockwise) 新建圆心为  `(x, y)` 长轴半径为  `radiusX` 短轴半径为  `radiusY` 从 x 轴开始，旋转角度为  `rotation` 起始角度为  `startAngle` 终止角度为  `endAngle` ，沿  `anticlockwise` 方向（ `true` 为逆时针， `false` 为顺时针）绘制椭圆路径
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.ellipse(100, 100, 100, 50, 0, 0, Math.PI * 2, true)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642573493-iRLetV-image.png)

*  quadraticCurveTo(x1, y1, x, y) 当前位置为起始点，`(x, y)` 为结束点，根据控制点`(x1, y1)` 绘制二次贝塞尔曲线
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.moveTo(0, 0)
ctx.quadraticCurveTo(100, 0, 100, 100)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642573522-aUFWty-image.png)

* bezierCurveTo(x1, y1, x2, y2, x, y) 当前位置为起始点， `(x, y)` 为结束点，根据控制点  `(x1, y1)` 和  `(x2, y2)` 绘制三次贝塞尔曲线
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.moveTo(0, 0)
ctx.bezierCurveTo(100, 0, 100, 100, 100, 100)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642573561-FfTkPB-image.png)

## 什么是 Path 2D 对象 ？
Path 2D 实例通过  `Path2D` 构造函数创建

* 可以在创建时，传入  `SVG Path data` （一系列绘制命令的简写），创建 SVG 路径
* Path 2D 实例，支持 CanvasRenderingContext2D 上的绘制方法，通过调用方法绘制的路径，会被记录在 Path 2D 实例中
    * 支持的方法包括： `moveTo`  `lineTo`  `rect`  `arc`  `arcTo`  `ellipse`  `quadraticCurveTo`  `bezierCurveTo`  `closePath` 
* 通过调用 CanvasRenderingContext2D 的  `stoke` 或  `fill` 方法传入 Path 2D 实例，可以描边或填充实例记录的路径，而不是当前路径
* 通过调用实例的  `addPath(path, [, transfrom])` 方法，可以将另一个 path 2D 实例合并到当前实例中，并可以应用矩阵变换

## 如何上色 ?
Canvas API 的 CanvasRenderingContext2D 提供了 `2` 种属性上色

* fillStyle 描述颜色和样式的属性，用于  `fill` `fillRect` 和  `fillText` 填充上色，值可以是以下类型：
    * CSS 数据类型`<color>` ：包括颜色关键字、RGB 立体坐标（ `#` + 十六进制  `rgb()` 和 `rgba()` ）、HSL 圆柱坐标（`hsl()` 和  `hsla()` ）
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.rect(0, 0, 100, 100)
ctx.fill()
```
![image.png](https://pic.leetcode-cn.com/1642574321-iDypNV-image.png)

* 描述渐变的不透明对象  `CanvasGradient` 通过以下两种方法创建
        * CanvasRenderingContext2D.createLinearGradient(x0, y0, x1, y1) 从起始点 `(x0, y0)` 到终止点  `(x1, y1)` 的直线渐变
            * addColorStop(offset, <color>) 指定从  `0` 到 `1` 偏移位置的颜色值 `<color>`
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
const gradient = ctx.createLinearGradient(0, 0, 100, 100)
gradient.addColorStop(0, 'skyblue') // 起始颜色是 skyblue
gradient.addColorStop(1, 'pink') // 终止颜色是 pink
ctx.fillStyle = gradient
ctx.rect(0, 0, 100, 100)
ctx.fill()
```
![image.png](https://pic.leetcode-cn.com/1642574350-XyXnmn-image.png)

CanvasRenderingContext2D.createRadialGradient(x0, y0, r0, x1, y1, r1) 从起始圆（圆心 (x0, y0) 半径 r0 ）到终止圆（圆心 (x1, y1) 半径  r1 ）的放射性渐变
            * addColorStop(offset, <color>) 指定从  `0` 到 `1` 偏移位置的颜色值 `<color>`
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
const gradient = ctx.createRadialGradient(50, 50, 15, 50, 50, 50)
gradient.addColorStop(0, 'skyblue')
gradient.addColorStop(1, 'pink') 
ctx.fillStyle = gradient
ctx.arc(50, 50, 50, 0, Math.PI * 2)
ctx.fill()
```
![image.png](https://pic.leetcode-cn.com/1642574385-YxdgZX-image.png)

* 描述模板的不透明对象  `CanvasPattern` ，通过以下方法创建
    * CanvasRenderingContext2D.createPattern(image, repetition) 设置重复元图像的来源对象 `image` ，包括`CSSImageValue` `HTMLCanvasElement` `HTMLImageElement`   `HTMLVideoElement` `ImageBitmap` `OffscreenCanvas`  `SVGImageElement` `VideoFrame` 等。按照 `repetition` 设置重复，包括 `repeat` 水平和垂直重复， `repeat-x` 仅水平重复， `repeat-y` 仅垂直重复， `no-repeat` 不重复等
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
canvas.width = canvas.height = 100 
ctx.arc(50, 50, 50, 0, Math.PI * 2) // 绘制一个直径为 100 的空心圆
ctx.stroke()
const pattern = ctx.createPattern(canvas, 'repeat') // 以原始画布为模板
canvas.width = canvas.height = 300 // 将画布宽高扩大 3 倍
ctx.fillStyle = pattern
ctx.rect(0, 0, 300, 300)
ctx.fill()
```
![image.png](https://pic.leetcode-cn.com/1642574468-DGwyFV-image.png)


* strokeStyle 用于描述颜色或样式的属性，用于 `stroke` `strokeRect` 和  `strokeText`  描边上色，值可以是以下类型：
    * CSS 数据类型`<color>` ：包括颜色关键字、RGB 立体坐标（ `#` + 十六进制  `rgb()` 和 `rgba()` ）、HSL 圆柱坐标（`hsl()` 和  `hsla()` ）
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.strokeStyle = 'skyblue'
ctx.rect(0, 0, 100, 100)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642574478-luszmy-image.png)

* 描述渐变的不透明对象  `CanvasGradient` 通过以下两种方法创建
    * CanvasRenderingContext2D.createLinearGradient(x0, y0, x1, y1) 从起始点 `(x0, y0)` 到终止点  `(x1, y1)` 的直线渐变
        * addColorStop(offset, <color>) 指定从  `0` 到 `1` 偏移位置的颜色值 `<color>`
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
const gradient = ctx.createLinearGradient(0, 0, 100, 100)
gradient.addColorStop(0, 'skyblue') // 起始颜色是 skyblue
gradient.addColorStop(1, 'pink') // 终止颜色是 pink
ctx.strokeStyle = gradient
ctx.rect(0, 0, 100, 100)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642574514-sBDIwD-image.png)

   * CanvasRenderingContext2D.createRadialGradient(x0, y0, r0, x1, y1, r1) 从起始圆（圆心 (x0, y0) 半径 r0 ）到终止圆（圆心 (x1, y1) 半径  r1 ）的放射性渐变
        * addColorStop(offset, <color>) 指定从  `0` 到 `1` 偏移位置的颜色值 `<color>`
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
const gradient = ctx.createRadialGradient(50, 50, 15, 50, 50, 50)
gradient.addColorStop(0, 'skyblue')
gradient.addColorStop(1, 'pink') 
ctx.strokeStyle = gradient
ctx.arc(50, 50, 15, 0, Math.PI * 2)
ctx.moveTo(100, 50)
ctx.arc(50, 50, 50, 0, Math.PI * 2)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642574561-uTyfiM-image.png)

* 描述模板的不透明对象  `CanvasPattern` ，通过以下方法创建
    * CanvasRenderingContext2D.createPattern(image, repetition) 设置重复元图像的来源对象 `image` ，包括`CSSImageValue` `HTMLCanvasElement` `HTMLImageElement`   `HTMLVideoElement` `ImageBitmap` `OffscreenCanvas`  `SVGImageElement` `VideoFram` 等。按照 `repetition` 设置重复，包括 `repeat` 水平和垂直重复， `repeat-x` 仅水平重复， `repeat-y` 仅垂直重复， `no-repeat` 不重复等
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
canvas.width = canvas.height = 1
ctx.fillStyle = 'skyblue'
ctx.rect(0, 0, 1, 1)
ctx.fill() // 绘制 1 个天蓝色像素点
const pattern = ctx.createPattern(canvas, 'repeat') // 以原始画布为模板
canvas.width = canvas.height = 100
ctx.strokeStyle = pattern
ctx.rect(0, 0, 100, 100)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642574587-tdBuMR-image.png)

## 如何设置透明度 ？
设置透明度有两种方法

* 使用 CSS 数据类型  `<color>` 中的  `rgba()` 和  `hsla()` ，最后一个参数  `alpha` 的范围从  `0` 到  `1` 表示不透明度， `0` 为完全透明， `1` 为完全不透明 
* 通过 CanvasRenderingContext2D.globalAlpha 属性设置，范围从  `0` 到  `1` 表示不透明度， `0` 为完全透明， `1` 为完全不透明 
示例

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'rgba(72, 201, 176, .5)' // 浅绿色，不透明度 0.5
ctx.fillRect(0, 0, 50, 50)
ctx.fillStyle = 'hsla(204, 70%, 63%, .5)' // 天蓝色，不透明度 0.5
ctx.fillRect(25, 25, 50, 50)
ctx.globalAlpha = 0.5 // 当前不透明度 0.5
ctx.fillStyle = 'pink'
ctx.fillRect(50, 50, 50, 50)
```
![image.png](https://pic.leetcode-cn.com/1642574782-DRzlCi-image.png)

## 线段末端端点有哪几种样式 ？
Canvas API 的 CanvasRenderingContext2D 提供 lineCap 属性来设置线条末端端点样式，可能值如下：

*  `butt` 线条末端端点以方形结束
*  `round` 线条末端端点以圆形结束，在 `butt` 的基础上，额外增加一个半径为 1/2 线条宽度的圆形
*  `square` 线条末端端点以方形结束，在 `butt` 的基础上，额外增加一个宽度与线条宽度相等，高度为 1/2 线条宽度的方形
示例

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.lineWidth = 1
ctx.moveTo(10, 5)
ctx.lineTo(10, 95)
ctx.moveTo(90, 5)
ctx.lineTo(90, 95)
ctx.stroke()
ctx.globalAlpha = 0.5
ctx.lineWidth = 10
ctx.beginPath()
ctx.lineCap = 'butt'
ctx.moveTo(10, 10)
ctx.lineTo(90, 10)
ctx.stroke()
ctx.beginPath()
ctx.lineCap = 'round'
ctx.moveTo(10, 50)
ctx.lineTo(90, 50)
ctx.stroke()
ctx.beginPath()
ctx.lineCap = 'square'
ctx.moveTo(10, 90)
ctx.lineTo(90, 90)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642574892-jnycpP-image.png)

## 如何设置线条宽度，如何解决线条被画布裁剪的问题 ？
Canvas API 的 CanvasRenderingContext2D 提供 lineWidth 属性来设置线条宽度

* 值可以是数字，非正数，无穷和 NaN 会被忽略
* 线条可以通过  `stroke()`  `strokeRect()`  `strokeText()` 绘制
* 宽度默认均匀地分布在路径两侧，这意味着位于路径外侧的部分可能会被裁剪掉
如何解决线条裁剪的问题

100 x 100 的方形画布，绘制一个圆心  `(50, 50)` 半径 50 的圆，线条宽度为 1 单位

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.arc(50, 50, 50, 0, Math.PI * 2)
ctx.lineWeight = 1
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642574828-hkHtNy-image.png)

由于线条的宽度在路径两侧均匀分布，即路径内侧 0.5 单位，路径外侧 0.5 单位，超出画布的部分被裁剪

于是，我们将路径，即园的半径向内收缩 0.5 单位，这样绘制出的线条刚好与原来路径吻合，从而不会被画布裁剪

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.arc(50, 50, 49.5, 0, Math.PI * 2)
ctx.lineWeight = 1
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642574851-stCzuG-image.png)

## 线段连接处有哪几种样式 ？
Canvas API 的 CanvasRenderingContext2D 提供 lineJoin 属性来设置 2 个长度不为 0 且方向不同的线段的相连部分的样式，可能值如下：

*  `round` 磨圆效果，增加一个半径为 1/2 线条宽度的扇形
*  `bevel` 斜切效果，增加一个以两线条外边缘端点连接线段为底的三角形
*  `miter` 斜接效果，延伸两线条的外边缘，使其相交，形成菱形
此外，还可以通过设置  `miterLimit` 斜接限定值，自动选用  `bevel` 或  `miter` 效果

* `miterLimit` 斜接限定值，默认值为  `10`，延伸长度与 1/2 线条宽度的最大允许比值
    * 大于此值：  `bevel` 斜切效果
    * 小于或等于此值： `miter` 斜接效果
    示例

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.moveTo(0, 90)
ctx.lineTo(100, 90)
ctx.stroke()
ctx.beginPath()
ctx.lineWidth = 10
ctx.globalAlpha = 0.5
ctx.lineJoin = 'miter' // 底部，从左向右，第 1 处连接采用 miter 效果
ctx.miterLimit = 10
ctx.moveTo(10, 10)
ctx.lineTo(20, 90)
ctx.lineTo(30, 10)
ctx.stroke()
ctx.beginPath()
ctx.miterLimit = 1 //第 2 处连接采用 miter 效果，缩小了 miterLimit 值，实际为 bavel 效果
ctx.moveTo(30, 10) 
ctx.lineTo(40, 90)
ctx.lineTo(50, 10)
ctx.stroke()
ctx.beginPath()
ctx.miterLimit = 10 // 第 3 处连接采用 bavel 效果，但恢复了 miterLimit 默认值，实际为 miter 效果
ctx.lineJoin = 'bavel' 
ctx.moveTo(50, 10)
ctx.lineTo(60, 90)
ctx.lineTo(70, 10)
ctx.stroke()
ctx.beginPath()
ctx.lineJoin = 'round' // 第 4 处为 round 效果
ctx.moveTo(70, 10)
ctx.lineTo(80, 90)
ctx.lineTo(90, 10)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642574980-CqDkcZ-image.png)

## 如何设置虚线 ？
Canvas API 的 CanvasRenderingContext2D 提供 1 个方法和 1 个属性来设置虚线

* setLineDash(segments) 描边线条时，使用  `segments` 定义的交替描述线段长度和间距的数组绘制虚线的方法。如果数组长度时奇数，将自动乘以  2
* lineDashOffset 设置虚线偏移量的属性，值为  `float` 数字，可以为正数、负数和 0
示例

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
const anime = () => {
  ctx.clearRect(0, 0, 100, 100)
  ctx.setLineDash([10, 5, 5, 5])
  ctx.lineDashOffset -= 1
  ctx.moveTo(0, 10)
  ctx.lineTo(100, 10)
  ctx.stroke()
  requestAnimationFrame(anime)
}
requestAnimationFrame(anime)
```
![image.png](https://pic.leetcode-cn.com/1642575165-cVDAXP-image.png)

## 如何设置阴影 ？
Canvas API 的 CanvasRenderingContext2D 提供 4 个属性来设置阴影

* shadowOffsetX 设定阴影在 X 轴的延伸距离， `float` 数字，默认值`0` 支持正数和负数
* shadowOffsetY 设定阴影在 Y 轴的延伸距离， `float` 数字，默认值`0` 支持正数和负数
* shadowBlur 设定阴影的模糊等级， `float` 数字，默认值  `0` 支持正数
* shadowColor 设定阴影的颜色，CSS 数据类型`<color>` ，默认值是完全透明的黑色
阴影绘制的条件

* shadowOffsetX shadowOffsetY 或 shadowBlur 有一个值不为 `0` 
* shadowColor 不为完全透明
示例

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.shadowOffsetX = 0
ctx.shadowOffsetY = 0
ctx.shadowBlur = 20
ctx.shadowColor = 'pink'
ctx.fillStyle = 'skyblue'
ctx.arc(50, 50, 30, 0, Math.PI * 2)
ctx.fill()
```
![image.png](https://pic.leetcode-cn.com/1642575210-GMkRha-image.png)

## Canvas 填充规则有哪些，区别是什么 ？
Canvas API 的 CanvasRenderingContext2D 使用  `2` 种 fillRule 填充规则，通过 isPointInPath 来判断点是否在路径内，还是路径外，并以此 fill 填充或 clip 裁剪路径

* nonzero 非零环绕规则，默认规则：指定点到无穷远处绘制一条任意方向的射线，计算射线穿过的给定路径的相交情况，顺时针相交，计数器 +1，逆时针相交，计数器 -1。最终值不为 0，点在路径里面，如果为 0，点在路径外面
* evenodd 奇偶环绕规则：指定点到无穷远处绘制一条任意方向的射线，计算射线穿过的给定形状的路径条数。如果该数是奇数，点在路径里面，如果是偶数，点在路径外面
示例

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.moveTo(50, 50)
ctx.lineTo(100, 50)
ctx.globalAlpha = 0.5
ctx.fillStyle = 'skyblue'
ctx.arc(50, 50, 49.5, 0, Math.PI*2, true) // 逆时针绘制外圆
ctx.arc(50, 50, 24.5, 0, Math.PI*2, true) // 逆时针绘制内圆
ctx.stroke()
```
使用 nonzero 非零环绕规则填充，从内圆圆心引出射线，分别与逆时针绘制的内圆和外圆相交，每次相交计数器 -1，最终值为 -2 不等于 0，内圆圆心所在区域，即内圆在路径内部，应被填充
```javascript
ctx.fill('nonzero') 
```
![image.png](https://pic.leetcode-cn.com/1642575255-DdJolC-image.png)

如果将内圆的绘制方向改为顺时针，射线与内圆相交，计数器 +1，与外圆相交，计数器 -1，最终值为 0，内圆圆心所在区域，即内圆在路径外部，不应被填充

```javascript
ctx.arc(50, 50, 24.5, 0, Math.PI*2, false) // 顺时针绘制内圆
ctx.stroke()
ctx.fill('nonzero') 
```
或者内圆的绘制方向保持不变（逆时针），使用 evenodd 奇偶环绕规则填充，射线分别与内圆和外圆相交，相交的路径数为 2，即偶数，内圆圆心所在区域，即内圆在路径外部，不应被填充
```javascript
ctx.fill('evenodd') 
```
![image.png](https://pic.leetcode-cn.com/1642575297-KnRSNt-image.png)

## 如何设置文本 ？
Canvas API 的 CanvasRenderingContext2D 使用  `2` 种方法和  `4` 种属性设置文本

* fillText(text, x，y, [, maxWidth]) 起始点 `(x, y)` 填充文本 `text` 最大宽度不超过 `maxWidth` 
* strokeText(text, x, y, [, maxWidth]) 起始点 `(x, y)` 描边文本  `text` 最大宽度不超过  `maxWidth` 
* font 字体样式的简写属性， 必须设置 `font-size` `font-family` 可以包含以下值 `font-style`  `font-variant`  `font-weight`  `line-height` 。默认值  `10px sans-serif` 
* textAlign 文本水平对齐方式属性，值分别是相对于  `x` 左对齐 `left` 右对齐 `right` 居中对齐 `center`，根据文本方向  `direction` 对齐起始位置 `start` 对齐结束位置 `end` 。默认值 `start` 
* textBaseline 文本基线属性，即文本垂直对齐方式属性。 `top` 文本基线在字符块顶部基线， `hanging` 文本基线是悬挂基线， `middle` 文本基线是垂直居中基线， `alphabetic` 文本基线是标准字母基线， `ideographic` 文本基线是字符底部基线， `bottom` 文本基线是字符块底部基线。默认值  `alphabetic` 
* direction 文本方向属性， `ltr` 方向从左向右， `rtl` 方向从右向左， `inherit` 继承自 `<canvas>` 或  `Document` 
示例

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.font = '20px sans-serif'
ctx.textAlign = 'center'
ctx.textBaseline = 'middle'
ctx.direction = 'rtl'
ctx.fillText('Leetcode', 100, 50)
ctx.arc(100, 60, 5, 0, Math.PI * 2)
ctx.fill()
```
![image.png](https://pic.leetcode-cn.com/1642575357-BHlldk-image.png)

## 如何测量文本宽度 ？
Canvas API 的 CanvasRenderingContext2D 使用  `1` 种方法返回一个被测量文本  `TextMetrics` 对象，其中包含的只读属性  `width` ，是文本宽度，单位是像素

示例

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.font = '16px sans-serif'
const textMetrics = ctx.measureText('Leetcode')
console.log(textMetrics.width) // 69.609375
```

## 如何导入图片 ？
Canvas API 的 CanvasRenderingContext2D 使用  `1` 方法和  `1` 属性导入图片

* drawImage 方法有三种用法
    * drawImage(image, dx, dy) 将  `image` 导入到 canvas 画布，左上角坐标是  `(dx, dy)` 
    * drawImage(image, dx, dy, dWidth, dHeight) 额外设定导入后  `image` 的宽度  `dWidth` 和高度  `dHeight` 
    * drawImage(image, sx, sy ,sWidth, sHeight, dx, dy, dWidth, dHeight) 额外设定从  `image` 的左上角  `(sx, sy)` 裁剪宽度 `sWidth` 高度  `sHeight` 的部分导入
* imageSmoothingEnabled 是否平滑图片的布尔属性，默认值是`true` 
 `image` 为 CanvasImageSource 类型对象，包括  `CSSImageValue` `HTMLCanvasElement`  `HTMLImageElement` `HTMLVideoElement` `ImageBitmap` `OffscreenCanvas` `SVGImageElement`  `VideoFrame` 

示例

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.width = ctx.height = 100
ctx.globalAlpha = .5
ctx.arc(50, 50, 50, 0, Math.PI * 2) // 绘制圆心(50, 50)，半径 50 的圆
ctx.fill()
ctx.drawImage(canvas, 50, 50, 50, 50, 0, 0, 100, 100) //截取圆的右下部分铺满画布
```
![image.png](https://pic.leetcode-cn.com/1642575429-hepyiB-image.png)

## 常用的变形有哪些 ？
常见的变形共有 `4` 种

* 移动
translate(x, y)  向左 `x` ，向右 `y` ，移动 canvas 的原点

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillRect(0, 0, 5, 5)
ctx.translate(50, 50) // 将画布水平移动 50，竖直移动 50
ctx.rect(0, 0, 100, 50)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642575485-cpCAqP-image.png)

* 旋转
rotate(angle) 以 canvas 的原点为中心，顺时针旋转  `angle` 度

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillRect(0, 0, 5, 5)
ctx.translate(50, 50) // 将画布水平移动 50，竖直移动 50
ctx.rotate(Math.PI / 2) // 将画布顺时针旋转 90 度
ctx.rect(0, 0, 100, 50)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642575516-yJEQli-image.png)

* 缩放
  scale(x, y) 以图形左上角为原点

    * 水平方向缩放 `x` 倍，负数为沿  `y` 轴镜像翻转后缩放  `-y` 倍
    * 竖直方向缩放 `y` 倍，负数为沿  `x` 轴镜像翻转后缩放  `-x` 倍
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillRect(0, 0, 5, 5)
ctx.translate(50, 50) // 将画布水平移动 50，竖直移动 50
ctx.scale(0.5, -1) // 画布水平缩小到 0.5 倍，竖直以图形左上角为原点，x 轴为对称轴镜像翻转
ctx.rect(0, 0, 100, 50)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642575539-xGSYGG-image.png)

* 矩阵
transform(m11, m12, m21, m22, dx, dy) 画布左上角为原点，水平移动 `dx` 竖直移动 `dy` 

以图形左上角为原点，竖直倾斜  `m12` 水平倾斜 `m21` 水平缩放 `m11` 竖直缩放 `m22` 

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillRect(0, 0, 5, 5)
ctx.transform(.5, 0, 0, -1, 50, 50) // 等同于 translate(50, 50) scale(.5, -1)
ctx.rect(0, 0, 100, 50)
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642575577-AbmOwh-image.png)

## 如何保存和恢复状态 ？
Canvas 状态的存储的数据结构为栈，先进后出

Canvas API 的 CanvasRenderingContext2D 提供了 `2` 种方法分别来保存和恢复状态

* save()  `push` 当前画布状态到栈 
* restore()  `pop` 恢复最近一次保存的画布状态
画布状态包括

* 属性
    * 填充属性：`strokeStyle` `fillStyle`  
    * 透明属性：`globalAlpha` 
    * 线条属性：`lineWidth`  `lineCap`  `lineJoin`  `miterLimit` `lineDashOffset` 
    * 合成属性：`globalCompositeOperation`  
    * 文字属性：`font`  `textAlign`  `textBaseline`  `direction` 
    * 阴影属性：`shadowOffsetX`  `shadowOffsetY`  `shadowBlur` 
    * 平滑属性：`imageSmoothingEnabled` 
* 变形
    * 移动：`translate(x, y)`  
    * 旋转：`rotate(angle)`  
    * 缩放：`scale(x, y)` 
    * 矩阵：`transform(m11, m12, m21, m22, dx, dy)` 
* 裁剪路径：即通过 `clip()` 转换的路径
示例

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
for (let i = 0; i < 3; i++) {
  for (let j = 0; j < 3; j++) {
    ctx.save()
    ctx.fillStyle = `hsl(${60 * i}, ${33 * j}%, ${15 * (i + j)}%)`
    ctx.translate(i * 35, j * 35)
    ctx.arc(15, 15, 15, 0, Math.PI * 2)
    ctx.closePath()
    ctx.clip()
    ctx.fillRect(0, 0, 30, 30)
    ctx.restore()
  }
}
```
![image.png](https://pic.leetcode-cn.com/1642575646-BQChir-image.png)

## 合成图形有哪些策略 ？
Canvas API 的 CanvasRenderingContext2D 提供了 `1` 种属性来合成图形

* globalCompositeOperation 用于指定合成图形的覆盖策略，共有   `26`  种策略
    * source-over 覆盖
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'source-over'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575728-qnSPXp-image.png)


* source-in 只绘制新图形和原图形重叠的区域
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'source-in'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575753-etQQOj-image.png)


* source-out 只绘制新图形和原图形不重叠的区域
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'source-out'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575766-XVPMdA-image.png)


* source-atop 只绘制新图形和原图形重叠的区域，并覆盖
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'source-atop'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575790-zqOFuY-image.png)


* destination-over 新图形在原图形下面
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'destination-over'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575800-yjxruU-image.png)


* destination-in 原图形只保留和新图形重叠的部分
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'destination-in'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575811-FcGfwi-image.png)


* destination-out 原图形只保留与新图形不重叠的部分
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'destination-out'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575820-pxxjJz-image.png)


* destination-atop 原图形只保留和新图形重叠的部分，新图形在原图形下面
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'destination-atop'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575834-igRVwZ-image.png)


* lighter 新图形和原图形的重叠部分颜色叠加并变亮
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'lighter'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575848-tNtwsA-image.png)


* copy 只绘制新图形
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'copy'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575862-KgvNII-image.png)


* xor 新图形和原图形重叠的部分透明
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'xor'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
设置 `body` 背景色为绿色后，与 lighter 对比
* xor
![image.png](https://pic.leetcode-cn.com/1642575882-PkMehr-image.png)


* lighter
![image.png](https://pic.leetcode-cn.com/1642575894-TNenwa-image.png)


* multiply 正片叠底，新图片像素与原图片重叠的部分像素相乘加深。与黑色混合为黑色。与白色混合，保持基色。与其它颜色混合，变暗
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'multiply'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575926-kABqxh-image.png)


* screen 滤色，新图片像素与原图片重叠的部分像素取补数，相乘，再取补数。与白色混合为白色。与黑色混合，保持基色。与其它颜色混合，变亮
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'screen'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575936-PAlHeL-image.png)


* overlay 叠加，图片基色小于一定值，应用 multiply，相反应用 screen。保留基色明暗
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'overlay'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575946-EbiZeD-image.png)


* darken 变暗，新图片和原图片重叠的部分颜色混合，替换比混合色亮的颜色，保留比混合色暗的颜色
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'darken'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575963-CrPEiE-image.png)


* lighten 变亮，新图片和原图片重叠的部分颜色混合，替换比混合色暗的颜色，保留比混合色亮的颜色
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'lighten'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575977-bfDVII-image.png)


* color-dodge 颜色减淡，新图片和原图片重叠的部分颜色混合。与黑色混合为黑色。与其它颜色混合，减少两者的对比度使基色变亮，表现为混合色
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'color-dodge'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642575990-vHWQgo-image.png)


* color-burn 颜色加深，新图片和原图片重叠的部分颜色混合。与白色混合为白色。与其它颜色混合，增加两者的对比度使基色变暗，表现为混合色
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'color-burn'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642576002-Rksydi-image.png)


* hard-light 强光，新图片和原图片重叠的部分颜色混合。与黑色混合为黑色。与白色混合为白色。混合色小于一定值，应用 screen。混合色大于一定值，应用 multiply。亮色越亮，暗色越暗
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'hard-light'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642576013-wwYPAG-image.png)


* soft-light 柔光，新图片和原图片重叠的部分颜色混合。与黑色混合，明显变暗。与白色混合，明显变量。混合色小于一定值，应用 lighten。混合色大于一定值，应用 darken。亮色越亮，暗色越暗
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'soft-light'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642576027-eXwALr-image.png)


* difference 差值，新图片和原图片重叠的部分颜色混合。与黑色混合为黑色。与白色混合基色反转。基色亮度大于混合色亮度，表现为基色减去混合色，相反，表现为混合色减去基色
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'difference'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642576039-Kjstng-image.png)


* exclusion 排除，新图片和原图片重叠的部分颜色混合。与黑色混合为黑色。与白色混合基色反转。基色亮度大于混合色亮度，表现为基色减去混合色，相反，表现为混合色减去基色。与 difference 不同的是，对比度更低
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'exclusion'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642576052-aIIRam-image.png)


* hue 色相，新图片和原图片重叠的部分颜色混合。使用基色的明亮度和饱和度，使用新图片的色相
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'hue'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642576063-geldNr-image.png)


* saturation 饱和度，新图片和原图片重叠的部分颜色混合。使用基色的明亮度和色调，使用新图片的饱和度
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'saturation'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642576073-mzxfwW-image.png)


* color 颜色，新图片和原图片重叠的部分颜色混合。使用基色的明亮度，使用新图片的色调和饱和度
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'color'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642576088-OVkYme-image.png)


* luminosity 明亮度，新图片和原图片重叠的部分颜色混合。使用基色的色相和饱和度，使用新图片的明亮度
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 100, 50)
ctx.globalCompositeOperation = 'luminosity'
ctx.fillStyle = 'pink'
ctx.fillRect(50, 0, 100, 50)
```
![image.png](https://pic.leetcode-cn.com/1642576099-ErypGw-image.png)

## 如何裁剪图形 ？
Canvas API 的 CanvasRenderingContext2D 提供了 `1` 种方法来裁剪图形

* clip([path][, fillRule]) 将当前路径或指定路径  `path` 按照  `fillRule` 设定的非零环绕或者奇偶环绕规则转换为裁剪路径，即遮罩，裁剪路径内部透明，外部不透明，即不会被绘制
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.arc(50, 50, 50, 0, Math.PI * 2)
ctx.clip()
ctx.fillRect(0, 0, 100, 100)
```
![image.png](https://pic.leetcode-cn.com/1642576228-VKGozP-image.png)

## 如何实现动画 ？
Canvas 的动画通过重绘实现，每次重绘相当于创建动画的一帧，以小于 `0.1s` 的时间间隔重绘，访客就可以看到连续的动画效果。具体实现步骤如下：

* 创建绘制函数
    * 清空或覆盖画布，即重置上一帧的内容
        * clearRect(x, y, width, height) 将画布指定区域的内容，设置为透明
        * fillRect(x, y, width, height) 
            * 通常将属性 fillStlyle 设置为画布背景色，如 `white` 
            * 填充背景色矩形，用于制造视觉暂留效果
    * 保存初始状态到栈
        * save() 属性、变形和裁剪的初始值被保存
    * 绘制图形
        * 绘制路径
        * 设置属性、变形或裁剪
        * 描边或填充
    * 从栈弹出并恢复初始状态
        * restore() 重置属性、变形和裁剪到初始值，不影响下一帧
* 调用重绘方法 
    * 定时调用
        * 周期性调用绘制函数
            * setInterval(drawFunction, delay, [arg1, arg2, ...]) 调用绘制函数
            * chrome.alarms
                * 配置 chrome.alarms.create 的 periodInMinutes 参数，生产环境 >= 1 分钟
                * chrome.alarms.onAlarm.adListener
                    * 通过 alarm.name 在第一步设置的 alarm 被触发时
                    * 调用绘制函数
        * 在绘制函数内部，一定时间后，重复调用自身
            * setTimeout(drawFunction[, delay, arg1, arg2, ...]) 
            * requestAnimationFrame(drawFunction)
    * 事件驱动：监听鼠标、键盘、触摸等事件，当事件被触发时，调用绘制函数，常用于游戏、VR 等
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
let x = y = 0, stepX = stepY = 3
const draw = () => {
  ctx.clearRect(0, 0, 300, 150)
  if (x + stepX > 300 || x + stepX < 0) stepX = -stepX
  if (y + stepY > 150 || y + stepY < 0) stepY = -stepY
  ctx.fillStyle = 'black'
  ctx.beginPath()
  ctx.arc(x += stepX, y += stepY, 15, 0, Math.PI * 2)
  ctx.closePath()
  ctx.fill()
  requestAnimationFrame(draw)
}
draw()
```
![image.png](https://pic.leetcode-cn.com/1642576381-EkzeYP-image.png)

## 如何访问和操作 Canvas 的像素 ？
Canvas 对象的像素数据通过 ImageData 对象存储，它有 `3` 个属性

* width 宽度，单位像素
* height 高度，单位像素
* data  `8` 位无符号整型固定类型数组，即 Uint8ClampedArray 元素值在  `[0, 255]` 之内，每  `4` 位表示一个像素， `4` 位中的每一位分别对应  `rgba` 的顺序，即红、绿、蓝和透明度。数组长度 `length` /  `4` 即像素数量
Canvas API 的 CanvasRenderingContext2D 提供了 `3`  种方法来访问和操作像素

* createImageData(width, height) / createImageData(imagedata) 创建指定宽度 `width` 和高度  `height` 的 ImageData 对象
* getImageData(left, top, width, height [, ImageDataSettings]) 返回坐标 `(left, top)` 宽度 `width` 高度  `height` 颜色空间为 `SRGB` 的 ImageData 对象，通过  `data` 属性可以访问（读取）其中的像素
* putImageData(ImageData, dx, dy) 将指定 imageData 对象写入  `(dx, dy)` 
示例：将蓝色矩形的中心部分替换为粉色

```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
ctx.fillStyle = 'skyblue'
ctx.fillRect(0, 0, 200, 100)
const imageData = ctx.getImageData(25, 25, 150, 50)
const { data } = imageData
for (let i = 0; i < data.length; i += 4) {
  data[i] = 255
  data[i + 1] = 192
  data[i + 2] = 203
}
ctx.putImageData(imageData, 25, 25)
```
![image.png](https://pic.leetcode-cn.com/1642576445-cqpNLQ-image.png)

## 如何将 Canvas 导出图片 ？
Canvas API 提供了 `2`  种方法来保存图片

* toDataURL(type, encoderOptions) 将图片导出成 data URI，即嵌入文档的 `base64` 编码的分辨率为 96dpi 的图片
* toBlob(callback, type, encoderOptions)将图片导出成 Blob，即不可变原始数据的类文件对象，通过 URL.createObjectURL(object) 方法生成 ·URL，供 `src` 或 `href` 属性使用
 `2` 种方法都支持设定

* type 图片格式，如  `image/png`  `image/jpeg`  `image/webp` 
* encoderOptions 图片质量，当 type 为 `image/jpeg`  `image/webp` 有效，范围 `0` - `1` 
示例：生成 Canvas 的下载链接

```javascript
const canvas = document.getElementById('canvas')
canvas.width = canvas.height = 20
const ctx = canvas.getContext('2d')
ctx.arc(10, 10, 10, 0, Math.PI * 2)
ctx.fill()
canvas.toBlob(blob => { 
  const a = document.createElement('A')
  a.href = URL.createObjectURL(blob)
  a.innerText = '点此保存图片'
  a.download = Date.now() + '.webp'
  document.body.append(a)
}, 'image/webp', 1)
```
![image.png](https://pic.leetcode-cn.com/1642576501-zXTKJs-image.png)

## 如何提高 Canvas 的性能 ？
视觉暂留，又称余辉效应，人眼在观察时，光信号传入大脑神经，产生的视觉形象，在光作用结束后，会暂留一段时间，该时间受明亮度等因素影响，通常是 0.05 到 0.4 秒

根据视觉暂留，图像每秒出现 10 次以上，便会产生相对连贯的动画效果。早期电影多为 16 FPS，为兼容音频的采样率（44.1khz and 48khz），24 FPS 成为有声电影的标准。PAL 制式和 NTSC 制式的电视帧率略高，分别是  25 FPS 和 29.97 FPS。而现代显示设备的刷新频率是 60 HZ - 360 HZ

以 60 HZ 为例，绘制每一帧的时间间隔为 1000 ms / 60 ≈ 16.67 ms

这意味着我们调用定时器的时间间隔如果是 16.67ms，就可以在每一次屏幕刷新时，绘制新的画面。现代运行环境提供的 window.requestAnimationFrame 的执行次数通常与屏幕的刷新次数一致。使用该方法，我们无需关心屏幕刷新率来决定具体的时间间隔，并由现代运行环境，根据用户电量和使用场景，自动控制调用时机

使用 Canvas 来绘制动画的过程，可以分为计算和渲染两部分，期间不断调用 Canvas API 提供的各种属性和方法。如果增加交互。从用户下达指令，到 CPU 计算，GPU 渲染，显示设备呈现，至少需要 3 帧的时间。这不可避免，而开发者能做的，便是降低计算和渲染的时间，避免阻塞主进程或者被 JavasScript 进程阻塞，避免不必要的消耗，按需惰性计算、惰性渲染，使得运行环境始终可以响应用户输入，主要业务逻辑不被影响

减少计算和渲染的时间，提高 Canvas 性能，就是要减少计算量和渲染量，提高计算和渲染速度，按需降低计算和渲染频率，充分借鉴 Web 性能优化中，常用的缓存、惰性计算和渲染、任务拆分、异步等思想，提高 Canvas 的运行 FPS，兼容更多低配置设备，并节省电量

具体提高 Canvas 性能的方法有：

* 减少计算量
    * 避免使用浮点数，总是取整
        * 浮点数，在抗锯齿效果下，运行环境需额外进行子像素渲染
    * 减少边界计算
        * 必须在画布内或超出画布必须清除的图形，进行边界计算
        * 超过画布没有影响的图形，允许画布外绘制，不进行边界计算，由运行环境自动优化
    * 优化算法
        * 减少迭代次数：例如，对于碰撞检测，可以采用 AABB，四叉树等算法降低复杂度
        * 减少操作对象：根据业务逻辑，预判受到影响的对象，每帧只对这些对象进行计算
            * 例如：射击游戏，***射出时，位于***后方的敌人永远不会收到***影响
* 减少渲染量
    * 画布尺寸合适
        * 非全屏应用，避免将大画布缩小显示
        * 全屏应用，画布尺寸与视窗大小一致，避免缩放
        * 如需缩放时，使用 CSS transform 的  `scale` 属性
    * 禁用透明度
        * 使用  `getContext('2d', { alpha: false })` 协助浏览器内部优化
    * 减少使用  `shadowBlur` 模糊效果
        * 渲染模糊效果会消耗额外的资源
        * 帧率极高时，产生的动态模糊，会提升用户的真实感
            * 可以在减少频率的情况下，使用  `shadowBlur` 增加模糊效果
            * 可以使用其它方法，来模拟模糊效果
                * 例如：采用  `rgba()` 设置  `fillStyle` 的值，用  `fillRect` 绘制透明矩形的方式来更新画布，可以产生模糊轨迹的效果
```javascript
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
let x = y = 20, stepX = stepY = 3
const draw = () => {
  ctx.fillStyle = 'rgba(255, 255, 255, .1)'
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  if (x + stepX > 280 || x + stepX < 20) stepX = -stepX
  if (y + stepY > 130 || y + stepY < 20) stepY = -stepY
  ctx.fillStyle = 'skyblue'
  ctx.beginPath()
  ctx.arc(x += stepX, y += stepY, 20, 0, Math.PI * 2)
  ctx.fill()
  requestAnimationFrame(draw)
}
requestAnimationFrame(draw)
```
![image.png](https://pic.leetcode-cn.com/1642576686-OwSIDZ-image.png)

* 避免使用  `fillText` 和  `strokeText` 来渲染文本
        * 推荐在画布之上创建额外的层，放置文本
    * 避免频繁调用  `putImageData` 
* 减少计算频率
    * 使用 requestAnimationFrame 代替 setTimeout 和 setInterval
        * 让最多执行次数通常与屏幕的刷新次数一致，避免无意义的执行
        * 由现代运行环境，根据用户电量和使用场景，自动控制调用频率
    * 节流
        * 对于绝大多数动画，只需保持基本流畅度，不需要每次屏幕刷新都渲染
```javascript
const throttle = (fn, interval) => { // 手写一个节流函数
  let timer = null
  return function (...args) {
    if (timer) return
    timer = setTimeout(() => {
      timer = null
      fn.apply(this, args)
    }, (interval + '') | 0 || 1000 / 60)
  }
}
const draw = () => { 
  // 原绘制方法
  requestAnimationFrame(drawWithThrottle)
}
const drawWithThrottle = throttle(draw, 100) // 每 100 ms 最多调用 1 次
requestAnimationFrame(drawWithThrottle)
```
* 减少渲染频率
    * 属性和状态相同的路径绘制合并，一次性描边和填充
```javascript
/** 优化前 */
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
const points = [[0, 0], [50, 150], [100, 0], [150, 150], [200, 0], [250, 150], [300, 0]]
for (let i = 1; i < points.length; i++) {
  const [lastX, lastY] = points[i - 1]
  const [x, y] = points[i]
  ctx.beginPath()
  ctx.moveTo(lastX, lastY)
  ctx.lineTo(x, y)
  ctx.stroke()
}
/** 优化后 */
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
const points = [[0, 0], [50, 150], [100, 0], [150, 150], [200, 0], [250, 150], [300, 0]]
for (let i = 0; i < points.length; i++) {
  const [x, y] = points[i]
  ctx.lineTo(x, y)
}
ctx.stroke()
```
![image.png](https://pic.leetcode-cn.com/1642576743-JjSshB-image.png)

* 分层渲染
        * 背景不使用 Canvas，直接通过位于底层的 `img` 或 CSS 的 `background` 设置更好
            * 避免 drawImage 调用的消耗
            * 避免转换为位图，保持背景原始格式的清晰度和内存占用
        * 将受同样事件驱动的图形放于同一 Canvas，不同的放在不同 Canvas
            * 背景通常置于底层
            * 事件发生时，只有受到该事件影响的 Canvas 被重绘，经常使用分类的方式
                * 用户输入设备（键盘、鼠标、触屏、语音、重力感应等）影响
                * 定时影响，根据时间变化，有默认行为，如移动的敌人，***等
                * 完全不影响：背景、装饰物、界面等
    * 离屏渲染
        * 避免重复绘制：每帧重复的绘制的内容，放入单独的 Canvas
            * 使用  `document.createElement('canvas')` 新建一个 canvas 元素，在其中绘制，该元素不放入文档流
            * 使用可脱离屏幕渲染的 OffscreenCanvas 对象
```javascript
/** 优化前 */
 const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
const points = [[0, 0], [50, 150], [100, 0], [150, 150], [200, 0], [250, 150], [300, 0]]
const rate = [0, 0], step = [.01, .01]
const draw = () => {
  ctx.setTransform(1, 0, 0, 1, 0, 0) // 重置变形
  ctx.clearRect(0, 0, 300, 150)
  if (rate[0] + step[0] < 0 || rate[0] + step[0] > 1) step[0] = -step[0]
  if (rate[1] + step[1] < 0 || rate[1] + step[1] > 1) step[1] = -step[1]
  rate[0] += step[0]
  rate[1] += step[1]
  ctx.translate((300 - 300 * rate[0]) / 2, (150 - 150 * rate[1]) / 2) // 中心缩放
  ctx.scale(rate[0], rate[1])
  ctx.beginPath()
  for (let i = 0; i < points.length; i++) {
    const [x, y] = points[i]
    ctx.lineTo(x, y)  
  }
  ctx.stroke()
  requestAnimationFrame(draw)
}
requestAnimationFrame(draw)

/** 优化后 */
 /** 将折线绘制好缓存到 OffscreenCanvas */
const offscreen = new OffscreenCanvas(300, 150)
const offscreenCTX =  offscreen.getContext('2d')
const points = [[0, 0], [50, 150], [100, 0], [150, 150], [200, 0], [250, 150], [300, 0]]
for (let i = 0; i < points.length; i++) {
  const [x, y] = points[i]
  offscreenCTX.lineTo(x, y)  
}
offscreenCTX.stroke()
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
const rate = [0, 0], step = [.01, .01]
const draw = () => {
  ctx.setTransform(1, 0, 0, 1, 0, 0) // 重置变形
  ctx.clearRect(0, 0, 300, 150)
  if (rate[0] + step[0] < 0 || rate[0] + step[0] > 1) step[0] = -step[0]
  if (rate[1] + step[1] < 0 || rate[1] + step[1] > 1) step[1] = -step[1]
  rate[0] += step[0]
  rate[1] += step[1]
  ctx.scale(rate[0], rate[1])
  ctx.drawImage(offscreen, (300 - 300 * rate[0]) / 2 / rate[0], (150 - 150 * rate[1]) / 2 / rate[1]) // 将缓存放入画布
  requestAnimationFrame(draw)
}
requestAnimationFrame(draw)
```
![image.png](https://pic.leetcode-cn.com/1642576805-uVHXNl-image.png)
* 避免重复裁剪：将裁剪好的内容，放入单独的 Canvas
            * 避免重复使用  `drawImage(image, sx, sy ,sWidth, sHeight, dx, dy, dWidth, dHeight)` 从大图，如精灵（Sprites）图中裁剪图形
            * 一次性使用 `drawImage(image, sx, sy ,sWidth, sHeight, dx, dy, dWidth, dHeight)` 将需要的图形或需要的尺寸裁剪好，每个放入不同的 Canvas 中
                * 使用时，直接导入 Canvas
* 提升渲染速度
    * 避免不必要的画布状态改变，避免不必要的 Canvas API 属性赋值
        * Canvas 的绘图上下文 Context 是状态机，更改属性的同时，要更新上下文状态，为下次绘制路径或填充做好准备。对绘图上下文的属性的赋值操作耗时，高于对普通对象属性的赋值操作
        * 避免传入非法值，对属性的不合法的赋值，通常不会报错，并会最终使用默认值。但会增加额外的消耗
    * 每帧清除画布时，根据需求使用合适的方法
        * 以下三种方法，第一种单独使用，可清空内容。第一种和第二种组合使用，保留属性，清空内容、变形。第一种和第三种组合使用，用于清空内容、属性和变形
            * clearRect(0, 0, canvas.width, canvas.height) 将画布设置为透明
            * context.setTransform(1, 0, 0, 1, 0, 0) 重置平移 translate 旋转 rotate 缩放 scale 等其它矩阵变形
            * save() 和 restore() 在绘制前保存初始状态，在绘制后恢复到初始状态，包括属性、变形及裁剪路径都被重置到初始状态
        * 以下方法用于重置路径
            * beginPath() 重新开始路径，避免和上一帧的路径连结
                * 正确的路径绘制流程：使用 beginPath() 开始路径，绘制路径，最后使用 closePath() 结束路径
                * 如果没有遵照该流程，直接绘制路径，会出现和上一帧的路基那个连结的情况
        * 以下方法可以重置内容、属性和变形，但可读性一般，在部分浏览器版本性能优于 clearRect 与其它方法组合调用
            * canvas.width = canvas.width 设置画布宽度等于自身宽度
            * canvas.height = canvas.height 或者设置画布高度等于自身高度
        * 以下方法可以覆盖内容，但性能一般，并且让画布失去透明度
            * fillStyle='背景色' 和 fillRect(0, 0, canvas.width, canvas.height) 用颜色为背景色的矩形填充画布
                * 采用  rgba() 设置  fillStyle 的值，用  fillRect 绘制透明矩形的方式来更新画布，可以产生模糊轨迹的效果
        * 避免总是清空画布
            * 根据业务需求，保留内容、属性或变形
            * 每次只绘制前后两帧的不同处，能够保留的尽量保留
    * 数据量大、视觉效果要求高的场景使用 WebGL 及 WebGL2 
        * WebGL 是 OpenGL ES 2.0 规范的 Web 端实现，可利用 GPU 并行处理特性
        * WebGL2 是 OpenGL ES 3.0 规范的 Web 端实现，支持多绘制缓冲等延迟渲染技术
* 避免阻塞主线程
    * 任务分解
        * 将耗时较高的任务，拆分成任务单元
        * 每执行完一个任务单元，预估距离下一次渲染的时间，是否足够执行下一个任务单元
            * 如果足够，继续执行
            * 如果不够，停止执行，保留任务进度，将控制权交还主进程
```javascript
/** 示例：将 10 个复杂任务（每个任务耗时 3 ms），分解成 2 个任务一个单元
    每完成一个单元，如果用时超过 10 ms，则保存进度，将控制权交还主进程 */
const canvas = document.getElementById('canvas')
const ctx = canvas.getContext('2d')
const taskTotal = 10 // 任务总数：10 个
const taskUnit = 2 // 任务单元：每次 2 个
let start = 0 // 进度指针：0
const complexTasks = async (ctx, i) => { // 模拟复杂任务，耗时 3 ms
  ctx.arc(i * 10 + 5, 5, 5, 0, Math.PI * 2)
  await new Promise(resolve=>setTimeout(()=>resolve(), 3))
}
const draw = async () => {
const startTime = Date.now()
  for (let i = start; i < taskTotal; i++) {
    await complexTasks(ctx, i) // 完成耗时长的任务
    if (i === taskTotal - 1) start = taskTotal
    else if ((i + 1) % taskUnit === 0 && Date.now() - startTime > 10) { // 每完成一个任务单元，检验时间
      start = i + 1
      break
    }
  }
  ctx.fill()
  if (start < taskTotal) requestAnimationFrame(draw)
}
requestAnimationFrame(draw)
```

* Web Worker
        * Web Worker 将为 JavaScript 创建多线程运行环境
        * 可以将计算及渲染任务放到 Worker 进程上
        * 主线程通过消息与 Worker 进程通信
        * 主线程和 Worker 线程不会相互阻塞
            * 减少影响主线程的业务逻辑和用户交互
            * 主线程阻塞时，动画正常展示
示例：

draw.js 

```javascript
/** 绘制旋转的矩形（将在主线程和 worker 同时调用 */
let i = 0
function draw () {
  const ctx = this.getContext('2d')
  ctx.clearRect(0, 0, this.width, this.height)
  ctx.setTransform(1, 0, 0, 1, 0, 0)
  if (++i === 360) i = 0
  ctx.translate(75, 75)
  ctx.rotate(Math.PI / 180 * i)
  ctx.translate(-75, -75)
  ctx.fillRect(50, 50, 50, 50)
  requestAnimationFrame(draw.bind(this))
}
```
index.html
```xml
<!-- 两个动画分别在主线程（上）和 Worker 线程（下）进行
在控制台阻塞主线程时，主线程（上）的动画卡住，而 Worker 线程（下）正常 -->
<body>
主线程：<br>
<canvas id="canvasMain"></canvas><br>
Worker 线程：<br>
<canvas id="canvasWorker"></canvas>
<script src="draw.js"></script>
<script type="script/worker" id="workerContent">
  self.onmessage = function(e) {
    importScripts(e.data.dir + '/draw.js');
    draw.call(e.data.canvasWorker)
  };
</script>
<script>
  /** 在主线程上绘制 */
  const canvasMain = document.getElementById('canvasMain')
  draw.call(canvasMain)
  /** 创建 worker */
  const blob = new Blob([document.getElementById('workerContent').textContent], { type: 'text/javascript' })
  const url = URL.createObjectURL(blob)
  const worker = new Worker(url)
  /** 在 worker 上绘制 */
  const canvasWorker = document.getElementById('canvasWorker').transferControlToOffscreen()
  const dirAr = location.href.split('/')
  dirAr.pop()
  worker.postMessage({ dir: dirAr.join('/'), canvasWorker }, [ canvasWorker ])
</script>
</body>
```
控制台执行
```javascript
/** 阻塞主线程 3 秒钟左右 */
for (let i = 0; i < 2000000000; i++) {}
```


# View / MVVM 框架


## 对比 React 、Angular 和 Vue
该问题 Vue 官方在 [《对比其他框架》](https://cn.vuejs.org/v2/guide/comparison.html?fileGuid=kc8dyHpRxGjrjvyy) 中作过说明，整理如下：

- React 和 Vue都提供了 Virtual Dom
- 提供了 响应式（Reactive）和组件化（Composable）的视图组件
- 注意力保持在核心库，而将其他功能如路由和全局状态管理交给相关的库

## React 和 Vue 不同点

### 渲染优化
* React：当组件状态发生变化时，以该组件为根，重新渲染整个组件子树
     * shouldComponentUpdate，采用合适方式，如不可变对象，比较 props 和 state，决定是否重新渲染当前组件
     * 使用 PureComponent：继承自 Component 类，自动加载 shoudComponentUpdate 函数，自动对 props 和 state 浅比较决定是否触发更新
* Vue：自动追踪组件依赖，精确渲染状态改变的组件
### HTML  和 CSS
* React：支持 JSX
    * 在构建视图时，使用完整的 JavaScript 功能
    * 开发工具多支持 JSX 语法高亮，类型检查和自动完成
* Vue：提供渲染函数，支持 JSX，但默认推荐 Vue 模版
    * 与书写 HTML 更一致的开发体验
    * 基于 HTML 的模版更容易迁移到 Vue
    * 设计师和新人开发者更容易理解和参与
    * 支持模板预处理器，如 Pug
### CSS 作用域
* React：通过 CSS-in-JS 方案，如 styled-components 和 emotion
* Vue：
    * 支持 CSS-in-JS 方案，如 styled-components-vue 和 vue-emotion
    * 单文件组件中 style 标签可选 scoped 属性。支持 Sass \ Less \ Stylus 等 CSS 预处理器，深度集成 CSS Modules
### 规模
#### 向上扩展：
* React：
    * 路由库和状态管理库，由社区维护支持，生态松散且繁荣
    * 提供脚手架工具，故意作了限制
        * 不允许在项目生成时进行配置
        * 只提供一个单页面应用模板
        * 不支持预设配置
* Vue：
    * 路由库和状态管理库，由官方维护支持，与核心库同步更新
    * 提供 CLI脚手架，可构建项目，快速开发组件的原型
        * 允许在项目生成时配置
        * 提供了各种用途的模板
        * 支持预设配置
#### 向下拓展
* React：学习曲线陡峭，需要前置知识：JSX ES2015，需要学习构建系统
* Vue：既支持向上拓展与 React 一样，也支持向下拓展与 jQuery 一样，上手快
### 原生渲染
* React Native：使用相同组件模型编写具有本地渲染能力的APP，跨平台开发
* Weex：阿里巴巴发起，Apache 基金会孵化，同样支持本地渲染，跨平台开发
    * NativeScript-Vue，基于 Vue.js 构建原生应用的 NativeScript 插件
### MobX
- React：流行的状态管理框架
- Vue：选择 Vue 比 React + MobX 更合理
### Preact 和其它类 React 库
- 难以保证与 React 库 100% 兼容

## Vue 和 Angular 相同点

* TypeScript 都支持 TypeScript，支持 **类型声明** 和 **组件装饰器**
* 运行时性能，Angular 和 Vue 都很快

## Vue 和 Angular 不同点

**体积**
- Angular 用 AOT 和 tree-shaking 缩小体积
- Vuex + Vue Router  （gzip 后 30kB）比使用优化angular-cli （~65kB）小
**灵活性**
- Vue 提供构建工具，不限制组织应用代码的方式
- Angular 提供构建工具，有相对严格的代码组织规范
**学习曲线**
- Vue 只需 HTML 和 JavaScript 基础
- Angular 提供 API 和 概念 更多，设计目标针对 大型复杂应用，对新手有难度

## 如何实现一个组件，前端组件的设计原则是什么？
* 单一原则：一个组件只做一件事
* 通过脑图、结构图，标识组件的 State Props Methods 生命周期，表示层次和数据流动关系
* State 和 Props
    * 扁平化：最多使用一层嵌套，便于对比数据变化，代码更简洁
    * 无副作用：State 仅响应事件，不受其他 State 变化影响
* 松耦合
    * 组件应该独立运行，不依赖其它模块
* 配置、模拟数据、非技术说明文档、helpers、utils 与 组件代码分离
* 视图组件只关心 视图，数据获取，过滤，事件处理应在外部 JS 或 父组件 中处理
* Kiss原则（Keep it Simple Stupid）
    * 不需要 State 时，使用 函数组件
    * 不要传递不需要的 Props
    * 及时抽取复杂组件为独立组件
    * 不要过早优化
* 参考 CSS 的 OOSS 方法论，分离 位置 和 样式，利于实现皮肤
* 考虑 多语言、无障碍 等后期需求

## Angular


### 如何理解 Angular 的依赖注入？
依赖注入（DI）是一种重要应用设计模式

* 依赖：类执行功能，所需要服务或对象
* DI 框架会在实例化类时，向其提供这个类声明的依赖项
* 使用 `ng generate service` 生成 Service 类
## 分层注入体系
### ModuleInjector
* `@Injectable` 装饰器标记服务 （推荐，利于摇树优化）
    * 可以配置 `provider` 是 root 或 具体的 `NgMoudle`
* `@NgMoudle` 装饰器都有 providers 元数据
    * 可以覆盖 `@Injectable` 中的 `provider`，来配置多个应用共享的服务非默认提供者
### ElementInjector
* 为每个 DOM 元素隐式创建 ElementInjector
* 默认为空
* 在 `@Directive` 和 `@Component` 的 providers 属性中配置
## 注入器继承机制
### 当组件声明依赖时
* 优先使用它自己的 ElementInjector 来满足依赖
* 组件缺少提供者，请求转发至 父组件 ElementInjector
* 任何 ElementInjector 都找不到，返回发起请求元素
* 在 ModuleInjector 层次结构中查找
* 任何 ModuleInjector 都找不到，引发错误
### 解析修饰符
* `@Optional`
    * 声明依赖是可选的，找不到返回 null，无需抛出错误
* `@Self`
    * 仅查看当前组件或指令的 ElementInjector
* `@SkipSelf`
    * 跳过当前，查找父级的 ElementInjector
* `@Host`
    * 当前组件作为注入器树的最后一站



# VUE


## computed 与 watch 的区别？
## computed
* 支持数据缓存
* 内部数据改变也会触发
* 不支持异步，异步无效
* 适用于 一个属性由其他属性计算而来，依赖其他属性的场景
## watch
* 不支持数据缓存
* 可以设置一个函数，带有两个参数，新旧数据
* 支持异步
* 监听数据必须是 data 中声明过或者父组件传递过来的 props 中数据
    * immediate：组件加载立即触发回调函数执行
    * deep：深度监听

## Vue.nextTick 原理和作用？
* Vue 异步执行 DOM 更新，观察数据变化，开启队列缓冲同一事件循环中所有数据改变
* 同一个 watcher 被多次触发，只会被推入到队列中一次，避免不必要的计算和 DOM 操作
* 在下一个事件循环 `tick` 中，Vue 刷新队列并执行实际（已去重）工作
* 异步队列使用 `Promise.then` 和 `MessageChannel`，不支持环境使用 `setTimeout(fn, 0)`
* 在需要立即更新 DOM 的场景中使用

## Vue3.x 的新特性
## API 风格
* Vue2.x：Options API
* Vue3.x：Composition API
## 生命周期
* 组件生命周期
    * Vue2.x：
        * beforeCreate
        * created
        * beforeMount
        * mounted
        * beforeUpdate
        * updated
        * beforeDestroy
        * destroyed
        * activated
        * deactivated
        * errorCaptured
    * Vue3.x：
        * setup
        * onBeforeMount
        * onMounted
        * onBeforeUpdate
        * onUpdate
        * onBeforeUnmout
        * onUnmounted
        * onActivated
        * onDeactivated
        * onErrorCaptured
        * onRenderTriggered
        * onRenderTracked
* 指令生命周期
    * Vue2.x：
        * bind
        * inserted
        * update
        * componentUpdated
        * unbind
    * Vue3.x：
        * beforeMount
        * mounted
        * beforeUpdate
        * updated
        * beforeUnmount
        * unmounted
## 数据
* Vue2.x：data
* Vue3.x
    * ref 基础类型和对象的双向绑定
    * reactive 对象的双向绑定
        * 通过 `toRefs` 转为 ref
## 监听
* Vue2.x：watch
* Vue3.x：watchEffect
    * 传入回调函数，不需要指定监听的数据源，自动收集响应式数据
    * 可以从回调函数中，获取数据的最新值，无法获取原始值
## slot
* Vue2.x：通过 `slot` 使用插槽，通过 `slot-scope` 给插槽绑定数据
* Vue3.x：`v-slot:` 插槽名 `=` 绑定数据名
## v-model
* Vue2.x：`.async` 绑定属性和 `update:`+ 属性名 事件
* Vue3.x：无需 `.async` 修饰
## 新功能
* Teleport：适合 Model 实现
* Suspense：
    * 一个组件两个 template
    * 先渲染 #fallback 内容，满足条件再渲染 #default
    * 适合异步渲染显示加载动画，骨架屏等
* defineAsyncComponent：定义异步组件
* 允许多个根节点
## 性能
* 使用 `Proxy` 代替 `definePoperty` 和 数组劫持
* 标记节点类型，diff 时，跳过静态节点
* 支持 ES6 引入方法，按需编译
* 配套全新的 Web 开发构建工具 Vite


# React


## React 生命周期
## React 16 前的生命周期
* Mounting
    * componentWillMount
    * render
    * componentDidMount
* Updation
    * props
        * componentWillReceiveProps
        * shouldComponentUpdate
        * componentWillUpdate
        * render
        * componentDidUpdate
    * states
        * shouldComponentUpate
        * componentWillUpdate
        * render
        * componentDidUpdate
* Unmouting
    * componentWillUnmount
## React 16.3 生命周期
* Mounting
    * constructor
    * getDerivedStateFromProps
    * render
    * React 更新 DOM 和 refs
    * componentDidMount
* Updation
    * props 变化 → getDerivedStateFromProps
    * setState()  → shouldComponentUpdate
    * forceUpdate() → render
    * getSnapshotBeforeUpdate
    * React 更新 DOM 和 refs
    * componentDidUpate
* Unmouting
    * compoentWillUnmount
## React 16.4 + 生命周期
* Mounting
    * constructor
    * getDerivedStateFromProps
    * render
    * React 更新 DOM 和 refs
    * componentDidMount
* Updation
    * props 变化 → getDerivedStateFromProps
    * setState() →  getDerivedStateFromProps →  shouldComponentUpdate
    * forceUpdate()  → getDerivedStateFromProps
    * render
    * getSnapshotBeforeUpdate
    * React 更新 DOM 和 refs
    * componentDidUpate
* Unmouting
    * componentWillUnmount

## React 中使用 useEffect 如何清除副作用？
在 useEffect 中返回一个清除函数，名称随意，可以是匿名函数或箭头函数，在清除函数中添加 处理副作用的逻辑，如移除订阅等

```javascript
function component(props) {
  function handleStatusChange(status) { console.log(status.isOnine) }
  useEffect(() => {
    API.subscribe(props.id, handleStatusChange))
    return function cleanup() { 
      API.unsubscribe(props.id, handleStatusChange)
    }
  }
}
```

## 对比 React 和 Vue 的 diff 算法？
（1）相同点

* 虚拟 Dom 只同级比较，不跨级比较
* 使用 key 标记和复用节点，不建议使用数组索引 index 作为 key

（2）不同点

* 顺序
    * Vue：两端到中间
    * React：从左到右
* 节点元素类型相同，ClassName 不同
    * Vue：不同类型元素，删除重新创建
    * React：相同类型元素，修改
* 节点类型
    * Vue 3.x：VNode 创建时，即确定类型

## React 中有哪几种类型的组件，如何选择？
* 无状态组件
    * 更适合函数组件
    * 负责展示
    * 无状态，复用度高
* 有状态组件
    * 函数组件 + hooks 或 类组件
    * useState 或 声明 state
    * useEffect 或 使用生命周期
* 容器组件
    * 子组件状态提升到此，统一管理
    * 异步操作，如数据请求等
    * 提高子组件的复用度
* 高阶组件
    * 接收组件，返回组件
    * 为原有组件增加新功能和行为
    * 代替 mixins，避免状态污染
* 回调组件
    * 高阶组件的另一种形式
    * 将组件本身，通过 props.children 或 prop 属性 传递给子组件
    * 适合不能确定或不关心传给子组件数据的场景，如路由，加载组件的实现


# 阶段测Ⅱ
本章阶段测针对Canvas绘图、View / MVVM框架、VUE、React这四章的知识点进行测试。

## 简答题
<!DOCTYPE html>
<html>
<head>
<style>
label:hover   {color: #3172cc;}
.nav-con{display: none;}
.nav-box{display: none;}
.nav-con:checked ~ .nav-box{display: block;}
.nav-btn{font-size:16px; font-weight: bold;}
</style>
</head>
<body>

<p>1. 什么是 Canvas ?</p>
<label for="control1" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box">  
	Canvas 是 HTML5 新增元素，它允许 JavaScript 脚本语言动态渲染位图像。常用于动画、游戏画面、数据可视化、图片编辑和实时视频处理等
    </p>
</div>

<p>2. Canvas 包括哪些？。</p>
<label for="control2" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box">  
	• HTML 的 <canvas> 标签 <br>
	• 操作 <canvas> 元素的 API <br>
	• 其它 HTMLCanvasElement API
    </p>
</div>

<p>3. 请简述一下设置透明度的两种方法。</p>
<label for="control3" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box">  
	• 使用 CSS 数据类型 <color> 中的 rgba() 和 hsla() ，最后一个参数 alpha 的范围从 0 到 1 表示不透明度， 0 为完全透明， 1 为完全不透明  <br>
	• 通过 CanvasRenderingContext2D.globalAlpha 属性设置，范围从 0 到 1 表示不透明度， 0 为完全透明， 1 为完全不透明
    </p>
</div>

<p>4. Canvas API 的 CanvasRenderingContext2D 使用 2 种 fillRule 填充规则，通过什么来判断点是否在路径内，还是路径外？</p>
<label for="control4" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box">  
	isPointInPath 
    </p>
</div>

<p>5. Canvas API 的 CanvasRenderingContext2D 使用 2 种方法和 4 种属性设置文本，4 种属性分别是什么？</p>
<label for="control5" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control5" class="nav-con">
    <p class="nav-box">  
	font 字体样式的简写属性、extAlign 文本水平对齐方式属性、textBaseline 文本基线属性、direction 文本方向属性
    </p>
</div>

<p>6. Canvas 的动画通过什么实现？</p>
<label for="control6" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control6" class="nav-con">
    <p class="nav-box">  
	重绘
    </p>
</div>

<p>7. 请简述一下创建绘制函数步骤。</p>
<label for="control7" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control7" class="nav-con">
    <p class="nav-box">  
	• 清空或覆盖画布，即重置上一帧的内容 <br>
	• 保存初始状态到栈 <br>
	• 绘制图形 <br>
	• 从栈弹出并恢复初始状态
    </p>
</div>

<p>8. 提高 Canvas 性能的方法有哪些？</p>
<label for="control8" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control8" class="nav-con">
    <p class="nav-box">  
	减少计算量、减少渲染量、避免使用 fillText 和 strokeText 来渲染文本、减少计算频率、减少渲染频率、分层渲染、避免重复裁剪、提升渲染速度、避免阻塞主线程等
    </p>
</div>

<p>9. 提高 Canvas 性能的方法中减少计算量如何实现？</p>
<label for="control9" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control9" class="nav-con">
    <p class="nav-box">  
	• 避免使用浮点数，总是取整 <br>
	• 减少边界计算 <br>
	• 优化算法
   </p>
</div>

<p>10. 请简述一下 Vue 和 Angular 相同点。</p>
<label for="control10" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control10" class="nav-con">
    <p class="nav-box">  
	• TypeScript 都支持 TypeScript，支持 类型声明 和 组件装饰器  <br>
	• 运行时性能，Angular 和 Vue 都很快
    </p>
</div>

<p>11. 简述Vue 和 Angular 在学习曲线上的不同。</p>
<label for="control11" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control11" class="nav-con">
    <p class="nav-box">  
	• Vue 只需 HTML 和 JavaScript 基础 <br>
	• Angular 提供 API 和 概念 更多，设计目标针对 大型复杂应用，对新手有难度
    </p>
</div>

<p>12. 请简述一下Kiss原则（Keep it Simple Stupid）</p>
<label for="control12" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control12" class="nav-con">
    <p class="nav-box">  
	• 不需要 State 时，使用 函数组件 <br>
	• 不要传递不需要的 Props <br>
	• 及时抽取复杂组件为独立组件 <br>
	• 不要过早优化
    </p>
</div>

<p>13. 请简述 Vue3.x 的新功能。</p>
<label for="control13" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control13" class="nav-con">
    <p class="nav-box">  
	• Teleport：适合 Model 实现 <br>
	• Suspense： <br>
	• 一个组件两个 template <br>
	• 先渲染 #fallback 内容，满足条件再渲染 #default <br>
	• 适合异步渲染显示加载动画，骨架屏等 <br>
	• defineAsyncComponent：定义异步组件 <br>
	• 允许多个根节点
    </p>
</div>

<p>14. 简述 React 和 Vue 的 diff 算法相同点。</p>
<label for="control14" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control14" class="nav-con">
    <p class="nav-box">  
	• 虚拟 Dom 只同级比较，不跨级比较 <br>
	• 使用 key 标记和复用节点，不建议使用数组索引 index 作为 key
    </p>
</div>

<p>15. React 中有哪几种类型的组件？</p>
<label for="control15" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control15" class="nav-con">
    <p class="nav-box">  
	无状态组件、有状态组件、容器组件、高阶组件、回调组件
    </p>
</div>




</body>
</html>

## 选择题
x53sd2x5qkvcx563nix5ku2e


# 全栈


## Node.js


### express 中 next 的作用？
next 是 中间件函数的第三参数

* 执行 next()，控制权交给下个中间件
* 不执行
    * 终止请求
    * 挂起请求

### 对比 express 和 koa？
* Handler 处理方式
    * Express：回调函数
    * Koa：Async /  Await
* 中间件
    * Express：同一线程，线性传递
    * Koa：洋葱模型，级联传递
* 响应机制
    * Express：`res.send` 立即响应
    * Koa：设置`ctx.body`，可累加，经过中间件后响应


## 计算机网络


### 对比持续通信的方法？
## 轮询
* 通过 setInterval 或 setTimeout 定时获取并刷新页面上的数据
* 定时查询，不一定有新数据
* 并发较多时，增加服务器负担
## 长连接
* 页面其纳入 iframe，将 src 设为长连接
* 减少无用请求
* 并发较多时，增加服务器负担
## 长轮询
* 服务端收到请求后，hold 住链接，直到新消息返回时才响应
* 减少无用请求
* 返回数据顺序无保证
## Flash Socket
* 客户端通过嵌入 Socket 类 Flash与服务器端的 Socket 接口通信
* 真正即时通信
* 非 HTTP 协议，无法自动穿越防火墙
## WebSocket
* 在客户端和服务器间打开交互式通信绘话
* 兼容 HTTP 协议。与 HTTP 同属应用层。默认端口是 80 和 443
* 建立在 TCP 协议基础之上，与 HTTP 协议同属于应用层
* 数据格式轻量，性能开销小，通信高效
* 可以发送文本，也可以发送二进制数据
* **没有同源限制**
* 协议表示符：ws，加密 wss
## socket.io
* 跨平台的 WebSocket 库，API 前后端一致，可以触发和响应自定义事件
```JavaScript []
// 服务端
const io = require("socket.io")(3000)
io.on('connection', socket => {
  socket.on('update item', (arg1, arg2, callback) => {
    console.log(arg1, arg2)
    callback({ status: 'fulfilled' })
  })
})
// 客户端
const socket = io()
socket.emit('update item', "1", { name: 'updated' }, res => {
  console.log(res.status) // ok
})
```

### 网络结构按五层和七层分别是？
TCP / IP 体系结构

* 网络接口层
* 网际层 IP
* 运输层 TCP 或 UDP
* 应用层（TELNET FTP SMTP等）

五层

* 物理层
* 数据链路层
* 网络层
* 运输层
* 应用层

七层：Open System Inerconnect Reference Model 开放式系统互联通信参考模型

* 物理层
* 数据链路层
* 网络层
* 传输层
* 会话层
* 表达层
* 应用层

### 什么是 TCP 三次握手，为什么要三次握手？
（1）什么是 TCP 三次握手？

* 起初
    * 客户端 CLOSED
    * 服务端 CLOSED
* 第一次握手
    * 客户端发送请求报文
        * 传输自身通讯初始序号
        * 客户端 SYN-SENT
* 第二次握手
    * 服务器接收请求报文
        * 同意连接
            * 传输自身通讯初始序号
            * 服务端 SYN-RECEIVED
        * 拒绝连接
            * 服务端 REFUSED
* 第三次握手
    * 客户端接收应答报文
        * 客户端发送确认报文
        * 客户端 ESTABLISHED
    * 服务端接收确认报文
        * 服务端 ESTABLISHED

（2）为什么要三次握手？

* 客户端首次发送请求无应答，TCP 启动超时重传
* 服务器收到重传的请求，建立连接，接收数据，关闭连接
* 服务器收到客户端首次发送请求，再次建立连接，但客户端已经关闭连接

需要三次握手，客户端发送确认报文后再建立连接，避免重复建立连接

### 浏览器有哪些请求方法？
安全：请求会影响服务器资源

幂等：多次执行重复操作，结果相同

|方法|描述|请求体|响应体|支持表单|安全|幂等|可缓存|
|:----|:----|:----|:----|:----|:----|:----|:----|
|GET|请求资源|无|有|是|是|是|是|
|HEAD|请求资源头部|无|无|否|是|是|是|
|POST|发送数据 数据类型由Content-Type 指定|有|有|是|否|否|响应头包含 expires 和 max-age|
|PUT|发送负载 创建或替换目标资源|有|无|否|否|是|否|
|DELETE|删除资源|不限|不限|否|否|是|否|
|CONNECT|创建点到点沟通隧道|无|有|否|否|否|否|
|OPTIONS|检测服务器支持方法|无|有|否|是|是|否|
|TRACE|消息环路测试 多用于路由检测|无|无|否|是|是|否|
|PATCH|部分修改资源|有|有|否|否|否|否|

### 提交表单的内容类型有哪些？
面试高频指数：★ ★ ★ ☆ ☆

* application/x-www-form-urlencoded：初始的默认值

```plain
Content-Type：application/x-www-form-urlencoded
...
key1=value1&key2=value2
```

* multipart/form-data：适用于使用 `<input>` 标签上传的文件

```plain
Content-Type：multipart/form-data; boundary=------数据边界值
...
------数据边界值
Content-Disposition: form-data; name="key1"
value1
------数据边界值
Content-Disposition: form-data; name="key2"
value2
```

* text/plain：HTML5 引入类型

```plain
Content-Type：text/plain
...
key1=value1
key2=value2
```

### docker 与虚拟机区别
## 启动速度
* Docker：秒级启动
* 虚拟机：几分钟启动
## 需要资源
* Docker：操作系统级别虚拟化，与内核直接交互，几乎没有性能损耗
* 虚拟机：
    * 通过虚拟机监视器（Virtual machine monitor，VMM，Hypervisor）
    * 厂商：Citrix XenServer，Hyper-V，开源 KVM 、Xen、VirtualBSD
## 轻量
* Docker：内核与应用程序库可共享，占用内存极小，资源利用率高
* 虚拟机：同样硬件环境，Docker 运行的镜像数量远多于 虚拟机数量
## 安全性
* Docker：安全性更弱。租户 root 与宿主机 root 等同，有提权安全风险
* 虚拟机：
    * 租户 root 权限与宿主机的 root 虚拟机权限分离
    * 用如 Intel 的 VT-d 和 VT-x 的 ring-1 硬件隔离技术，虚拟机难以突破 VMM 直接与宿主或彼此交互
## 可管理型
* Docker：集中化管理工具还不算成熟
* 虚拟机：拥有相对完备的集中化管理工具
## 高可用和可恢复性
* Docker：依靠 快速重新部署 实现
* 虚拟机：负载均衡、高可用、容错、迁移、数据保护，VMware可承诺 SLA（服务级别协议）99.999% 高可用
## 快速创建、删除
* Docker：秒级别，开发、测试、部署更快
* 虚拟机：分钟级别
## 交付、部署
* Docker：在 Dockerfile 中记录了容器构建过程，可在集群中实现快速分发和快速部署
* 虚拟机：支持镜像

### 对比 Intel 的 VT-x，VT-d，VT-c
## VT-x

* 运行 ESXI 上的 64位 Guest OS 基本指令
* Intel 运用Virtualization 虚拟化技术中的指令集
* 减少 VMM 干预，硬件支持 VMM 与 Guest OS
* 需要 VMM 干预，更快速、可靠、安全切换
* 更灵活、更稳定

## VT-d

* 使一个 Guest OS 独占并直接存取硬件设备，加快读写速度
* 开启条件：北桥芯片支持，BIOS 开启

## VT-c

### Virtual Machine Direct Connect
*  虚拟机的虚拟网络卡传送透过 VMM 来进行传输
*  Guest OS 可以直接对 实体网络 I/O 进行存取
*  加强 VT-d，让多个虚拟机与实体 I/O 装置同时建立通道
### Virtual Machine Direct Queues
*  由 VMM 管理的虚拟化 Switch 转送封包给虚拟机
    *  封包流向哪个虚拟机，需要额外 CPU 资源
*  透过网卡内建 Layer2 classifier / sorter 加速网络资料传送
    *  在芯片里安排并通过队列排序好封包给虚拟机，不需要 VMM 支持
        *  大大降低网络负载和 CPU 使用率


## HTTP


### 什么是 URL ？
* URL （统一资源定位器）是指定在 Internet 上可以找到资源的位置的文本字符串
    * 在 HTTP 的上下文中，URL 被叫做“网络地址”或“链接”
    * 浏览器在其地址栏显示 URL，例如 [https://leetcode-cn.com](https://leetcode-cn.com)
    * URL 也可用于文件传输（FTP），电子及邮件（SMTP）和其他应用
* URL 接口用于解析、构造、规范化和编码 URLs
    * 通过调用 URL 构造函数  `new URL(url, [, base])` 创建并返回一个 URL 对象
        * 该 URL 对象引用使用绝对 URL 字符串
        * 或相对 URL 字符串和基本 URL 字符串指定的 URL
    * 通过 URL 对象读取已解析的组成部分或对 URL 进行更改
* `<url>` 是 CSS 中的一种数据类型
    * `<url>` 没有独有的表达形式，只能通过 `url()` 函数定义
    * `url()` 函数中的 URL 可以使用单引号或双引号包含，也可以直接书写
        * 使用相对地址时，相对地址相对于 CSS 样式表的 URL （而不是网页的 URL）

### 什么是 HTTP 报文？
（1）定义  

HTTP 全称 Hypertext Transfer Protocol，超文本传输协议，是应用层协议  

HTTP 报文由从客户端到服务器的请求和从服务器到客户端的响应构成  

（2）组成  

* 起始行：报文描述
* 头部：报文属性
* 主体：报文数据
（3）分类  

* 请求报文：客户端到服务端发送请求
    * 请求行：方法 + URL + HTTP协议版本
    * 通用信息头：`Connection` 等
    * 请求头
    * 实体头：POST / PUT / PATCH 的 `Content-Type` `Content-Length` 等
    * 报文主体
* 响应报文：服务端到客户端返回数据
    * 状态行：状态码 + 原因
    * 通用信息头：`Connection`等
    * 响应头
    * 实体头：`Content-Type` `Content-Length` 等
    * 报文主体

### 常见的 HTTP 状态码有哪些？
|**状态码**|**原因**|**说明**|
|:----|:----|:----|
|100-199 | 信息响应 |    |
|100 | Continue | 已收到请求，客户端应继续|
|101 | Switching Protocol | 响应客户端Upgrade列出协议，服务端正在切换协议|
|102 | Processing | 服务端正在处理请求，无响应可用|
|103 | Early Hints | 与Link一起使用，客户端应在服务端继续响应前开始预加载资源|
|200-299 | 成功响应 |    |
|200 | OK | 请求成功，常见于GET HEAD POST TRACE|
|201 | Created | 请求成功，新资源已创建，常见于POST PUT|
|202 | Accepted | 请求已收到，但未响应|
|203 | Non-Authoritative Information | 响应经过了代理服务器修改|
|204 | No Content | 请求已处理，无返回，客户端不更新视图|
|205 | Reset Content | 请求已处理，无返回，客户端应更新视图|
|206 | Partial Content | 请求已处理，返回部分内容，常见于视频点播、分段下载、断点续传|
|300-399 | 重定向 |    |
|300 | Multiple Choice | 提供一系列地址供客户端选择重定向|
|301 | Moved Permanently | 永久重定向，默认可缓存，搜索引擎应更新链接|
|302 | Found | 临时重定向，默认不缓存，除非显示指定|
|303 | See Other | 临时重定向，必须GET请求|
|304 | Not Modified | 未修改，不含响应体|
|307 | Temporary Redirect | 临时重定向，默认不缓存，除非显示指定，不改变请求方法和请求体|
|308 | Permanent Redirect | 永久重定向，默认可缓存，搜索引擎应更新链接，不改变请求方法和请求体|
|400-499 | 客户端错误 |    |
|400 | Bad Request | 请求语义或参数有误，不应重复请求|
|401 | Unauthorized | 请求需身份验证或验证失败|
|403 | Forbidden | 拒绝，不应重复请求|
|404 | Not Found | 未找到，无原因|
|405 | Method Not Allowed | 不允许的请求方法，并返回 Allow 允许的请求方法列表|
|406 | Not Acceptable | 无法根据请求条件，返回响应体|
|407 | Proxy Authentication Required | 请求需在代理服务器上身份验证|
|408 | Request Timeout | 请求超时|
|409 | Conflict | 请求冲突，响应应包含冲突原因|
|410 | Gone | 资源已被永久移除|
|411 | Length Required | 请求头需添加 Content-Length|
|412 | Precondition Failed | 非 GET POST 请求外，If-Unmodified-Since 或 If-None-Match 规定先决条件无法满足|
|413 | Payload Too Large | 请求体数据大小超过服务器处理范围|
|414 | URI Too Long | URL过长，查询字符串过长时，应使用 POST 请求|
|415 | Unsupported Media Type | 请求文件类型服务端不支持|
|416 | Range Not Satisfiable  | 请求头 Range 与资源可用范围不重合|
|417 | Expectation Failed | 服务端无法满足客户端通过 Expect 设置的期望响应|
|421 | Misdirected Request | HTTP2 下链接无法复用时返回|
|425 | Too Early | 请求有重放攻击风险|
|426 | Upgrade Required | 客端应按响应头Upgrade的协议列表中的协议重新请求|
|428 | Precondition Required | 没有符合 If-Match 的资源|
|429 | Too Many Requests | 请求频次超过服务端限制|
|431 | Request Header Fields Too Large | 请求头字段过大|
|451 | Unavailable For Legal Reasons | 因法律原因该资源不可用|
|500-511 | 服务端响应 |    |
|500 | Internal Server Error | 服务端报错，通常是脚本错误|
|501 | Not Implemented |  请求方法不被服务器支持|
|502 | Bad Gateway | 网关无响应，通常是服务端环境配置错误|
|503 | Service Unavailable | 服务端临时不可用，建议返回 Retry-After，搜索引擎爬虫应一段时间再次访问这个URL|
|504 | Gateway Timeout | 网关超时，通常是服务端过载|
|505 | HTTP Version Not Supported | 请求的 HTTP 协议版本不被支持|
|506 | Variant Also Negotiates | 内部服务器配置错误|
|510 | Not Extended | 不支持 HTTP 扩展|
|511 | Network Authentication Required | 需要身份验证，常见于公用 WIFI|

### 常用的 HTTP 方法有哪些，GET 和 POST 的区别是什么？
* 安全：请求方法不会影响服务器上的资源
* 幂等：多次执行相同操作，结果相同
* 显示声明缓存：响应头包含 `Expires` `Cache-Control: max-age` 等时缓存

|**方法**|**描述**|**请求含主体**|**响应含主体**|**支持表单**|**安全**|**幂等**|**可缓存**|
|:----|:----|:----|:----|:----|:----|:----|:----|
|GET | 请求资源 | 否 | 是 | 是 | 是 | 是 | 是|
|HEAD | 请求资源头部 | 否 | 否 | 否 | 是 | 是 | 是|
|POST | 发送数据，主体类型由 Content-Type 指定 | 是 | 是 | 是 | 否 | 否 | 显式声明缓存|
|PUT | 发送负载创建或替换目标资源 | 是 | 否 | 否 | 否 | 是 | 否|
|DELETE | 删除资源 | 不限 | 不限 | 否 | 否 | 是 | 否|
|CONNECT | 创建点到点沟通隧道 | 否 | 是 | 否 | 否 | 否 | 否|
|OPTIONS | 检测服务端支持方法 | 否 | 是 | 否 | 是 | 是 | 否|
|TRACE | 消息环回测试，多用于路由检测 | 否 | 否 | 否 | 是 | 是 | 否|
|PATCH | 部分修改资源 | 是 | 是 | 否 | 否 | 否 | 否|

### 常见的 HTTP 请求头和响应头有哪些？
|**请求头**|**描述**|**示例**|
|:----|:----|:----|
|Accept | 用户代理支持的MIME类型列表 | Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9|
|Accept-Encoding | 用户代理支持的压缩方法（优先级） | Accept-Encoding: br, gzip, deflate|
|Accept-Language | 用户代理期望的语言（优先级） | Accept-Language: zh-CN,zh;q=0.9|
|Cache-Control | 缓存机制 | Cache-Control: max-age=0|
|Connection | 是否持久连接 | Connection: keep-alive|
|Cookie | HTTP cookies | 服务器通过 Set-Cookie 存储到客户端的 Cookie|
|Host | 主机名 + 端口号 | Host: 127.0.0.1:8080|
|If-Match | 请求指定标识符资源 | If-Match: "56a88df57772gt555gr5469a32ee75d65dcwq989"|
|If-Modified-Since | 请求指定时间修改过的资源 | If-Modified-Since: Wed, 19 Oct 2020 17:32:00 GMT|
|If-None-Match | 请求非指定标识符资源 | If-None-Match: "56a88df57772gt555gr5469a32ee75d65dcwq989"|
|Upgrade-Insecure-Requests |  客户端优先接受加密和有身份验证的响应，支持CSP | Upgrade-Insecure-Requests: 1|
|User-Agent | 用户代理 | User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36|
|Vary | 缓存策略 | Vary: User-Agent 常用于自适应缓存配置和 SEO|


|**响应头**|**描述**|**示例**|
|:----|:----|:----|
|Cache-Control| 缓存机制 | Cache-Control: public, max-age=3600|
|Connection | 是否持久连接 | Connection: keep-alive|
|Content-Encoding | 内容编码方式 | Content-Encoding: br|
|Content-Type | 内容的MIME类型 | Content-Type: text/html; charset=UTF-8|
|Date | 报文创建时间 | Date: Sun, 28 Feb 2021 11:52:51 GMT|
|Expires | 资源过期时间 | Expires: Sun, 28 Feb 2021 12:52:51 GMT|
|ETag | 资源标识符 | ETag: "56a88df57772gt555gr5469a32ee75d65dcwq989"|
|Set-Cookie | 服务端向客户端发送Cookie | Set-Cookie: __yjs_duid=1_7a24a73cae0e4926e7604ec1fd9277eb1614513171854; expires=Tue, 30-Mar-21 11:52:51 GMT; Path=/; Domain=baidu.com; HttpOnly|

### 什么是 HTTPS，与 HTTP 的区别？
（1）什么是 HTTPS？  

HTTPS 的全称是 Hyper Text Transfer Protocol over SecureSocket Layer，基于安全套接字协议 SSL，提供传输加密和身份认证保证传输的安全性，通过证书确认网站的真实性     

HTTP2.0 和 HTTP3.0 都只用于 `https://` 网址  

（2）HTTPS 三次握手 
![image.png](https://pic.leetcode-cn.com/1642581112-NFaeeu-image.png)
① Client Hello：客户端将支持 SSL 版本、加密算法、密钥交换算法等发送服务端  

② Server Hello：服务端确定 SSL 版本、算法、会话 ID 发给客户端  

③ Certificate：服务端将携带公钥的数字证书发给客户端  

④ Server Hello Done：通知客户端版本和加密套件发完，准备交换密钥  

⑤ Client Key Exchange：客户端验证证书合法性，随机生成 `premaster secret` 用公钥加密发给服务端  

⑥ Change Cipher Spec：通知服务端后续报文采用协商好的密钥和加密套件  

⑦ Finished：客户端用密钥和加密套件计算已交互消息的 Hash 值发给服务端。服务端进行同样计算，与收到的客户端消息解密比较，相同则协商成功  

⑧ Change Cipher Spec：通知客户端后续报文采用协商好的密钥和加密套件   

⑨ Finished：服务端用密钥和加密套件计算已交互消息的 Hash 值发给服务端。客户端进行同样计算，与收到的服务端消息解密比较，相同则协商成功 

（3）HTTP 与 HTTPS 对比   

|**项目**|**HTTP**|**HTTPS**|
|:----|:----|:----|
|默认端口 | 80 | 443|
|HTTP 版本 | 1.0 - 1.1 | 2 - 3|
|传输 | 明文，易被劫持 | 加密，不易劫持|
|浏览器标识 | 不安全 | 安全|
|CA 认证 | 不支持 | 支持|
|SEO | 无优待 | 优先|

### 对比 HTTP1.0 / HTTP1.1 / HTTP2.0 / HTTP3.0？
**HTTP1.0**  

无状态，无连接的应用层协议

* 无法复用连接
    每次发送请求，都要新建连接  
* 队头阻塞
    下个请求必须在上个请求响应到达后发送。如果上个请求响应丢失，则后面请求被阻塞
    **HTTP1.1**  

HTTP1.1 继承了 HTTP1.0 简单，克服了 HTTP1.0 性能上的问题  

* 长连接
    新增 `Connection: keep-alive` 保持永久连接
* 管道化
    支持管道化请求，请求可以并行传输，但响应顺序应与请求顺序相同。实际场景中，浏览器采用建立多个TCP会话的方式，实现真正的并行，通过域名限制最大会话数量
* 缓存处理
    新增 `Cache-control`，支持强缓存和协商缓存
* 断点续传
* 主机头
    新增 `Host` 字段，使得一个服务器创建多个站点  
    

**HTTP2.0**  

HTTP2.0进一步改善了传输性能

* 二进制分帧
    在应用层和传输层间增加二进制分帧层
* 多路复用
    建立双向字节流，帧头部包含所属流 ID，帧可以乱序发送，数据流可设优先级和依赖。从而实现一个 TCP 会话上进行任意数量的HTTP请求，真正的并行传输
* 头部压缩
    压缩算法编码原来纯文本发送的请求头，通讯双方各自缓存一份头部元数据表，避免传输重复头
* 服务器推送
    服务端可主动向客户端推送资源，无需客户端请求
    **HTTP3.0**  

当一个 TCP 会丢包时，整个会话都要等待重传，后面数据都被阻塞。这是由于 TCP 本身的局限性导致的。HTTP3.0 基于 UDP 协议，解决 TCP 的局限性  

* 0-RTT
    缓存当前会话上下文，下次恢复会话时，只需要将之前缓存传递给服务器，验证通过，即可传输数据
* 多路复用
    一个会话的多个流间不存在依赖，丢包只需要重发包，不需要重传整个连接
* 更好的移动端表现
    移动端 IP 经常变化，影响 TCP 传输，HTTP3.0 通过 ID 识别连接，只要 ID 不变，就能快速连接
* 加密认证的根文
    TCP 协议头没有加密和认证，HTTP3.0 的包中几乎所有报文都要经过认证，主体经过加密，有效防窃听，注入和篡改
* 向前纠错机制
    每个包还包含其他数据包的数据，少量丢包可通过其他包的冗余数据直接组装而无需重传。数据发送上限降低，但有效减少了丢包重传所需时间

### Cookie 和 Session 的区别？
难度：★ ★ ★ ☆ ☆      
面试高频指数：★ ★ ★ ★ ☆     
|**项目**|**Cookie**|**Session**|
|:----|:----|:----|
|存取值类型 | 字符串 | 大多数类型|
|存取位置 | 客户端 | 服务端，sessionId 非主动传参时，依赖 Cookie|
|存取方式 | 文件 | 文件、内存、关系或非关系型数据库等|
|大小 | 受客户端限制 | 自行配置|
|过期时间 | 写入时设置，用户可清除 | 自行配置，用户可清除对应Cookie，服务端自动清除过期 Session|
|兼容性 | 需浏览器开启，用户同意 | 不依赖 Cookie 时，通过 Get 或自定请求字段传入|
|作用范围 | 可设置跨子域，不可跨主域 | 用户身份唯一标识符不变时，可跨域，跨服务器。默认受限于 Cookie，仅限会话期间有效|


## 存储


### 什么是在线和离线事件 ？
navigator.online 被用来标识当前的网络状态， `true` 为连通， `false` 为离线

* 当 navigator.online 从  `false`  到  `true` ，触发  `online` 在线事件
* 当 navigator.online 从  `true` 到  `false` ，触发  `offline` 离线事件
早期浏览器不同版本，对离线的标准实现存在差异，如有的浏览器存在脱机模式，被认为是在线状态，从 Firefox 41，IE 9，Chrome 14 和 Safari 5 起，绝大多数浏览器实现趋于一致，该状态和相应的事件都与真实网络状态相关

由于不同网站，域名解析，服务器及网关、应用防火墙等的存在，该属性及在线事件，不能表示用户可以访问某网站。实际的可访问性，仍然依赖发送到指定网站的请求来判断，对于跨域的情况，可以请求图片，CSS 或 JS，测试连通性。如果是插件，可以在 manifest.json 的 host_permissions 中添加需要跨域的网站主机头

```javascript
/** 在线事件 */
window.addEventListener('online',  () => console.log('online'))
/** 离线事件 */
window.addEventListener('offline',  () => console.log('offline'))
```

### 什么是 Service Worker？
* Web 应用程序、浏览器与网络之间的代理服务器
* 拦截网络请求，并根据网络采取适当动作，更新服务器资源
* 完全异步，不阻塞 JavaScript 线程，不能访问 DOM
* 提供入口以推送通知和访问后台同步 API
* 用于离线缓存，后台数据同步，响应来自其它源的资源请求，集中接收成本高的数据更新

### 什么是持久化存储 ？
持久化是将数据从瞬时状态转换为持久状态，通常是将内存中的数据模型转换为存储模型，根据持久化的作用域，持久化分为：

* 会话持久化：在网页会话或浏览器标签处于活动状态时，保留数据。
    * 例如：Session Storage API
        * 会话在浏览器打开期间保持，不受重新加载或恢复页面的影响
        * 在新标签或窗口打开页面时，会复制顶级浏览会话的上下文作为新会话的上下文
        * 打开多个相同 URL 的 Tabs 页面，创建各自 sessionStorage
        * 关闭浏览期窗口或标签，清除 sessionStorage
        * 缓存上限值一般为 5MB / 域名 左右
* 设备持久化：在跨会话、浏览器标签和窗口，在设备中保留数据
    * 例如：Cache API
        * Cache 接口以 URL 作为键名，将 Response 作为键值缓存
        * 缓存长期有效，需开发者手动设计清理逻辑
        * 缓存上限值按域名限制，浏览器自动管理，必要时，将全部删除某个域名下的缓存
* 全局持久化：跨会话、浏览器标签和窗口，跨设备，在云端保存设备
    * 例如：Web Extension Storage API 的  `storage.sync` 方法
        * 用户数据可以与浏览器账号自动同步
        * 即使使用隐身模式，用数据也可以保留
        * 异步读写
        * 存储对象，不需要转换为字符串

### 什么是 IndexedDB API ?
IndexDB 是事务型数据库系统，是基于 JavaScript 的面向对象数据库，通过索引实现对数据的高性能搜索。客户端处于离线状态，可以访问 IndexDB 存储的数据，其用于在客户端持久化存储大量的结构化数据，支持结构化克隆算法支持的类型：

* 原始类型（不含 Symbols ）
* Boolean 对象
* String 对象
* Date 对象
* RegExp 对象（不保留 lastIndex 字段）
* Blob 对象（二进制文件对象）
* File 对象
* FileList 对象
* ImageData 对象
* Array 对象
* ArrayBuffer 对象（通用、固定长度的二进制数据缓冲区）
* TypedArray 对象 （类型化数组）
* Object 对象 （包括对象字面量）
* Set 对象
* Map 对象
不支持类型：

* Error 对象
* Funtion 对象
* DOM 节点
* 原型链上的属性和方法
使用 IndexDB 创建数据仓库，添加索引，通过事务，增、删、查、改的代码示例：

```javascript
const datas = [
  { name: 'shon', phone: '13010001000' },
  { name: 'shon', phone: '13010001001' },
  { name: 'carl', phone: '13010001002' },
]
const request = indexedDB.open('leetcodeDB', 1) // 创建名为 leetcodeDB 数据库，版本号为 1
request.onerror = e => { // 数据库错误回调，底层如事务错误，也会冒泡到这里
  console.log(e.target.error) // 输出错误
}
request.onsuccess = e => { // 数据库打开 / 创建成功时回调
  const db = e.target.result // 保存数据库接口
  run(db)
}
request.onupgradeneeded = e => { // 数据库更新时回调
  const db = e.target.result // 保存数据库接口
  const store = db.createObjectStore('member', { keyPath: 'phone' }) // 创建会员仓库，使用手机号作为 keyPath （类似关系型数据库的主键）
  store.createIndex('name', 'name', { unique: false }) // 将名称作为非唯一索引
  store.transaction.oncomplete = () => run(db)
}
const run = db => {
  const transaction = db.transaction('member', 'readwrite')
  const memberStore = transaction.objectStore('member')
  /** 增 */
  datas.forEach(data => memberStore.put(data)) // 将数据逐条插入数据仓库
  transaction.oncomplete = () => {
    const memberStore = db.transaction('member', 'readwrite').objectStore('member')
    /** 删 */
    memberStore.delete('13010001001').onsuccess = () => {console.log('delete success')}
    /** 查 */
    memberStore.get('13010001000').onsuccess = e => console.log(e.target.result.name) // 输出：shon
    /** 改 */
    memberStore.get('13010001002').onsuccess = e => {
      e.target.result.name = 'shon' // 修改名称 carl -> shon
      memberStore.put(e.target.result).onsuccess = () => {
        /** 搜索 */
        const index = memberStore.index('name') // name 之前已经添加索引
        index.openCursor(IDBKeyRange.only('shon'), 'prev').onsuccess = e => { // 倒序搜索名称 shon
          const cursor = e.target.result
          if (cursor) {
            console.log(cursor.value.phone) // 依次输出手机号：13010001002 13010001000
            cursor.continue()
          }
        }
      }
    }
  }
}
```
输出如图：
![image.png](https://pic.leetcode-cn.com/1642581680-tIaHpz-image.png)

### 什么是 Web Storage API ?
Web Storage API 是浏览器提供用来替代 Cookie 更直观，容量更大，更节省请求带宽的在客户端存取键值对类型数据的接口

Web Storage API 提供两种机制

* sessionStorage 存储区域根据域名隔离，该区域仅在页面会话期间可用。在浏览器实现了 WindowSessionStorage 对象挂载到 Window 对象的 sessionStorage 属性
* localStorage 存储区域根据根据域名隔离，除非用户操作，不会主动清空。在浏览器实现了 WindowLocalStorage 对象挂载到 Window 对象的 localStorage 属性
Web Storage API 提供的存储上限值：

* 现代浏览器一般是 5M 左右
* Firefox  45 起，浏览器崩溃或重启时，上限将限制为 10 M
* 手机QQ、手机QQ浏览器、微信一般是 2M - 5M
* iOS 5.1 起，Safari 移动版将 localStorage 数据存储在缓存文件夹，空间不足时会偶尔清理
Web Storage API 提供  `1` 属性和  `5` 方法

* 属性
 `.length` 表示存储在 Storage 对象中的数据项的数量

* 方法
 `.key(key)` 返回存储对象中第 key 项的键名，key 即索引，顺序由客户端实现

 `.getItem(keyName)` 返回存储对象中键名为 keyName 对应的值

 `.setItem(keyName, keyValue)` 创建或更新存储对象中键名为 keyName 的值为 keyValue

 `.removeItem(keyName)` 从存储对象中删除键名为 keyName 的数据项，如果该键名不存在，则什么都不做

 `.clear()` 清空存储对象中的所有键名及其对应的数据项

### 什么是 Cache API?
Cache API 以 URL 为键名，Response 为键值，为请求和响应提供缓存

* Cache API 可以在浏览器 window 下使用，也可以配合 Service worker 使用
* Cache API 存储的数据无法自动过期，开发者需要自行设计过期的逻辑
* Cache API 存储上限值按域名限制，浏览器自动管理，必要时将全部删除某个域名下的缓存
* Cache API 使用前，需要通过 CacheStorage API 返回 resolve 为 Cache 对象的 Promise
    * Caches.open(cacheName) 打开，若不存在则创建指定  `cacheName` 的 Cache，Cache 作为返回 Promise 的 resolve
    * Caches.has(cacheName) 检查指定  `cacheName` 的 Cache 是否存在，是否存在的布尔值作为返回 Promise 的 resolve
    * Caches.match(request, options) 在全局 Caches 按创建顺序查找第一个匹配 `request` URL 的 response 作为返回 Promise 的 resolve
    * Caches.delete(cacheName) 查找指定  `cacheName` 的 Cache
        * 找到，删除 Cache，返回  `true` 作为返回 Promise 的 resolve
        * 找不到，返回  `false` 作为返回 Promise 的 resolve
    * Cache.keys() 在全局 Caches 按创建顺序返回所有 Cache 对象的 CacheName 数组作为返回 Promise 的 resolve
* Cache API 提供的方法包括
    * Cache.match(request, options) 按添加顺序查找第一个匹配请求 `request` URL 的响应  `response` 作为返回 Promise 的 resolve
        *  `options` 选项
            * ignoreSearch 是否忽略查询字符串，默认值  `false` 
            * ignoreMethod 是否忽略方法 （GET / HEAD），默认值  `false` 
            * ignoreVary 是否忽略 Vary 头，默认值  `false`
    * Cache.matchAll(request, options) 匹配请求 `request` URL 的响应  `response` 数组作为返回 Promise 的 resolve
        *  `options` 选项
            * ignoreSearch 是否忽略查询字符串，默认值  `false` 
            * ignoreMethod 是否忽略方法 （GET / HEAD），默认值  `false` 
            * ignoreVary 是否忽略 Vary 头，默认值  `false`
    * Cache.add(request) 请求`request` URL，检查  `response.status` 
        * 等于 200，以 URL 为键名，响应  `response` 为键值，添加到 Cache
        * 不等于 200 不添加
        * 无需等待响应体流式传输完成
        * 仅在 GET 请求可用
        * `undefined` 作为返回 Promise 的 resolve
    * Cache.addAll(requests) 请求  `requests` URL 数组，检查  `response.status` 
        * 等于 200，以每个 URL 为键名，响应 `response` 为键值，添加到 Cache
        * 不等于 200 不添加
        * 无需等待响应体流式传输完成
        * 仅在 GET 请求可用
        * `undefined` 作为返回 Promise 的 resolve
    * Cache.put(request, response) 
        * 以  `request` URL 为键名，指定  `response` 为键值，添加到 Cache
        * 可以不检查  `response.status` 
        * 无需等待响应体流式传输完成
        * 仅在 GET 请求可用
        *  `undefined` 作为返回 Promise 的 resolve
    * Cache.delete(request, { options }) 
        * 以  `request` URL 为键名，查找 Cache
            * 找到，删除，返回 `true` 作为返回 Promise 的 resolve
            * 找不到，返回`false` 作为返回 Promise 的 resolve
        * `options` 选项
            * ignoreSearch 是否忽略查询字符串，默认值  `false` 
            * ignoreMethod 是否忽略方法 （GET / HEAD），默认值  `false` 
            * ignoreVary 是否忽略 Vary 头，默认值  `false`
    * Cache.keys(request, options)
        * 以  `request` URL 为键名 或者 不传查找全部，查找 Cache
        * Cache 数组作为返回 Promise 的 resolve

### 对比 Cookie、LocalStorage、SessionStorage、Session、Toke
Cookie

* 保存位置：客户端
* 生命周期：expires 前有效，不设置 会话期间有效
* 存储大小：一般 4KB
* 数据类型：字符串
* 特点：
    * 请求头 cookie ，同域名每次请求都附加
    * 响应头 set-cookie 设置  cookie
    LocalStorage

* 保存位置：客户端
* 生命周期：不清空缓存，一直有效
* 存储大小：一般 5MB
* 数据类型：字符串
SessionStorage

* 保存位置：客户端
* 生命周期：会话期间有效
* 存储大小：一般 5MB
* 数据类型：字符串
Seesion

* 保存位置：服务端，sessionid 存在 cookie 或 跟在 URL 后
* 生命周期：默认 20分钟，可更改。清空 cookie 或 更改 URL 传参，影响 Session
* 存储大小：不限制
* 数据类型：字符串、对象、数组，序列化后以字符串存储
Token

* 保存位置：客户端 Cookie / WebStorage / 表单 等
* 生命周期：根据存储位置决定
* 存储大小：根据存储位置决定
* 数据类型：字符串
* 组成
    * uid 用户身份标识
    * time 时间戳
    * sign 签名
    * 其他参数
    JWT - JSON  Web Token

* 特点
    * 将部分用户信息存储本地，避免重复查询数据库
* 组成
    * Header（头部）
        * alg 表示签名的算法，默认是 HMAC SHA256 (HS256)
        * typ 表示令牌的类型，JWT
    * Payload（负载）
        * 7个官方字段
            * jti 编号
            * iss 签发人
            * sub 主题
            * aud 受众
            * exp 过期时间
            * nbf 生效时间
            * iat 签发时间
        * 私有字段
            * name 姓名
            * admin 是否管理员
    * Signature（签名）
        * secret 密钥
        * 使用指定 alg 签名算法，生成签名
            * HMAC SHA256(btoa(Header) + '.' + btoa(Payload), secret)
    * 算出签名


## 性能


### JavaScript 垃圾回收机制
* 内存分配回收是自动的，垃圾回收器定时找出不再使用的数据，释放内存空间
* 两种回收检测模式
    * 引用计数：清除没有任何引用指向的数据。无法处理循环引用。IE6使用
    * 标记清除：标记可达数据，清除不可达数据。可处理循环引用。现代浏览器广泛使用
        * 从根出发：包括 全局变量、本地函数的局部变量、参数、调用链上其它函数的局部变量和函数等
        * 标记相连的对象为可达和访问过
        * 直到引用链上没有未访问过的对象为止
        * 删除没有被标记过，即不可达对象
* 标记清除的优化：标记清除存在 内存不连续，回收效率低，偶尔卡顿 的缺点
    * 只在CPU空间时进行
    * 分代回收：
        * 新生代：存活时间短，新生或经过一次垃圾回收的对象
            * 复制：复制 From 的可达对象 到 To 空间，释放 不可达对象
                * 晋升：复制时，To 空间使用超过 25%，晋升到 老生代
            * 交换：交换 From 和 To 空间
        * 老生代：存活时间长，经过一次被晋升或多次垃圾回收的对象
            * 标记清除
            * 标记整理：清除阶段先整理，将可达对象连续放置一起，再释放之外的内存
            * 增量标记：用增量标记代替全暂停，在回收间歇执行应用逻辑，避免卡顿

### 详解标记整理算法
* 标记完成
* 存活对象向内存空间一端移动
* 移动完成，清理掉边界外的所有内存

### 前端常见的内存溢出途径，如何避免？
占用内存且无法被垃圾回收机制回收对象，容易导致内存溢出（泄漏），让应用程序占用本应回收或不需要占用的内存

* 意外的全局变量：全局变量是标记清除中的「根」，除非定义为空 或 重新分配，不可回收
    * 非严格模式下，没有使用 var let const 声明的变量
    * 挂载在 this 下的属性
    避免：尽量不使用全局变量，在 JavaScript 头部使用严格模式

* 未清除的计时器
    * setInterval 自身及其回调函数内的对象，即使不被引用，也需要计时器停止才能清除
    避免：使用 requestAnimationFrame / setTimeout + 递归 代替 setInterval，并设置边界

* 删除不完全的对象
    * addEventListener 监听的对象已不可达，但监听没有移除。现代浏览器会自动移除
    * JS 中引用了 DOM 对象，对象已从 DOM Tree 中移除，但 JS 中依旧保持引用
    避免：

    * 移除对象前，移除监听。需大量监听对象，使用事件代理监听父元素
    * 移除 DOM 后，设置引用该 DOM 的变量为空
* 闭包中未使用函数引用了可从根访问的父级变量
```javascript
var global = 0
function closure () {
  let fromGlobal = global // 引用全局变量 global
  function unused () { // 闭包内不使用的函数
    if (fromGlobal) return // 引用父级变量 fromGlobal，导致 unused 占用内存
  }
  global = {} // 每次调用闭包 global 都会重新赋值
  /** 避免 **/
  fromGlobal = null
  closure()
}
```

### 如何诊断前端内存泄漏？
* 进入 Chrome 浏览器，打开要分析的网页和开发者工具
    * 切换到 Perfomance 面板
    * 勾选 Memory 选项
    * 点击圆圈录制按钮
    * 录制端一段时间，停止
    * 观察 JS Heap、Documents、Nodes、Listeners、GPU Memory 的数量是否有异常增长
* 发现异常增长，切换到 Memory 面板
    * 录制一个堆内存快照
    * 在页面上执行可能发生内存泄漏的操作
    * 再录制一个堆内存快照
    * 重复执行可能发生内存泄漏的操作
    * 最后录制一个堆内存快照
    * 选择最后一个堆内存快照，在右侧下拉菜单，选择 `Objects allocated between snapshots 1 and 2` 
* 通过对比，找到新生成或者没有释放的对象，点击可以看到堆栈信息，并定位其所在代码的位置


## SEO


### 前端中有哪些 SEO 优化手段？
## 文字

* 字号 14px 以上，16px 为宜，避免小于 12px，有行距、换行和段落
* 避免使用 visibility:hidden，display: none, 绝对定位，与背景相同颜色，堆砌关键词，隐藏主要内容

## 图片

* Logo 的 DIV 中写关键词，设置 text-ident 为负数隐藏
* 图片添加 width 和 height，避免读取元数据，再重排
* 图片添加 alt，描述图片内容，便于搜索引擎蜘蛛理解，提升可访问性
* 主要图片与内容相关，不要过长或过窄，正方形为宜
* 主要图片设置 src 属性，避免全部图片都使用懒加载
* 图片可以点击放大，多张图片间可以切换

## 适配

### 独立 H5 网站
* H5移动版与PC版域名不同，移动版子域名，推荐使用 m.x.com 等移动网站常用域名
* 向搜索引擎提交适配规则：PC版和H5移动版组成一一对应的URL对或正则匹配关系
* 不同域名，使用不同蜘蛛抓取
### 代码适配
* H5 移动版和PC版域名相同，返回代码不同
* 后端根据 User-Agent，返回不同的代码
* 添加响应头：Vary: User-agent
* 同一URL，蜘蛛应使用不同UA或不同蜘蛛多次抓取
### 自适应
* H5 移动版和PC版 域名相同，返回代码相同
* 前端通过相对单位、媒体查询、srcset 实现响应式或自适应布局
* 同一URL，蜘蛛可以只抓取一次

## SSR：Server Side Render 服务端渲染


## 安全


### 什么是帆布指纹？
**目标**：追踪用户
**背景**：移动互联网 IP 经常变化，用户禁用 cookie
**解决**：
**Canvas Fingerprinting**
* 不通过 cookie
* 用户不易屏蔽

**手写代码**

```JavaScript []
const canvas = document.createElement('canvas')
const ctx = canvas.getContext('2d')
const txt = 'canvasfingerprinting'
ctx.fillText(txt, 0, 0)
const b64 = canvas.toDataURL().replace('data:image/png;base64,', '') // 返回一个包含图片的 data URI，并替换 Mine-type，返回 base64 编码
const bin = atob(b64) // 函数能够解码 base64 编码的字符串数据
const canvasFingerprinting = bin2hex(bin.slice(-16, -12)) // 将 Unicode 编码转为十六进制
```

**fingerprintJS2 / fingerprintJS**

除 canvas 外，加入其它影响因素：

* navigator.userAgent 用户代理
* navigator.language 用户语言
* screen.colorDepth 屏幕色彩信息
* screen.height / screen.width 屏幕宽度和高度
* Date().getTimezoneOffset() 格林威治时间与本地时间时差
* seesionStorage 是否支持 sessionStorage
* localStorage 是否支持 localStorage
* indexedDB 是否支持 indexedDB
* addBehavior 是否支持 document.body.addBehavior IE5 属性
* openDatabase 是否支持调用本地数据库
* cpuClass 浏览器所在系统的 CPU 等级
* navigator.platform 客户端操作系统
* doNotTrack 是否支持 Do not  track 功能
* Flash plugin / Adobe PDF reader / QuickTime / Real players / ShockWave player / Windows media player /  Silverlight / Skype

### 对比各种分布式 ID 的生成方式？
## UUID

* 生成简单，本地生成
* 无序，无意义

## 数据库自增ID

* `auto_increment` 实现简单，单调自增，查询快
* 数据库服务器宕机风险
    * 使用 SELECTLAST_INSERT_ID() 代替 `max(id)` 提高高并发时的查询效率
    * 不同数据库服务器，设置不同自增起始值和步长

## 数据库自增ID段

```sql
CREATE TABLE ids_increment (
  type int(8) NOT NULL COMMENT '业务类型',
  max_id int(8) NOT NULL COMMENT '当前业务的最大ID',
  step int(8) NOT NULL COMMENT '当前业务的ID段步长',
  version ini(8) NOT NULL COMMENT '当前业务的版本号，每次分配 +1，乐观锁'
)
```

## Redis

* `set` 字段的初始值 `incr` 该字段，每次 `+1`
* 使用 `RDB` 定时持久化
* 使用 `AOF` 命令持久化

## 雪花算法

* 64 位 ID：符号位（1 位） + 时间戳（41 位）  + 机器 ID（5 位） + 数据中心 ID（5 位）+ 自增值（12 位）

### 列举各种跨域方法
## （1）跨域

协议、域名、端口不同，需要跨域

## （2）跨域解决方案

### jsonp：JSON with Padding
* <script> 标签没有同域限制
* 服务端返回页面上 callback 包裹的 json 数据
* 兼容性好
* 仅支持 GET

### CORS：Cross-origin resource sharing 跨域资源共享

#### 请求类型：
**简单请求** ：
满足以下 2 条件
* GET HEAD POST
* Content-Type
	* application/x-www-form-urlencoded
	* multipart/form-data
	* text/plain
** 复杂请求** ：
不满足以上2条件
	* 需发送 OPTION 预检请求，查询服务器支持的方法
**按请求类别处理** 

```JavaScript []
const express = require('express')
const app = express()
const whiteList = ['http://localhost']
app.use((req, res, next) => {
  const origin = req.headers.origin
  if (whiteList.includes(origin)) {
    // 允许访问源，附带凭证请求时，必须指定 URI。相反，可设置为 *
    res.setHeader('Access-Control-Allow-Origin', origin)
    // 允许请求头，逗号隔开
    res.setHeader('Access-Control-Allow-Headers', 'authorization, username')
    // 允许请求方法，逗号隔开
    res.setHeader('Access-Control-Allow-Methods'， 'GET, HEAD, POST, OPTIONS')
    /* 允许凭证
       客户端需配置 const xhr = new XMLHttpRequest()
       xhr.withCredentials = true */
    res.setHeader('Access-Control-Allow-Credentials', true)
    // 预检请求的返回结果，允许请求头和请求方法可以被缓存多久，缓存期间不再发送预检请求，单位秒
    res.setHeader('Access-Control-Allow-Max-Age', 10)
    // 允许响应头
    res.setHeader('Access-Control-Expose-Headers', 'authorization, username')
    if (req.method === 'OPTIONS') {
      res.end() // 预检请求直接返回空响应体
    }
  }
})
```

### postMessage
* window属性
* 跨窗口，跨框架`frame`、`iframe`，跨域
* 允许不同源脚本采用异步方式进行有限通信

```JavaScript []
otherWindow.postMessage(message, targetOrigin, [transfer])
// otherWindow:
iframe.contentWindow 属性
window.open 返回
window.frames 访问
window.onmessage = e => console.log(e.data) // 接收返回数据
```

### Websocket
* 基于 TCP
* 全双工通信
* 应用层协议

```JavaScript []
// 客户端
const socket = new WebSocket('ws://localhost:3000')
socket.onopen = () => socket.send('message') // 向服务器发送数据
soket.onmessage = e => console.log(e.data) // 接收服务器返回数据
// server.js
const express = require('express')
const app = express()
const ws = require('ws')
const wss = new ws.Server({port: 3000})
wss.on('connection', ws => {
  ws.on('message', data => console.log(data))
})
```

### 代理服务器转发
* 代理服务器设置 CORS 请求头字段
    * nginx
        * add_header
    * kangle
        * 回应控制，增加表，标记模块，add_header
    * nodejs
        * response.writeHead
* 代理服务器向源服务器继续请求
    * nginx
        * 七层 HTTP 代理：配置 http

```shell
http {
  server {
    listen 80;
    location / {
      proxy_pass http://127.0.0.1:3000
    }
  }
}
```

四层 TCP 代理：配置 stream

```shell
steam {
  upstream proxyServer {
    server 127.0.0.1:3000;
  }
  server {
    listen 80;
    proxy_pass proxyServer;
  }
}
```

* kangle
    * 七层 HTTP 代理
        * 请求控制，增加表
        * 目标设置为代理
        * 匹配模块设置原域名和端口，标记模块设置目标域名和端口
* nodejs
    * 七层 HTTP 代理

```JavaScript []
const http = require('http')
http.request({
  host: '127.0.0.1',
  port: 3000,
  url: '/'
})
```

### document.domain
* 主域名相同，子域名不同
* 设置值为 主域名
### iframe
* window.name
    * 不超过 2MB
    * 同一个iframe
        * 加载跨域页，跨域页设置 window.name
        * 加载同域页，读取 iframe.contentWindow.name
* location.hash
    * 不会被 URL 编码
    * 加载跨域页，参数跟在 `#` 后。window.onhashchange 监听 hash 变化
    * 跨域页获取 location.hash，加载同域页，参数跟在 `#` 后
    * 同域页设置  window.parent.parent.location.hash = location.hash，将参数回传

### 什么是点击劫持，如何防御 ？
点击劫持，通常会使用透明的  `<iframe>` 元素链接被攻击网站，并将其覆盖在恶意页面之上，诱导用户点击恶意页面上某个元素，而实际点击的是被攻击网站的某个元素。引导用户在不知情的情况下，与被攻击网站发生交互，劫持用户的点击、Cookie、以及自动填充的密码或拖拽的文件等

防御点击劫持的核心是禁止页面被嵌套，或禁止页面在嵌套时被点击、响应拖拽，共享 Cookie

* 禁止页面被嵌套
    * 使用 JavaScript
```javascript
if (top != window) top.location = window.location
```
* 原理：当页面被嵌套时，自动跳转到当前页面
* 局限性（以下场景失效，下同）：
    * 禁用 JavaScript 
    * 在恶意页面监听  `onbeforeunload` 事件，当用户点击否，停止退出
    * 设置  `iframe` 的  `sandbox` 属性，将 iframe 沙箱化，不添加  `allow-top-navigation` 禁止其更改  `top.location` , IE 10 + 兼容 
* X-Frame-Options
    * 原理：禁止页面被嵌套，或者设置页面可被嵌套的策略
    * 局限性：
        * 老版本浏览器不兼容
        * 善意第三方将无法嵌套网页
* 设置 Cookie 的  `SameSite` 属性 
    * 原理：`iframe` 嵌入被攻击网页，Cookie 不会被发送
        * 值为  `Lax` 时，当前网页的 top.location.href 与请求 URL 不同域时，除链接、预加载请求、GET表单外，不发送 Cookie
        * 值为  `Strict` 时，当前网页的 top.location.href 与请求 URL 不同域时，始终不发送 Cookie
    *  局限性：
        * 老版本浏览器不兼容
            * Chrome 84 / Firefox 69 起的默认 `SameSite=Lax`，Chrome 较宽松，因为其允许在顶级 POST 请求上发送某些 Cookie
* 拦截点击
    * 原理：使用一个透明层，在  `top != window` 时，覆盖整个网页，拦截点击
    * 局限性：
        * 禁用 JavaScript
        * 影响 SEO，可能会被认为故意遮主体内容，作弊
        * 善意嵌套也会触发拦截

### 如何提高 iframe 嵌入内容的安全性 ？
* 采取防止点击劫持措施
    * 声明  `X-Frame-Options` 的属性：`deny`  `sameorigin`  `allow-from` 来源
    * 当页面被嵌套时，弹出透明的层覆盖文档，阻止用户与文档上的元素交互
    * 设置 Cookie 的  `SameSite` 属性，页面被嵌套时无法读取直接打开时的 Cookie
* 使用 HTTPS
    * HTTPS 由 HTTP + SSL 协议构建，可进行加密传输、身份认证，比 HTTP 安全性高
    * 现代浏览器安全策略限制 HTTPS 下不能使用  `<iframe>`  嵌入 HTTP 内容
    * HTTP 与 HTTPS 因协议不同，受同源策略限制
        * 互相嵌套时，HTTP 不能访问 HTTPS 内容，反之亦然
        * HTTPS 在 CA 机构签发证书时，需要验证域名所有权，伪造 HTTPS 同域几乎不可能
* 设置  `sandbox` 属性，使用沙箱运行  `<iframe>` 
    * 默认不设置具体值，即开启所有限制
    * 每一项限制用半角空格分隔
        * `allow-downloads-without-user-activation` 用户未激活时可以启动下载
        * `allow-forms` 允许提交表单
        * `allow-modals` 允许模态框
        * `allow-orientation-lock` 允许方向锁定
        * `allow-pointer-lock` 允许嵌入内容使用 Pointer Lock API 锁定指针
        * `allow-popups` 允许 `window.open` 弹窗
        * `allow-popups-to-escape-sandbox` 允许弹窗不受沙箱限制
        * `allow-presentation` 允许嵌入内容使用 Presentation API
        * `allow-same-origin` 不打开该项限制，所有加载网页视为跨域
        * `allow-scripts` 允许嵌入内容允许非弹窗外的脚本，与 `allow-same-origin` 一起使用，存在安全风险，即嵌入网页可能可以设置或删除  `sandbox` 属性
        * `allow-storage-access-by-user-activation` 用户激活时嵌入内容可通过 Storage Access API 访问父窗口的 Storage
        * `allow-top-navigation` 允许嵌入内容修改父窗口  `top.location` 
        *  `allow-top-navigation-by-user-activation` 用户激活时，允许嵌入内容修改父窗口  `top.location` 


* 配置 CSP 内容安全策略
    * 策略 `policy` 可以配置在响应头 `Content-Security-Policy` 
    * 策略 `policy` 可以配置在 `meta` 标签 `http-equiv="Content-Security-Policy"` 
    * 策略类型
        * `default-src` 默认策略，没有配置后面的策略时，采用的策略，必须
        * `img-src` 图片策略
        * `media-src` 多媒体策略
        * `script-src` 脚本策略
        * `style-src` 样式策略
        * `font-src` 字体策略
        * `object-src` 插件策略
        * `child-src` 框架
        * `connect-src` HTTP 连接策略
        * `workder-src` Worker 脚本策略
        * `manifest-src` Manifest 策略
        * `prefetch-src` 预加载或预渲染策略
    *   策略值
        * `self` 同源策略，关键字，用引号包裹
        * `none` 禁止加载任何外部资源，关键字，用引号包裹
        * 域名，泛域名（支持 `*` 通配符），网址（含协议头  `http://` 或  `https://` )，路径名，协议名
        * `report-uri` + 网址，向指定 URL 发送违例报告
            * 调试时，可以将策略 `policy` 配置到  `Content-Security-Policy-Report-Only` 响应头，只报告不应用策略
        * `script-src` 关键字，用引号包裹
            * `unsafe-inline` 允许 `<script>` 标签和事件监听函数
            * `unsafe-eval` 允许将字符串作代码执行，包含使用  `eval`  `Function`  `setTimeout`  `setInterval` 函数
            * `nonce-{token}` 允许  `<script nonce={token}></script>` 中代码执行
            * `{hash}` 允许  `<script>` 中的 `{hash}` 值相符的代码执行

### 什么是插件，为什么要使用 Web 技术代替插件 ？
（1）什么是插件？

插件，英文名为 plugin-in、plugin、add-in、addin、add-on、addon、extension。

插件是一种应用程序，通过应用程序自身与用户交互，为应用程序增加所需要的特定功能，减少应用程序自身的体积。

插件运行依赖于应用程序提供服务、接口，必须加载到应用程序或网络传输协议中，与应用程序交换数据。

应用程序本身不依赖于插件，可以独立运行，插件一般不会更改应用程序自身。

区别于插件，拓展不必通过应用程序自身与用户交互，可以有自己的独立界面。

（2）对于不同应用场景，插件有不同的具体含义

* 对于 Web 浏览器来说，插件是能够为浏览器自身无法读取的内容提供访问权限的软件，例如 Flash、PDF 等
* 对于电子邮件客户端，插件是用来加密和解密的软件
* 对于绘图软件，插件是用来支持不同文件格式、处理图片、支持自动化批量的软件
* 对于媒体播放器，插件是用来支持不同媒体格式的软件、提供视觉、音效等增强
* 对于集成开发环境，插件用来支持不同编程语言、提供文件系统、语法高亮、拼写检查、版本管理、终端等增强
（3）为什么要使用 Web 技术代替插件？

* 传统插件因安全隐患、移动端兼容、耗电、内存泄漏问题不再被支持
    * ActiveX：曾被 Microsoft 在 Windows 内置，被恶意网站利用安装病毒或后门，例如
        * Scripting.FileSystemObject 可操作新增或修改文件内容
        * WbemScripting.SWbemLocator 可操作 WMI 访问登录信息
        * WScript.Shell 可从浏览器之中直接运行外部可执行文件
        * Microsoft 在 2015 年 7 月 29 日发行 Windows 10，以不支持 ActiveX 的 Microsoft Edege 浏览器作为默认浏览器，作为可选浏览器的 Internet Explorer 11 于 2022 年 6 月 15 日退役
    * Flash：Adobe 在 2020 年 12 月 31 日之后不再支持 Flash Player，并且从 2021 年 1 月 12 日开始阻止 Flash 内容在 Flash Player 中运行，因此 Adobe 强烈建议所有用户立即卸载 Flash Player 以帮助保护他们的系统
* 信息平等、增强可访问性、利于搜索引擎收录
    * 通过插件提供访问权限的内容，需要用户安装插件，由于系统、配置、平台和地区等差异，用户能否平等访问信息，受到能否安装，运行插件的限制
    * 传统插件通过  `<embed>`  `<object>` 等嵌入浏览器，其内容不经特殊处理，无法在源代码中体现，这意味着依赖文档结构的读屏软件、搜索引擎蜘蛛无法读取这部分内容，从而无法正确地这部分内容建立索引，计算权重。这部分内容对于无法阅读或搜索引擎用户就像黑盒一样不可见
    * Flash: 可以通过为图形元素提供替代文本，允许用户按顺序阅读、键盘控制、提供字幕、控制音频播放、为导航添加说明、避免仅使用颜色区分不同信息等方式来增强可访问性，但不使用 Flash，或者使用 Adobe Animate CC 等按上述原则构建等效 HTML5 方案是更好选择
* HTML 5、CSS 3+ 模块化标准和 ES 6+
    * Microsoft Edge、Mozilla Firefox、Google Chrome、Apple Safari、Opera 等都支持 HTML5、CSS 3+ 模块化标准和 ES 6+
    * 现代浏览器的广泛普及以及自动更新的特性，允许开发者使用 Web 技术支持以前需要使用插件开发的功能
    * 需要更多本地权限或跨域，可以用 Web 技术实现的扩展或附加组件的形式提供给 Chrome 或 Firefox 等现代浏览器

### 什么是内容安全策略（CSP）？
（1）什么是内容安全策略（CSP）？

内容安全策略（Content Security Policy）是用于检测并削弱某些特定类型攻击的额外安全层

* 预防跨站脚本攻击（XSS - Cross Site Scripting）
    * 通过 CSP 设置信任的可执行脚本的来源
        * 可设置白名单  URL，域名，仅加载 https
        * 通过 token 或 hash 限制内联脚本等
* 预防数据包嗅探、中间人攻击和 HTTP 劫持
    * 通过 CSP 设置信任的资源的来源，必须使用 https 协议
        * HTTP 超文本传输协议位于 OSI 模型的第 7 层，传输以纯文本形式进行
        * HTTP 数据包可以被嗅探，容易遭受中间人攻击
        * HTTPS 流量经过加密
            * 即使嗅探到数据包或者以其他方式截取数据包
            * 它们也会呈现为无意义的字符
* 数据注入攻击
    * 通过 CSP 设置信任的资源的来源
        * 当数据注入发生后，阻止浏览器加载非法来源的数据
        （2）如何配置内容安全策略（CSP）？

* 策略 `policy` 可以配置在响应头 `Content-Security-Policy` 
* 策略 `policy` 可以配置在 `meta` 标签 `http-equiv="Content-Security-Policy"` 
* 策略类型
    * `default-src` 默认策略，没有配置后面的策略时，采用的策略，必须
    * `img-src` 图片策略
    * `media-src` 多媒体策略
    * `script-src` 脚本策略
    * `style-src` 样式策略
    * `font-src` 字体策略
    * `object-src` 插件策略
    * `child-src` 框架
    * `connect-src` HTTP 连接策略
    * `workder-src` Worker 脚本策略
    * `manifest-src` Manifest 策略
    * `prefetch-src` 预加载或预渲染策略
* 策略值
    * `self` 同源策略，关键字，用引号包裹
    * `none` 禁止加载任何外部资源，关键字，用引号包裹
    * 域名，泛域名（支持 `*` 通配符），网址（含协议头  `http://` 或  `https://` )，路径名，协议名
    * `report-uri` + 网址，向指定 URL 发送违例报告
        * 调试时，可以将策略 `policy` 配置到  `Content-Security-Policy-Report-Only` 响应头，只报告不应用策略
    * `script-src` 关键字，用引号包裹
        * `nsafe-inline` 允许 `<script>` 标签和事件监听函数
        * `unsafe-eval` 允许将字符串作代码执行，包含使用  `eval`  `Function`  `setTimeout`  `setInterval` 函数
        * `nonce-{token}` 允许  `<script nonce={token}></script>` 中代码执行
    * `{hash}` 允许  `<script>` 中的 `{hash}` 值相符的代码执行

### 什么是 XSS ，如何防范 XSS ？
（1）定义

通过 Web 开发留下的漏洞注入恶意代码，使用户加载并执行攻击者恶意制造的程序，与 Web 开发相关的 JavaScript，Java，VBScript，ActiveX，Flash 或 HTML 都可能被注入

攻击成功后，攻击者将得到更高权限、私密网页内容、会话和 Cookie

（2）分类

* DOM-based 型
    * 范围：客户端
    * 攻击方式
    文档对象模型（DOM）是 HTML 和 XML 文档的编程接口，它提供了对文档的结构化表述，并定义了一种方式，可以在程序中访问并操作该结构，从而改变文档结构，样式和内容

    设置属性或内容来自 Location 或 Document 接口或 Socket 接口等其它客户端传递 Message 的途径，未经过滤和转义，包含 JavaScript 脚本的恶意代码通过 URL 或 Referer 传入，被意外执行，轻则影响用户体验，客户端崩溃，重则用户数据被发送，身份被冒充用于滥发消息、投票、转账等进而引发社会工程学相关安全问题

    * 传递路径
Location 或 Document 接口 或 Socket 接口等其它客户端传递 Message 的途径  → 客户端

    * 传播方式
构造特殊 URL 或从特定或伪造来源发起请求，诱导用户访问或点击，一次性攻击

* 反射型 / 非持久型
    * 范围：客户端 + 服务端
    * 定义
    设置属性或内容来自后端，未经过滤和转义，包含 JavaScript 脚本的恶意代码通过 URL 或 Referer 传入，被意外执行，轻则影响用户体验，客户端崩溃，重则用户数据被发送，身份被冒充用于滥发消息、投票、转账等进而引发社会工程学相关安全问题

    * 传递路径
    Location 或 Document 接口 或 Socket 接口等其它客户端传递 Message 的途径  → 服务端 → 客户端

    * 备注
    与 DOM-based 的区别在于不需要服务端参与，服务端将恶意内容反射回客户端，即反射型攻击的命名来源

    * 传播方式
    构造特殊 URL 或从特定或伪造来源发起请求，诱导用户访问或点击，一次性攻击

* 存储型 / 持久型
    * 范围：客户端 + 服务端
    * 攻击方式
    设置属性或内容来自数据库或 Web 或 Extension 存储或 Cookie 中，未经过滤和转义，包含 JavaScript 脚本的恶意代码通过 URL 或 Referer 以及用户主动提交等方式传入，并被存入数据库或 Web 或 Extension 存储或 Cookie 中，读取后，被意外执行，轻则影响用户体验，客户端崩溃，重则用户数据被发送，身份被冒充用于滥发消息、投票、转账等进而引发社会工程学相关安全问题

    * 传递路径
    Location 或 Document 接口 或 Socket 接口等其它客户端传递 Message 的途径和用户主动提交 → 服务端  → 数据库 → 客户端 → 客户端

    Location 或 Document 接口 或 Socket 接口等其它客户端传递 Message 的途径和用户主动提交 → Web 或 Extension 存储或 Cookie → 客户端

    * 传播方式
寻找过滤和转义缺乏或不完善的提交及展示路径，将恶意 JavaScript 脚本代码经过处理，提交到存储引擎，攻击者通过读取存储引擎的展示路径，持久攻击

（3） 防御

① 限制输入（来源）

* 前端和后端同时校验数据长度、类型、格式是否符合预期
* 始终过滤嵌入内容，如  `iframe` `object` `embed` ，推荐始终过滤可执行代码，如 `<script>` ，`css` 中 `expression` 表达式和  `behavior` 属性，
* 建立黑白名单，过滤不需要的标签，属性，内容或者只保留符合预期的相应项目
* 在代理端、 服务器端、CDN 边缘节点、Web 服务器端、后台脚本端建立并维护 WAF 规则库或者购买相应安全防护服务，拦截以下请求：
    * 请求行：请求头，请求体包含敏感、恶意、垃圾内容
    * 请求来源：如 IP，用户代理，地区，代理 IP，Origin，Referer，Cookie，帆布指纹等来源标识无法相互印证，被伪造，已被标记为高风险或命中黑名单
    * 请求行为：如请求频率过高，短期大量请求敏感路径和参数，停留时间、请求总数、请求历史记录不符合真实用户，频繁索取权限，读取敏感数据，一次性 token 被重复使用，不回应验证码，验证问答，或多次验证失败
* 转义所有 UGC（用户生成内容），例如将 HTML 中预留字符转为字符实体
② 限制输出（渲染）

    * 始终避免将输入内容作为 HTML 渲染
        * 避免使用 `.innerHTML`  `.outerHTML` 和   `document.write()`  `document.writeln()` 
        * 避免在模板渲染引擎支持的模板中使用  `{{{}}}` 标签
        * 避免在框架，如 React 中使用  `dangerouslySetInnerHTML={ {__html:''}}` 和 Vue 中使用  `v-html` 等
        * 避免使用内联方式，添加事件监听属性，推荐使用`addEventListener()` 
        * 推荐使用  `.innerText` 或  `.textContent` 设置内容，属性直接操作 DOM 属性节点
    * 根据输入内容的渲染位置作相应限制
        * HTML 解析环境
            * 范围：HTML 标签、 HTML 属性
            * 限制：将 HTML 中预留字符转为字符实体
        * JavaScript 解析环境：
            * 范围：Script 标签、事件属性
            * 限制：将  `\` 添加额外 `\` 的转义，除字母及数字之外， `charCode` 小于及等于 127 的字符使用 `\x` + 16 进制编码，大于 127 使用 Unicode 编码
        * URL 解析环境
            * 范围：`href` 属性、 `src` 属性、 `srcset` 属性
            * 限制：使用  `encodeURI` 转义非 URL 保留字符，Mark 字符和大小写字母、数字以外字符
    * 避免执行远程代码
        * 避免在 Web 端使用  `eval()` 和  `new Function()` 执行远程代码
        * 避免在 Extension 端使用  `chrome.tabs.executeScript({code: '...'})` 和 `chrome.scripting.executeScript({code: '...'})`  执行远程代码
        * 推荐将所有远程代码（JS / Webassembly / CSS） 下载到本地使用
    * 使用黑白名单渲染
        * 根据上下文，只渲染需要的标签和属性，过滤危险标签和属性，转义需要但存在风险的标签和属性。例如，前后端都是 JavaScript 可以通过  `js-xss` 库实现
      ③ 鉴权

* 限制 Cookie 访问
    * 设置 `Secure` 属性，声明 Cookie 只能通过 HTTPS 协议传输，依然有可能通过访问客户端硬盘读取
    * 设置 `HttpOnly` 属性，声明 Cookie 只对服务端会话可用，无法通过`Document.cookie` 访问，有助于缓解依赖此接口的 XSS 的攻击
    * 设置  `SameSite` 属性
        * 值为  `Lax` 时，当前网页的 top.location.href 与请求 URL 不同域时，除链接、预加载请求、GET表单外，不发送 Cookie
        * 值为  `Strict` 时，当前网页的 top.location.href 与请求 URL 不同域时，始终不发送 Cookie
    *  使用预防点击劫持的方法，禁止网页被嵌入，或者嵌入时弹出空白层禁止用户操作
* 配置 CSP 内容安全策略
    * 配置 `style-src` `script-src` `img-src` `connect-src` `workder-src` `manifest-src` 等的  `self` 策略，只允许加载同源文件，与同域 URL 通信
    * 配置 `script-src` 
        * 避免使用 `unsafe-inline` 允许内联  `<script>` 和事件监听函数
        * 避免使用  `unsafe-eval` 允许使用  `eval` `Function` `setTimeout` `setInterval` 函数
        * 推荐使用 `nonce-{token}` 和  `{hash}` 策略，只允许  `token` 或  `hash` 一致的 `<script>` 标签执行
* 与预防 CSRF 的防御中的方法组合使用，避免 XSS + CSRF 扩大攻击
    * 校验 `Referer` 
    * 校验 `token` 
        * 前端生成令牌：混淆前端计算 `token` 的代码。计算算法容易被破解
        * 令牌同步模式：将  `token` 计算放入后端，前端只读取  `token` 值。容易被盗用
        * 令牌同步模式增强：将  `token` 计算放入后端，并绑定用户唯一标识符及使用环境。前端只读取  `token` 值，该  `token` 只能由绑定用户在指定环境中使用，一次性或自动过期。依然有破解的可能，容易误伤正常用户
    * 验证码、验证问答、验证语音、验证图片、生物识别等
        * `token` 校验的必要补充，在  `token` 校验失败时，避免影响用户，要求其验证
            * 一般操作，验证通过，在一定时间，一定次数内，不再重复验证
            * 敏感数据，风险操作，一个请求，一次验证
            ④ 业务侧

* 开发者
    * 建立网址安全云库或使用第三方的 API，禁止用户访问仿冒、钓鱼、恶意网站，对未知安全的网址提示用户不要输入敏感信息
    * 建立内容安全监控平台，深度学习大数据，定义参数，预测热门内容传播模型。对不符合传播规律，短期内异常传播的内容进行二次审查，减少 XSS 蠕虫、钓鱼的内容传播
* 用户
    * 推荐用户使用支持沙箱运行的现代浏览器，严格限制恶意脚本能够访问的内容，缩小被攻击时影响范围
    * 推荐用户使用带有 XSS Filter 的浏览器，如 Google Chrome
    * 推荐用户安装防病毒软件或者启用浏览器的安全功能，拦截仿冒、钓鱼、恶意网站

### 什么是 CSRF ，如何防范 CSRF ？
（1）定义：

CSRF，跨站请求伪造，英文全称为 Cross-site request forgery

盗用用户身份的唯一标识符，冒充用户，伪造来源，模拟用户行为，执行未经其授权的的操作

（2）分类：

* 基于 Cookie 的 CSRF
    * 通过 XSS 漏洞，在要攻击页面，注入 Script 脚本，通过  `document.cookie` 获取用户 Cookie，通过设置可有限跨域标签的属性，如 `<img>` 的  `src` 属性，或 `<iframe>` 的  `src` 属性， 或`<link>` 的  `href` 属性等，以及通过  `<embed>`  `<object>` 的  `src` 属性和引入插件自身的漏洞，将 Cookie 发送给第三方网站 
    * 通过 XSS 漏洞，在要攻击页面，注入 Script 脚本，同域下通过   `XHR`  `Fetch` 或上述设置标签属性的方式，发起恶意请求
    * 通过 XSS 漏洞，在要攻击页面所在域的其它存在漏洞的页面，注入 Script 脚本，通过  `<iframe>` 嵌入要攻击页面，通过  `contentDocument.cookie` 获取 Cookie，通过可有限跨域标签的属性、插件属性或漏洞，将  Cookie 发送给第三方
* 基于 Token 的 CSRF
    * Token 由前端生成：尝试使用第三方工具或者浏览器的控制台还原混淆后的代码。使用 Tampermonkey 或自行开发 Extension，注入 Script，恢复控制台的使用，清除或覆盖随机注入 Debugger 等其它干扰代码调试的定时器和 Observer。最终还原 Token 生成算法
    * Token 由后端生成：
        * 抓取网页源代码，使用正则或 DOM 解析（如 JSDOM 或 cheerio）方式获取 Token
        * 使用无头浏览器，如 PhantomJS 或 Headless Chrome 等模拟用户访问获取 Token
        * 使用 Webview 嵌入 Token 所在网页，通过 Webview API 获取 Token
* 基于帆布指纹的 CSRF
    * 对抗 Canvas 指纹
        * 重写  `HTMLCanvasElement.prototype` 的方法，伪造用户的 Canvas 指纹
    * 对抗浏览器指纹
        * 使用虚拟机 + 浏览器，仿造用户环境
        * 自行编译浏览器或使用候鸟浏览器等，伪造关键特征，如用户代理，系统、分辨率，WebRTC 指纹等
* 基于用户行为的 CSRF
        * 使用无头浏览器或 Webview，在客户端隐藏打开网页，模拟用户行为发起请求
        * 使用模拟器或按键精灵等软件，录制或开发脚本，在客户端模拟用户行为发起请求
    （3）防御

* 基于 Cookie 的防御
    * Cookie 设置 `Secure` 属性，声明允许 Cookie 通过 https 传输
    * Cookie 设置 `HttpOnly` 属性，声明  JavaScript 无法访问 Cookie
    * Cookie 设置 `SameSite` 属性
        * 值为  `Lax` 时，当前网页的 top.location.href 与请求 URL 不同域时，除链接、预加载请求、GET表单外，不发送 Cookie
        * 值为  `Strict` 时，当前网页的 top.location.href 与请求 URL 不同域时，始终不发送 Cookie
    * 替代 Cookie
        * 使用  Storage API 替代村存储原来需要 Cookie 存储到客户端的数据
        * 使用 token 替代 Cookie 作身份验证
* 基于来源的防御
  来源可以被伪造，且不同浏览器的实现存在差异，部分真实用户请求来源也被修改，容易误伤，故不推荐

    * 校验 Origin
        如果 Origin 不为空，判断  Origin 是否合法

        * IE 11 跨站请求，Origin 为空
        * 302 重定向请求，Origin 为空
        * 使用 Curl 或在非浏览器环境或特殊浏览器，自定义 HTTP 头，可伪造 Origin
        * 用户的 HTTP 请求被网关或代理修改，可伪造 Origin
    * 校验 Referer
        如果 Referer 不为空，判断 Referer 是否合法

        * IE 6/7 使用  `window.location.href` 或  `window.open` 跳转或打开 URL，Referer 为空
        * HTTPS 到 HTTP， Referer 为空
        * 插件跳转到网页，Referer 不确定
        * 使用 Curl 或在非浏览器环境或特殊浏览器，自定义 HTTP 头，可伪造 Referer
        * 用户的 HTTP 请求被网关或代理修改，可伪造 Referer
        * 用户出于正常需求，直接打开请求链接，或者使用第三方软件，如下载软件打开请求链接，Referer 为空
* 基于 Token 的防御
    * Token 的生成：后端生成随机密钥，输出到前端，前端获取密钥，按某算法生成 Token
        * 抓取源代码，仅能获取随机密钥，无法获得 Token
        * 还原了前端 Token 计算算法，依然需要获取随机密钥
    * Token 的使用：前端将帆布指纹发给后端，后端生成的随机密钥，绑定该指纹，并设置最大使用次数和过期时间
        * Token 与帆布指纹一一对应，从 A 环境获取的 Token，无法在 B 环境使用
* 基于帆布指纹的防御
    * 基于 AudioContext 声音指纹，生成跨浏览器帆布指纹，减少对容易伪造的参数依赖
    * 获取和使用 Token 时，都重新获取指纹，要求获取 Token 的指纹和使用  Token 的指纹一致
* 基于 CSP 内容安全策略的防御
    * 配置 `style-src` `script-src` `img-src` `connect-src` `workder-src` `manifest-src` 等的  `self` 策略，只允许加载同源文件，与同域 URL 通信
    * 配置 `script-src` 
        * 避免使用 `unsafe-inline` 允许内联  `<script>` 和事件监听函数
        * 避免使用  `unsafe-eval` 允许使用  `eval` `Function` `setTimeout` `setInterval` 函数
        * 推荐使用 `nonce-{token}` 和  `{hash}` 策略，只允许  `token` 或  `hash` 一致的 `<script>` 标签执行
*  基于验证码的防御
    * 对于能够获取的用于验证的信息有限，校验失败但可能存在误伤的请求，使用验证码、验证问题、图形验证、生物识别的方式，要求请求者手动验证合法性
        * 验证方式存在局限性
            * 图形验证码：可被图像识别，会使用软件截屏，传递给打打码平台人工验证
            * 验证问题：可建立验证问题和答案，会将问题传递给平台人工回答
            * 图形验证（标记图片、文字）：用户体验不佳
            * 图形验证改进版（旋转、点击图片，或拖拽滑块到空缺处）：基于操作方向、轨迹、速度，用户操作容易，体检较好
            * 生物识别：存在隐私风险，影响用户信任度
        * 一般操作，验证通过，在一定时间，一定次数内，不再重复验证
        * 敏感数据，风险操作，一个请求，一次验证


## 项目管理


### 您使用过哪些文档管理工具？
## API 接口协作管理工具
* Swagger
* Spring
* Apizza
## 文档协作工具
* 石墨文档
* 有道笔记 + 有道云协作
* 印象笔记
## 自动文档生成
* apiDoc：根据 API 描述，自动生成文档
* jsDoc：根据 JS 注释，自动生成文档

### 对比 Git 和 SVN？
## 架构
* Git：
    * 分布式，本地克隆版本库
    * 无网络依然可以操作分支，提交文件，查看历史记录
* SVN：
    * 集中式，代码一致性高
    * 依赖网络
## 存储
* Git：按元数据，即描述文件的数据
* SVN：按文件
## 分支
* Git：移动指针，创建切换快
* SVN：拷贝目录
## 权限
* Git：
    * 经常按项目配置
    * 更适合开源
* SVN：
    * 经常按目录配置
    * 更适合内部开发

### 什么是敏捷开发？
定义

* 以用户需求为核心，迭代、循序渐进的开发方法
* 大项目分成多个子项目，相互关联，可独立运行。整个开发过程中，软件保持可用
特点

* 增量开发，快速响应变化
    * 对比瀑布开发，客户可以很快看到基础版本，更新需求，作出响应
* 优先实现最低成本，最大收益需求
* 软件为目标，高效沟通 > 图 > 文档
技术实践

* 测试驱动开发 （Test-DrivenDevelopment）
    * 先编写单元测试用例，确保测试用例覆盖需求
    * 快速开发需求，通过测试用例
    * 已通过测试用例为前提
        * 重构代码，提升可读性、可维护性和性能
* 行为驱动开发 （BehaviorDriven Development）
* 持续集成 CI （Continuous Integration）
    * 开发提交新代码（提交合并请求 PR），立即构建、风格检查和单元测试
    * 只有构建成功，通过风格检查和单元测试的代码，才可被合并
* 持续部署 CD （Continuous Deployment）
    * 在持续交付的基础上，把部署到生产环境的过程自动化
    Sprint

* 一个迭代即一个 Sprint，每个 Sprint 包含 1 个及以上 Build 版本
* 过程
    * 第一步：需求分析，排优先级将需求放入 Sprint
    * 第二步：规划测试，确定需求如何测试，质量目标是什么
    * 第三步：测试用例及评审，确定测试目标和顺序，明确开发方向
    * 第四步：拉新分支，开发及自测
    * 第五步：冒烟测试，未通过打回改 bug，通过合并主分支
    * 第六步：产品或需求方验证后，确认发布
* 会议
    * Sprint 计划会议
    * 每日站会
    * Sprint 评审会议
    * Sprint 回顾会议

### 敏捷开发的原则是什么？
* 快速迭代
    * 大项目分成小项目，大版本分成小版本
    * 需求、开发和测试更加简单快速
* 需求分析
    * 产品、测试、开发，包括运营等参与，明确需求优先级，增强参与感
* 需求文档
    * 以“用户故事”方法编写需求文档
    * 需求文档专注需求，而不是技术
* 产品原型
    * 用草图和模型直观地描述用户界面
* 沟通
    * 每日站会，面对面沟通
* 测试优先
    * 开发前明确测试目标，范围，顺序和关键点
    * 撰写测试用例并评审
    * 推荐测试驱动开发的技术实践
        * 先写单元测试用例再开发
        * 先安祖需求再优化性能、可读性和可维护性


## 数据库


### 什么是乐观锁，什么是悲观锁
## 并发控制

* 需要保证并发情况下的数据准确性
* 保证一个用户的工作不会对另一个用户的工作产生不合理的影响
* 避免
    * 脏读：一个事务看见另一个事务未提交的数据
    * 不可重复读：一个事务两次读取到的数据内容不同，另一事务修改了数据
    * 幻读：一个事务两次读取到的数据条数不同，另一事物增删了数据

## 乐观锁：多读 适用

* 仅在数据提交更新时，检测数据冲突。冲突时，采用竞争机制
* 依靠数据本身来保证数据正确性，如添加字段 version

## 悲观锁：多写 适用

* 共享锁（读锁）：多个事务同一数据共享锁，只读不可写
* 排他锁（写锁）：一次仅一个事务可读写数据
    * 依赖数据库的锁机制，如 MySQL：select ... for update

### 什么是事务
## （1）定义

访问并可能更新数据库中数据项的一个程序执行单元（Uint）

一条 SQL、一组 SQL 和 整个程序都可以是事务

## （2）特点

* 原子性（atomicity）：不可分割，要么都做，要么都不做
* 一致性（consistency）：一个一致性状态变到另一个一致性状态
* 隔离性（isolation）：一个事务的执行不能被其他事务干扰，操作和数据使用不依赖和干扰其它并发事务
* 持久性（durability）：提交后的改变永久生效。不受故障或其它操作影响

## （3）在 Mysql 中使用事务

```sql
# 关闭自动提交
SET autocommit = 0
# 或者开始一个事务
BEGIN
若干SQL语句
# 提交事务
COMMIT 对数据库所有修改都永久生效
若干SQL语句
# 回滚事务
ROLLBACK 结束当前事务，撤销所有未提交的更改
# 设置保存点
SAVEPOINT id 创建名为 id 的保存点
# 回滚事务到保存点
ROLLBACK TO id 把事务回滚到保存标记点
# 设置事务的隔离级别
SET TRANSACTION InnoDB 存储引擎提供事务的隔离级别有
(1) READ UNCOMMITTED
(2) READ COMMITED
(3) REPEATABLE READ
(4) SERIALIZABLE 
```



# 算法


## 位运算


### 什么是原码、反码、补码？
原码、反码和补码，均有 **符号位** 和 **数值位** 两部分

符号位：用 0 表示正，用 1 表示负

在计算机系统中

* 数值一律用补码来表示和存储，好处
    * 符号位和数值位统一处理
    * 加法和减法统一处理

**正数**

* 原码：符号位 0
* 反码：与原码相同
* 补码：与原码相同

**负数**

* 原码：符号位 1
* 反码：符号位不变，数值位取反
* 补码：符号位不变，数值位取反 +1

**0**

* 原码：+0 0000 0000 -0 1000 0000
* 反码：+0 0000 0000 -0 1111 1111
* 补码：+0 0000 0000 -0 0000 0000 相同

### 位运算求绝对值？
数在计算机中，用补码表示

负数的补码 = 负数的原码 → 符号位不变，其余位取反，+1

```plain
-2
原码：1000 0010
反码：1111 1101
补码：1111 1110（反码加一，计算机实际存储的值）
取反：0000 0001
加一：0000 0010 = 2
```

解法一：根据符号位，正数返回本身，负数返回 取反 + 1

```plain
const abs = x => {
const y = x >>> 31 // 看符号位
return y === 0 ? x : ~x + 1
}
```

解法二：任何数与 -1 异或 ^ 运算，相当于取反。任何数与 0 异或 ^ 运算，还是本身

```plain
-1
原码：1000 0001
反码：1111 1110
补码：1111 1111
```

无符号右移

```JavaScript []
const abs = x => {
const y = x >>> 31
return (x ^ -y) + y
}
```

有符号右移

```JavaScript []
const abs = x => {
const y = x >> 31
return (x ^ y) - y
}
```


## 数组


### 去除数组中的指定元素
>输入：a = ['1', '2', '3', '4', '5', '6'] target = '4'
>
>输出：a = ['1', '2', '3', '5', '6']

**方法一**：

```JavaScript []
const removeByValue = (a, target) => {
	for (let i = 0; i < a.length; i++) {
		if (target === a[i]) {
			a.splice(i, 1)
		}
	}
	return a
}
```

**方法二**：

```JavaScript []
const removeByValue = (a, target) => a.splice(a.findIndex(v => v === target), 1)
```

**方法三**：

```JavaScript []
const removeByValue = (a, target) => {
	let j = 0, i = -1
	while (++i < a.length) {
		if (a[i] === target) i++
			a[j++] = a[i]
		}
	a.length--
	return a
}
```

### 数组去重方法
```JavaScript []
function unique (arr) {
	return Array.from(new Set(arr))
}
```

* Set 去重 + 扩展运算符 ...

```JavaScript []
function unique (arr) {
	return [...new Set(arr)]
}
```

* Object

```JavaScript []
function unique (arr) {
	const h = Object.create(null)
	arr.forEach(v => h[v] = 1)
	return Object.keys(h).map(v => v | 0)
}
```

* Map

```JavaScript []
function unique (arr) {
	const h = new Map
	arr.forEach(v => h.set(v, 1))
	return Array.from(h.keys())
}
```

* for 循环 + splice

```JavaScript []
function unique (arr) {
	for (let i = 0; i < arr.length; i++) {
		for (let j = i + 1; j < arr.length; j++) {
			if (arr[i] === arr[j]) {
				arr.splice(j, 1)
				j--
			}
		}
	}
	return arr
}
```

* Sort 排序 + 相邻相同 splice

```JavaScript []
function unique (arr) {
	arr.sort()
	for (let i = 0; i < arr.length - 1; i++) {
		if (arr[i] === arr[i + 1]) {
			arr.splice(i, 1)
			i--
		}
	}
	return arr
}
```

* filter + indexOf

```JavaScript []
function unique (arr) {
	return arr.filter((v, index, ar) => ar.indexOf(v) === index)
}
```

* filter + hasOwnproperty

```JavaScript []
function unique (arr) {
	const h = {} // 注意只有 {} 才有 hasOwnProperty
	return arr.filter(v => !h.hasOwnProperty(v) && (h[v] = 1))
}
```

* indexOf + 辅助数组
```JavaScript []
function unique (arr) {
	const r = []
 	arr.forEach(v => r.indexOf(v) === -1 && r.push(v)) 
 	return r
}
```

* includes + 辅助数组

```JavaScript []
function unique (arr) {
	const r = []
	arr.forEach(v => !r.includes(v) && r.push(v))
	return r
}function unique (arr) {
	const r = []
	arr.forEach(v => !r.includes(v) && r.push(v))
	return r
}
```

### 判断一个对象是不是数组 Array
* isPrototypeOf
    * 测试一个对象是否在另一个对象的原型链上
    * prototype 不可省略

```JavaScript []
 function isArray(o) {
	return Array.prototype.isPrototypeOf(o)
}
```

* instanceof
    * 用于检测构造函数的 prototype 属性是否出现在某个实例对象的原型链上

```JavaScript []
function isArray(o) {
	return o instanceof Array
}
```

* Array.isArray
    * 用于确定传递的值是否是一个 Array

```JavaScript []
function isArray(o) {
	return Array.isArray(o)
}    * 
```

* Object.prototype.toString
    * 方法返回一个表示对象的字符串

```JavaScript []
function isArray(o) {
  return Object.prototype.toString.call(o) === '[object Array]'
}
```

### 移动零
## 问题

给定一个数组 nums，编写一个函数所有 0 移动到数组的末尾，同时保持非零元素的相对顺序

**示例**：

```plain
输入：[0, 1, 0, 3, 12]
输出：[1, 3, 12, 0, 0]
```

**说明**：
（1）必须在原数组上操作，不能拷贝额外的数组

（2）尽量减少操作次数

## 解析

**(1) 辅助数组**

```JavaScript []
const moveZeros = a => {
	const tmp = new Uint32Array(a.length)
	for (let i = 0, j = 0; i < a.length; i++) if (a[i]) tmp[j++] = a[i]
	return tmp
}
```

**(2) 双指针交换**

```JavaScript []
const moveZeros = a => {
	let i = j = -1
	while (++i < a.length) if (a[i]) a[++j] = a[i]
	while (++j < a.length) a[j] = 0
	return a
}
```

**(3) Sort 排序**

```JavaScript []
const moveZeros = a => a.sort((a, b) => -(b === 0 ^ 0))
```

### 空间复杂度为 O(1) 的中序遍历（莫里斯）遍历
```JavaScript []
const isValidBST = (root, l = -Infinity) {
  while(root) {
    if (root.left) {
      const p = root.left
      while (p.right && p.right !== root) p = p.right
      if (p.right === null) p.right = root, root = root.left
      else {
        root = root.right
      p.right= null
}
    } else {
      root= root.right
    }
  }
}
```


## 递归


### 求最大公约数
## 辗转相除法 （又称 欧几里得算法）
* 递归

```JavaScript []
function gcd(a, b) {
	const t = a % b
	if (t === 0) return b
	return gcd(b, t)
}
```

* 迭代

```JavaScript []
function gcd(a, b) {
	let t
	while (t = a % b) {
		a = b
		b = t
	}
	return b
}
```

## 更相减损法（又称 九章算术）
* 递归

```JavaScript []
function gcd(a, b) {
	if (a === b) return b
	a > b ? a -= b : b -= a
	return gcd(a, b)
}
```


## 排序


### 插入排序
```JavaScript []
const sort = a => {
	for (let i = 1; i < a.length; i++)
	for (let j = i; j-- && a[j + 1] < a[j];)
	[a[j + 1], a[j]] = [a[j], a[j + 1]]
	return a
}
```

### 快速排序
```JavaScript []
const sort = (a, s = 0, e = a.length - 1) => {
	if (s >= e) return
	let l = s, r = e
	while (l < r) {
		while (l < r && a[r] >= a[s]) r--
		while (l < r && a[l] <= a[s]) l++
		[a[l], a[r]] = [a[r], a[l]]
	}
	[a[l], a[s]] = [a[s], a[l]]
	sort(a, s, l - 1)
	sort(a, l + 1, e)
	return a
}
```

### 归并排序
```JavaScript []
const sort = (a, l = 0, r = a.length - 1) => {
	if (l === r) return 
	const m = l + r >>> 1, t = []
	sort(a, l, m)
	sort(a, m + 1, r)
	let p1 = l, p2 = m + 1, i = 0
	while (p1 <= m || p2 <= r) t[i++] = p2 > r || p1 <= m && a[p1] < a[p2] ? a[p1++] : a[p2++]
	for (i = 0; i < t.length; i++) a[l + i] = t[i]
	return a
}
```

### 冒泡排序
```JavaScript []
const sort = (a) => {
	for(let i = 0; i < a.length - 1; i++)
	for (let j = 0; j < a.length - 1 - i; j++)
	if (a[j] > a[j + 1])[a[j], a[j + 1]] = [a[j + 1], a[j]]
	return a
}
```



# 阶段测Ⅲ
本章阶段测针对全站这一章的知识点进行测试。

## 简答题
<!DOCTYPE html>
<html>
<head>
<style>
label:hover   {color: #3172cc;}
.nav-con{display: none;}
.nav-box{display: none;}
.nav-con:checked ~ .nav-box{display: block;}
.nav-btn{font-size:16px; font-weight: bold;}
</style>
</head>
<body>

<p>1. 对比持续通信的方法有哪些？</p>
<label for="control1" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control1" class="nav-con">
    <p class="nav-box">  
	轮询、长连接、长轮询、Flash Socket、WebSocket
    </p>
</div>

<p>2. 简述一下第三次握手。
</p>
<label for="control2" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control2" class="nav-con">
    <p class="nav-box">  
	• 客户端接收应答报文 <br>
		○ 客户端发送确认报文 <br>
		○ 客户端 ESTABLISHED <br>
	• 服务端接收确认报文 <br>
		○ 服务端 ESTABLISHED
    </p>
</div>

<p>3. 为什么要三次握手？</p>
<label for="control3" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control3" class="nav-con">
    <p class="nav-box">  
	• 客户端首次发送请求无应答，TCP 启动超时重传 <br>
	• 服务器收到重传的请求，建立连接，接收数据，关闭连接 <br>
	• 服务器收到客户端首次发送请求，再次建立连接，但客户端已经关闭连接
    </p>
</div>

<p>4. docker 与虚拟机中，秒级启动的是？</p>
<label for="control4" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control4" class="nav-con">
    <p class="nav-box">  
	Docker
    </p>
</div>

<p>5. 简述一下 HTTP 报文的组成</p>
<label for="control5" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control5" class="nav-con">
    <p class="nav-box">  
	• 起始行：报文描述 <br>
	• 头部：报文属性 <br>
	• 主体：报文数据
    </p>
</div>

<p>6. HTTP 报文的分为哪两类？</p>
<label for="control6" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control6" class="nav-con">
    <p class="nav-box">  
	请求报文：客户端到服务端发送请求<br>
	响应报文：服务端到客户端返回数据
    </p>
</div>

<p>7. Cookie 的生命周期一般为？</p>
<label for="control7" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control7" class="nav-con">
    <p class="nav-box">  
	expires 前有效，不设置 会话期间有效
    </p>
</div>

<p>8. 请列举出几个解决跨域的方法。</p>
<label for="control8" class="nav-btn">👉查看答案👈</label>
<div>
    <input type="checkbox" name="" id="control8" class="nav-con">
    <p class="nav-box">  
	jsonp：JSON with Padding、CORS：Cross-origin resource sharing 跨域资源共享、postMessage、Websocket
    </p>
</div>


</body>
</html>

## 选择题
x5g7mgx5zwpvx5s2ojx54petx51e9rx5yxxsx5yjhdx5c1fh

