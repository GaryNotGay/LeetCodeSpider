
# 概述
<p>之前，我们更多关注于二叉树。本 LeetBook 将会把你对二叉树的认知延伸到 N 叉树（N-ary Tree） 。<p>

<p>完成后，你将能够：
<ol>
<li> 理解 N 叉树的定义。</li>
<li> 了解 N 叉树不同的遍历方法。</li>
<li> 对于解决 N 叉树类型问题有基本的概念。</li>
</ol>
<p>

# 遍历
<p>在进行本章的学习之前，让我们先介绍一下 N 叉树的定义。</p>
<p>二叉树是一棵以根节点开始，每个节点含有不超过 2 个子节点的树。让我们将这个定义扩展到 <code>N 叉树</code> 。 一棵以根节点开始，每个节点不超过 <code>N</code> 个子节点的树，称为 <code>N叉树</code> 。</p>

<p>以下是三叉树的一个例子：</p>

<p><center><img src="https://s3-us-west-1.amazonaws.com/s3-lc-upload/explore/cards/n-ary-tree/nary_tree_example.png" width="210" /></center></p>

<br />
<p><code>前缀树</code> ，又称 <code>字典树</code>（Trie）， 就是一个常用的 N 叉树。</p>

<p>并且二叉树是 N 叉树的一种特殊表示形式。在接下来的章节中，我们将把你所掌握的与二叉树相关的知识全部拓展到 N 叉树中。</p>

## N 叉树的遍历
<h3>树的遍历</h3>

<hr />
<p>一棵二叉树可以按照前序、中序、后序或者层序来进行遍历。在这些遍历方法中，前序遍历、后序遍历和层序遍历同样可以运用到 N 叉树中。</p>

<blockquote>
<p>回顾 - 二叉树的遍历</p>

<ol>
	<li>前序遍历 - 首先访问根节点，然后遍历左子树，最后遍历右子树；</li>
	<li>中序遍历 - 首先遍历左子树，然后访问根节点，最后遍历右子树；</li>
	<li>后序遍历 - 首先遍历左子树，然后遍历右子树，最后访问根节点；</li>
	<li>层序遍历 - 按照从左到右的顺序，逐层遍历各个节点。</li>
</ol>
</blockquote>

<p>请注意，N 叉树的中序遍历没有标准定义，中序遍历只有在二叉树中有明确的定义。尽管我们可以通过几种不同的方法来定义 N 叉树的中序遍历，但是这些描述都不是特别贴切，并且在实践中也不常用到，所以我们暂且跳过 N 叉树中序遍历的部分。</p>

<p>把上述关于二叉树遍历转换为 N 叉树遍历，我们只需把如下表述:</p>

<blockquote>
<p>遍历左子树... 遍历右子树...&nbsp;</p>
</blockquote>

<p>变为:</p>

<blockquote>
<p>对于每个子节点:<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;通过递归地调用遍历函数来遍历以该子节点为根的子树</p>
</blockquote>

<p>我们假设 for 循环将会按照各个节点在数据结构中的顺序进行遍历：通常按照从左到右的顺序，如下所示。</p>

<p>&nbsp;</p>

<h3>N 叉树遍历示例</h3>

<hr />
<p>我们用如图所示的三叉树来举例说明:</p>

<center><img src="https://s3-us-west-1.amazonaws.com/s3-lc-upload/explore/cards/n-ary-tree/nary_tree_example.png" width="280" /></center>

<p>&nbsp;</p>

<h4>1. 前序遍历</h4>

<p>在 N 叉树中，前序遍历指先访问根节点，然后逐个遍历以其子节点为根的子树。<br />
例如，上述三叉树的前序遍历是：A-&gt;B-&gt;C-&gt;E-&gt;F-&gt;D-&gt;G.</p>

<h4>2. 后序遍历</h4>

<p>在 N 叉树中，后序遍历指前先逐个遍历以根节点的子节点为根的子树，最后访问根节点。<br />
例如，上述三叉树的后序遍历是：B-&gt;E-&gt;F-&gt;C-&gt;G-&gt;D-&gt;A.</p>

<h4>3. 层序遍历</h4>

<p>N 叉树的层序遍历与二叉树的一致。通常，当我们在树中进行广度优先搜索时，我们将按层序的顺序进行遍历。<br />
例如，上述三叉树的层序遍历是：A-&gt;B-&gt;C-&gt;D-&gt;E-&gt;F-&gt;G.</p>

<p>&nbsp;</p>

<h3>练习</h3>

<hr />
<p>接下来，我们将为你提供几道与 N 叉树相关的习题。</p>

## N 叉树的前序遍历

>https://leetcode.cn/problems/n-ary-tree-preorder-traversal/
<p>给定一个 n&nbsp;叉树的根节点 <meta charset="UTF-8" />&nbsp;<code>root</code>&nbsp;，返回 <em>其节点值的<strong> 前序遍历</strong></em> 。</p>

<p>n 叉树 在输入中按层序遍历进行序列化表示，每组子节点由空值 <code>null</code> 分隔（请参见示例）。</p>

<p><br />
<strong>示例 1：</strong></p>

<p><img src="https://assets.leetcode.com/uploads/2018/10/12/narytreeexample.png" style="height: 193px; width: 300px;" /></p>

<pre>
<strong>输入：</strong>root = [1,null,3,2,4,null,5,6]
<strong>输出：</strong>[1,3,5,6,2,4]
</pre>

<p><strong>示例 2：</strong></p>

<p><img alt="" src="https://assets.leetcode.com/uploads/2019/11/08/sample_4_964.png" style="height: 272px; width: 300px;" /></p>

<pre>
<strong>输入：</strong>root = [1,null,2,3,4,5,null,null,6,7,null,8,null,9,10,null,null,11,null,12,null,13,null,null,14]
<strong>输出：</strong>[1,2,3,6,7,11,14,4,8,12,5,9,13,10]
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li>节点总数在范围<meta charset="UTF-8" />&nbsp;<code>[0, 10<sup>4</sup>]</code>内</li>
	<li><code>0 &lt;= Node.val &lt;= 10<sup>4</sup></code></li>
	<li>n 叉树的高度小于或等于 <code>1000</code></li>
</ul>

<p>&nbsp;</p>

<p><strong>进阶：</strong>递归法很简单，你可以使用迭代法完成此题吗?</p>


## N 叉树的后序遍历

>https://leetcode.cn/problems/n-ary-tree-postorder-traversal/
<p>给定一个 n&nbsp;叉树的根节点<meta charset="UTF-8" />&nbsp;<code>root</code>&nbsp;，返回 <em>其节点值的<strong> 后序遍历</strong></em> 。</p>

<p>n 叉树 在输入中按层序遍历进行序列化表示，每组子节点由空值 <code>null</code> 分隔（请参见示例）。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<p><img src="https://assets.leetcode.com/uploads/2018/10/12/narytreeexample.png" style="height: 193px; width: 300px;" /></p>

<pre>
<strong>输入：</strong>root = [1,null,3,2,4,null,5,6]
<strong>输出：</strong>[5,6,3,2,4,1]
</pre>

<p><strong>示例 2：</strong></p>

<p><img alt="" src="https://assets.leetcode.com/uploads/2019/11/08/sample_4_964.png" style="height: 269px; width: 296px;" /></p>

<pre>
<strong>输入：</strong>root = [1,null,2,3,4,5,null,null,6,7,null,8,null,9,10,null,null,11,null,12,null,13,null,null,14]
<strong>输出：</strong>[2,6,14,11,7,3,12,8,4,13,9,10,5,1]
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li>节点总数在范围 <code>[0, 10<sup>4</sup>]</code> 内</li>
	<li><code>0 &lt;= Node.val &lt;= 10<sup>4</sup></code></li>
	<li>n 叉树的高度小于或等于 <code>1000</code></li>
</ul>

<p>&nbsp;</p>

<p><strong>进阶：</strong>递归法很简单，你可以使用迭代法完成此题吗?</p>


## N 叉树的层序遍历

>https://leetcode.cn/problems/n-ary-tree-level-order-traversal/
<p>给定一个 N 叉树，返回其节点值的<em>层序遍历</em>。（即从左到右，逐层遍历）。</p>

<p>树的序列化输入是用层序遍历，每组子节点都由 null 值分隔（参见示例）。</p>

<p> </p>

<p><strong>示例 1：</strong></p>

<p><img src="https://assets.leetcode.com/uploads/2018/10/12/narytreeexample.png" style="width: 100%; max-width: 300px;" /></p>

<pre>
<strong>输入：</strong>root = [1,null,3,2,4,null,5,6]
<strong>输出：</strong>[[1],[3,2,4],[5,6]]
</pre>

<p><strong>示例 2：</strong></p>

<p><img alt="" src="https://assets.leetcode.com/uploads/2019/11/08/sample_4_964.png" style="width: 296px; height: 241px;" /></p>

<pre>
<strong>输入：</strong>root = [1,null,2,3,4,5,null,null,6,7,null,8,null,9,10,null,null,11,null,12,null,13,null,null,14]
<strong>输出：</strong>[[1],[2,3,4,5],[6,7,8,9,10],[11,12,13],[14]]
</pre>

<p> </p>

<p><strong>提示：</strong></p>

<ul>
	<li>树的高度不会超过 <code>1000</code></li>
	<li>树的节点总数在 <code>[0, 10^4]</code> 之间</li>
</ul>



# 递归
从前有座山，山上有座庙，庙里有个老和尚和一个小和尚，有一天，老和尚对小和尚说：从前有座山，山上有座庙，庙里有个老和尚和一个小和尚，有一天，老和尚对小和尚说：从前有座山，山上有座庙，庙里有个老和尚和一个小和尚，有一天，老和尚对小和尚说.......
<br><br><br>
<center>
<img src="https://s3-us-west-1.amazonaws.com/s3-lc-upload/explore/cards/n-ary-tree/siri.png" width="80%" />
</center><br>

## N 叉树的经典递归解法
<br/>
<h3>经典递归法</h3>
<hr/>
<p>我们在之前的章节中讲过如何运用递归法解决二叉树问题。在这篇文章中，我们着重介绍如何将这个思想引入到 N 叉树中。</p>

<blockquote>
<p>在阅读以下内容之前，请确保你已阅读过 <a href="https://leetcode-cn.com/leetbook/read/data-structure-binary-tree/xefb4e/ ">运用递归解决树的问题</a> 这篇文章。</p>
</blockquote>

<p>1. &quot;自顶向下&quot;的解决方案</p>

<blockquote>
<p>&quot;自顶向下&quot;意味着在每个递归层次上，我们首先访问节点以获得一些值，然后在调用递归函数时，将这些值传给其子节点。</p>
</blockquote>

<p>一个典型的 &quot;自顶向下&quot; 函数 <code>top_down(root, params)</code> 的工作原理如下：</p>

<pre>
1. 对于 null 节点返回一个特定值
2. 如果有需要，对当前答案 answer 进行更新                         // answer &lt;-- params
3. for each child node root.children[k]:
4.      ans[k] = top_down(root.children[k], new_params[k])  // new_params &lt;-- root.val, params
5. 如果有需要，返回答案 answer                                 // answer &lt;-- all ans[k]
</pre>

<p>2. &quot;自底向上&quot;的解决方案</p>

<blockquote>
<p>&quot;自底向上&quot; 意味着在每个递归层次上，我们首先为每个子节点递归地调用函数，然后根据返回值和根节点本身的值给出相应结果。</p>
</blockquote>

<p>一个典型的 &quot;自底向上&quot; 函数 <code>bottom_up(root)</code> 的工作原理如下：</p>

<pre>
1.对于 null 节点返回一个特定值
2.for each child node root.children[k]:
3.    ans[k] = bottom_up(root.children[k]) // 为每个子节点递归地调用函数
4. 返回答案 answer                          // answer &lt;- root.val, all ans[k]
</pre>

## N 叉树的最大深度

>https://leetcode.cn/problems/maximum-depth-of-n-ary-tree/
<p>给定一个 N 叉树，找到其最大深度。</p>

<p class="MachineTrans-lang-zh-CN">最大深度是指从根节点到最远叶子节点的最长路径上的节点总数。</p>

<p class="MachineTrans-lang-zh-CN">N 叉树输入按层序遍历序列化表示，每组子节点由空值分隔（请参见示例）。</p>

<p class="MachineTrans-lang-zh-CN"> </p>

<p><strong>示例 1：</strong></p>

<p><img src="https://assets.leetcode.com/uploads/2018/10/12/narytreeexample.png" style="width: 100%; max-width: 300px;" /></p>

<pre>
<strong>输入：</strong>root = [1,null,3,2,4,null,5,6]
<strong>输出：</strong>3
</pre>

<p><strong>示例 2：</strong></p>

<p><img alt="" src="https://assets.leetcode.com/uploads/2019/11/08/sample_4_964.png" style="width: 296px; height: 241px;" /></p>

<pre>
<strong>输入：</strong>root = [1,null,2,3,4,5,null,null,6,7,null,8,null,9,10,null,null,11,null,12,null,13,null,null,14]
<strong>输出：</strong>5
</pre>

<p> </p>

<p><strong>提示：</strong></p>

<ul>
	<li>树的深度不会超过 <code>1000</code> 。</li>
	<li>树的节点数目位于 <code>[0, 10<sup>4</sup>]</code> 之间。</li>
</ul>



# 小结
<p>本 LeetBook 旨在介绍 <code>N 叉树</code> 的基本思想。 实际上，<code>二叉树</code> 只是 <code>N 叉树</code> 的一种特殊形式，<code>N 叉树</code> 相关问题的解决方案与 <code>二叉树</code> 的解法十分相似。 因此，我们可以把在 <code>二叉树</code> 中学到的知识扩展到 N 叉树中。</p>

<p>我们提供了一些经典的 <code>N 叉树</code> 习题，以便进一步帮助你理解本章中 <code>N 叉树</code> 的概念。</p>
</div>

## 序列化和反序列化 N 叉树

>https://leetcode.cn/problems/serialize-and-deserialize-n-ary-tree/
<p>序列化是指将一个数据结构转化为位序列的过程，因此可以将其存储在文件中或内存缓冲区中，以便稍后在相同或不同的计算机环境中恢复结构。</p>

<p>设计一个序列化和反序列化 N 叉树的算法。一个 N 叉树是指每个节点都有不超过 N 个孩子节点的有根树。序列化 / 反序列化算法的算法实现没有限制。你只需要保证 N 叉树可以被序列化为一个字符串并且该字符串可以被反序列化成原树结构即可。</p>

<p>例如，你需要序列化下面的 <code>3-叉</code> 树。</p>

<p>&nbsp;</p>

<p><img src="https://assets.leetcode.com/uploads/2018/10/12/narytreeexample.png" style="height: 321px; width: 500px;" /></p>

<p>&nbsp;</p>

<p>为&nbsp;<code>[1 [3[5 6] 2 4]]</code>。你不需要以这种形式完成，你可以自己创造和实现不同的方法。</p>

<p>或者，您可以遵循 LeetCode 的层序遍历序列化格式，其中每组孩子节点由空值分隔。</p>

<p><img alt="" src="https://assets.leetcode.com/uploads/2019/11/08/sample_4_964.png" style="height: 454px; width: 500px;" /></p>

<p>例如，上面的树可以序列化为 <code>[1,null,2,3,4,5,null,null,6,7,null,8,null,9,10,null,null,11,null,12,null,13,null,null,14]</code></p>

<p>你不一定要遵循以上建议的格式，有很多不同的格式，所以请发挥创造力，想出不同的方法来完成本题。</p>

<p>&nbsp;</p>

<p><strong>示例 1:</strong></p>

<pre>
<strong>输入:</strong> root = [1,null,2,3,4,5,null,null,6,7,null,8,null,9,10,null,null,11,null,12,null,13,null,null,14]
<strong>输出:</strong> [1,null,2,3,4,5,null,null,6,7,null,8,null,9,10,null,null,11,null,12,null,13,null,null,14]
</pre>

<p><strong>示例 2:</strong></p>

<pre>
<strong>输入:</strong> root = [1,null,3,2,4,null,5,6]
<strong>输出:</strong> [1,null,3,2,4,null,5,6]
</pre>

<p><strong>示例 3:</strong></p>

<pre>
<strong>输入:</strong> root = []
<strong>输出:</strong> []
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li>树中节点数目的范围是 <code>[0,&nbsp;10<sup>4</sup>]</code>.</li>
	<li><code>0 &lt;= Node.val &lt;= 10<sup>4</sup></code></li>
	<li>N 叉树的高度小于等于 <code>1000</code></li>
	<li>不要使用类成员 / 全局变量 / 静态变量来存储状态。你的序列化和反序列化算法应是无状态的。</li>
</ul>


